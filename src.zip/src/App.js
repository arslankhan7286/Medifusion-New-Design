import React from 'react';
import './css/bootstrap.min.css'
import './css/style.css'

import Header from './components/Header'
import MainPage from './components/MainPage';
import  Login from './components/Login';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from './actions/selectTabAction';
import {loginAction} from './actions/LoginAction';




class  App extends React.Component {
  constructor(props){
    super(props);
    this.state={
      isLogin : false
    }
  }
  render(){
    return (
      <div >

        {this.props.loginObject.isLogin == false ? <Login ></Login>   : 
              <div>
                <Header></Header>
                <MainPage></MainPage>
              </div>
             
        }  
  
      </div>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from App Page" , state);
  return {
      selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
      selectedTabPage: state.selectedTabPage,
      selectedPopup: state.selectedPopup,
      id: state.selectedTab !== null ? state.selectedTab.id : 0,
      setupLeftMenu: state.leftNavigationMenus,
      loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false}
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction , loginAction }, dispatch);
}
export default connect(mapStateToProps, matchDispatchToProps)(App);
