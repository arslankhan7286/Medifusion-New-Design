import React, { Component } from 'react'

import $ from "jquery";

import Label from "./Label";
import Input from "./Input";

import axios from 'axios';

import Swal from 'sweetalert2'
import { Tabs, Tab } from 'react-tab-view';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'




export class NewPlanFollowupModal extends Component {
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/PlanFollowup/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };





        this.planFollowupModel = {
            reasonID: '',
            actionID: '',
            groupID: '',


            adjustmentCodeID: null,
            claimStatusCode: '',
            tickleDate: '',

            addedDate: '',
            age: '',

            payerName: '',
            payerID: '',
            receiver: '',
            telePhoneNumber: '',
            prTelephoneNumber: '',
            submitDate: '',
            dos: '',
            billedAmount: '',
            planBalance: '',




            practiceID: '',
            locationv: '',
            providerID: '',
            refProviderID: '',
            supProviderID: '',


            notes: "",

            planPayerName: '',


            patientId: '',
            patientName: '',
            accountNumber: '',
            dob: '',
            gender: '',


            posId: '',
            //  providerID: '',
            //  refProviderId: '',
            planName: '',
            insuredName: '',
            insuredID: 0,


        }
        this.validationModel = {
            valreasonID: '',
            valactionID: '',
            valgroupID: ''

        }

        this.state = {
            planFollowupModel: this.planFollowupModel,
            validationModel: this.validationModel,
            editId: this.props.id,
            data: [],
            id: 0,

            resData: [],
            remCodeData: [],
            grData: [],
            acData: [],
            adjData: [],
            locData: [],
            proData: [],
            refproData: [],
            supproData: [],
            pracData: [],

            patientInfoData: '',
            submissionData: '',

            isActive: true
        }


        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleCheck = this.handleCheck.bind(this);
        this.savePlanFollowupModel = this.savePlanFollowupModel.bind(this);
    }
    componentDidMount() {


        this.setModalMaxHeight($('.modal'));

        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);
        if (this.state.editId > 0) {

            axios.get(this.url + 'FindPlanFollowUp/' + this.state.editId , this.config)


                .then(response => {

                    this.setState({ planFollowupModel: response.data });
                    console.log(this.state.planFollowupModel)
                }).catch(error => {
                    console.log(error);
                });
        }
    }

    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find(".modal-content");
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
        var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight });
    }

    componentWillMount() {
        axios.get(this.url + 'GetProfiles/' + this.props.id  ,this.config)


            .then(response => {
                console.log(response)


                this.setState({
                    resData: response.data.reason,
                    grData: response.data.group,
                    acData: response.data.action,
                    remCodeData: response.data.adjusmentCode,

                    pracData: response.data.practice,

                    locData: response.data.location,
                    proData: response.data.provider,
                    refproData: response.data.refProvider,
                    supproData: response.data.supProvider,

                    patientInfoData: response.data.patientInfo,
                    submissionData: response.data.submissionInfo,

                })

            }).catch(error => {
                console.log(error);
            });
    }

    isNull(value) {
        if (value === '' || value === null || value === undefined)
            return true;
        else return false;
    }








    savePlanFollowupModel = (e) => {
        console.log(this.state.planFollowupModel)



        if (this.state.planFollowupModel.reasonID === 'Please Select') {

            Swal.fire(
                {
                    type: 'error',
                    text: 'Please Select the Reason',
                })
            return
        }
        else {
            axios.post(this.url + 'SavePlanFollowup', this.state.planFollowupModel , this.config)
                .then(response => {




                    this.setState({ planFollowupModel: response.data, editId: response.data.id });
                    Swal.fire(
                        'Record Saved Successfully',
                        '',
                        'success'
                    )
                    this.componentWillMount()
                }).catch(error => {
                    let errorsList = []
                    if (error.response !== null && error.response.data !== null) {
                        errorsList = error.response.data
                        console.log(errorsList)

                        Swal.fire({
                            type: 'error',
                            text: 'Please Select valid value',
                        })

                    } else {
                        console.log(error);
                        alert('Something went wrong. Plese check console.')
                    }
                });

            e.preventDefault();
        }





    }

    handleChange = event => {


        event.preventDefault();


        this.setState({
            planFollowupModel: {
                ...this.state.planFollowupModel,
                [event.target.name]: event.target.value
            }
        });
    };


    handleCheck() {
        console.log('handle check')
        this.setState({

            planFollowupModel: {
                ...this.state.planFollowupModel,
                isActive: !this.state.planFollowupModels.isActive
            }
        });
    }




    render() {

        const isActive = this.state.planFollowupModel.isActive;
        const headers = ['Details', 'Other 1', 'Other 2'];

        var addtickleDate = this.state.planFollowupModel.tickleDate ? this.state.planFollowupModel.tickleDate.slice(0, 10) : "";
        var statFY = this.state.planFollowupModel.addedDate ? this.state.planFollowupModel.addedDate.slice(0, 4) : "";
        var statFM = this.state.planFollowupModel.addedDate ? this.state.planFollowupModel.addedDate.slice(5, 7) : "";
        var statFD = this.state.planFollowupModel.addedDate ? this.state.planFollowupModel.addedDate.slice(8, 10) : "";

        return (

            <React.Fragment>
                <div id='myModal' className="modal fade bs-example-modal-new show" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div className="modal-dialog modal-lg">

                        <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>

                        <div className="modal-content" style={{ overflow: 'hidden' }}>




                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div className="mainTable fullWidthTable">
                                    <div className="row-form">

                                        <div className="mf-12">

                                            <Tabs headers={headers} style={{ cursor: "default" }}>
                                                <Tab>
                                                    <div style={{ marginTop: "20px" }}>
                                                        <div className="mainTable fullWidthTable wSpace" style={{ maxWidth: "100%" }}>
                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    {/* <Label name="Reason"> <span className="redlbl"> *</span></Label> */}

                                                                    <label>Reason <span className="redlbl"> *</span></label>

                                                                    <div className="selectBoxValidate">
                                                                        <select name="reasonID" id="reasonID"
                                                                            value={this.state.planFollowupModel.reasonID} onChange={this.handleChange}>
                                                                            {this.state.resData.map(s => (
                                                                                <option key={s.id} value={s.id}>
                                                                                    {s.description}
                                                                                </option>
                                                                            ))}
                                                                        </select>
                                                                    </div>

                                                                </div>
                                                                <div className="mf-4">
                                                                    {/* <Label name="Action"> <span className="redlbl"> *</span></Label> */}
                                                                    <label>Action <span className="redlbl"> *</span></label>

                                                                    <div className="selectBoxValidate">
                                                                        <select name="actionID" id="actionID"
                                                                            value={this.state.planFollowupModel.actionID} onChange={this.handleChange}>
                                                                            {this.state.acData.map(s => (
                                                                                <option key={s.id} value={s.id}>
                                                                                    {s.description}
                                                                                </option>
                                                                            ))}
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    {/* <Label name="Group"></Label> */}
                                                                    <label>Group <span className="redlbl"> *</span></label>

                                                                    <div className="selectBoxValidate">
                                                                        <select name="groupID" id="groupID"
                                                                            value={this.state.planFollowupModel.groupID} onChange={this.handleChange}>
                                                                            {this.state.grData.map(s => (
                                                                                <option key={s.id} value={s.id}>
                                                                                    {s.description}
                                                                                </option>
                                                                            ))}
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>


                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Adjusment Code"></Label>


                                                                    <div className="selectBoxValidate">
                                                                        <select name="adjustmentCodeID" id="adjustmentCodeID"
                                                                            value={this.state.planFollowupModel.adjustmentCodeID} onChange={this.handleChange}>
                                                                            {this.state.remCodeData.map(s => (
                                                                                <option key={s.id} value={s.id}>
                                                                                    {s.description}
                                                                                </option>
                                                                            ))}
                                                                        </select>
                                                                    </div>



                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Claim Status Code"></Label>

                                                                    <Input type="text" value={this.state.planFollowupModel.claimStatusCode} name="claimStatusCode" id="claimStatusCode" onChange={() => this.handleChange}></Input>

                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Tickle Date"></Label>

                                                                    <div className="textBoxValidate">
                                                                        <input
                                                                            style={{
                                                                                width: "215px",
                                                                                marginLeft: "0px"
                                                                            }}
                                                                            className="myInput"
                                                                            type="date"
                                                                            name="tickleDate"
                                                                            id="tickleDate"
                                                                            value={addtickleDate}
                                                                            onChange={this.handleChange}
                                                                        ></input>
                                                                    </div>

                                                                </div>
                                                            </div>



                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Follow up Date"></Label>


                                                                    <div className="textBoxValidate">

                                                                        <Input type="text" disabled="disabled" value={statFM + '/' + statFD + '/' + statFY} name="addedDate" id="addedDate" onChange={() => this.handleChange}></Input>

                                                                    </div>

                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Follow up Age "></Label>

                                                                    <Input readOnly type="text" value={this.state.planFollowupModel.age} name="age" id="age" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                <Label name="Visit #"></Label>

<Input type="text" value={this.state.planFollowupModel.visitID} name="visitID" id="visitID" onChange={() => this.handleChange}></Input>


                                                                </div>
                                                            </div>


                                                            <div className="row-form">
                                                                <div className="mf-12 field_full-12">
                                                                    <label>Notes:</label>
                                                                    <textarea
                                                                        name="notes"
                                                                        id="notes"
                                                                        cols="30"
                                                                        rows="10"
                                                                        value={this.state.planFollowupModel.notes}
                                                                        onChange={this.handleChange}
                                                                    ></textarea>
                                                                </div>
                                                            </div>

                                                            <div className="headingOne mt-25">
                                                                <p>Submission Info</p>
                                                            </div>


                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Payer Name"></Label>

                                                                    <Input disabled type="text" value={this.state.submissionData.payerName} name="payerName" id="payerName" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Payer ID"></Label>

                                                                    <Input disabled="disabled" type="text" value={this.state.submissionData.payerID} name="payerID" id="payerID" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Receiver"></Label>

                                                                    <Input disabled="disabled" type="text" value={this.state.submissionData.receiver} name="receiver" id="receiver" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                            </div>
                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Telephone#"></Label>

                                                                    <Input disabled="disabled" type="text" value={this.state.submissionData.telePhoneNumber} name="telePhoneNumber" id="telePhoneNumber" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="PR. Telephone#"></Label>

                                                                    <Input disabled="disabled" type="text" value={this.state.submissionData.prTelephoneNumber} name="prTelephoneNumber" id="prTelephoneNumber" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Submit Date"></Label>

                                                                    <div className="textBoxValidate">
                                                                        <Input disabled="disabled" type="text" value={this.state.submissionData.submitDate} name="submitDate" id="submitDate" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="DOS"></Label>

                                                                    <div className="textBoxValidate">
                                                                        <Input disabled="disabled" type="text" value={this.state.submissionData.dos} name="dos" id="dos" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Billed Amount "></Label>

                                                                    <Input disabled="disabled" type="text" value={this.state.submissionData.billedAmount} name="billedAmount" id="billedAmount" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Plan Balance"></Label>

                                                                    <Input disabled="disabled" type="text" value={this.state.submissionData.planBalance} name="planBalance" id="planBalance" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                            </div>
                                                            <div className="headingOne mt-25">
                                                                <p>Legal Entities</p>
                                                            </div>

                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Practice"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientInfoData.practiceName} name="practiceName" id="practiceName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Location"></Label>

                                                                    <div className="textBoxValidate">
                                                                        <Input disabled="disabled" type="text" value={this.state.patientInfoData.locationName} name="locationName" id="locationName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Provider"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientInfoData.providerName} name="providerName" id="providerName" onChange={() => this.handleChange}></Input>


                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Ref. Provider"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientInfoData.refProviderName} name="refProviderName" id="refProviderName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Sup. Provider "></Label>

                                                                    <div className="textBoxValidate">


                                                                        <Input disabled="disabled" type="text" value={this.state.patientInfoData.supProviderName} name="supProviderName" id="supProviderName" onChange={() => this.handleChange}></Input>


                                                                    </div>



                                                                </div>
                                                                <div className="mf-4">
                                                                    &nbsp;
                                                                </div>
                                                            </div>
                                                            <div className="headingOne mt-25">
                                                                <p>Patient Detail</p>
                                                            </div>

                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Account #"></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientInfoData.accountNumber} name="accountNumber" id="accountNumber" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Patient name"></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientInfoData.patientName} name="patientName" id="patientName" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="DOB"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input type="text" disabled="disabled" value={this.state.patientInfoData.dob} name="dob" id="dob" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Plan Name"></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientInfoData.planName} name="planName" id="planName" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Insured Name"></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientInfoData.insuredName} name="insuredName" id="insuredName" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Insured ID "></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientInfoData.insuredID} name="insuredID" id="insuredID" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </Tab>
                                                <Tab>

                                                </Tab>
                                                <Tab>

                                                </Tab>
                                            </Tabs>


                                        </div>
                                    </div>



                                </div>
                                
                            <div className="modal-footer">
                                <div className="mainTable">
                                    <div className="row-form row-btn">
                                        <div className="mf-12">
                                            <button className="btn-blue" onClick={this.savePlanFollowupModel}>Save </button>
                                            <button id='btnCancel' className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>Cancel </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>

                        </div>

                    </div>

                </div>


            </React.Fragment >
        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(NewPlanFollowupModal);
