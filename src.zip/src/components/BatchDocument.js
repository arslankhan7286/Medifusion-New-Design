import React, { Component } from 'react'

import BatchDocumentPopup from './BatchDocumentPopup'
import Label from "./Label";
import Input from "./Input";
import GifLoader from 'react-gif-loader';
import Eclips from '../images/loading_spinner.gif'
import $ from 'jquery';
import axios from 'axios';
import { MDBDataTable, MDBBtn } from 'mdbreact';
import GridHeading from './GridHeading';
import SearchHeading from "./SearchHeading";


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


export class BatchDocument extends Component {
    constructor(props) {
        super(props)
        this.url = 'http://192.168.110.44/Database/api/BatchDocument/';

         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        this.searchModel = {
            "batchNumber": "",
            "description": "",
            "biller": "",
            "category": "",
            "status": "",
            "chargeBatchDetail": "",
            "admitBatchDetail": "",
            "paymentBatchDetail": "",
            //  "facilityID": null 
            //that why clear s not working also on facilityID
        }


        this.state = {
            searchModel: this.searchModel,

            id: 0,
            data: [],
            showPopup: false,

            facData: [],
            cateData: [],
            billData: [],

            showPopup: false,
            loading:false

        }
        this.openBatchPopup = this.openBatchPopup.bind(this);
        this.closePopup = this.closePopup.bind(this);


    }
    componentWillMount() {
        axios.get(this.url + 'GetProfiles' , this.config)
            .then(response => {

                this.setState({
                    billData: response.data.biller,
                    cateData: response.data.category,
                    facData: response.data.practice
                })

                console.log(response.data);
            }).catch(error => {
                console.log(error);
            });
    }

    closePopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
    }


    handleChange = event => {
        console.log(event.target.value);
        this.setState({
            searchModel: { [event.target.name]: event.target.value }
        });
    };


    openBatchPopup = (id) => {
        this.setState({ showPopup: true, id: id });
    }

    clearFields = event => {
        this.setState({
            searchModel: this.searchModel
        });
    };

    searchBatchDocuments = (e) => {

        this.setState({loading:true})

        e.preventDefault()
        console.log(this.state)
        axios.post(this.url + 'FindBatchDocument', this.state.searchModel , this.config)
            .then(response => {

                let newList = []
                response.data.map((row, i) => {
                    console.log(row)
                    newList.push({
                        id: row.id,

                        batchNumber: <MDBBtn className='gridBlueBtn' onClick={() => this.openBatchPopup(row.batchNumber)}>{row.batchNumber}</MDBBtn>,
                        description: row.description,
                        biller: row.biller,
                        category: row.category,
                        status: row.status,
                        chargeBatchDetail: row.chargeBatchDetail,
                        admitBatchDetail: row.admitBatchDetail,
                        paymentBatchDetail: row.paymentBatchDetail


                    });
                });

                this.setState({ data: newList , loading:false });

            }).catch(error => {
                this.setState({loading:false})
                console.log(error)
            });

        e.preventDefault();
    }



    render() {



        const data = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 150
                }
                ,
                {
                    label: "BATCH #",
                    field: "batchNumber",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "DESCRIPTION",
                    field: "description",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "BILLER",
                    field: "biller",
                    sort: "asc",
                    width: 150
                }, {
                    label: "CATEGORY",
                    field: "category",
                    sort: "asc",
                    width: 150
                }
                ,
                {
                    label: "STATUS",
                    field: "status",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "CHARGE BATCH DETAIL ",
                    field: "chargeBatchDetail",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "ADMIT BATCH DETAIL ",
                    field: "admitBatchDetail",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PAYMENT BATCH DETAIL ",
                    field: "paymentBatchDetail",
                    sort: "asc",
                    width: 150
                }
            ],
            rows: this.state.data
        };



        const statusID = [

            { value: "", display: "All" },
            { value: "O", display: "Open" },
            { value: "C", display: "Closed" },
            { value: "I", display: "In process" },
            { value: "Q", display: "Have Question" },

        ]



        let popup = ''

        if (this.state.showPopup) {
            popup = <BatchDocumentPopup onClose={() => this.closePopup} id={this.state.id}></BatchDocumentPopup>
        }
        else
            popup = <React.Fragment></React.Fragment>






            let spiner = ''
            if (this.state.loading == true) {
    
    
                spiner = (
                    <GifLoader
                        loading={true}
                        imageSrc={Eclips}
                        // imageStyle={imageStyle}
                        overlayBackground="rgba(0,0,0,0.5)"
                    />
                )
            }



        return (
            < React.Fragment >
            {spiner}

                <SearchHeading heading='BATCH DOCUMENTS SEARCH'
                    handler={() => this.openBatchPopup(0)}

                ></SearchHeading>




                <form onSubmit={event => this.searchBatchDocuments(event)}


                >
                    <div className="mainTable">

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Batch'></Label>
                                <Input type='text' name='batchNumber' id='batchNumber' value={this.state.searchModel.batchNumber}
                                    onChange={() => this.handleChange} />
                            </div>


                            <div className="mf-6">
                                <Label name='description'></Label>
                                <Input type='text' name='description' id='description'
                                    value={this.state.searchModel.description} onChange={() => this.handleChange} />
                            </div>
                        </div>

                        <div className="row-form">
                            <div className="mf-6">

                                <label>Biller</label>
                                <select name="biller" id="biller"
                                    value={this.state.searchModel.biller} onChange={this.handleChange}>
                                    {this.state.billData.map(s => (
                                        <option key={s.id} value={s.id}>
                                            {s.description}
                                        </option>
                                    ))}
                                </select>

                            </div>
                            <div className="mf-6">
                                <label>Category</label>
                                <select name="category" id="category"
                                    value={this.state.searchModel.category} onChange={this.handleChange}>
                                    {this.state.cateData.map(s => (
                                        <option key={s.id} value={s.id}>
                                            {s.description}
                                        </option>
                                    ))}
                                </select>

                            </div>
                        </div>


                        <div className="row-form">
                            <div className="mf-6">
                                <label>Practice</label>
                                <select name="facilityID" id="facilityID"
                                    value={this.state.searchModel.facilityID} onChange={this.handleChange}>
                                    {this.state.facData.map(s => (
                                        <option key={s.id} value={s.id}>
                                            {s.description}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="mf-6">
                                <label>Status</label>
                                <select name="status" id="status"
                                    value={this.state.searchModel.status} onChange={this.handleChange}>
                                    {statusID.map(s => (
                                        <option key={s.value} value={s.value}>
                                            {s.display}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">
                                <Input type='submit' name='name' id='name' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>
                </form>

                <div className="mf-12 table-grid mt-15">
                    <GridHeading Heading='BATCH DOCUMENTS SEARCH RESULT'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            responsive={true}
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

                {popup}

            </React.Fragment >
        )
    }
}



function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(BatchDocument);
