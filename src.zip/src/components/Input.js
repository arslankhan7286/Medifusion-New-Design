import React, { Component } from 'react'

export class Input extends Component {


    // handleNumericCheck(event) {

    //     if (!this.props.max) {
    //         return true
    //     }

    //     if (
    //         event.charCode >= 48 && event.charCode <= 57 &&
    //         this.state.npi.length < 10
    //     ) {
    //         return true;
    //     } else {
    //         event.preventDefault();
    //         return false;
    //     }
    // }

    render() {

        let control = ''
        if (this.props.type === 'text')
            control = <input value={this.props.value} type={this.props.type} name={this.props.name} id={this.props.id} className={this.props.className}
                onChange={this.props.onChange()} autoComplete='off' maxLength={this.props.max} disabled={this.props.disabled}
                readOnly={this.props.readOnly}
                onKeyPress={(this.props.onKeyPress)}
            ></input>;
        else if (this.props.type === 'number')
            control = <input value={this.props.value} type={this.props.type} name={this.props.name} id={this.props.id} className={this.props.className}
                onChange={this.props.onChange()} max={this.props.max} onKeyPress={this.props.onKeyPress}></input>;
        else if (this.props.type === 'submit')
            control = <input value={this.props.value} type={this.props.type} name={this.props.name} id={this.props.id} className={this.props.className} />;
        else if (this.props.type === 'button')
            control = <input value={this.props.value} type={this.props.type} name={this.props.name} id={this.props.id} className={this.props.className} onClick={this.props.onClick} />;
        else if (this.props.type === 'checkbox')
            control = <input type={this.props.type} name={this.props.name} id={this.props.id} className={this.props.className}
                onChange={this.props.onChange()} ></input>;
        return (
            control
        )
    }
}

// export default Input


// function Input(props) {

//     return (
//         control
//     )
// }

//  {this.props.text} 
export default Input
