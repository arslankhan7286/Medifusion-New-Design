import React, { Component } from 'react'



import SearchHeading from './SearchHeading'
import Label from './Label'
import Button from './Input'
import Input from './Input'
import SearchInput2 from './SearchInput2'

import axios from 'axios';
import { MDBDataTable, MDBBtn, MDBTableHead, MDBTableBody, MDBTable } from 'mdbreact';

import GridHeading from './GridHeading';
import NewClient from './NewClient'

import searchIcon from '../images/search-icon.png'
import refreshIcon from '../images/refresh-icon.png'
import newBtnIcon from '../images/new-page-icon.png'
import settingsIcon from '../images/setting-icon.png'

import ReactDataGrid from 'react-data-grid';


import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import $ from 'jquery';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


class Client extends Component {


    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/client/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };


        this.searchModel = {
            name : '',
            organizationName : '',
            serviceLocation  : '',
            taxID : '',
            address : '',
            officePhoneNo : '',
        }

        this.state = {
            searchModel: this.searchModel,
            id: 0,
            data: [],
            showPopup: false,
            loading : false
        }

        this.searchClient = this.searchClient.bind(this);
        this.closePracticePopup = this.closePracticePopup.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.openClientPopup = this.openClientPopup.bind(this);

    }

    searchClient = (e) => {
        this.setState({loading:true})
                console.log(this.state.searchModel);
                axios.post(this.url + 'FindClients', this.state.searchModel , this.config)
                    .then(response => {

                        let newList = []
                        response.data.map((row, i) => {
                            console.log(row)
                            newList.push({
                                id: row.id,
                                name: <MDBBtn className='gridBlueBtn' onClick={() => this.openClientPopup(row.id)}>{row.name}</MDBBtn>,
                                organizationName: row.organizationName,
                                contactPerson : row.contactPerson,
                                taxID: row.taxID,
                                address: row.address,
                                officePhoneNum: row.officePhoneNum
                            });
                        });

                        this.setState({ data: newList ,loading:false});
                    }).catch(error => {
                        this.setState({loading:false})
                        console.log(error);
                    });

        e.preventDefault();
    }

    handleChange = event => {
        event.preventDefault();
        this.setState({
            searchModel: { ...this.state.searchModel, [event.target.name]: event.target.value.toUpperCase() }
        });
    };

    clearFields = event => {
        this.setState({
            searchModel: this.searchModel
        });
    };

    openClientPopup = (id) => {
        this.setState({ showPopup: true, id: id });
    }


    closePracticePopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }

    render() {

        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 150,
                },
                {
                    label: 'NAME',
                    field: 'name',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'ORGANIZATION NAME',
                    field: 'organizationName',
                    sort: 'asc',
                    width: 270
                },
                {
                    label: 'CONTACT PERSON',
                    field: 'contactPerson',
                    sort: 'asc',
                    width: 200
                },
                {
                    label: 'TAX ID',
                    field: 'taxID',
                    sort: 'asc',
                    width: 100
                },
                {
                    label: 'ADDRESS',
                    field: 'address',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'OFFICE PHONE #',
                    field: 'officePhoneNum',
                    sort: 'asc',
                    width: 100
                }
            ],
            rows:
                this.state.data
        };


        let popup = '';
        if (this.state.showPopup) {
            popup = <NewClient onClose={() => this.closePracticePopup} id={this.state.id}></NewClient>
        }
        else
            popup = <React.Fragment></React.Fragment>

            let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }


        return (

            < React.Fragment >
                {spiner}
                <SearchHeading heading='CLIENT SEARCH' handler={() => this.openClientPopup(0)}></SearchHeading>

                <form onSubmit={this.searchClient}>
                    <div className="mainTable">

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Name'></Label>
                                <Input max="20" type='text' name='name' id='name' value={this.state.searchModel.name} onChange={() => this.handleChange} />
                            </div>


                            <div className="mf-6">
                                <Label name='Organization Name'></Label>
                                <Input type='text' name='organizationName' id='organizationName'
                                    max='30' value={this.state.searchModel.organizationName} onChange={() => this.handleChange} />
                            </div>
                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                            <Label name='Phone #'></Label>
                                <Input type='text' name='officePhoneNo' id='officePhoneNo' max='10' value={this.state.searchModel.officePhoneNo} onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)} />
                            </div>
                            <div className="mf-6">
                                <Label name='Tax ID'></Label>
                                <Input type='text' name='taxID' id='taxID' max='9' value={this.state.searchModel.taxID} onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)} />
                            </div>
                        </div>


                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Address'></Label>
                                <Input type='text' name='address' id='address' max='30' value={this.state.searchModel.address} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                               
                            </div>
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">
                                <Input type='submit' name='name' id='name' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>
                </form>

                <div className="mf-12 table-grid mt-15">
                    <GridHeading Heading='CIIENT SEARCH RESULT'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            responsive={true}
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

                {popup}

            </React.Fragment >
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(Client);