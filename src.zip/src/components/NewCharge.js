import React, { Component } from "react";
import { Tabs, Tab } from "react-tab-view";
import Select from "react-select";
import ReactTooltip from "react-tooltip";
import Swal from "sweetalert2";
import { MDBDataTable } from "mdbreact";
import $ from "jquery";
import axios from "axios";
import Input from "./Input";
import Label from "./Label";
import dob_icon from "../images/dob-icon.png";
import samll_doc_icon from "../images/dob-small-icon.png";
import { isNull, isNullOrUndefined } from "util";
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

// import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
// import Loader from 'react-loader-spinner'
import GPopup from './GPopup';

import { totalmem } from "os";
import SearchHeading from "./SearchHeading";
import searchIcon from "../images/search-icon.png";
import refreshIcon from "../images/refresh-icon.png";
import newBtnIcon from "../images/new-page-icon.png";
import settingsIcon from "../images/setting-icon.png";
import EditCharge from "./EditCharge";

import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";
import NewPOS from "./NewPOS";
import NewRefferingProvider from "./NewRefferingProvider";
import NewICD from "./NewICD";
import NewInsurancePlan from "./NewInsurancePlan";



//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


export class NewCharge extends Component {
  constructor(props) {
    super(props);

    this.errorField = "errorField";
    this.visitUrl = process.env.REACT_APP_URL + '/visit/';
    this.patientPlanUrl = process.env.REACT_APP_URL + '/patientPlan/';
    this.chargeUrl = process.env.REACT_APP_URL + '/charge/';
    
 //Authorization Token
 this.config = {
  headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
};


    let popupVisitId = 0;
    popupVisitId = this.props.popupVisitId;

    this.chargeValidationModel = {
      dosFromValField: "",
      dosToValField: "",
      cptCodeValField: "",
      pointer1ValField: "",
      unitsValField: "",
      amountValField: "",
      validation: false
    };
    this.validationModel = {
      posValField: "",
      descriptionValField: "",
      patientValField: "",
      practiceValField: "",
      locationValField: "",
      posValField: "",
      providerValField: "",
      cliaNumberValField:"",

      icd1ValField: "",
      icd2ValField: "",
      icd3ValField: "",
      icd4ValField: "",
      icd5ValField: "",
      icd6ValField: "",
      icd7ValField: "",
      icd8ValField: "",
      icd9ValField: "",
      icd10ValField: "",
      icd11ValField: "",
      icd12ValField: "",

      unableToWorkFromDateValField : "",
      dischargeDateValField :"",
      onSetDateOfSimiliarIllnessValField : ""
    };
    this.chargeModel = {
      visitID: 0,
      clientID: 1,

      // practiceID: "",
      // locationID: "",
      // posid: "",
      // providerID: "",
      // patientID: "",
      // primaryPatientPlanID: null,
      totalAmount: 0.0,
      isSubmitted: false,

      dateOfServiceFrom: "",
      dateOfServiceTo: "",

      cptid: null,
      cptObj: {},

      modifier1ID: null,
      modifier2ID: null,
      modifier3ID: null,
      modifier4ID: null,

      modifier1Obj: {},
      modifier2Obj: {},
      modifier3Obj: {},
      modifier4Obj: {},

      pointer1: "",
      pointer2: "",
      pointer3: "",
      pointer4: "",

      units: null,
      unitOfMeasurement: null,
      totalAmount: "",

      startDate: "",
      endDate: "",
      minutes: "",

      validationModel: this.validationModel,
      dosFromValField: "",
      dosToValField: "",
      cptCodeValField: "",
      modifierValField:"",
      pointer1ValField: "",
      unitsValField: "",
      amountValField: "",
      validation: false
    };
    this.visitModel = {
      patientID: "",
      patient: "",
      documentBatchID: null,
      batchNumber: "",
      pageNumber: "",
      clientID: 1,

      primaryPatientPlanID: null,
      secondaryPatientPlanID: null,
      tertiaryPatientPlanID: null,

      primaryBilledAmount :"",
      primaryAllowed :"",
      primaryWriteOff :"",
      primaryPaid :"",
      primaryPatResp :"",
      primaryBal :"",
      primaryTransferred :"",
      primaryStatus:"",

      // primaryBilledAmount: "",
      // primaryPlanAmount: "",
      // primaryPlanAllowed: "",
      // primaryPlanPaid: "",
      // primaryWriteOff: "",

      practiceID: null,
      locationID: null,
      posid: null,
      providerID: null,
      refProviderID: null,
      supervisingProvID: null,

      icD1ID: null,
      icD2ID: null,
      icD3ID: null,
      icD4ID: null,
      icD5ID: null,
      icD6ID: null,
      icD7ID: null,
      icD8ID: null,
      icD9ID: null,
      icD10ID: null,
      icD11ID: null,
      icD12ID: null,

      icd1Obj: {},
      icd2Obj: {},
      icd3Obj: {},
      icd4Obj: {},
      icd5Obj: {},
      icd6Obj: {},
      icd7Obj: {},
      icd8Obj: {},
      icd9Obj: {},
      icd10Obj: {},
      icd11Obj: {},
      icd12Obj: {},

      totalAmount: "",
      coPay: "",

      isSubmitted: false,
      submittedDate: "",
      submissionLogID: null,
      rejectionReason: "",

      authorizationNum: "",
      outsideReferral: false,
      referralNum: "",
      onsetDateOfIllness: "",
      firstDateOfSimiliarIllness: "",
      illnessTreatmentDate: "",
      dateOfPregnancy: "",
      admissionDate: "",
      dischargeDate: "",
      lastXrayDate: "",
      lastXrayType: "",
      unableToWorkFromDate: "",
      unableToWorkToDate: "",

      accidentDate: "",
      accidentType: "",
      accidentState: "",
      cliaNumber: "",
      outsideLab: false,
      labCharges: "",

      payerClaimControlNum: "",
      claimNotes: "",
      claimFrequencyCode: "",
      serviceAuthExcpCode: "",
      emergency: false,
      epsdt: false,
      familyPlan: false,

      charges: []

      //isActive: true
    };

    this.state = {
      chargeModel: this.chargeModel,
      visitModel: this.visitModel,
      validationModel: this.validationModel,
      chargeValidationModel: [],
      patientDropDown: [],
      patientPlanDropdown: [],
      chargeModelArray: [],
      practice: [],
      location: [],
      provider: [],
      refProvider: [],
      supProvider: [],
      pos: [],
      editId: popupVisitId > 0 ? this.props.popupVisitId :  this.props.id,
      popupPatientId:0,
      maxHeight: "361",
      activeItem: "1",
      diagnosisRow: false,
      cptRows: [],
      dob: "",
      gender: "",
      primaryPlanName: "",
      secondaryPlanName: "",
      tertiaryPlanName: "",
      showPopup: false,
      chargeId: 0,
      icd1 : "",
      ide2:"",
      icd3:"",
      icd4:"",

      modifierOptions: [],
      options: [],
      cptOptions: [],
      popupName: "",
      id:0,
      items: [],
      icdArr : [],
      loading : false
    };

    this.handleOutsideRefCheck = this.handleOutsideRefCheck.bind(this);
    this.saveCharge = this.saveCharge.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.addDiagnosisRow = this.addDiagnosisRow.bind(this);
    this.addCPTRow = this.addCPTRow.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
    this.handleOutsideLabCheck = this.handleOutsideLabCheck.bind(this);
    this.handleEmergencyCheck = this.handleEmergencyCheck.bind(this);
    this.handleEPSDTCheck = this.handleEPSDTCheck.bind(this);
    this.handleFamilyPlanCheck = this.handleFamilyPlanCheck.bind(this);
    this.handleChargeChange = this.handleChargeChange.bind(this);
    this.handlePatientDropDownChange = this.handlePatientDropDownChange.bind(this);
    this.setPatientetails = this.setPatientetails.bind(this);
    this.deleteCPTRow = this.deleteCPTRow.bind(this);
    this.deleteVisit = this.deleteVisit.bind(this);
    this.resubmitVisit = this.resubmitVisit.bind(this);

    this.openPopup = this.openPopup.bind(this);
    this.closePopup = this.closePopup.bind(this);

    this.handleNumericCheck = this.handleNumericCheck.bind(this);
    this.handleAmountChange = this.handleAmountChange.bind(this);
    this.handleCPTAmountChange = this.handleCPTAmountChange.bind(this);
    this.test = this.test.bind(this);
  }

//auto complete
filter(e){
  console.log("Event : " , e.target)
  this.setState({filter: e.target.value})
}

componentWillMount(){
  this.setState({popupVisitId : this.props.popupVisitId })
}

  async componentDidMount() {
    console.log("Edit Id : " , this.visitModel.id , this.config)
    await axios
      .get(this.visitUrl + "GetProfiles"  ,this.config)
      .then(response => {
        console.log("");
        this.setState({
          visitModel: {
            ...this.state.visitModel
          },
          practice: response.data.practice,
          location: response.data.location,
          provider: response.data.provider,
          refProvider: response.data.refProvider,
          supProvider: response.data.refProvider,
          pos: response.data.pos,
          patientDropDown: response.data.patientInfo,
          options: response.data.icd,
          modifierOptions: response.data.modifier,
          cptOptions: response.data.cpt,
          items : response.data.cpt
        });
      })
      .catch(error => {
        console.log(error);
      });

    if (this.state.editId > 0 || this.state.visitModel.id > 0) {
      this.setState({loading:true})
      var visitId = 0;
      if(this.state.visitModel.id > 0){
        visitId = this.state.visitModel.id ;
        console.log("Edit Id 1 : " , visitId)
      }else{
        visitId = this.state.editId ;
        console.log("Edit Id 2 : " , visitId)
      }
      await axios
        .get(this.visitUrl+"FindVisit/" +visitId
         , this.config)
        .then(response => {
          console.log("Visit Response : ", response.data);

          var patientInfo = this.state.patientDropDown.filter(
            patient => patient.patientID == response.data.patientID
          );
          this.setState({
            dob: patientInfo[0].dob,
            gender: patientInfo[0].gender
          });

          axios
            .get(
              "http://192.168.110.44/Database/api/patientPlan/GetpatientPlansByPatientID/" +
                response.data.patientID , this.config
            )
            .then(res => {
              this.setState({
                patientPlanDropdown: res.data
              });

              for (var i = 0; i < this.state.patientPlanDropdown.length; i++) {
                if (this.state.patientPlanDropdown[i].description == "P") {
                  this.setState({
                    primaryPlanName:
                      "Primary - " +
                      this.state.patientPlanDropdown[i].description2
                  });

                  break;
                } else {
                  this.setState({
                    primaryPlanName: "",
                    visitModel: {
                      ...this.state.visitModel,
                      primaryPatientPlanID: null
                    }
                  });
                }
              }
            });

          this.setState({ visitModel: response.data });
          this.setState({
            visitModel: {
              ...this.state.visitModel,
              icd1Obj: this.state.options.filter(
                option => option.id == response.data.icD1ID
              ),
              icd2Obj: this.state.options.filter(
                option => option.id == response.data.icD2ID
              ),
              icd3Obj: this.state.options.filter(
                option => option.id == response.data.icD3ID
              ),
              icd4Obj: this.state.options.filter(
                option => option.id == response.data.icD4ID
              ),
              icd5Obj: this.state.options.filter(
                option => option.id == response.data.icD5ID
              ),
              icd6Obj: this.state.options.filter(
                option => option.id == response.data.icD6ID
              ),
              icd7Obj: this.state.options.filter(
                option => option.id == response.data.icD7ID
              ),
              icd8Obj: this.state.options.filter(
                option => option.id == response.data.icD8ID
              ),
              icd9Obj: this.state.options.filter(
                option => option.id == response.data.icD9ID
              ),
              icd10Obj: this.state.options.filter(
                option => option.id == response.data.icD10ID
              ),
              icd11Obj: this.state.options.filter(
                option => option.id == response.data.icD11ID
              ),
              icd12Obj: this.state.options.filter(
                option => option.id == response.data.icD12ID
              )
            }
          });

          var ICdArr = [...this.state.icdArr];
          response.data.icD1ID != null ?  ICdArr = ICdArr.concat(response.data.icD1ID): ICdArr.concat(0);
          response.data.icD2ID != null ?  ICdArr = ICdArr.concat(response.data.icD2ID): ICdArr.concat(0);
          response.data.icD3ID != null ?  ICdArr = ICdArr.concat(response.data.icD3ID): ICdArr.concat(0);
          response.data.icD4ID != null ?  ICdArr = ICdArr.concat(response.data.icD4ID): ICdArr.concat(0);
          response.data.icD5ID != null ?  ICdArr = ICdArr.concat(response.data.icD5ID): ICdArr.concat(0);
          response.data.icD6ID != null ?  ICdArr = ICdArr.concat(response.data.icD6ID): ICdArr.concat(0);
          response.data.icD7ID != null ?  ICdArr = ICdArr.concat(response.data.icD7ID): ICdArr.concat(0);
          response.data.icD8ID != null ?  ICdArr = ICdArr.concat(response.data.icD8ID): ICdArr.concat(0);
          response.data.icD9ID != null ?  ICdArr = ICdArr.concat(response.data.icD9ID): ICdArr.concat(0);
          response.data.icD10ID != null ? ICdArr = ICdArr.concat(response.data.icD10ID): ICdArr.concat(0);
          response.data.icD11ID != null ? ICdArr = ICdArr.concat(response.data.icD11ID): ICdArr.concat(0);
          response.data.icD12ID != null ? ICdArr = ICdArr.concat(response.data.icD12ID): ICdArr.concat(0);

          this.setState({icdArr : ICdArr})

          
          this.state.visitModel.charges.map((charge, index) => {
            var cpt = {};
            cpt = this.state.cptOptions.filter(
              option => option.id == charge.cptid
            );
            var modifier1 = {};
            modifier1 = this.state.modifierOptions.filter(
              option => option.id == charge.modifier1ID
            );
            var modifier2 = {};
            modifier2 = this.state.modifierOptions.filter(
              option => option.id == charge.modifier2ID
            );
            var modifier3 = {};
            modifier3 = this.state.modifierOptions.filter(
              option => option.id == charge.modifier3ID
            );
            var modifier4 = {};
            modifier4 = this.state.modifierOptions.filter(
              option => option.id == charge.modifier4ID
            );

            charge.dateOfServiceFrom = charge.dateOfServiceTo
              ? charge.dateOfServiceFrom.replace("T00:00:00", "")
              : "";
            charge.dateOfServiceTo = charge.dateOfServiceTo
              ? charge.dateOfServiceTo.replace("T00:00:00", "")
              : "";
            charge.cptObj = cpt[0];
            charge.modifier1Obj = modifier1[0];
            charge.modifier2Obj = modifier2[0];
            charge.modifier3Obj = modifier3[0];
            charge.modifier4Obj = modifier4[0];

            this.setState({
              loading:false,
              visitModel: {
                ...this.state.visitModel,
                charges: [
                  ...this.state.visitModel.charges.slice(0, index),
                  Object.assign(
                    {},
                    this.state.visitModel.charges[index],
                    charge
                  ),
                  ...this.state.visitModel.charges.slice(index + 1)
                ]
              }
            });
          });
        })
        .catch(error => {
          this.setState({loading:false})
          try {
            let errorsList = [];
            if (error.response !== null && error.response.data !== null) {
              errorsList = error.response.data;
              console.log(errorsList);
            }
          } catch {
            console.log(error);
          }
        });
    } else {
      await this.setState({
        chargeValidationModel: this.state.chargeValidationModel.concat(
          this.chargeValidationModel
        ),
        visitModel: {
          ...this.state.visitModel,
          charges: this.state.visitModel.charges.concat(this.chargeModel)
        }
      });
    }
  }

  openPopup = (name, id) => {
    console.log("Id : " , id)
    if (name === "insuranceplan") {
      axios
        .get(
          "http://192.168.110.44/Database/api/patientplan/findpatientplan/" + id  ,this.config
        )
        .then(response => {
          this.setState({
            id: response.data.insurancePlanID,
            popupName: name
          });
        })
        .catch(error => {
          console.log(error);
        });
    } else this.setState({ popupName: name, id: id == "Please Select" ? 0 : id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  async handleOutsideRefCheck() {
    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        outsideReferral: !this.state.visitModel.outsideReferral
      }
    });
  }

  async handleOutsideLabCheck() {
    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        outsideLab: !this.state.visitModel.outsideLab
      }
    });
  }

  async handleEmergencyCheck() {
    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        emergency: !this.state.visitModel.emergency
      }
    });
  }

  async handleEPSDTCheck() {
    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        epsdt: !this.state.visitModel.epsdt
      }
    });
  }

  async handleFamilyPlanCheck() {
    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        familyPlan: !this.state.visitModel.familyPlan
      }
    });
  }

  async handleChange(event) {
    console.log(event.target);
    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        [event.target.name]: event.target.value
      }
    });
  }

  handleAmountChange(e) {
    const amount = e.target.value;
    var regexp = /^\d+(\.(\d{1,2})?)?$/;

    if (e.target.value.length < 15) {
      if (regexp.test(amount)) {
        this.setState({
          visitModel: {
            ...this.state.visitModel,
            [e.target.name]: amount
          }
        });
      } else if (amount == "") {
        this.setState({
          visitModel: {
            ...this.state.visitModel,
            [e.target.name]: amount
          }
        });
      }
    }
  }

  async setPatientetails(id) {
    for (var i = 0; i < this.state.patientDropDown.length; i++) {
      if (this.state.patientDropDown[i].patientID == id) {
        await this.setState({
          dob: this.state.patientDropDown[i].dob,
          gender: this.state.patientDropDown[i].gender,

          visitModel: {
            ...this.state.visitModel,
            practiceID: this.state.patientDropDown[i].practiceID,
            locationID: this.state.patientDropDown[i].locationID,
            posid: this.state.patientDropDown[i].posid,
            providerID: this.state.patientDropDown[i].providerID,
            refProviderID: this.state.patientDropDown[i].refProviderID
            //supervisingProvID  :this.state.patientDropDown[i].providerId
          }

          // chargeModel :{
          //   ...this.state.chargeModel ,
          //   practiceID : this.state.patientDropDown[i].practiceId,
          //   locationID : this.state.patientDropDown[i].locationId,
          //   posid : this.state.patientDropDown[i].posId,
          //   providerID : this.state.patientDropDown[i].providerId
          //  }
        });
      }
    }
  }

  async handlePatientDropDownChange(event) {
    const id = event.target.value;
    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        [event.target.name]: event.target.value
      }
    });

    await this.setPatientetails(id);

    await axios
      .get(
        this.patientPlanUrl + "GetpatientPlansByPatientID/" + id , this.config
      )
      .then(res => {
        console.log("Patient Plan Response : ", res.data);
        this.setState({
          patientPlanDropdown: res.data
        });
      });

    if (this.state.patientPlanDropdown.length > 0) {
      for (var i = 0; i < this.state.patientPlanDropdown.length; i++) {
        if (this.state.patientPlanDropdown[i].description == "P") {
          await this.setState({
            primaryPlanName:
              "Primary - " + this.state.patientPlanDropdown[i].description2,
            visitModel: {
              ...this.state.visitModel,
              primaryPatientPlanID: this.state.patientPlanDropdown[i].id
            }
          });
        } else {
          await this.setState({
            primaryPlanName: "",
            visitModel: {
              ...this.state.visitModel,
              primaryPatientPlanID: null
            }
          });
          Swal.fire(
            "PatientPlan Does'nt Exists",
            "Visit can't be created",
            "error"
          );
        }
      }
    } else {
      await this.setState({
        primaryPlanName: "",
        visitModel: {
          ...this.state.visitModel,
          primaryPatientPlanID: null
        }
      });
      Swal.fire(
        "PatientPlan Does'nt Exists",
        "Visit can't be created",
        "error"
      );
    }

    var charge = { ...this.state.visitModel.charges[0] };
    charge.posid = this.state.visitModel.posid;

    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        charges: [
          // ...this.state.visitModel.charges.slice(0 , index),
          Object.assign({}, this.state.visitModel.charges[0], charge),
          ...this.state.visitModel.charges.slice(1)
        ]
      }
    });
  }

  async handleChargeChange(event) {
    console.log("Pointer Event : ", event.target);

    let newChargeList = this.state.visitModel.charges;

    const index = event.target.id;
    const name = event.target.name;
    newChargeList[index][name] = event.target.value;
    if (event.target.name == "dateOfServiceFrom") {
      newChargeList[index]["dateOfServiceTo"] = event.target.value;
    }

    var totalAmount = 0;

    newChargeList.map(charge => {
      totalAmount = totalAmount + parseInt(charge.totalAmount, 10);
    });

    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        totalAmount: totalAmount,
        primaryBilledAmount: totalAmount,
        charges: newChargeList
      }
    });
  }

  async handleCPTAmountChange(e) {
    let newChargeList = this.state.visitModel.charges;
    const index = e.target.id;
    const name = e.target.name;
    const amount = e.target.value;
    var regexp = /^\d+(\.(\d{1,2})?)?$/;

    var totalAmount = 0;
    await newChargeList.map(charge => {
      if (
        charge.totalAmount == undefined ||
        charge.totalAmount == "" ||
        charge.totalAmount < 0
      ) {
        totalAmount += 0;
      } else {
        totalAmount += parseFloat(charge.totalAmount);
      }
    });

    if (
      newChargeList[index][name] == undefined ||
      newChargeList[index][name] == "" ||
      newChargeList[index][name] < 0
    ) {
      totalAmount += 0;
    } else {
      totalAmount = totalAmount - parseFloat(newChargeList[index][name]);
    }

    if (amount.length < 15) {
      if (regexp.test(amount)) {
        newChargeList[index][name] = amount;
        totalAmount += parseFloat(amount);
        this.setState({
          visitModel: {
            ...this.state.visitModel,
            totalAmount: totalAmount.toFixed(2),
            primaryBilledAmount: totalAmount.toFixed(2),
            charges: newChargeList
          }
        });
      } else if (amount == "") {
        newChargeList[index][name] = "";
        this.setState({
          visitModel: {
            ...this.state.visitModel,
            totalAmount: totalAmount.toFixed(2),
            primaryBilledAmount: totalAmount.toFixed(2),
            charges: newChargeList
          }
        });
      }
    }

    //   if((amount.length < 15)){
    //     console.log("IF First")
    //         if (regexp.test(amount)){
    //           console.log("IF Second" , amount)
    //           newChargeList[index][name] = amount
    //           console.log("New Charge List : " , newChargeList)
    //           this.setState({
    //             visitModel:{
    //               ...this.state.visitModel ,
    //               charges : newChargeList
    //             }

    //           });
    //       }else if(amount == ""){
    //         console.log("Else Second" , amount)
    //         newChargeList[index][name] = ""
    //             this.setState({
    //               visitModel:{
    //                 ...this.state.visitModel ,
    //                 charges : newChargeList
    //               }

    //             });
    //       }
    //     }
    // var totalAmount = 0;
    // await newChargeList.map( charge => {

    //     if((charge.totalAmount == undefined) || (charge.totalAmount == "") || charge.totalAmount < 0  ){
    //       totalAmount +=0;

    //     }else{
    //       totalAmount +=parseInt(charge.totalAmount , 10);
    //     }
    // });

    // newChargeList[index][name] = "";
    // this.setState({
    //   visitModel:{
    //     ...this.state.visitModel ,
    //     totalAmount : totalAmount,
    //     primaryBilledAmount : totalAmount,
    //     charges : newChargeList
    //   }
    // });
  }

  openEditChargePopup = (event, index, id) => {
    alert(index);
    var icd1 , icd2 , icd3 ,icd4, icdId;
    if(this.state.visitModel.charges[index].pointer1 != ""){
      icdId = "icD" + this.state.visitModel.charges[index].pointer1 + "ID";
      icd1 = this.state.visitModel[icdId];
    }
    if(this.state.visitModel.charges[index].pointer2 != ""){
      icdId = "icD" + this.state.visitModel.charges[index].pointer2 + "ID";
      icd2 = this.state.visitModel[icdId];
    }
    if(this.state.visitModel.charges[index].pointer3 != ""){
      icdId = "icD" + this.state.visitModel.charges[index].pointer3 + "ID";
      icd3 = this.state.visitModel[icdId];
    }
    if(this.state.visitModel.charges[index].pointer4 != ""){
      icdId = "icD" + this.state.visitModel.charges[index].pointer4 + "ID";
      icd4 = this.state.visitModel[icdId];
    }
    // icd1Obj: this.state.options.filter(
    //   option => option.id == response.data.icD1ID
    // )
    this.setState({ showPopup: true, chargeId: id , icd1 : icd1 , icd2 : icd2 , icd3 : icd3 , icd4 : icd4 });
  };

  //resubmit Visit
  resubmitVisit() {
    console.log(this.state.visitModel);
    this.setState({loading :true})
    if (this.state.visitModel.isSubmitted === true) {
      axios
        .get(this.visitUrl + 
          "ResubmitVisit/" +
            this.state.visitModel.id  ,this.config
        )
        .then(response => {
          console.log("Response Data : ", response.data);
          this.setState({ visitModel: response.data , loading : false });

          this.componentDidMount();

          Swal.fire("SUCCESS", "Visit Re-Submited Successfully", "success");
        }).catch(error => {
          this.setState({loading : false})
        });
    } else {
      Swal.fire(
        "SOMETHING WRONG",
        "Visit can not be Re-Submitted,First Submit the Visit",
        "error"
      );
    }
  }

  async handleDateChange(event) {
    await this.setState({
      chargeModel: {
        ...this.state.chargeModel,
        [event.target.name]: event.target.value
      }
    });
  }

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  //Save Visit
  async saveCharge() {
    this.visitInput.focus();
   await this.setState({loading : true})
   console.log("Loading : " , this.state.visitModel)

    var myVal = this.validationModel;
    myVal.validation = false;

    //icd1 validation
    if (this.isNull(this.state.visitModel.icD1ID)) {
      myVal.icd1ValField = <span className="validationMsg">Enter ICD1</span>;
      myVal.validation = true;
    } else {
      myVal.icd1ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd2 validation
    if (this.isNull(this.state.visitModel.icD1ID)) {
      if (!this.isNull(this.state.visitModel.icD2ID)) {
        myVal.icd2ValField = (
          <span className="validationMsg">First Enter ICD1</span>
        );
        myVal.validation = true;
      } else {
        myVal.icd2ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd2ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd3 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD3ID)) {
        myVal.icd3ValField = (
          <span className="validationMsg">First Enter ICD1 & ICD2</span>
        );
        myVal.validation = true;
      } else {
        myVal.icd3ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd3ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd4 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD4ID)) {
        myVal.icd4ValField = (
          <span className="validationMsg">First Enter ICD1 & ICD2 & ICD3</span>
        );
        myVal.validation = true;
      } else {
        myVal.icd4ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd4ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd5 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID) ||
      this.isNull(this.state.visitModel.icD4ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD5ID)) {
        myVal.icd5ValField = (
          <span className="validationMsg">
            First Enter ICD1 & ICD2 & ICD3 & ICD4
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.icd5ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd5ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd6 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID) ||
      this.isNull(this.state.visitModel.icD4ID) ||
      this.isNull(this.state.visitModel.icD5ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD6ID)) {
        myVal.icd6ValField = (
          <span className="validationMsg">
            First Enter ICD1 & ICD2 & ICD3 & ICD4 & ICD5
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.icd6ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd6ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd7 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID) ||
      this.isNull(this.state.visitModel.icD4ID) ||
      this.isNull(this.state.visitModel.icD5ID) ||
      this.isNull(this.state.visitModel.icD6ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD7ID)) {
        myVal.icd7ValField = (
          <span className="validationMsg">
            First Enter ICD1 & ICD2 & ICD3 & ICD4 & ICD5 & ICD6
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.icd7ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd7ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd8 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID) ||
      this.isNull(this.state.visitModel.icD4ID) ||
      this.isNull(this.state.visitModel.icD5ID) ||
      this.isNull(this.state.visitModel.icD6ID) ||
      this.isNull(this.state.visitModel.icD7ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD8ID)) {
        myVal.icd8ValField = (
          <span className="validationMsg">
            First Enter ICD1 & ICD2 & ICD3 & ICD4 & ICD5 & ICD6 & ICD7
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.icd8ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd8ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd9 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID) ||
      this.isNull(this.state.visitModel.icD4ID) ||
      this.isNull(this.state.visitModel.icD5ID) ||
      this.isNull(this.state.visitModel.icD6ID) ||
      this.isNull(this.state.visitModel.icD7ID) ||
      this.isNull(this.state.visitModel.icD8ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD9ID)) {
        myVal.icd9ValField = (
          <span className="validationMsg">
            First Enter ICD1 & ICD2 & ICD3 & ICD4 & ICD5 & ICD6 & ICD7
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.icd9ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd9ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd10 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID) ||
      this.isNull(this.state.visitModel.icD4ID) ||
      this.isNull(this.state.visitModel.icD5ID) ||
      this.isNull(this.state.visitModel.icD6ID) ||
      this.isNull(this.state.visitModel.icD7ID) ||
      this.isNull(this.state.visitModel.icD8ID) ||
      this.isNull(this.state.visitModel.icD9ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD10ID)) {
        myVal.icd10ValField = (
          <span className="validationMsg">
            First Enter ICD1 & ICD2 & ICD3 & ICD4 & ICD5 & ICD6 & ICD7 & ICD8 &
            ICD9
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.icd10ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd10ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd11 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID) ||
      this.isNull(this.state.visitModel.icD4ID) ||
      this.isNull(this.state.visitModel.icD5ID) ||
      this.isNull(this.state.visitModel.icD6ID) ||
      this.isNull(this.state.visitModel.icD7ID) ||
      this.isNull(this.state.visitModel.icD8ID) ||
      this.isNull(this.state.visitModel.icD9ID) ||
      this.isNull(this.state.visitModel.icD10ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD11ID)) {
        myVal.icd11ValField = (
          <span className="validationMsg">
            First Enter ICD1 & ICD2 & ICD3 & ICD4 & ICD5 & ICD6 & ICD7 & ICD8 &
            ICD9 & ICD10
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.icd11ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd11ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //icd12 validation
    if (
      this.isNull(this.state.visitModel.icD1ID) ||
      this.isNull(this.state.visitModel.icD2ID) ||
      this.isNull(this.state.visitModel.icD3ID) ||
      this.isNull(this.state.visitModel.icD4ID) ||
      this.isNull(this.state.visitModel.icD5ID) ||
      this.isNull(this.state.visitModel.icD6ID) ||
      this.isNull(this.state.visitModel.icD7ID) ||
      this.isNull(this.state.visitModel.icD8ID) ||
      this.isNull(this.state.visitModel.icD9ID) ||
      this.isNull(this.state.visitModel.icD10ID) ||
      this.isNull(this.state.visitModel.icD11ID)
    ) {
      if (!this.isNull(this.state.visitModel.icD12ID)) {
        myVal.icd12ValField = (
          <span className="validationMsg">
            First Enter ICD1 & ICD2 & ICD3 & ICD4 & ICD5 & ICD6 & ICD7 & ICD8 &
            ICD9 & ICD10 & ICD11
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.icd12ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.icd12ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    
    //patient validation
    if (this.isNull(this.state.visitModel.patientID)) {
      myVal.patientValField = (
        <span className="validationMsg">Select Patient</span>
      );
      myVal.validation = true;
    } else {
      myVal.patientValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //practice validation
    if (this.isNull(this.state.visitModel.practiceID)) {
      myVal.practiceValField = (
        <span className="validationMsg">Select Practice</span>
      );
      myVal.validation = true;
    } else {
      myVal.practiceValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //location validation
    if (this.isNull(this.state.visitModel.locationID)) {
      myVal.locationValField = (
        <span className="validationMsg">Select Location</span>
      );
      myVal.validation = true;
    } else {
      myVal.locationValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //pos validation
    if (this.isNull(this.state.visitModel.posid)) {
      myVal.posValField = <span className="validationMsg">Select POS</span>;
      myVal.validation = true;
    } else {
      myVal.posValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //provider validation
    if (this.isNull(this.state.visitModel.providerID)) {
      myVal.providerValField = (
        <span className="validationMsg">Select Provider</span>
      );
      myVal.validation = true;
    } else {
      myVal.providerValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //OnserDateOfSimilarIllness validation
    if ((!this.isNull(this.state.visitModel.onsetDateOfIllness) && !isNull(this.state.visitModel.firstDateOfSimiliarIllness)) && 
          (this.state.visitModel.onsetDateOfIllness < this.state.visitModel.firstDateOfSimiliarIllness)) {
      myVal.onSetDateOfSimiliarIllnessValField = (
        <span className="validationMsg">Onset Date of Current Illness Must Be Greater Than or Equal To First Date Of Similar Illness</span>
      );
      myVal.validation = true;
    } else {
      myVal.onSetDateOfSimiliarIllnessValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

     //Unable To Work To Greater Than validation
     if ((!this.isNull(this.state.visitModel.unableToWorkFromDate) && !isNull(this.state.visitModel.unableToWorkToDate)) && 
        (this.state.visitModel.unableToWorkToDate < this.state.visitModel.unableToWorkFromDate)) {
      myVal.unableToWorkFromDateValField = (
        <span className="validationMsg">Unable To Work To Date  Must Be Greater Than or Equal To Unable To Work From Date</span>
      );
      myVal.validation = true;
      } else {
      myVal.unableToWorkFromDateValField = "";
      if (myVal.validation === false) myVal.validation = false;
      }

      //Discharge Date Greater Than validation
      if ((!this.isNull(this.state.visitModel.admissionDate) && !isNull(this.state.visitModel.dischargeDate)) && 
        (this.state.visitModel.dischargeDate < this.state.visitModel.admissionDate)) {
        myVal.dischargeDateValField = (
        <span className="validationMsg">Discharge Must Be Greater Than or Equal To Admission Date</span>
        );
        myVal.validation = true;
        } else {
        myVal.dischargeDateValField = "";
        if (myVal.validation === false) myVal.validation = false;
        }


    await this.setState({
      validationModel: myVal
    });

    // if (myVal.validation === true) {
    //   Swal.fire(
    //     "SOMETHING WRONG",
    //     "Please Select All Fields Properly",
    //     "error"
    //   );
    //   return;
    // }

    //Charge  Model Validation
    var chargeVal;
     for (var i = 0; i < this.state.visitModel.charges.length; i++) {
      chargeVal = { ...this.state.visitModel.charges[i] };
      chargeVal.validation = false;

      //dos from validation
      if (this.isNull(this.state.visitModel.charges[i].dateOfServiceFrom)) {
        chargeVal.dosFromValField = (
          <span className="validationMsg">Enter DOS From</span>
        );
        chargeVal.validation = true;
      } else {
        chargeVal.dosFromValField = "";
        if (chargeVal.validation === false) chargeVal.validation = false;
      }




    if ((this.state.visitModel.cliaNumber.lenggth>0) &&( this.state.visitModel.cliaNumber.length < 10)) {
        myVal.cliaNumberValField = <span className="validationMsg">CLIA length should be 10</span>
        myVal.validation = true
    } else {
        myVal.cliaNumberValField = ''
        if (myVal.validation === false) myVal.validation = false
    }

      //DOS To Validation
      if (this.isNull(this.state.visitModel.charges[i].dateOfServiceTo)) {
        chargeVal.dosToValField = (
          <span className="validationMsg">Enter DOS To</span>
        );
        chargeVal.validation = true;
      } else {
        chargeVal.dosToValField = "";
        if (chargeVal.validation === false) chargeVal.validation = false;
      }

      //DOS To greater than check
      if (
        !this.isNull(this.state.visitModel.charges[i].dateOfServiceFrom) &&
        !this.isNull(this.state.visitModel.charges[i].dateOfServiceTo)
      ) {
        var dosFrom = new Date(
          this.state.visitModel.charges[i].dateOfServiceFrom
        );
        var dosTo = new Date(this.state.visitModel.charges[i].dateOfServiceTo);
        if (dosTo < dosFrom) {
          chargeVal.dosToValField = (
            <span className="validationMsg">
              DOS To must be greater than DOS From
            </span>
          );
          chargeVal.validation = true;
        }
      } else {
        chargeVal.dosToValField = "";
        if (chargeVal.validation === false) chargeVal.validation = false;
      }

      //CPT Code Validation
      if (this.isNull(this.state.visitModel.charges[i].cptid)) {
        console.log("CPT Code Empty ", i);
        chargeVal.cptCodeValField = (
          <span className="validationMsg">Enter CPT Code</span>
        );
        chargeVal.validation = true;
      } else {
        chargeVal.cptCodeValField = "";
        if (chargeVal.validation === false) chargeVal.validation = false;
      }

      //Units Validation
      if (this.isNull(this.state.visitModel.charges[i].units)) {
        chargeVal.unitsValField = (
          <span className="validationMsg">Enter Units</span>
        );
        chargeVal.validation = true;
      } else {
        chargeVal.unitsValField = "";
        if (chargeVal.validation === false) chargeVal.validation = false;
      }

      //Total Amount Validation
      if (this.isNull(this.state.visitModel.charges[i].totalAmount)) {
        chargeVal.amountValField = (
          <span className="validationMsg">Enter Amount</span>
        );
        chargeVal.validation = true;
      } else {
        chargeVal.amountValField = "";
        if (chargeVal.validation === false) chargeVal.validation = false;
      }

      //pointers validation
      if (this.isNull(this.state.visitModel.charges[i].pointer1)) {
        chargeVal.pointer1ValField = (
          <span className="validationMsg">Enter Pointer1</span>
        );
        chargeVal.validation = true;
      } else if (
        chargeVal.pointer1 > 12 ||
        chargeVal.pointer2 > 12 ||
        chargeVal.pointer3 > 12 ||
        chargeVal.pointer4 > 12
      ) {
        chargeVal.pointer1ValField = (
          <span className="validationMsg">Enter Valid Pointer(s) 12</span>
        );
        chargeVal.validation = true;
      } else if (
        (this.state.visitModel.icD1ID === null &&
          (chargeVal.pointer1 === "1" ||
            chargeVal.pointer2 === "1" ||
            chargeVal.pointer3 === "1" ||
            chargeVal.pointer4 === "1")) ||
        (this.state.visitModel.icD2ID === null &&
          (chargeVal.pointer1 === "2" ||
            chargeVal.pointer2 === "2" ||
            chargeVal.pointer3 === "2" ||
            chargeVal.pointer4 === "2")) ||
        (this.state.visitModel.icD3ID === null &&
          (chargeVal.pointer1 === "3" ||
            chargeVal.pointer2 === "3" ||
            chargeVal.pointer3 === "3" ||
            chargeVal.pointer4 === "3")) ||
        (this.state.visitModel.icD4ID === null &&
          (chargeVal.pointer1 === "4" ||
            chargeVal.pointer2 === "4" ||
            chargeVal.pointer3 === "4" ||
            chargeVal.pointer4 === "4")) ||
        (this.state.visitModel.icD5ID === null &&
          (chargeVal.pointer1 === "5" ||
            chargeVal.pointer2 === "5" ||
            chargeVal.pointer3 === "5" ||
            chargeVal.pointer4 === "5")) ||
        (this.state.visitModel.icD6ID === null &&
          (chargeVal.pointer1 === "6" ||
            chargeVal.pointer2 === "6" ||
            chargeVal.pointer3 === "6" ||
            chargeVal.pointer4 === "6")) ||
        (this.state.visitModel.icD7ID === null &&
          (chargeVal.pointer1 === "7" ||
            chargeVal.pointer2 === "7" ||
            chargeVal.pointer3 === "7" ||
            chargeVal.pointer4 === "7")) ||
        (this.state.visitModel.icD8ID === null &&
          (chargeVal.pointer1 === "8" ||
            chargeVal.pointer2 === "8" ||
            chargeVal.pointer3 === "8" ||
            chargeVal.pointer4 === "8")) ||
        (this.state.visitModel.icD9ID === null &&
          (chargeVal.pointer1 === "9" ||
            chargeVal.pointer2 === "9" ||
            chargeVal.pointer3 === "9" ||
            chargeVal.pointer4 === "9")) ||
        (this.state.visitModel.icD10ID === null &&
          (chargeVal.pointer1 === "10" ||
            chargeVal.pointer2 === "10" ||
            chargeVal.pointer3 === "10" ||
            chargeVal.pointer4 === "10")) ||
        (this.state.visitModel.icD11ID === null &&
          (chargeVal.pointer1 === "11" ||
            chargeVal.pointer2 === "11" ||
            chargeVal.pointer3 === "11" ||
            chargeVal.pointer4 === "11")) ||
        (this.state.visitModel.icD12ID === null &&
          (chargeVal.pointer1 === "12" ||
            chargeVal.pointer2 === "12" ||
            chargeVal.pointer3 === "12" ||
            chargeVal.pointer4 === "12"))
      ) {
        chargeVal.pointer1ValField = (
          <span className="validationMsg">Enter Valid Pointer(s)</span>
        );
        chargeVal.validation = true;
      } else if (
        ((this.state.visitModel.charges[i].pointer1 !=  "" ) && 
        ((this.state.visitModel.charges[i].pointer1 == this.state.visitModel.charges[i].pointer2) ||
        (this.state.visitModel.charges[i].pointer1 == this.state.visitModel.charges[i].pointer3) ||
        (this.state.visitModel.charges[i].pointer1 == this.state.visitModel.charges[i].pointer4))) ||
       ((this.state.visitModel.charges[i].pointer2 !=  "" ) && 
        ((this.state.visitModel.charges[i].pointer2 ==  this.state.visitModel.charges[i].pointer3 ) ||
        (this.state.visitModel.charges[i].pointer2 ==  this.state.visitModel.charges[i].pointer4 )) ) ||
       ( (this.state.visitModel.charges[i].pointer3 !=  "" ) &&
        (this.state.visitModel.charges[i].pointer3 == this.state.visitModel.charges[i].pointer4))
      ) {
        chargeVal.pointer1ValField = (
          <span className="validationMsg">Enter Unique Pointer(s)</span>
        );
        chargeVal.validation = true;
      }else if ((( (this.state.visitModel.charges[i].pointer2 !=  "")  ) &&
                  ( (this.state.visitModel.charges[i].pointer1 ==  "" ))) ||
              ((( this.state.visitModel.charges[i].pointer3 !=  "" )) && 
                  ( (this.state.visitModel.charges[i].pointer2 ==  "")  )) ||
              ((( this.state.visitModel.charges[i].pointer4 !=  "" )) && 
                  ((this.state.visitModel.charges[i].pointer3 ==  "") ))){

            chargeVal.pointer1ValField = (
              <span className="validationMsg">Enter Pointer(s) in Sequence</span>
            );
            chargeVal.validation = true;

      } else {
        chargeVal.pointer1ValField = "";
        if (chargeVal.validation === false) chargeVal.validation = false;
      }

      //Unique Modifies Check
      if (
        ((this.state.visitModel.charges[i].modifier1ID != null || "" ) && (this.state.visitModel.charges[i].modifier2ID != null || "") && (this.state.visitModel.charges[i].modifier1ID ==
          this.state.visitModel.charges[i].modifier2ID)) ||
       ( (this.state.visitModel.charges[i].modifier1ID != null || "" ) && (this.state.visitModel.charges[i].modifier3ID != null || "") &&(this.state.visitModel.charges[i].modifier1ID ==
          this.state.visitModel.charges[i].modifier3ID) )||
        ((this.state.visitModel.charges[i].modifier1ID != null || "" ) && (this.state.visitModel.charges[i].modifier4ID != null || "") &&(this.state.visitModel.charges[i].modifier1ID ==
          this.state.visitModel.charges[i].modifier4ID ))||
        ((this.state.visitModel.charges[i].modifier2ID != null || "" ) && (this.state.visitModel.charges[i].modifier3ID != null || "") &&(this.state.visitModel.charges[i].modifier2ID ==
          this.state.visitModel.charges[i].modifier3ID) )||
       ( (this.state.visitModel.charges[i].modifier2ID != null || "" ) && (this.state.visitModel.charges[i].modifier4ID != null || "") &&(this.state.visitModel.charges[i].modifier2ID ==
          this.state.visitModel.charges[i].modifier4ID) )||
       ((this.state.visitModel.charges[i].modifier3ID != null || "" ) && (this.state.visitModel.charges[i].modifier4ID != null || "") && (this.state.visitModel.charges[i].modifier3ID ==
          this.state.visitModel.charges[i].modifier4ID))
      ) {
        chargeVal.modifierValField = (
          <span className="validationMsg">Enter Unique Modifiers(s)</span>
        );
        chargeVal.validation = true;
      }else {
        chargeVal.modifierValField = "";
        if (chargeVal.validation === false) chargeVal.validation = false;
      }


    

      //Charge model Validation set state
      await this.setState({
        visitModel: {
          ...this.state.visitModel,
          charges: [
            ...this.state.visitModel.charges.slice(0, i),
            Object.assign({}, this.state.visitModel.charges[i], chargeVal),
            ...this.state.visitModel.charges.slice(i + 1)
          ]
        }
      });
    }
    //end of for loop

    if (myVal.validation === true) {
       this.visitInput.focus();
       await this.setState({loading : false})
      Swal.fire(
        "SOMETHING WRONG",
        "Please Select All Visits Fields Properly",
        "error"
      );
     
      return;
    }

    for (var i = 0; i < this.state.visitModel.charges.length; i++) {
      if (this.state.visitModel.charges[i].validation == true) {
        this.chargeInput.focus();
        this.setState({loading : false})
        Swal.fire("Something Wrong", "Please Check All Charge Fields", "error");         
         return;
      }
    }

    if (this.state.visitModel.supervisingProvID == "Please Select") {
      this.setState({
        visitModel: {
          ...this.state.visitModel,
          supervisingProvID: null
        }
      });
    }

    if (this.state.visitModel.refProviderID == "Please Select") {
      this.setState({
        visitModel: {
          ...this.state.visitModel,
          refProviderID: null
        }
      });
    }

    if (this.state.visitModel.primaryPatientPlanID == null) {
      this.setState({loading:false})
      Swal.fire(
        "PatientPlan Does'nt Exists",
        "Visit can't be created",
        "error"
      );
      this.visitInput.focus(); 
       } else {

      await axios
        .post(
          this.visitUrl+"SaveVisit",
          this.state.visitModel , this.config
        )
        .then(response => {
          console.log("Visit Response : ",response);
          this.setState({
            visitModel: response.data , loading : false
          });

          
          Swal.fire("Record Saved Successfully", "", "success");
          this.componentDidMount();
        })
        .catch(error => {
          this.visitInput.focus();
          this.setState({loading:false})
          if (error.response) {
            if(error.response.status){
                Swal.fire("Unauthorized Access" , "" , "error");
                console.log("Response Status : " , error.response.status)
                return
            }
          } else if (error.request) {
            console.log("Error Request : " , error.request);
            return
          } else {
            console.log('Error Message', error.message);
            console.log("Error Object ; " ,JSON.stringify(error));
            Swal.fire("Something went Wrong" , "" , "error");
            return
          }
        });
    }
  }

  deleteVisit() {
   
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.setState({loading : true})
        axios
          .delete(
            this.visitUrl+"DeleteVisit/" +
              this.state.editId , this.config
          )
          .then(response => {
            console.log("Delete Response :", response);
            this.setState({loading : false})
            Swal.fire("Record Deleted Successfully", "", "success").then(
              res => {
                this.props.selectTabAction("Charges");
              }
            );
          })
          .catch(error => {
            this.setState({loading : false})
            Swal.fire(
              "Record Not Deleted!",
              "Record can not be delete,  it maybe referenced in other screens.",
              "error"
            );
          });
      }
    });
  }

  addDiagnosisRow() {
    this.setState({
      diagnosisRow: !this.state.diagnosisRow
    });
  }

  async addCPTRow() {
    // const length = this.state.visitModel.charges.length;
    // var charge = this.state.visitModel.charges[length-1];
    const charge = { ...this.chargeModel };

    // charge.practiceID = this.state.visitModel.practiceID;
    // charge.providerID = this.state.visitModel.providerID;
    // charge.locationID = this.state.visitModel.locationID;
    charge.posid = this.state.visitModel.posid;
    // charge.patientID = this.state.visitModel.patientID;
    // charge.visitID = this.state.visitModel.visitID;
    // charge.primaryPatientPlanID = this.state.visitModel.primaryPatientPlanID;

    // await this.setState({
    //   visitModel: {
    //     ...this.state.visitModel,
    //     charges : [
    //       ...this.state.visitModel.charges.slice(0 , -2),
    //      Object.assign({}, this.state.visitModel.charges[length-1] , charge),
    //      ...this.state.visitModel.charges.slice((length))
    //     ]
    //   }
    // });

    await this.setState({
      visitModel: {
        ...this.state.visitModel,
        charges: this.state.visitModel.charges.concat(charge)
      }
    });
  }

  async deleteCPTRow(event, index, chargeId) {
    const chargeID = chargeId;
    console.log("Charge Id : ", chargeId);
    const id = event.target.id;
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        if (chargeID) {
          axios
            .delete(
              this.chargeUrl+"DeleteCharge/" +
                chargeId , this.config
            )
            .then(response => {
              console.log("Delete Response :", response);
              Swal.fire("Record Deleted Successfully", "", "success");
            })
            .catch(error => {
              Swal.fire(
                "Record Not Deleted!",
                "Record can not be delete, as it is being referenced in other screens.",
                "error"
              );
            });
        }

        let charges = [...this.state.visitModel.charges];
        charges.splice(id, 1);

        this.setState({
          visitModel: {
            ...this.state.visitModel,
            charges: charges
          }
        });
      }
    });

    //   let charges = [...this.state.visitModel.charges];
    //   charges.splice( event.target.id , 1)

    //   this.setState({
    //    visitModel : {
    //      ...this.state.visitModel,
    //      charges : charges
    //    }
    //  })
  }

  //Handle  Change Modifies Function
  async handleICD1Change (icd1SelectedOption, id, icdObj)  {

    //If ICD value selected
    if (icd1SelectedOption) {

            //UNIQUE ICD VALIDATION
          //filter icd array to check if this id already eists
            var isAvailable = await this.state.icdArr.filter((icdId) => icdId == icd1SelectedOption.id );

            var myVal = this.validationModel;
            myVal.validation = false;

            //if selected icd id alredy exists in array then set validation message
            if (isAvailable.length > 0) {
              myVal.icd1ValField = <span className="validationMsg">Please Enter Unique Modifiers</span>;
              myVal.validation = true;
            } else {
              myVal.icd1ValField = "";
              if (myVal.validation === false) myVal.validation = false;
            }

            //set validation model state
            await this.setState({
              validationModel : myVal
            });

            //if validation error then return
            if(myVal.validation === true){
              return
            }
             //if every thing is right then set state of selected ICD
            this.setState({
            icdArr : this.state.icdArr.concat(icd1SelectedOption.id),
            visitModel: {
              ...this.state.visitModel,
              [id]: icd1SelectedOption.id,
              [icdObj]: icd1SelectedOption
            }
          });
    } else {  //if remove ICD value  option selected   
      
      //Get the copy of ICD Array
      var ICDArr = [...this.state.icdArr]; 
      //get the index of deleted ICD and then remove it
      await ICDArr.splice((this.state.icdArr.indexOf(this.state.visitModel[id])) , 1);

      //set state
      this.setState({
        icdArr : ICDArr,
        visitModel: {
          ...this.state.visitModel,
          [id]: null,
          [icdObj]: {}
        }
      });
    }
  }

  handletest() {
    console.log("test");
  }

  handleCPTCodeChange = (cptModel, index) => {
    console.log("Event : ", cptModel);
    var charge = this.state.visitModel.charges[index];
    charge.cptid = cptModel.id;
    charge.cptObj = cptModel;
    if (cptModel.description1) {
      charge.units = cptModel.description1;
    } else {
      charge.units = "";
    }

    if (cptModel.description2) {
      charge.totalAmount = cptModel.description2;
    } else {
      charge.totalAmount = "";
    }

    this.setState({
      visitModel: {
        ...this.state.visitModel,
        charges: [
          ...this.state.visitModel.charges.slice(0, index),
          Object.assign({}, this.state.visitModel.charges[index], charge),
          ...this.state.visitModel.charges.slice(index + 1)
        ]
      }
    });
  };

  handleModifier1Change = (modifier1, index) => {
    var charge = this.state.visitModel.charges[index];
    charge.modifier1ID = modifier1.id;
    charge.modifier1Obj = modifier1;

    this.setState({
      visitModel: {
        ...this.state.visitModel,
        charges: [
          ...this.state.visitModel.charges.slice(0, index),
          Object.assign({}, this.state.visitModel.charges[index], charge),
          ...this.state.visitModel.charges.slice(index + 1)
        ]
      }
    });
  };

  handleModifier2Change = (modifier2, index) => {
    var charge = this.state.visitModel.charges[index];
    charge.modifier2ID = modifier2.id;
    charge.modifier2Obj = modifier2;

    this.setState({
      modifier2ID: modifier2,
      visitModel: {
        ...this.state.visitModel,
        charges: [
          ...this.state.visitModel.charges.slice(0, index),
          Object.assign({}, this.state.visitModel.charges[index], charge),
          ...this.state.visitModel.charges.slice(index + 1)
        ]
      }
    });
  };

  handleModifier3Change = (modifier3, index) => {
    var charge = this.state.visitModel.charges[index];
    charge.modifier3ID = modifier3.id;
    charge.modifier3Obj = modifier3;

    this.setState({
      modifier3ID: modifier3,
      visitModel: {
        ...this.state.visitModel,
        charges: [
          ...this.state.visitModel.charges.slice(0, index),
          Object.assign({}, this.state.visitModel.charges[index], charge),
          ...this.state.visitModel.charges.slice(index + 1)
        ]
      }
    });
  };

  handleModifier4Change = (modifier4, index) => {
    var charge = this.state.visitModel.charges[index];
    charge.modifier4ID = modifier4.id;
    charge.modifier4Obj = modifier4;

    this.setState({
      modifier4ID: modifier4,
      visitModel: {
        ...this.state.visitModel,
        charges: [
          ...this.state.visitModel.charges.slice(0, index),
          Object.assign({}, this.state.visitModel.charges[index], charge),
          ...this.state.visitModel.charges.slice(index + 1)
        ]
      }
    });
  };

  closeEditChargePopup = () => {
    $("#myModal1").hide();
    this.setState({ showPopup: false });
  };

  closeNewCharge() {
    this.props.selectTabAction("Charges");
  }

  test(e) {
    console.log("Event : ", e.target);
    console.log("altKey : ", e.altKey);
    console.log("ctrlKey : ", e.ctrlKey);
    // console.log("Event : ",e)
    // console.log("Event : ",e)
  }
  render() {


    let items = this.state.items;
    if (this.state.filter){
      items = items.filter( item =>
        item.description.toLowerCase()
        .includes(this.state.filter.toLowerCase()))
    }  

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <EditCharge
          onClose={() => this.closeEditChargePopup}
          chargeId={this.state.chargeId}
          icd1Id={this.state.icd1}
          icd2Id={this.state.icd2}
          icd3Id={this.state.icd3}
          icd4Id={this.state.icd4}
        ></EditCharge>
      );
    }else if (this.state.popupName === "patient") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    }else if (this.state.popupName === "batch") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else if (this.state.popupName === "practice") {
      popup = (
        <NewPractice
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewPractice>
      );
    } else if (this.state.popupName === "location") {
      popup = (
        <NewLocation
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewLocation>
      );
    } else if (this.state.popupName === "provider") {
      popup = (
        <NewProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (this.state.popupName === "refprovider") {
      popup = (
        <NewRefferingProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewRefferingProvider>
      );
    } else if (this.state.popupName === "pos") {
      popup = (
        <NewPOS onClose={() => this.closePopup} id={this.state.id}></NewPOS>
      );
    } else if (this.state.popupName === "superprovider") {
      popup = (
        <NewProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (
      this.state.popupName === "icd1" ||
      this.state.popupName === "icd2" ||
      this.state.popupName === "icd3" ||
      this.state.popupName === "icd4" ||
      this.state.popupName === "icd5" ||
      this.state.popupName === "icd6" ||
      this.state.popupName === "icd7" ||
      this.state.popupName === "icd8" ||
      this.state.popupName === "icd9" ||
      this.state.popupName === "icd10" ||
      this.state.popupName === "icd11" ||
      this.state.popupName === "icd12" 
    ) {
      popup = (
        <NewICD onClose={() => this.closePopup} id={this.state.id}></NewICD>
      );
    } else if (this.state.popupName === "insuranceplan") {
      popup = (
        <NewInsurancePlan
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewInsurancePlan>
      );
    } else popup = <React.Fragment></React.Fragment>;

    const isActive = this.state.visitModel.isActive;

    const headers = [
      "Claim Dates & Authorizations",
      "Accident & Labs",
      "Other"
    ];

    const gender = [
      { value: "", display: "Select Gender" },
      { value: "male", display: "Male" },
      { value: "female", display: "Female" },
      { value: "unknown", display: "Unknown" }
    ];

    const status = [
      { value: "N", display: "New Charge" },
      { value: "S", display: "Submitted" }
    ];
    const accidentType = [
      { value: "", display: "Select Type" },
      { value: "EM", display: "New Employment " },
      { value: "AA", display: "Auto Accident" },
      { value: "OA", display: "Other Accident" },
      { value: "AB", display: "Abuse" },
      { value: "AP", display: "Another Party Responsible" }
    ];

    const claimFrequencyCode = [
      { value: "", display: "Select Code" },
      { value: "1", display: "Original " },
      { value: "6", display: "Corrected" },
      { value: "7", display: "Replacement" },
      { value: "8", display: "Void" }
    ];
    const usStates = [
      { value: "", display: "Select State" },
      { value: "AL", display: "AL - Alabama" },
      { value: "AK", display: "AK - Alaska" },
      { value: "AZ", display: "AZ - Arizona" },
      { value: "AR", display: "AR - Arkansas" },
      { value: "CA", display: "CA - California" },
      { value: "CO", display: "CO - Colorado" },
      { value: "CT", display: "CT - Connecticut" },
      { value: "DE", display: "DE - Delaware" },
      { value: "FL", display: "FL - Florida" },
      { value: "GA", display: "GA - Georgia" },
      { value: "HI", display: "HI - Hawaii" },
      { value: "ID", display: "ID - Idaho" },
      { value: "IL", display: "IL - Illinois" },
      { value: "IN", display: "IN - Indiana" },
      { value: "IA", display: "IA - Iowa" },
      { value: "KS", display: "KS - Kansas" },
      { value: "KY", display: "KY - Kentucky" },
      { value: "LA", display: "LA - Louisiana" },
      { value: "ME", display: "ME - Maine" },
      { value: "MD", display: "MD - Maryland" },
      { value: "MA", display: "MA - Massachusetts" },
      { value: "MI", display: "MI - Michigan" },
      { value: "MN", display: "MN - Minnesota" },
      { value: "MS", display: "MS - Mississippi" },
      { value: "MO", display: "MO - Missouri" },
      { value: "MT", display: "MT - Montana" },
      { value: "NE", display: "NE - Nebraska" },
      { value: "NV", display: "NV - Nevada" },
      { value: "NH", display: "NH - New Hampshire" },
      { value: "NJ", display: "NJ - New Jersey" },
      { value: "NM", display: "NM - New Mexico" },
      { value: "NY", display: "NY - New York" },
      { value: "NC", display: "NC - North Carolina" },
      { value: "ND", display: "ND - North Dakota" },
      { value: "OH", display: "OH - Ohio" },
      { value: "OK", display: "OK - Oklahoma" },
      { value: "OR", display: "OR - Oregon" },
      { value: "PA", display: "PA - Pennsylvania" },
      { value: "RI", display: "RI - Rhode Island" },
      { value: "SC", display: "SC - South Carolina" },
      { value: "SD", display: "SD - South Dakota" },
      { value: "TN", display: "TN - Tennessee" },
      { value: "TX", display: "TX - Texas" },
      { value: "UT", display: "UT - Utah" },
      { value: "VT", display: "VT - Vermont" },
      { value: "VA", display: "VA - Virginia" },
      { value: "WA", display: "WA - Washington" },
      { value: "WV", display: "WV - West Virginia" },
      { value: "WI", display: "WI - Wisconsin" },
      { value: "WY", display: "WY - Wyoming" }
    ];

    const unitOfMeasurement = [
      { value: "", display: "Select State" },
      { value: "UN", display: "Units" },
      { value: "MJ", display: "Minutes" }
    ];

    let newList = [];
    this.state.visitModel.charges.map((row, index) => {
      newList.push({
        id: row.id,
        ChargeId:
          (this.state.editId > 0 || this.state.visitModel.id > 0) ? (
            <button
              style={{ width: "40px" }}
              name="deleteCPTBtn"
              id={index}
              onClick={event => this.openEditChargePopup(event, index, row.id)}
            >
              {row.id}
            </button>
          ) : (
            ""
          ),
          dosFrom: (
          <div class="textBoxValidate">
            <input
              style={{
                background: "url(" + samll_doc_icon + ") no-repeat right",
                width: "145px"
              }}
              className="smallCalendarIcon"
              type="date"
              name="dateOfServiceFrom"
              id={index}
              value={this.state.visitModel.charges[index].dateOfServiceFrom}
              onChange={this.handleChargeChange}
            ></input>
            {this.state.visitModel.charges[index].dosFromValField}
          </div>
        ),
        dosTo: (
          <div class="textBoxValidate">
            {/*  <input style={{ width: "120px", marginRight:"5px",padding: "7px 5px"}} type="text" value="" name="" id=""></input>
                      <img class="smallCalendarIcon" src="images/dob-small-icon.png"/> */}
            <input
              style={{
                background: "url(" + samll_doc_icon + ") no-repeat right",
                width: "145px"
              }}
              className="smallCalendarIcon"
              type="date"
              name="dateOfServiceTo"
              id={index}
              value={this.state.visitModel.charges[index].dateOfServiceTo}
              onChange={this.handleChargeChange}
            ></input>
            {this.state.visitModel.charges[index].dosToValField}
          </div>
        ),
        cptCode: (
          <div className="hideDD" style={{ width: "125px" }}>
            <Select
              value={this.state.visitModel.charges[index].cptObj}
              // onChange={this.handletest}
              onChange={event => this.handleCPTCodeChange(event, index)}
              options={this.state.cptOptions}
              placeholder=""
              
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
            />
            {this.state.visitModel.charges[index].cptCodeValField}
          </div>
        ),
        modifiers: (
          <div className="container" style={{ width: "233px" }}>
            <div className="row">
              <div
                className="hideDD"
                style={{ width: "50px", height: "20px", marginRight: "6px" }}
              >
                <Select
                  value={this.state.visitModel.charges[index].modifier1Obj}
                  onChange={event => this.handleModifier1Change(event, index)}
                  options={this.state.modifierOptions}
                  placeholder=""
                  Clearable={false}
                  menuPosition="fixed"
                  openMenuOnClick={false}
                  escapeClearsValue={true}
                />
               
              </div>

              <div
                className="hideDD"
                style={{ width: "50px", marginRight: "6px" }}
              >
                <Select
                  value={this.state.visitModel.charges[index].modifier2Obj}
                  onChange={event => this.handleModifier2Change(event, index)}
                  options={this.state.modifierOptions}
                  placeholder=""
                  Clearable={false}
                  menuPosition="fixed"
                  openMenuOnClick={false}
                  escapeClearsValue={true}
                />
              </div>

              <div
                className="hideDD"
                style={{ width: "50px", marginRight: "6px" }}
              >
                <Select
                  value={this.state.visitModel.charges[index].modifier3Obj}
                  onChange={event => this.handleModifier3Change(event, index)}
                  options={this.state.modifierOptions}
                  placeholder=""
                  Clearable={false}
                  menuPosition="fixed"
                  openMenuOnClick={false}
                  escapeClearsValue={true}
                />
              </div>

              <div className="hideDD" style={{ width: "50px" }}>
                <Select
                  value={this.state.visitModel.charges[index].modifier4Obj}
                  onChange={event => this.handleModifier4Change(event, index)}
                  options={this.state.modifierOptions}
                  placeholder=""
                  Clearable={false}
                  menuPosition="fixed"
                  openMenuOnClick={false}
                  escapeClearsValue={true}
                />
              </div>
              {this.state.visitModel.charges[index].modifierValField}
            </div>
          </div>
        ),
        pointers: (
          <div style={{ width: "182px" }}>
            <input
             ref={(input) => { this.chargeInput = input; }}
              style={{ width: " 35px", marginRight: "5px", padding: "7px 5px" }}
              type="text"
              max="2"
              value={this.state.visitModel.charges[index].pointer1}
              name="pointer1"
              id={index}
              onChange={this.handleChargeChange}
              maxLength="2"
              onKeyPress={event => this.handleNumericCheck(event)}
            ></input>

            <input
              max="2"
              style={{ width: " 35px", marginRight: "5px", padding: "7px 5px" }}
              type="text"
              value={this.state.visitModel.charges[index].pointer2}
              name="pointer2"
              id={index}
              onChange={this.handleChargeChange}
              onKeyPress={event => this.handleNumericCheck(event)}
            ></input>
            <input
              max="2"
              style={{ width: " 35px", marginRight: "5px", padding: "7px 5px" }}
              type="text"
              value={this.state.visitModel.charges[index].pointer3}
              name="pointer3"
              id={index}
              onChange={this.handleChargeChange}
              onKeyPress={event => this.handleNumericCheck(event)}
            ></input>
            <input
              max="2"
              style={{ width: " 35px", marginRight: "5px", padding: "7px 5px" }}
              type="text"
              value={this.state.visitModel.charges[index].pointer4}
              name="pointer4"
              id={index}
              onChange={this.handleChargeChange}
              onKeyPress={event => this.handleNumericCheck(event)}
            ></input>

            {this.state.visitModel.charges[index].pointer1ValField}
          </div>
        ),
        units: (
          <div>
            <input
              maxLength="4"
              style={{ width: " 70px", marginRight: "5px", padding: "7px 5px" }}
              type="text"
              value={this.state.visitModel.charges[index].units}
              name="units"
              id={index}
              onChange={this.handleChargeChange}
              onKeyPress={event => this.handleNumericCheck(event)}
            ></input>
            {this.state.visitModel.charges[index].unitsValField}
          </div>
        ),
        pos: (
          <div style={{ width: "130px" }}>
            <select
              name="posid"
              id={index}
              value={this.state.visitModel.charges[index].posid}
              onChange={this.handleChargeChange}
            >
              {this.state.pos.map(s => (
                <option key={s.id} value={s.id}>
                  {" "}
                  {s.description2}{" "}
                </option>
              ))}
            </select>
          </div>
        ),
        ammount: (
          <div>
            <input
              style={{
                width: " 120px",
                marginRight: "5px",
                padding: "7px 5px"
              }}
              type="text"
              value={this.state.visitModel.charges[index].totalAmount}
              name="totalAmount"
              id={index}
              onChange={this.handleCPTAmountChange}
              //onKeyPress = {event => this.handleNumericCheck(event)}
            ></input>
            {this.state.visitModel.charges[index].amountValField}
          </div>
        ),
        remove: (
          <button
            style={{ width: "50px" }}
            name="deleteCPTBtn"
            id={index}
            onClick={(event, index) => this.deleteCPTRow(event, index, row.id)}
          >
            X
          </button>
        )
      });
    });

    const tableData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 60
        },
        {
          label: "#",
          field: "ChargeId",
          sort: "asc",
          width: 168
        },
        {
          label: "DOS FROM",
          field: "dosFrom",
          sort: "asc",
          width: 168
        },
        {
          label: "DOS TO",
          field: "dosTo",
          sort: "asc",
          width: 150
        },
        {
          label: "CPT CODE",
          field: "cptCode",
          sort: "asc",
          width: 254
        },
        {
          label: "MODIFIERS",
          field: "modifiers",
          sort: "asc",
          width: 205
        },
        {
          label: "DIAGNOSIS POINTERS",
          field: "pointers",
          sort: "asc",
          width: 100
        },
        {
          label: "UNITS",
          field: "units",
          sort: "asc",
          width: 153
        },
        {
          label: "POS",
          field: "pos",
          sort: "asc",
          width: 140
        },
        {
          label: "AMOUNT",
          field: "ammount",
          sort: "asc",
          width: 50
        },
        {
          label: "",
          field: "remove",
          sort: "asc",
          width: 50
        }
      ],
      rows: newList
    };

    var onsetDateOfIllness = this.state.visitModel.onsetDateOfIllness
      ? this.state.visitModel.onsetDateOfIllness.slice(0 , 10)
      : "";

    var firstDateOfSimiliarIllness = this.state.visitModel
      .firstDateOfSimiliarIllness
      ? this.state.visitModel.firstDateOfSimiliarIllness.slice(0 , 10)
      : "";

    var illnessTreatmentDate = this.state.visitModel.illnessTreatmentDate
      ? this.state.visitModel.illnessTreatmentDate.slice(0 , 10)
      : "";

    var dateOfPregnancy = this.state.visitModel.dateOfPregnancy
      ? this.state.visitModel.dateOfPregnancy.slice(0 , 10)
      : "";

    var admissionDate = this.state.visitModel.admissionDate
      ? this.state.visitModel.admissionDate.slice(0 , 10)
      : "";

    var dischargeDate = this.state.visitModel.dischargeDate
      ? this.state.visitModel.dischargeDate.slice(0 , 10)
      : "";

    var lastXrayDate = this.state.visitModel.lastXrayDate
      ? this.state.visitModel.lastXrayDate.slice(0 , 10)
      : "";

    var unableToWorkFromDate = this.state.visitModel.unableToWorkFromDate
      ? this.state.visitModel.unableToWorkFromDate.slice(0 , 10)
      : "";

    var unableToWorkToDate = this.state.visitModel.unableToWorkToDate
      ? this.state.visitModel.unableToWorkToDate.slice(0 , 10)
      : "";

    var accidentDate = this.state.visitModel.accidentDate
      ? this.state.visitModel.accidentDate.slice(0 , 10)
      : "";

    var submittedDate = this.state.visitModel.submittetdDate
      ? this.state.visitModel.submittetdDate.slice(0 , 10)
      : "";

    var dobYY = this.state.dob ? this.state.dob.slice(0 , 4) : "";
    var dobDD = this.state.dob ? this.state.dob.slice(5 , 7) : "";
    var dobMM = this.state.dob ? this.state.dob.slice(8 , 10) : "";
       console.log("Date : " , this.state.dob)
    //  if(this.state.dob){
    //   var newDate = new Date(this.state.dob);
    //   var day = newDate.getDate();
    //   var month = newDate.getMonth() + 1;
    //   var year = newDate.getFullYear();
    //   var dob = month + "-" + day + "-" + year;
    //  }
    
    let spiner = ''
    if (this.state.loading == true) {
        spiner = (
            <GifLoader
                loading={true}
                imageSrc={Eclips}
                // imageStyle={imageStyle}
                overlayBackground="rgba(0,0,0,0.5)"
            />
        )
    }



    return (
      <React.Fragment>
       {spiner}

        <div>
       
          <div className="mainHeading row">
            <div className="col-md-6">
              <h1>{this.state.editId > 0 ? "VISIT #  " +  this.state.visitModel.id  : "NEW VISIT"}</h1>
            </div>
            <div className="col-md-6 headingRight">
              <button
                data-toggle="modal"
                data-target=".bs-example-modal-new"
                className="btn-blue-icon"
                onClick={this.resubmitVisit}
              >
                ReSubmit
              </button>
              <button
                data-toggle="modal"
                data-target=".bs-example-modal-new"
                className="btn-blue-icon"
                onClick={this.deleteVisit}
                style={{ marginLeft: "20px" }}
              >
                Delete
              </button>
            </div>
          </div>

          <div>
            <div className="mainTable fullWidthTable mt-25">
              <div class="row-form">
                <div class="mf-4">
                <label
                            className={
                              this.state.visitModel.patientID
                                ? "txtUnderline"
                                : ""
                            }
                            onClick={
                              this.state.visitModel.patientID
                                ? () =>
                                    this.openPopup(
                                      "patient",
                                      this.state.visitModel.patientID
                                    )
                                : undefined
                            }
                          >
                            Patient
                          </label>
                  <div class="selectBoxValidate">
                    <select
                      name="patientID"
                      id="patientID"
                      value={this.state.visitModel.patientID}
                      onChange={this.handlePatientDropDownChange}
                    >
                      {this.state.patientDropDown.map(s => (
                        <option key={s.patientID} value={s.patientID}>
                          {" "}
                          {s.patientName}{" "}
                        </option>
                      ))}{" "}
                    </select>
                    {this.state.validationModel.patientValField}
                  </div>
                </div>
                <div class="mf-4">
                  <label>DOB </label>
                  <div class="textBoxValidate">
                    <input
                      // style={{fontSize:"25px"}}
                      type="text"
                      disabled="disabled"
                      value={dobMM + "/" + dobDD + "/" + dobYY}
                      name="primaryPlanName"
                      id="primaryPlanName"
                    ></input>
                    <img class="calendarIcon" src={dob_icon} />
                  </div>
                </div>
                <div class="mf-4">
                  <label>Gender </label>
                  <input
                    type="text"
                    readOnly
                    value={this.state.gender}
                    name="primaryPlanName"
                    id="primaryPlanName"
                    //onChange={this.handleChange}
                  ></input>
                </div>
              </div>

              <div class="row-form">
                <div class="mf-4">
                <label
                            className={
                              this.state.visitModel.documentBatchID
                                ? "txtUnderline"
                                : ""
                            }
                            onClick={
                              this.state.visitModel.documentBatchID
                                ? () =>
                                    this.openPopup(
                                      "batch",
                                      this.state.visitModel.documentBatchID
                                    )
                                : undefined
                            }
                          >
                            Batch#
                          </label>
                  <input
                    ref={(input) => { this.visitInput = input; }} 
                    type="text"
                    maxLength="20"
                    value={this.state.visitModel.documentBatchID}
                    name="documentBatchID "
                    id="documentBatchID "
                    onChange={this.handleChange}
                    //data-tip data-for='happyFace'
                  ></input>
                  {/* <ReactTooltip id='happyFace' type='error'>
                    <span>Show happy face</span>
                  </ReactTooltip> */}
                </div>
                <div class="mf-4">
                  <label>Page# </label>
                  <input
                    maxLength="20"
                    type="text"
                    value={this.state.visitModel.pageNumber}
                    name="pageNumber"
                    id="pageNumber"
                    onChange={this.handleChange}
                  ></input>
                </div>
                <div class="mf-4">&nbsp;</div>
              </div>

              <div class="mf-12 headingtwo">
                <p>Insurance Info</p>
              </div>

              <div class="mainTable fullWidthTable">
                  <div >
                    
                      <div class="row-form">
                        <div class="mf-4">
                          <label
                            className={
                              this.state.visitModel.primaryPatientPlanID
                                ? "txtUnderline"
                                : ""
                            }
                            onClick={
                              this.state.visitModel.primaryPatientPlanID
                                ? () =>
                                    this.openPopup(
                                      "insuranceplan",
                                      this.state.visitModel.primaryPatientPlanID
                                    )
                                : undefined
                            }
                          >
                            Plan
                          </label>
                          <input
                            type="text"
                            disabled="disabled"
                            value={this.state.primaryPlanName}
                            name="primaryPlanName"
                            id="primaryPlanName"
                            //onChange={this.handleChange}
                          ></input>
                        </div>
                        <div class="mf-4">
                          <label>Billed</label>
                          <input
                            type="text"
                            disabled="disabled"
                            value={this.state.visitModel.primaryBilledAmount}
                            name="primaryBilledAmount"
                            id="primaryBilledAmount"
                            //onChange={this.handleChange}
                          ></input>
                        </div>
                        <div class="mf-4">
                          <label>Allowed</label>
                          <input
                            type="text"
                            disabled="disabled"
                            value={this.state.visitModel.primaryAllowed}
                            name="primaryAllowed"
                            id="primaryAllowed"
                            //onChange={this.handleChange}
                          ></input>
                        </div>
                      </div>            

                      <div class="row-form">
                        <div class="mf-4">
                            <label>WriteOff</label>
                            <input
                              type="text"
                              disabled="disabled"
                              value={this.state.visitModel.primaryWriteOff}
                              name="primaryWriteOff"
                              id="primaryWriteOff"
                              onChange={this.handleChange}
                            ></input>
                          </div>
                        <div class="mf-4">
                            <label>Paid</label>
                            <input
                              type="text"
                              disabled="disabled"
                              value={this.state.visitModel.primaryPlanPaid}
                              name="primaryPlanPaid"
                              id="primaryPlanPaid"
                              //onChange={this.handleChange}
                            ></input>
                          </div>
                        <div class="mf-4">
                              <label>Balance</label>
                              <input
                                type="text"
                                disabled="disabled"
                                value={this.state.visitModel.primaryBal}
                                name="primaryBal"
                                id="primaryBal"
                                onChange={this.handleChange}
                              ></input>
                            </div>
                      </div>  

                     <div className="row-form">
                        <div class="mf-4">
                              <label>Patient Amount</label>
                              <input
                                type="text"
                                disabled="disabled"
                                value={this.state.visitModel.primaryPatResp}
                                name="primaryPatResp"
                                id="primaryPatResp"
                                onChange={this.handleChange}
                              ></input>
                            </div>
                        <div class="mf-4">
                            <label>Transferred</label>
                            <input
                              type="text"
                              disabled="disabled"
                              value={this.state.visitModel.primaryTransferred}
                              name="primaryTransferred"
                              id="primaryTransferred"
                              //onChange={this.handleChange}
                            ></input>
                          </div>
                        <div class="mf-4">
                              <label>Status</label>   

                                                        
                                < select 
                                disabled
                                  name="primaryStatus"
                                  id="primaryStatus"
                                  value={
                                    this.state.visitModel.primaryStatus
                                  }
                                  onChange={
                                    this.handleChange
                                  } >
                                  {
                                    status.map(s => (
                                      <option key={
                                        s.value
                                      }
                                        value={
                                          s.value
                                        } > {
                                          s.display
                                        } </option>
                                    ))
                          } </select> 
                              </div>
                     </div>   

                   </div>            
                  
              </div>

              <div class="headingtwo mt-25">
                <p>Legal Entities</p>
              </div>

              <div class="mainTable fullWidthTable wSpace">
                <div class="row-form">
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.practiceID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.practiceID
                          ? () =>
                              this.openPopup(
                                "practice",
                                this.state.visitModel.practiceID
                              )
                          : undefined
                      }
                    >
                      Practice
                    </label>

                    <div class="selectBoxValidate">
                      <select
                        name="practiceID"
                        id="practiceID"
                        value={this.state.visitModel.practiceID}
                        onChange={this.handleChange}
                      >
                        {this.state.practice.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                      {this.state.validationModel.practiceValField}
                    </div>
                  </div>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.locationID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.locationID
                          ? () =>
                              this.openPopup(
                                "location",
                                this.state.visitModel.locationID
                              )
                          : undefined
                      }
                    >
                      Location
                    </label>

                    <div class="selectBoxValidate">
                      <select
                        name="locationID"
                        id="locationID"
                        value={this.state.visitModel.locationID}
                        onChange={this.handleChange}
                      >
                        {this.state.location.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                      {this.state.validationModel.locationValField}
                    </div>
                  </div>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.posid ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.posid
                          ? () =>
                              this.openPopup("pos", this.state.visitModel.posid)
                          : undefined
                      }
                    >
                      POS
                    </label>

                    <div class="selectBoxValidate">
                      <select
                        name="posid"
                        id="posid"
                        value={this.state.visitModel.posid}
                        onChange={this.handleChange}
                      >
                        {this.state.pos.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                      {this.state.validationModel.posValField}
                    </div>
                  </div>
                </div>

                <div class="row-form">
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.providerID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.providerID
                          ? () =>
                              this.openPopup(
                                "provider",
                                this.state.visitModel.providerID
                              )
                          : undefined
                      }
                    >
                      Provider
                    </label>

                    <div class="selectBoxValidate">
                      <select
                        name="providerID"
                        id="providerID"
                        value={this.state.visitModel.providerID}
                        onChange={this.handleChange}
                      >
                        {this.state.provider.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                      {this.state.validationModel.providerValField}
                    </div>
                  </div>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.refProviderID
                          ? "txtUnderline"
                          : ""
                      }
                      onClick={
                        this.state.visitModel.refProviderID
                          ? () =>
                              this.openPopup(
                                "refprovider",
                                this.state.visitModel.refProviderID
                              )
                          : undefined
                      }
                    >
                      Ref. Provider
                    </label>

                    <div class="selectBoxValidate">
                      <select
                        name="refProviderID"
                        id="refProviderID"
                        value={this.state.visitModel.refProviderID}
                        onChange={this.handleChange}
                      >
                        {this.state.refProvider.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                    </div>
                  </div>

                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.supervisingProvID
                          ? "txtUnderline"
                          : ""
                      }
                      onClick={
                        this.state.visitModel.supervisingProvID
                          ? () =>
                              this.openPopup(
                                "superprovider",
                                this.state.visitModel.supervisingProvID
                              )
                          : undefined
                      }
                    >
                      Sup. Provider
                    </label>

                    <div class="selectBoxValidate">
                      <select
                        name="supervisingProvID"
                        id="supervisingProvID"
                        value={this.state.visitModel.supervisingProvID}
                        onChange={this.handleChange}
                      >
                        {this.state.provider.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              <div class="headingtwo mt-25">
                <div class="headingTable">
                  <div class="row">
                    <div class="col-md-6">
                      <p class="pt-15">Diagnosis</p>
                    </div>
                    <div
                      class="col-md-6 headingRight"
                      style={{ marginBottom: "10px" }}
                    >
                      <button
                        id="showDiagnosisRow"
                        class="btn-blue-icon mt-0"
                        onClick={this.addDiagnosisRow}
                      >
                        More Diagnosis{" "}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div class="mainTable fullWidthTable">
                <div class="row-form" style={{ overflow: "visible" }}>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.icD1ID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.icD1ID
                          ? () =>
                              this.openPopup(
                                "icd1",
                                this.state.visitModel.icD1ID
                              )
                          : undefined
                      }
                    >
                      D1{" "}
                    </label>

                    <div class="selectBoxValidate">
                      <Select
                        className=' this.state.validationModel.icd1ValField
                        ? this.errorField
                        : ""'
                        data-tip
                        data-for="happyFace"
                        value={this.state.visitModel.icd1Obj}
                        onChange={event =>
                          this.handleICD1Change(event, "icD1ID", "icd1Obj")
                        }
                        options={this.state.options}
                        placeholder=""
                        isClearable={true}
                        isSearchable={true}
                        menuPosition="fixed"
                        openMenuOnClick={false}
                        escapeClearsValue={true}
                      />
                      
                      {this.state.validationModel.icd1ValField}
                    </div>
                  </div>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.icD2ID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.icD2ID
                          ? () =>
                              this.openPopup(
                                "icd2",
                                this.state.visitModel.icD2ID
                              )
                          : undefined
                      }
                    >
                      D2
                    </label>
                    <div className="textBoxValidate">
                      <Select
                        value={this.state.visitModel.icd2Obj}
                        onChange={event =>
                          this.handleICD1Change(event, "icD2ID", "icd2Obj")
                        }
                        options={this.state.options}
                        placeholder=""
                        i isClearable={true}
                        isSearchable={true}
                        menuPosition="fixed"
                        openMenuOnClick={false}
                        escapeClearsValue={true}
                      />
                      {this.state.validationModel.icd2ValField}
                    </div>
                  </div>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.icD3ID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.icD3ID
                          ? () =>
                              this.openPopup(
                                "icd3",
                                this.state.visitModel.icD3ID
                              )
                          : undefined
                      }
                    >
                      D3
                    </label>
                    <div className="textBoxValidate">
                      <Select
                        value={this.state.visitModel.icd3Obj}
                        onChange={event =>
                          this.handleICD1Change(event, "icD3ID", "icd3Obj")
                        }
                        options={this.state.options}
                        placeholder=""
                        isClearable={true}
                        isSearchable={true}
                        menuPosition="fixed"
                        openMenuOnClick={false}
                        escapeClearsValue={true}
                      />
                      {this.state.validationModel.icd3ValField}
                    </div>
                  </div>
                </div>
                <div class="row-form" style={{ overflow: "visible" }}>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.icD4ID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.icD4ID
                          ? () =>
                              this.openPopup(
                                "icd4",
                                this.state.visitModel.icD4ID
                              )
                          : undefined
                      }
                    >
                      D4
                    </label>
                    <div class="textBoxValidate">
                      <Select
                        value={this.state.visitModel.icd4Obj}
                        onChange={event =>
                          this.handleICD1Change(event, "icD4ID", "icd4Obj")
                        }
                        options={this.state.options}
                        placeholder=""
                        isClearable={true}
                        isSearchable={true}
                        menuPosition="fixed"
                        openMenuOnClick={false}
                        escapeClearsValue={true}
                      />
                      {this.state.validationModel.icd4ValField}
                    </div>
                  </div>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.icD5ID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.icD5ID
                          ? () =>
                              this.openPopup(
                                "icd5",
                                this.state.visitModel.icD5ID
                              )
                          : undefined
                      }
                    >
                      D5
                    </label>
                    <div className="textBoxValidate">
                      <Select
                        value={this.state.visitModel.icd5Obj}
                        onChange={event =>
                          this.handleICD1Change(event, "icD5ID", "icd5Obj")
                        }
                        options={this.state.options}
                        placeholder=""
                        isClearable={true}
                        isSearchable={true}
                        menuPosition="fixed"
                        openMenuOnClick={false}
                        escapeClearsValue={true}
                      />
                      {this.state.validationModel.icd5ValField}
                    </div>
                  </div>
                  <div class="mf-4">
                    <label
                      className={
                        this.state.visitModel.icD6ID ? "txtUnderline" : ""
                      }
                      onClick={
                        this.state.visitModel.icD6ID
                          ? () =>
                              this.openPopup(
                                "icd6",
                                this.state.visitModel.icD6ID
                              )
                          : undefined
                      }
                    >
                      D6
                    </label>
                    <div class="textBoxValidate">
                      <Select
                        value={this.state.visitModel.icd6Obj}
                        onChange={event =>
                          this.handleICD1Change(event, "icD6ID", "icd6Obj")
                        }
                        options={this.state.options}
                        placeholder=""
                        isClearable={true}
                        isSearchable={true}
                        menuPosition="fixed"
                        openMenuOnClick={false}
                        escapeClearsValue={true}
                      />
                      {this.state.validationModel.icd6ValField}
                    </div>
                  </div>
                </div>

                {this.state.diagnosisRow ? (
                  <div>
                    <div class="row-form" style={{ overflow: "visible" }}>
                      <div class="mf-4">
                        <label
                          className={
                            this.state.visitModel.icD7ID ? "txtUnderline" : ""
                          }
                          onClick={
                            this.state.visitModel.icD7ID
                              ? () =>
                                  this.openPopup(
                                    "icd7",
                                    this.state.visitModel.icD7ID
                                  )
                              : undefined
                          }
                        >
                          D7{" "}
                        </label>
                        <div class="textBoxValidate">
                          <Select
                            value={this.state.visitModel.icd7Obj}
                            onChange={event =>
                              this.handleICD1Change(event, "icD7ID", "icd7Obj")
                            }
                            options={this.state.options}
                            placeholder=""
                            isClearable={true}
                            isSearchable={true}
                            menuPosition="fixed"
                            openMenuOnClick={false}
                            escapeClearsValue={true}
                          />
                          {this.state.validationModel.icd7ValField}
                        </div>
                      </div>
                      <div class="mf-4">
                        <label
                          className={
                            this.state.visitModel.icD8ID ? "txtUnderline" : ""
                          }
                          onClick={
                            this.state.visitModel.icD8ID
                              ? () =>
                                  this.openPopup(
                                    "icd8",
                                    this.state.visitModel.icD8ID
                                  )
                              : undefined
                          }
                        >
                          D8
                        </label>
                        <div className="textBoxValidate">
                          <Select
                            value={this.state.visitModel.icd8Obj}
                            onChange={event =>
                              this.handleICD1Change(event, "icD8ID", "icd8Obj")
                            }
                            options={this.state.options}
                            placeholder=""
                            isClearable={true}
                            isSearchable={true}
                            menuPosition="fixed"
                            openMenuOnClick={false}
                            escapeClearsValue={true}
                          />
                          {this.state.validationModel.icd8ValField}
                        </div>
                      </div>
                      <div class="mf-4">
                      <label
                          className={
                            this.state.visitModel.icD9ID ? "txtUnderline" : ""
                          }
                          onClick={
                            this.state.visitModel.icD9ID
                              ? () =>
                                  this.openPopup(
                                    "icd9",
                                    this.state.visitModel.icD9ID
                                  )
                              : undefined
                          }
                        >
                          D9
                        </label>
                        <div className="textBoxValidate">
                          <Select
                            value={this.state.visitModel.icd9Obj}
                            onChange={event =>
                              this.handleICD1Change(event, "icD9ID", "icd9Obj")
                            }
                            options={this.state.options}
                            placeholder=""
                            isClearable={true}
                            isSearchable={true}
                            menuPosition="fixed"
                            openMenuOnClick={false}
                            escapeClearsValue={true}
                          />
                          {this.state.validationModel.icd9ValField}
                        </div>
                      </div>
                    </div>
                    <div class="row-form" style={{ overflow: "visible" }}>
                      <div class="mf-4">
                      <label
                          className={
                            this.state.visitModel.icD10ID ? "txtUnderline" : ""
                          }
                          onClick={
                            this.state.visitModel.icD10ID
                              ? () =>
                                  this.openPopup(
                                    "icd10",
                                    this.state.visitModel.icD10ID
                                  )
                              : undefined
                          }
                        >
                          D10
                        </label>
                        <div class="textBoxValidate">
                          <Select
                            value={this.state.visitModel.icd10Obj}
                            onChange={event =>
                              this.handleICD1Change(
                                event,
                                "icD10ID",
                                "icd10Obj"
                              )
                            }
                            options={this.state.options}
                            placeholder=""
                            isClearable={true}
                            isSearchable={true}
                            menuPosition="fixed"
                            openMenuOnClick={false}
                            escapeClearsValue={true}
                          />
                          {this.state.validationModel.icd10ValField}
                        </div>
                      </div>
                      <div class="mf-4">
                      <label
                          className={
                            this.state.visitModel.icD11ID ? "txtUnderline" : ""
                          }
                          onClick={
                            this.state.visitModel.icD11ID
                              ? () =>
                                  this.openPopup(
                                    "icd11",
                                    this.state.visitModel.icD11ID
                                  )
                              : undefined
                          }
                        >
                          D11
                        </label>
                        <div className="textBoxValidate">
                          <Select
                            value={this.state.visitModel.icd11Obj}
                            onChange={event =>
                              this.handleICD1Change(
                                event,
                                "icD11ID",
                                "icd11Obj"
                              )
                            }
                            options={this.state.options}
                            placeholder=""
                            isClearable={true}
                            isSearchable={true}
                            menuPosition="fixed"
                            openMenuOnClick={false}
                            escapeClearsValue={true}
                          />
                          {this.state.validationModel.icd11ValField}
                        </div>
                      </div>
                      <div class="mf-4">
                      <label
                          className={
                            this.state.visitModel.icD12ID ? "txtUnderline" : ""
                          }
                          onClick={
                            this.state.visitModel.icD12ID
                              ? () =>
                                  this.openPopup(
                                    "icd12",
                                    this.state.visitModel.icD12ID
                                  )
                              : undefined
                          }
                        >
                          D12
                        </label>
                        <div class="textBoxValidate">
                          <Select
                            value={this.state.visitModel.icd12Obj}
                            onChange={event =>
                              this.handleICD1Change(
                                event,
                                "icD12ID",
                                "icd12Obj"
                              )
                            }
                            options={this.state.options}
                            placeholder=""
                            isClearable={true}
                            isSearchable={true}
                            menuPosition="fixed"
                            openMenuOnClick={false}
                            escapeClearsValue={true}
                          />
                          {this.state.validationModel.icd12ValField}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  ""
                )}
              </div>

              <div class="headingtwo mt-25">
                <p>Service Lines</p>
              </div>

              <div class="mainTable fullWidthTable">
                <div class="mf-12 table-grid mt-15">
                  <div class="row headingTable">
                    <div class="mf-6">
                      <h1>SERVICE LINES</h1>
                    </div>
                    <div class="mf-6 headingRightTable">
                      <button class="btn-blue" onClick={this.addCPTRow}>
                        Add CPT{" "}
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="tableGridContainer">
                      <MDBDataTable                       
                        striped
                        bordered
                        searching={false}
                        data={tableData}
                        displayEntries={false}
                        //sortable={true}
                        scrollX={false}
                        scrollY={false}
                        responsive
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div class="mainTable fullWidthTable mt-25">
                <div class="row-form">
                  <div class="mf-4">
                    <label>Total Amount</label>
                    <input
                      disabled
                      type="text"
                      value={this.state.visitModel.totalAmount}
                      name="totalAmount"
                      id="totalAmount"
                      onChange={this.handleChange}
                    ></input>
                  </div>
                  <div class="mf-4">
                    <label>Copay</label>
                    <input
                      type="text"
                      value={this.state.visitModel.coPay}
                      name="coPay"
                      id="coPay"
                      onChange={this.handleAmountChange}
                    ></input>
                  </div>
                  <div class="mf-4">&nbsp;</div>
                </div>
              </div>

              <div className="mf-12 headingtwo mt-25">
                <p>Submission Info</p>
              </div>
              <div className="mainTable fullWidthTable wSpace">
                <div className="row-form">
                  <div className="mf-4">
                    <label>Submitted</label>
                    <div class="textBoxValidate">
                      <div className="lblChkBox">
                        <input
                          type="checkbox"
                          checked={this.state.visitModel.isSubmitted}
                          id="markInactive0"
                          name=""
                        />
                        <label for="markInactive0">
                          <span></span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="mf-4">
                    <label>Submitted Date </label>
                    <input
                      disabled
                      type="text"
                      value={submittedDate}
                      name="submittetdDate"
                      id=""
                    ></input>
                  </div>
                  <div className="mf-4">
                    <label>Submission Batch</label>
                    <input
                      disabled
                      type="text"
                      value={this.state.visitModel.submissionLogID}
                      name=""
                      id=""
                    ></input>
                  </div>
                </div>

                <div className="row-form">
                  <div className="mf-12 field_full-12">
                    <label>Rejection Reason</label>
                    <input
                      disabled
                      type="text"
                      value={this.state.visitModel.rejectionReason}
                      name=""
                      id=""
                    ></input>
                  </div>
                </div>
              </div>

              <div class="headingtwo mt-25">
                <p>Extra Information</p>
              </div>

              <div class="mainTable fullWidthTable">
                <div class="row-form">
                  <div class="mf-12">
                    <Tabs headers={headers} style={{ cursor: "default" }}>
                      <Tab>
                        <div style={{ marginTop: "20px" }}>
                          <div
                            class="mainTable fullWidthTable wSpace"
                            style={{ maxWidth: "100%" }}
                          >
                            <div class="row-form">
                              <div class="mf-6">
                                <label>Authorization #</label>
                                <input
                                  maxlength="20"
                                  type="text"
                                  value={this.state.visitModel.authorizationNum}
                                  name="authorizationNum"
                                  id="authorizationNum"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-6">&nbsp;</div>
                            </div>
                            <div class="row-form">
                              <div class="mf-6">
                                <label for="markInactive">
                                  Outside Referral
                                </label>
                                <div
                                  class="textBoxValidate"
                                  onClick={this.handleOutsideRefCheck}
                                >
                                  <div class="lblChkBox">
                                    <input
                                      type="checkbox"
                                      id="outsideReferral"
                                      name="outsideReferral"
                                      checked={
                                        this.state.visitModel.outsideReferral
                                      }
                                    ></input>
                                    <label for="markInactive">
                                      <span></span>
                                    </label>
                                  </div>
                                </div>
                              </div>
                              <div class="mf-6">
                                <label>Referral#</label>
                                <input
                                  maxLength="20"
                                  type="text"
                                  value={this.state.visitModel.referralNum}
                                  name="referralNum"
                                  id="referralNum"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                            </div>
                            <div className="row-form">
                              <div class="mf-6">
                                <label>Onset Date of Current illness</label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="onsetDateOfIllness"
                                    id="onsetDateOfIllness"
                                    value={onsetDateOfIllness}
                                    onChange={this.handleChange}
                                  ></input>
                                  {this.state.validationModel.onSetDateOfSimiliarIllnessValField}
                                </div>
                              </div>
                              <div class="mf-6">
                                <label>First date of similar illness</label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="firstDateOfSimiliarIllness"
                                    id="firstDateOfSimiliarIllness"
                                    value={firstDateOfSimiliarIllness}
                                    onChange={this.handleChange}
                                  ></input>
                                </div>
                              </div>
                            </div>
                            <div class="row-form">
                              <div class="mf-6">
                                <label>Initial Treatment date </label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="illnessTreatmentDate"
                                    id="illnessTreatmentDate"
                                    value={illnessTreatmentDate}
                                    onChange={this.handleChange}
                                  ></input>
                                </div>
                              </div>
                              <div class="mf-6">
                                <label>Date of Pregnancy(LMP)</label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="dateOfPregnancy"
                                    id="dateOfPregnancy"
                                    value={dateOfPregnancy}
                                    onChange={this.handleChange}
                                  ></input>
                                </div>
                              </div>
                            </div>
                            <div class="row-form">
                              <div class="mf-6">
                                <label>Admission Date</label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="admissionDate"
                                    id="admissionDate"
                                    value={admissionDate}
                                    onChange={this.handleChange}
                                  ></input>
                                </div>
                              </div>
                              <div class="mf-6">
                                <label>Discharge Date</label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="dischargeDate"
                                    id="dischargeDate"
                                    value={dischargeDate}
                                    onChange={this.handleChange}
                                  ></input>
                                   {this.state.validationModel.dischargeDateValField}
                                </div>
                              </div>
                            </div>

                            <div className="row-form">
                              <div class="mf-6">
                                <label>Last X-ray Date </label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="lastXrayDate"
                                    id="lastXrayDate"
                                    value={lastXrayDate}
                                    onChange={this.handleChange}
                                  ></input>
                                </div>
                              </div>
                              <div class="mf-6">
                                <label>Last X-ray Type</label>
                                <input
                                  type="text"
                                  value={this.state.visitModel.lastXrayType}
                                  name="lastXrayType"
                                  id="lastXrayType"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                            </div>
                            <div class="row-form">
                              <div class="mf-6">
                                <label>Unable to Work From Date</label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="unableToWorkFromDate"
                                    id="unableToWorkFromDate"
                                    value={unableToWorkFromDate}
                                    onChange={this.handleChange}
                                  ></input>
                                </div>
                              </div>
                              <div class="mf-6">
                                <label>Unable To Work To Date</label>
                                <div class="textBoxValidate">
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="unableToWorkToDate"
                                    id="unableToWorkToDate"
                                    value={unableToWorkToDate}
                                    onChange={this.handleChange}
                                  ></input>
                                   {this.state.validationModel.unableToWorkFromDateValFields}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Tab>
                      <Tab>
                        <div style={{ marginTop: "20px" }}>
                          <div
                            class="mainTable fullWidthTable wSpace"
                            style={{ maxWidth: "100%" }}
                          >
                            <div class="row-form">
                              <div class="mf-6">
                                <label>Accident Date</label>
                                <div class="textBoxValidate">
                                  {/* <input type="text" value="" name="" id="" onChange={this.handleChange}></input>
                                  <img class="calendarIcon" src={dob_icon}></img> */}
                                  <input
                                    style={{
                                      width: "215px",
                                      marginLeft: "0px"
                                    }}
                                    className="myInput"
                                    type="date"
                                    name="accidentDate"
                                    id="accidentDate"
                                    value={accidentDate}
                                    onChange={this.handleChange}
                                  ></input>
                                </div>
                              </div>
                              <div class="mf-6">
                                <label>Accident Type</label>
                                <div class="selectBoxValidate">
                                  <select
                                    name="accidentType"
                                    id="accidentType"
                                    value={this.state.visitModel.accidentType}
                                    onChange={this.handleChange}
                                  >
                                    {accidentType.map(s => (
                                      <option key={s.value} value={s.value}>
                                        {" "}
                                        {s.display}{" "}
                                      </option>
                                    ))}{" "}
                                  </select>
                                </div>
                              </div>
                            </div>

                            <div className="row-form">
                              <div class="mf-6">
                                <label>Accident State</label>
                                {/* <input type="text" value={this.state.visitModel.accidentState} name="accidentState" id="accidentState"  max="20"
                                onChange={this.handleChange}></input> */}
                                <div class="selectBoxValidate">
                                  <select
                                    name="accidentState"
                                    id="accidentState"
                                    value={this.state.visitModel.accidentState}
                                    onChange={this.handleChange}
                                  >
                                    {usStates.map(s => (
                                      <option key={s.value} value={s.value}>
                                        {" "}
                                        {s.display}{" "}
                                      </option>
                                    ))}{" "}
                                  </select>
                                </div>
                              </div>
                              <div class="mf-6 mf-icon">
                                <label>CLIA #</label>

                                <div className="textBoxValidate">
                                {/* <input
                                  maxlength="10"
                                  type="text"
                                  value={this.state.visitModel.cliaNumber}
                                  name="cliaNumber"
                                  id="cliaNumber"
                                  onChange={this.handleChange}
                                  
                                ></input> */}


                                <Input className={this.state.validationModel.cliaNumberValField ? this.errorField : ""}
                                type="text" value={this.state.visitModel.cliaNumber} name="cliaNumber" id="cliaNumber" max='10'
                                  onChange={() => this.handleChange} />


                                 {this.state.validationModel.cliaNumberValField}
                                 </div>






                              </div>
                            </div>
                            <div class="row-form">
                              <div class="mf-6">
                                <label for="outsidelab">Outside lab</label>
                                <div
                                  class="textBoxValidate"
                                  onClick={this.handleOutsideLabCheck}
                                >
                                  <div class="lblChkBox">
                                    <input
                                      type="checkbox"
                                      id="outsideLab"
                                      name="outsideLab"
                                      checked={this.state.visitModel.outsideLab}
                                    ></input>
                                    <label for="outsidelab">
                                      <span></span>
                                    </label>
                                  </div>
                                </div>
                              </div>
                              <div class="mf-6">
                                <label>Lab Charges</label>
                                <input
                                  type="text"
                                  value={this.state.visitModel.labCharges}
                                  name="labCharges"
                                  id="labCharges"
                                  onChange={this.handleAmountChange}
                                ></input>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Tab>
                      <Tab>
                        <div style={{ marginTop: "20px" }}>
                          <div
                            class="mainTable fullWidthTable wSpace"
                            style={{ maxWidth: "100%" }}
                          >
                            <div class="row-form">
                              <div class="mf-6">
                                <label>Payer Claim Control #</label>
                                <input
                                  disabled
                                  type="text"
                                  value={this.state.payerClaimControlNum}
                                  name="payerClaimControlNum"
                                  id="payerClaimControlNum"
                                  onChange={this.handleChange}
                                  data-tip
                                  data-for="payerClaimControlNum"
                                ></input>
                              </div>
                              <div class="mf-6">
                                <label>Claim Frequency</label>
                                {/* <input type="text" value={this.state.claimFrequencyCode} 
                                name="claimFrequencyCode"
                                 id="claimFrequencyCode" 
                                 onChange={this.handleChange}></input> */}
                                <div class="selectBoxValidate">
                                  <select
                                    name="claimFrequencyCode"
                                    id="claimFrequencyCode"
                                    value={
                                      this.state.visitModel.claimFrequencyCode
                                    }
                                    onChange={this.handleChange}
                                  >
                                    {claimFrequencyCode.map(s => (
                                      <option key={s.value} value={s.value}>
                                        {" "}
                                        {s.display}{" "}
                                      </option>
                                    ))}{" "}
                                  </select>
                                </div>
                              </div>
                            </div>
                            <div className="row-form">
                              <div class="mf-6">
                                <label>Service Auth. Exeption Code</label>
                                <input
                                  maxLength="20"
                                  type="text"
                                  value={this.state.serviceAuthExcpCode}
                                  name="serviceAuthExcpCode"
                                  id="serviceAuthExcpCode"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                              <div className="mf-6"></div>
                            </div>
                            <div class="row-form">
                              <div class="mf-4">
                                <label for="emergency">Emergency</label>
                                <div class="textBoxValidate">
                                  <div class="lblChkBox">
                                    <input
                                      type="checkbox"
                                      id="emergency"
                                      name=""
                                      checked={this.state.visitModel.emergency}
                                      onClick={this.handleEmergencyCheck}
                                    ></input>
                                    <label for="emergency">
                                      <span></span>
                                    </label>
                                  </div>
                                </div>
                              </div>

                              <div class="mf-4">
                                <label for="epsdtchkbox">EPSDT</label>
                                <div
                                  class="textBoxValidate"
                                  onClick={this.handleEPSDTCheck}
                                >
                                  <div class="lblChkBox">
                                    <input
                                      type="checkbox"
                                      id="epsdtchkbox"
                                      name=""
                                      checked={this.state.visitModel.epsdt}
                                    ></input>
                                    <label for="epsdtchkbox">
                                      <span></span>
                                    </label>
                                  </div>
                                </div>
                              </div>
                              <div class="mf-4">
                                <label for="familyplan">Family Plan</label>
                                <div
                                  class="textBoxValidate"
                                  onClick={this.handleFamilyPlanCheck}
                                >
                                  <div class="lblChkBox">
                                    <input
                                      type="checkbox"
                                      id="familyplan"
                                      name=""
                                      checked={this.state.visitModel.familyPlan}
                                    ></input>
                                    <label for="familyplan">
                                      <span></span>
                                    </label>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row-form">
                              <div class="mf-12 field_full-12">
                                <label>Claim Notes</label>
                                <textarea
                                  name="claimNotes"
                                  id="claimNotes"
                                  value={this.state.visitModel.claimNotes}
                                  onChange={this.handleChange}
                                  cols="30"
                                  rows="10"
                                ></textarea>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Tab>
                    </Tabs>
                  </div>
                </div>
              </div>

              <div className="modal-footer">
                <div className="mainTable">
                  <div className="row-form row-btn">
                    <div className="mf-12">
                      <button className="btn-blue" onClick={this.saveCharge}>
                        Save{" "}
                      </button>
                      <button
                        id="btnCancel"
                        className="btn-grey"
                        data-dismiss="modal"
                        onClick = {this.state.popupVisitId > 0 ? this.props.onClose() : this.closeNewCharge.bind(this) }  
                        // onClick={this.closeNewCharge.bind(this)}
                      >
                        Cancel{" "}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {popup}
      </React.Fragment>
    );
  }
}


function mapStateToProps(state) {
  console.log("state from Header Page" , state);
  return {
      selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
      selectedTabPage: state.selectedTabPage,
      selectedPopup: state.selectedPopup,
      id: state.selectedTab !== null ? state.selectedTab.id : 0,
      setupLeftMenu: state.leftNavigationMenus,
      loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
      userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(NewCharge);
