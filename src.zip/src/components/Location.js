import React, { Component } from 'react'
import axios from 'axios';
import { MDBDataTable, MDBBtn } from 'mdbreact';
import Input from './Input'
import Label from './Label'
import GridHeading from './GridHeading';
import searchIcon from '../images/search-icon.png'
import refreshIcon from '../images/refresh-icon.png'
import newBtnIcon from '../images/new-page-icon.png'
import settingsIcon from '../images/setting-icon.png'
import NewLocation from './NewLocation.js'
import SearchHeading from "./SearchHeading";


import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

import $ from 'jquery';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'
import NewPractice from './NewPractice';


export class Location extends Component {
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/Location/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        this.searchModel = {
            name: '',
            organizationName: '',
            practice: '',
            npi: '',
            posCode: '',
            address: ''

        }
        this.state = {
            searchModel: this.searchModel,
            id: 0,
            data: [],
            showPopup: false,
            showPracticePopup: false,
            loading:false
        }

        this.searchLocation = this.searchLocation.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.clearFields = this.clearFields.bind(this);

        this.openLocationPopup = this.openLocationPopup.bind(this);
        this.closeLocationPopup = this.closeLocationPopup.bind(this);
        this.openPracticePopup = this.openPracticePopup.bind(this);
        this.closePracticePopup = this.closePracticePopup.bind(this);

    }
    searchLocation = (e) => {
        e.preventDefault()
        console.log(this.state.searchModel);
        this.setState({loading:true})

        axios.post(this.url + 'FindLocations', this.state.searchModel  ,this.config)
            .then(response => {
                let newList = []
                response.data.map((row, i) => {
                    console.log(row)
                    newList.push({
                        id: row.id,
                        name: <MDBBtn className='gridBlueBtn' onClick={() => this.openLocationPopup(row.id)}>{row.name}</MDBBtn>,
                        organizationName: row.organizationName,
                        practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPracticePopup(row.practiceID)}>{row.practice}</MDBBtn>,
                        npi: row.npi,
                        posCode: row.posCode,
                        address: row.address
                    });
                });
                this.setState({ data: newList , loading:false });
            }).catch(error => {
                this.setState({loading:false})
                console.log(error)
            });
        e.preventDefault();
    }

    componentDidMount = (e) => {
        // axios.post(this.url + '/FindLocations', this.state)
        //     .then(response => {
        //         console.log(response.data);
        //         this.setState({ data: response.data });
        //         console.log("DATA IS " + this.state.data);
        //     }).catch(error => {
        //         console.log(error)
        //     });
    }

    handleChange = event => {
        console.log(event.target.value)
        event.preventDefault();
        this.setState({
            searchModel: { [event.target.name]: event.target.value.toUpperCase() }
        });
    };


    clearFields = event => {
        console.log('claer')
        this.setState({
            searchModel: this.searchModel
        });
    };

    openLocationPopup = (id) => {
        this.setState({ showPopup: true, id: id });
    }

    closeLocationPopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    openPracticePopup = (id) => {
        this.setState({ showPracticePopup: true, id: id });
    }

    closePracticePopup = () => {
        $('#myModal').hide()
        this.setState({ showPracticePopup: false });
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }
    render() {
        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    // width: 150,
                },
                {
                    label: 'NAME',
                    field: 'name',
                    sort: 'asc',
                    // width: 250
                },
                {
                    label: 'ORGANIZATION NAME',
                    field: 'organizationName',
                    sort: 'asc',
                    // width: 150
                },
                {
                    label: 'Practice',
                    field: 'practice',
                    sort: 'asc',
                    // width: 150
                },
                {
                    label: 'NPI',
                    field: 'npi',
                    sort: 'asc',
                    // width: 150
                },
                {
                    label: 'POSCODE',
                    field: 'posCode',
                    sort: 'asc',
                    // width: 150
                },
                {
                    label: 'ADDRESS',
                    field: 'address',
                    sort: 'asc',
                    // width: 150
                }
            ],
            rows: this.state.data
        };
        let popup = ''

        if (this.state.showPopup) {
            popup = <NewLocation onClose={() => this.closeLocationPopup} id={this.state.id}></NewLocation>
        }
        else if (this.state.showPracticePopup) {
            popup = <NewPractice onClose={() => this.closePracticePopup} id={this.state.id}></NewPractice>
        } else
            popup = <React.Fragment></React.Fragment>

            let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }
        return (
            <div>
                < React.Fragment >
                {spiner}
                    
                     <SearchHeading heading='LOCATION SEARCH' handler={() => this.openLocationPopup(0)}></SearchHeading>
                        {/* <div className="col-md-6 headingRight">
                            <a className="btn-icon" href=""> <img src={searchIcon} alt="" /> </a>
                            <a className="btn-icon" href=""> <img src={refreshIcon} alt="" /> </a>
                            <a className="btn-icon" href=""> <img src={newBtnIcon} alt="" /> </a>
                            <a className="btn-icon" href=""> <img src={settingsIcon} alt="" /> </a>
                            <button data-toggle="modal" data-target=".bs-example-modal-new" className="btn-blue-icon"
                                onClick={() => this.openLocationPopup(0)}>Add New +</button>
                        </div> */}
                    

                    <form onSubmit={event => this.searchLocation(event)}>
                        <div className="mainTable">

                            <div className="row-form">
                                <div className="mf-6">
                                    <Label name='Name'></Label>
                                    <Input type='text' name='name' id='name' max='20' value={this.state.searchModel.name} onChange={() => this.handleChange} />
                                </div>
                                <div className="mf-6">
                                    <Label name='Organization Name'></Label>
                                    <Input type='text' name='organizationName' id='organizationName' max='20'
                                        value={this.state.searchModel.organizationName} onChange={() => this.handleChange} />
                                </div>
                            </div>

                            <div className="row-form">
                                <div className="mf-6">
                                    <Label name='Practice'></Label>
                                    <Input type='text' name='practice' id='practice' max='20' value={this.state.searchModel.practice} onChange={() => this.handleChange} />
                                </div>
                                <div className="mf-6">
                                    <Label name='NPI'></Label>
                                    <Input type='text' name='npi' id='npi' max='10' onKeyPress={event => this.handleNumericCheck(event)} value={this.state.searchModel.npi} onChange={() => this.handleChange} />
                                </div>
                            </div>


                            <div className="row-form">
                                <div className="mf-6">
                                    <Label name='POS Code'></Label>
                                    <Input type='text' name='posCode' id='posCode' max='20' value={this.state.searchModel.posCode} onChange={() => this.handleChange} />
                                </div>
                                <div className="mf-6">
                                    <label>&nbsp;</label>
                                </div>
                            </div>

                            <div className="row-form row-btn">
                                <div className="mf-12">
                                    <Input type='submit' name='name' id='name' className='btn-blue' value='Search' />
                                    <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                                </div>
                            </div>
                        </div>

                    </form>


                    <div className="mf-12 table-grid mt-15">
                        <GridHeading Heading='LOCATION SEARCH RESULT'></GridHeading>

                        <div className="tableGridContainer">
                            <MDBDataTable
                                responsive={true}
                                striped
                                bordered
                                searching={false}
                                data={data}
                                displayEntries={false}
                                sortable={true}
                                scrollX={false}
                                scrollY={false}
                            />
                        </div>


                    </div>


                    {popup}

                </React.Fragment >
            </div>
        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(Location);