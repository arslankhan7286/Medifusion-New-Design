import React, { Component } from "react";
import { MDBBtn } from "mdbreact";
import $ from "jquery";


import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import axios from "axios";
import { MDBDataTable } from "mdbreact";
import Swal from "sweetalert2";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
// import moment from "react-moment";

import SearchHeading from "./SearchHeading";
//import NewPayment from './NewPayment'

import Label from "./Label";
import Input from "./Input";


import format from "date-fns/format"

import dob from '../images/dob-icon.png'


import searchIcon from '../images/search-icon.png'
import refreshIcon from '../images/refresh-icon.png'
import newBtnIcon from '../images/new-page-icon.png'
import settingsIcon from '../images/setting-icon.png'
import { read } from "fs";

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'



class PaymentSearch extends Component {
    constructor(props) {
        super(props);

        this.url = process.env.REACT_APP_URL + "/PaymentCheck/";
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        this.searchModel = {
            entryDateTo: null,
            entryDateFrom: null,
            checkDateFrom: null,
            checkDateTo: null,
            checkNumber: '',
            facility: '',
            payer: ''
        };

        this.fileData = {
            content: '',
            name: '',
            size: '',
            type: '',
            clientID: 0
        }

        this.state = {
            searchModel: this.searchModel,
            data: [],
            pickerOpen: false,
            selectedDate: null,
            showPopup: false,
            id: 0,
            loading : false
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleNumericCheck = this.handleNumericCheck.bind(this);
        this.handleCheck = this.handleCheck.bind(this);
        this.handleDosFromChange = this.handleDosFromChange.bind(this);
        this.handleDosToChange = this.handleDosToChange.bind(this);
        this.handleEnterToChange = this.handleEnterToChange.bind(this);
        this.handleEnterFromChange = this.handleEnterFromChange.bind(this);
        this.closePaymentPopup = this.closePaymentPopup.bind(this);
        this.clearFields = this.clearFields.bind(this);

        this.openPaymentPopup = this.openPaymentPopup.bind(this);
        this.importEra = this.importEra.bind(this);
        this.handleDateChange = this.handleDateChange.bind(this);
        this.openVisitScreen = this.openVisitScreen.bind(this);
        this.openManualPosting = this.openManualPosting.bind(this);
    }

    handleChange = event => {

        this.setState({
            searchModel: {
                ...this.state.searchModel,
                [event.target.name]: event.target.value.toUpperCase()
            }
        });

    };

    openVisitScreen(id) {
        this.props.selectTabAction("ManualPosting", id);
    }

    openManualPosting() {
        this.props.selectTabAction("ManualPosting");
    }


    handleSearch = event => {
        event.preventDefault();
        console.log("Search Model Data : ", this.state.searchModel);
        this.setState({loading : true})

        axios
            .post(this.url + "FindPaymentChecks", this.state.searchModel  , this.config)
            .then(response => {
                console.log(response.data);
                let newList = [];
                response.data.map(row => {
                    newList.push({
                        id: row.id,
                        checkNumber: (
                            <MDBBtn className="gridBlueBtn" onClick={() => this.openVisitScreen(row.id)}> {row.checkNumber}</MDBBtn>
                        ),
                        paymentMethod: row.paymentMethod,
                        checkDate: row.checkDate,
                        checkAmount: row.checkAmount,
                        appliedamount: row.appliedamount,
                        postedAmount: row.postedAmount,
                        numberOfVisits: row.numberOfVisits,
                        numberOfPatients: row.numberOfPatients,
                        status: row.status,
                        payer: row.payer,
                        facility: row.facility
                    });
                });

                this.setState({ data: newList ,loading : false});
            })
            .catch(error => {
                this.setState({loading : false})
                Swal.fire("Something Wrong", "Please Seach Again", "error");

                let errorsList = [];
                if (error.response !== null && error.response.data !== null) {
                    errorsList = error.response.data;
                    console.log(errorsList);
                } else console.log(error);
            });
    };


    clearFields = event => {
        this.setState({ searchModel: this.searchModel });
    };


    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }

    handleCheck() {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                active: !this.state.searchModel.active,

                isChecked: !this.state.searchModel.isChecked,
            }
        });
    }

    handleDosFromChange = (date) => {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                dosFrom: date,
            }

        });
    };

    handleDosToChange = (date) => {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                dosTo: date,
            }

        });
    };

    handleEnterToChange = (date) => {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                entryDateTo: date,
            }

        });
    };

    handleEnterFromChange = (date) => {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                entryDateFrom: date,
            }

        });
    };

    openPaymentPopup(id) {

        this.setState({ showPopup: true, id: id });
        console.log(id);
    }


    closePaymentPopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    controlYearLength(event) {
        var date = new Date(event.target.value);
        var date1 = date.getFullYear().toString();
        if (date1.length >= 4) {
            event.preventDefault();
            return
        }
        return true;
    }

    handleDateChange(event) {
        console.log(event.target.value);
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                dosFrom: event.target.value
            }
        })
    }


    importEra(e) {
        e.preventDefault();
        this.setState({loading:true})

        let reader = new FileReader();
        reader.readAsDataURL(e.target.files[0]);
        let file = e.target.files[0];

        reader.onloadend = (e) => {
            var url = 'https://localhost:44306/api/payment/ImportEraFile/'

            let obj = this.fileData
            obj.content = reader.result;
            obj.name = file.name;
            obj.size = file.size;
            obj.type = file.type;
            obj.clientID = 1


            axios.post(url, obj  ,  this.config)
                .then(response => {
                    console.log(response);
                    this.setState({loading:false});                   
                })
                .catch(error => {
                    this.setState({loading:false})
                    console.log(error);
                });
        }
    }



    render() {

        const tableData = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "CHECK #",
                    field: "checkNumber",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "TYPE",
                    field: "paymentMethod",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "CHECK DATE",
                    field: "checkDate",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "CHECK AMT.",
                    field: "checkAmount",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "APPLIDED AMT.",
                    field: "appliedamount",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "POSTED AMT.",
                    field: "postedAmount",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "VISIT #",
                    field: "numberOfVisits",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PATIENTS",
                    field: "numberOfPatients",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "STATUS",
                    field: "status",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PAYER",
                    field: "payer",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "FACILITY",
                    field: "facility",
                    sort: "asc",
                    width: 150
                }
            ],
            rows: this.state.data
        };

        let popup = ''

        if (this.state.showPopup) {
            //popup = <NewPayment onClose={() => this.closePaymentPopup} id={this.state.id}></NewPayment>
        }
        else
            popup = <React.Fragment></React.Fragment>

            let spiner = ''
            if (this.state.loading == true) {
                spiner = (
                    <GifLoader
                        loading={true}
                        imageSrc={Eclips}
                        // imageStyle={imageStyle}
                        overlayBackground="rgba(0,0,0,0.5)"
                    />
                )
            }

        return (
            <React.Fragment>
                {spiner}
                <div>
                    <div>
                        <div>
                            {/* <SearchHeading
                                heading="Payment Check SEARCH"
                                btnCaption='Import ERA'
                                handler={() => this.importEra()}
                            ></SearchHeading> */}

                            <div className="mainHeading row">
                                <div className="col-md-6">
                                    <h1>PAYMENT CHECK SEARCH</h1>
                                </div>
                                <div className="col-md-6 headingRight">
                                    {/* <a className="btn-icon" href=""> <img src={searchIcon} alt="" /> </a>
                                    <a className="btn-icon" href=""> <img src={refreshIcon} alt="" /> </a>
                                    <a className="btn-icon" href=""> <img src={newBtnIcon} alt="" /> </a>
                                    <a className="btn-icon" href=""> <img src={settingsIcon} alt="" /> </a> */}



                                    <Input type='button' value='Manual Posting' className="btn-blue" onClick={this.openManualPosting} >Add Manual Posting</Input>

                                    <label for="btnImportEra" style={{ visibility: 'none' }}></label>
                                    <input className="btn-blue-icon"
                                        id="btnImportEra"
                                        type="file"
                                        onChange={e => this.importEra(e)}
                                    />

                                </div>
                            </div>


                            <div className="container-fluid">
                                <form onSubmit={event => { this.handleSearch(event); }}>

                                    <div className="mainTable fullWidthTable" style={{ maxWidth: "1500px" }} >

                                        <div className="row-form">
                                            <div className="mf-3">
                                                <Label name="Entry Date From"></Label>
                                                <div class="textBoxValidate">
                                                    <input
                                                        style={{ marginLeft: "0px" }}
                                                        className="myInput"
                                                        type="date"
                                                        name="entryDateFrom"
                                                        id="entryDateFrom"
                                                        onChange={this.handleDateChange}
                                                        value={this.state.searchModel.entryDateFrom}
                                                        onKeyPress={this.controlYearLength}
                                                    ></input>
                                                </div>
                                            </div>


                                            <div className="mf-3">
                                                <Label name="Entry Date To"></Label>
                                                <div class="textBoxValidate">
                                                    <input
                                                        style={{ marginLeft: "0px" }}
                                                        className="myInput"
                                                        type="date"
                                                        name="entryDateTo"
                                                        id="entryDateTo"
                                                        onChange={this.handleDateChange}
                                                        value={this.state.searchModel.entryDateTo}
                                                        onKeyPress={this.controlYearLength}
                                                    ></input>
                                                </div>
                                            </div>


                                            <div className="mf-3">
                                                <Label name="Check Date From"></Label>
                                                <div class="textBoxValidate">
                                                    <input
                                                        style={{ marginLeft: "0px" }}
                                                        className="myInput"
                                                        type="date"
                                                        name="checkDateFrom"
                                                        id="checkDateFrom"
                                                        onChange={this.handleDateChange}
                                                        value={this.state.searchModel.checkDateFrom}
                                                        onKeyPress={this.controlYearLength}
                                                    ></input>
                                                </div>
                                            </div>

                                            <div className="mf-3">
                                                <Label name="Check Date To"></Label>
                                                <div class="textBoxValidate">
                                                    <input
                                                        style={{ marginLeft: "0px" }}
                                                        className="myInput"
                                                        type="date"
                                                        name="checkDateTo"
                                                        id="checkDateTo"
                                                        onChange={this.handleDateChange}
                                                        value={this.state.searchModel.checkDateTo}
                                                        onKeyPress={this.controlYearLength}
                                                    ></input>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="row-form">
                                            <div className="mf-3">
                                                <Label name="Check #"></Label>
                                                <Input
                                                    type="text"
                                                    name="checkNumber"
                                                    id="checkNumber"
                                                    value={this.state.searchModel.checkNumber}
                                                    onChange={() => this.handleChange}
                                                    onKeyPress={event => this.handleNumericCheck(event)}
                                                ></Input>
                                            </div>
                                            <div className="mf-3">
                                                <Label name="Facility"></Label>
                                                <Input
                                                    type="text"
                                                    name="facility"
                                                    id="facility"
                                                    value={this.state.searchModel.facility}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>
                                            <div className="mf-3">
                                                <Label name="Payer"></Label>
                                                <Input
                                                    type="text"
                                                    name="payer"
                                                    id="payer"
                                                    value={this.state.searchModel.payer}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>

                                            <div className="mf-3">

                                            </div>

                                        </div>

                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <Input
                                                    type="submit"
                                                    name="search"
                                                    id="search"
                                                    className="btn-blue"
                                                    value="Search"
                                                ></Input>
                                                <Input
                                                    type="button"
                                                    name="clear"
                                                    id="clear"
                                                    value="Clear"
                                                    className="btn-grey"
                                                    onClick={event => this.clearFields(event)}
                                                ></Input>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div className="mf-12 table-grid mt-15">
                                <div className="row headingTable">
                                    <div className="mf-6">
                                        <h1>PAYMENT  CHECK SEARCH RESULT</h1>
                                    </div>
                                    <div className="mf-6 headingRightTable">
                                        <a href="javascript:;">
                                            <img src="images/setting-icon.png" alt="" />
                                        </a>
                                    </div>
                                </div>

                                <div className="tableGridContainer">
                                    <MDBDataTable
                                        responsive={true}
                                        striped
                                        bordered
                                        searching={false}
                                        data={tableData}
                                        displayEntries={false}
                                        sortable={true}
                                        scrollX={false}
                                        scrollY={false}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {popup}

            </React.Fragment>
        );
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(PaymentSearch);