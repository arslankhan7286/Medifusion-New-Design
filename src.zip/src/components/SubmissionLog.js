import React, { Component } from 'react'
import axios from 'axios';
import { MDBDataTable, MDBBtn, MDBInput } from 'mdbreact';
import GridHeading from './GridHeading';
import Label from './Label'
import Input from './Input'
import { saveAs } from 'file-saver';
import $ from 'jquery';
import Swal from 'sweetalert2';


import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

export class SubmissionLog extends Component {
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/SubmissionLog/'
        this.elecUrl = process.env.REACT_APP_URL + '/ElectronicSubmission/'
        this.paperUrl = process.env.REACT_APP_URL + '/PaperSubmission/'

        this.electModel = {

            "receiver": '',
            "submitDate": null,
            "submitType": '',
            "isaControllNumber": '',
            "submitBatchNumber": '',
            "formType": ''
        }

        this.state = {
            electModel: this.electModel,
            data: [],
            id: 0,
            revData: [],
            loading:false,
        }
        this.searchSubmissionLog = this.searchSubmissionLog.bind(this);
        this.clearFields = this.clearFields.bind(this);
        this.downloadSubmissionLogs = this.downloadSubmissionLogs.bind(this);
    }


    handleChange = event => {
        event.preventDefault();
        this.setState({
            electModel: { ...this.state.electModel, [event.target.name]: event.target.value.toUpperCase() }
        });
    };

    clearFields = event => {
        this.setState({
            electModel: this.electModel
        });
    };

    componentWillMount() {
        axios.get(this.url + 'GetSubmissionLogs')
            .then(response => {
                console.log(response.data);
                this.setState({
                    revData: response.data.receivers,
                })
            }).catch(error => {
                console.log(error);
            });
    }

    downloadSubmissionLogs(id, submitType) {
        let myUrl = ''
        let contentType = ''
        let outputfile = ''

        if (submitType === 'EDI') {
            myUrl = this.elecUrl + 'DownloadEDIFile/'
            contentType = 'application/txt'
            outputfile = '837.txt'
        }
        else if (submitType === 'Paper') {
            myUrl = this.paperUrl + 'DownloadHCFAFile/'
            contentType = 'application/pdf'
            outputfile = 'hcfa.pdf'
        }

        this.setState({loading:true})
        axios.get(
            myUrl + id, {
            headers: {
                'Content-Type': 'application/json',
            },
            responseType: 'blob',
        })
            .then(function (res) {
                var blob = new Blob([res.data], {
                    type: contentType,
                });

                saveAs(blob, outputfile);
                this.setState({loading:false})
            }).catch(error => {
                this.setState({loading:false})
                if (error.response.status === 404) {
                    console.log(error.response.status)
                    Swal.fire(
                        {
                            type: 'info',
                            text: 'File Not Found on server',
                        })
                }
            });;
    }

    searchSubmissionLog = (e) => {
        console.log(this.state.electModel)
        this.setState({loading : true});

        axios.post(this.url + 'FindSubmissionLog', this.state.electModel)
            .then(response => {
                console.log(response.data)

                let newList = []
                response.data.map((row, i) => {
                    newList.push({

                        id: row.id,
                        submitBatchNumber: row.submitBatchNumber,
                        receiver: row.receiver,
                        formType: row.formType,
                        submitDate: row.submitDate,
                        status: row.status,
                        isaControllNumber: row.isaControllNumber,
                        submitType: row.submitType,
                        notes: row.notes,
                        download: < MDBBtn className='gridBlueBtn' onClick={() => this.downloadSubmissionLogs(row.submitBatchNumber, row.submitType)}> {"Download"}</MDBBtn >,
                    });
                });
                this.setState({
                    data: newList,
                    loading : false

                });
            }).catch(error => {
                this.setState({loading : false})
                console.log(error)
            });
        e.preventDefault();
    }

    render() {

        const subType = [
            { value: "", display: "All" },
            { value: "E", display: "EDI" },
            { value: "P", display: "Paper" }
        ]

        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 0,
                },
                {
                    label: 'SUBMIT BATCH #',
                    field: 'submitBatchNumber',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'RECEIVER',
                    field: 'receiver',
                    sort: 'asc',
                    width: 150
                },

                {
                    label: 'HCFA TEMPLATE',
                    field: 'formType',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'SUBMIT DATE',
                    field: 'submitDate',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'STATUS',
                    field: 'status',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'CONTROL #',
                    field: 'isaControllNumber',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'SUBMIT TYPE',
                    field: 'submitType',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'NOTES',
                    field: 'notes',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'DOWNLOAD',
                    field: 'download',
                    sort: 'asc',
                    width: 150
                }
            ],
            rows: this.state.data
        };
        const formType = [
            { value: "", display: "Select Title" },
            { value: "HCFA 1500", display: "HCFA 1500" },
            { value: "PLAN 1500", display: "Plan 1500" }
        ]

        var admissionDate = this.state.electModel.submitDate ? this.state.electModel.submitDate.replace("T00:00:00", "") : "";

        let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }


        
        return (
            < React.Fragment >
            {spiner}
                <div className="mainHeading row">
                    <div className="col-md-6">
                        <h1>SUBMISSION LOGS SEARCH</h1>
                    </div>
                    <div className="col-md-6 headingRight">
                    </div>
                </div>

                <form onSubmit={event => this.searchSubmissionLog(event)}>
                    <div className="mainTable">

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Receiver'></Label>
                                <Input type='text' name='receiver' id='receiver' value={this.state.electModel.receiver} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                {/* <Label name='Form Type'></Label>
                                <Input type='text' name='formType' id='formType' value={this.state.electModel.formType} onChange={() => this.handleChange} /> */}

                                <label>HCFA Template</label>
                                <select name="formType" id="formType" value={this.state.electModel.formType} onChange={this.handleChange}>
                                    {formType.map(s => (
                                        <option key={s.value} value={s.value}>
                                            {s.display}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                {/* <Label name='Submit Date'></Label>
                                <Input type='text' name='submitDate' id='submitDate' value={this.state.electModel.submitDate} onChange={() => this.handleChange} /> */}
                                <label>Submit Date</label>
                                <div class="textBoxValidate">
                                    <input
                                        style={{
                                            width: "215px",
                                            marginLeft: "0px"
                                        }}
                                        className="myInput"
                                        type="date"
                                        name="submitDate"
                                        id="submitDate"
                                        value={admissionDate}
                                        onChange={this.handleChange}
                                    ></input>
                                </div>


                            </div>
                            <div className="mf-6">
                                <Label name='Submit Type'></Label>
                                <select name="submitType" id="submitType" value={this.state.electModel.submitType} onChange={this.handleChange}>
                                    {subType.map(s => (
                                        <option key={s.value} value={s.value}>
                                            {s.display}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        <div className="row-form">

                            <div className="mf-6">
                                <Label name='Control Number'></Label>
                                <Input type='text' name='isaControllNumber' id='isaControllNumber' value={this.state.electModel.isaControllNumber} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Submit Batch #'></Label>
                                <Input type='text' name='submitBatchNumber' id='submitBatchNumber'
                                    value={this.state.electModel.submitBatchNumber} onChange={() => this.handleChange} />
                            </div>


                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">

                                <Input type='submit' name='name' id='name' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>

                </form>


                <div className="mf-12 table-grid mt-15">

                    <GridHeading Heading='SUBMISSION LOG SEARCH RESULT'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            responsive={true}
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

            </React.Fragment >
        )
    }
}

export default SubmissionLog
