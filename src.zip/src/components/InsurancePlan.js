import React, { Component } from 'react'

import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import SearchHeading from './SearchHeading'
import Label from './Label'
import Button from './Input'
import Input from './Input'
import SearchInput2 from './SearchInput2'

import axios from 'axios';
import { MDBDataTable, MDBBtn, MDBTableHead, MDBTableBody, MDBTable } from 'mdbreact';

import GridHeading from './GridHeading';
import NewInsurancePlan from './NewInsurancePlan'

import searchIcon from '../images/search-icon.png'
import refreshIcon from '../images/refresh-icon.png'
import newBtnIcon from '../images/new-page-icon.png'
import settingsIcon from '../images/setting-icon.png'
import NewInsurance from './NewInsurance'

import ReactDataGrid from 'react-data-grid';

import $ from 'jquery';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

class InsurancePlan extends Component {


    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/InsurancePlan/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        this.searchModel = {
            PlanName: '',
            Description: '',
            Insurance: '',
            PlanType: '',
            payerName: '',
            PayerID: ''
        }

        this.state = {
            searchModel: this.searchModel,
            id: 0,
            data: [],
            showPopup: false,
            showInsurancePopup: false,
            loading:false
        }

        this.searchInsurancePlans = this.searchInsurancePlans.bind(this);
        this.handleChange = this.handleChange.bind(this);

        this.openInsurancePlanPopup = this.openInsurancePlanPopup.bind(this);
        this.closeInsurancePlanPopup = this.closeInsurancePlanPopup.bind(this);
        this.openInsurancePopup = this.openInsurancePopup.bind(this);
        this.closeInsurancePopup = this.closeInsurancePopup.bind(this);

    }

    searchInsurancePlans = (e) => {
        this.setState({loading:true})
        console.log(this.state.searchModel);
        axios.post(this.url + 'FindInsurancePlan', this.state.searchModel , this.config)
            .then(response => {

                let newList = []
                response.data.map((row, i) => {
                    console.log(row)
                    newList.push({
                        id: row.id,
                        planName: <MDBBtn className='gridBlueBtn' onClick={() => this.openInsurancePlanPopup(row.id)}>{row.planName}</MDBBtn>,
                        description: row.description,
                        insurance: <MDBBtn className='gridBlueBtn' onClick={() => this.openInsurancePopup(row.insuranceID)}>{row.insurance}</MDBBtn>,
                        payerName: row.payerName,
                        payerID: row.payerID,
                        planType: row.planType
                    });
                });

                this.setState({ data: newList , loading:false });
            }).catch(error => {
                this.setState({loading:false})

                console.log(error);
            });

        e.preventDefault();
    }

    handleChange = event => {
        event.preventDefault();
        this.setState({
            searchModel: { [event.target.name]: event.target.value.toUpperCase() }
        });
    };

    clearFields = event => {
        this.setState({
            searchModel: this.searchModel
        });
    };

    openInsurancePlanPopup = (id) => {
        this.setState({ showPopup: true, id: id });
    }

    closeInsurancePlanPopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    openInsurancePopup = (id) => {
        this.setState({ showInsurancePopup: true, id: id });
    }

    closeInsurancePopup = () => {
        $('#myModal').hide()
        this.setState({ showInsurancePopup: false });
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }

    render() {

        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 150,
                },
                {
                    label: 'PLAN',
                    field: 'planName',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'DESCRIPTION',
                    field: 'description',
                    sort: 'asc',
                    width: 270
                },
                {
                    label: 'INSURANCE',
                    field: 'insurance',
                    sort: 'asc',
                    width: 200
                },
                {
                    label: 'PAYER NAME',
                    field: 'payerName',
                    sort: 'asc',
                    width: 100
                },
                {
                    label: 'PAYER ID',
                    field: 'payerID',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'PLAN TYPE',
                    field: 'planType',
                    sort: 'asc',
                    width: 100
                }
            ],
            rows:
                this.state.data
        };


        let popup = ''

        if (this.state.showPopup) {
            popup = <NewInsurancePlan onClose={() => this.closeInsurancePlanPopup} id={this.state.id}></NewInsurancePlan>
        } else if (this.state.showInsurancePopup) {
            popup = <NewInsurance onClose={() => this.closeInsurancePopup} id={this.state.id}></NewInsurance>
        } else
            popup = <React.Fragment></React.Fragment>

        
            let spiner = ''
            if (this.state.loading == true) {
                spiner = (
                    <GifLoader
                        loading={true}
                        imageSrc={Eclips}
                        // imageStyle={imageStyle}
                        overlayBackground="rgba(0,0,0,0.5)"
                    />
                )
            }

        return (


            < React.Fragment >
            {spiner}
            <SearchHeading heading="INSURANCE PLAN SEARCH" handler={() => this.openInsurancePlanPopup(0)} ></SearchHeading>

                

                <form onSubmit={event => this.searchInsurancePlans(event)}>
                    <div className="mainTable">

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Plan Name'></Label>
                                <Input type='text' name='PlanName' id='PlanName' value={this.state.searchModel.PlanName} onChange={() => this.handleChange} />
                            </div>


                            <div className="mf-6">
                                <Label name='Description'></Label>
                                <Input type='text' name='Description' id='Description' max='20'
                                    value={this.state.searchModel.Description} onChange={() => this.handleChange} />
                            </div>
                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Insurance'></Label>
                                <Input type='text' name='Insurance' id='Insurance' max='20'
                                    value={this.state.searchModel.Insurance} onChange={() => this.handleChange} />
                            </div>

                            <div className="mf-6">
                                <Label name='Plan Type'></Label>
                                <Input type='text' name='PlanType' id='PlanType' max='20'
                                    value={this.state.searchModel.PlanType} onChange={() => this.handleChange} />
                            </div>

                        </div>


                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Payer Name'></Label>
                                <Input type='text' name='payerName' id='payerName' max='20'
                                    value={this.state.searchModel.payerName} onChange={() => this.handleChange} />
                            </div>


                            <div className="mf-6">
                                <Label name='Payer ID'></Label>
                                <Input type='text' name='PayerID' id='PayerID' max='10' value={this.state.searchModel.PayerID} onChange={() => this.handleChange} />
                            </div>
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">
                                <Input type='submit' name='name' id='name' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>
                </form>

                <div className="mf-12 table-grid mt-15">
                    <GridHeading Heading='IMSURANCE PLAN SEARCH RESULT'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            responsive={true}
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

                {popup}

            </React.Fragment >
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(InsurancePlan);