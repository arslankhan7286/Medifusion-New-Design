import React, { Component } from 'react'
import SearchHeading from './SearchHeading'
import Label from './Label'
import Button from './Input'
import Input from './Input'
import SearchInput2 from './SearchInput2'
import axios from 'axios';
import { MDBDataTable, MDBBtn, MDBTableHead, MDBTableBody, MDBTable } from 'mdbreact';
import GridHeading from './GridHeading';
import NewPractice from './NewPractice'
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import $ from 'jquery';
import Swal from 'sweetalert2';



//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


class Practice extends Component {


    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/Practice/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        this.searchModel = {
            name: '',
            organizationName: '',
            npi: '',
            taxid: '',
            address: '',
            phoneNumber: '',
        }

        this.state = {
            searchModel: this.searchModel,
            id: 0,
            data: [],
            showPopup: false,
            loading : false
        }

        this.searchPractices = this.searchPractices.bind(this);
        this.closePracticePopup = this.closePracticePopup.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.openPracticePopup = this.openPracticePopup.bind(this);

    }

    searchPractices = (e) => {
        this.setState({loading:true})
                console.log(this.state.searchModel);

               var config = {
                    headers: {'Authorization': "Bearer1  " + this.props.loginObject.token}
                };

                axios.post(this.url + 'FindPractices', this.state.searchModel ,  this.config)
                    .then(response => {

                        let newList = []
                        response.data.map((row, i) => {
                            console.log(row)
                            newList.push({
                                id: row.id,
                                practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPracticePopup(row.id)}>{row.name}</MDBBtn>,
                                organizationName: row.organizationName,
                                npi: row.npi,
                                taxid: row.taxID,
                                address: row.address,
                                officePhoneNum: row.officePhoneNum
                            });
                        });

                        this.setState({ data: newList ,loading:false});
                    }).catch(error => {
                        this.setState({loading:false})
                        if (error.response) {
                            if(error.response.status){
                                Swal.fire("Unauthorized Access" , "" , "error")
                            }
                          } else if (error.request) {
                            console.log(error.request);
                          } else {
                            console.log('Error', error.message);
                          }
                          console.log(JSON.stringify(error));
                    });

        e.preventDefault();
    }

    handleChange = event => {
        event.preventDefault();
        this.setState({
            searchModel: { ...this.state.searchModel, [event.target.name]: event.target.value.toUpperCase() }
        });
    };

    clearFields = event => {
        this.setState({
            searchModel: this.searchModel
        });
    };

    openPracticePopup = (id) => {
        this.setState({ showPopup: true, id: id });
    }


    closePracticePopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }

    render() {

        console.log("Props Token ",this.props.loginObject)

        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 150,
                },
                {
                    label: 'NAME',
                    field: 'practice',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'ORGANIZATION NAME',
                    field: 'organizationName',
                    sort: 'asc',
                    width: 270
                },
                {
                    label: 'NPI',
                    field: 'npi',
                    sort: 'asc',
                    width: 200
                },
                {
                    label: 'TAX ID',
                    field: 'taxid',
                    sort: 'asc',
                    width: 100
                },
                {
                    label: 'ADDRESS',
                    field: 'address',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'OFFICE PHONE #',
                    field: 'officePhoneNum',
                    sort: 'asc',
                    width: 100
                }
            ],
            rows:
                this.state.data
        };

console.log("Edit Id : " , this.state.id)
        let popup = '';
        if (this.state.showPopup) {
            popup = <NewPractice onClose={() => this.closePracticePopup} practiceID={this.state.id}></NewPractice>
        }
        else
            popup = <React.Fragment></React.Fragment>

            let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }


        return (

            < React.Fragment >
            {spiner}

                <SearchHeading heading='PRACTICE SEARCH' handler={() => this.openPracticePopup(0)}></SearchHeading>

                {/* <div className="mainHeading row">
                    <div className="col-md-6">
                        <h1>Practice SEARCH</h1>
                    </div>
                    <div className="col-md-6 headingRight">
                        <a className="btn-icon" href=""> <img src={searchIcon} alt="" /> </a>
                        <a className="btn-icon" href=""> <img src={refreshIcon} alt="" /> </a>
                        <a className="btn-icon" href=""> <img src={newBtnIcon} alt="" /> </a>
                        <a className="btn-icon" href=""> <img src={settingsIcon} alt="" /> </a>
                        <button data-toggle="modal" data-target=".bs-example-modal-new" className="btn-blue-icon"
                            onClick={() => this.openPracticePopup(0)}>Add New +</button>
                    </div>
                </div> */}


                <form onSubmit={this.searchPractices}>
                    <div className="mainTable">

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Name'></Label>
                                <Input type='text' name='name' id='name' value={this.state.searchModel.name} onChange={() => this.handleChange} />
                            </div>


                            <div className="mf-6">
                                <Label name='Organization Name'></Label>
                                <Input type='text' name='organizationName' id='organizationName'
                                    max='30' value={this.state.searchModel.organizationName} onChange={() => this.handleChange} />
                            </div>
                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='NPI'></Label>
                                <Input type='text' name='npi' id='npi' max='10' value={this.state.searchModel.npi} onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)} />
                            </div>
                            <div className="mf-6">
                                <Label name='Tax ID'></Label>
                                <Input type='text' name='taxid' id='taxid' max='9' value={this.state.searchModel.taxid} onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)} />
                            </div>
                        </div>


                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Address'></Label>
                                <Input type='text' name='address' id='address' max='30' value={this.state.searchModel.address} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Phone #'></Label>
                                <Input type='text' name='phoneNumber' id='phoneNumber' max='10' value={this.state.searchModel.phoneNumber} onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)} />
                            </div>
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">
                                <Input type='submit' name='name' id='name' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>
                </form>

                <div className="mf-12 table-grid mt-15">
                    <GridHeading Heading='PRACTICE SEARCH RESULT'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            responsive={true}
                            striped
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

                {popup}

            </React.Fragment >
        )
    }
}




function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(Practice);