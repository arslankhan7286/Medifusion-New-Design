import React, { Component } from 'react'


import searchIcon from '../images/search-icon.png'
import refreshIcon from '../images/refresh-icon.png'
import newBtnIcon from '../images/new-page-icon.png'
import settingsIcon from '../images/setting-icon.png'

export class SearchHeading extends Component {
    render() {
        return (
            <div className="mainHeading row">
                <div className="col-md-8">
                    <h1>{this.props.heading}</h1>
                </div>
                <div className="col-md-4 headingRight">
                    {/* <a className="btn-icon" href=""> <img src={searchIcon} alt="" /> </a>
                    <a className="btn-icon" href=""> <img src={refreshIcon} alt="" /> </a>
                    <a className="btn-icon" href=""> <img src={newBtnIcon} alt="" /> </a>
                    <a className="btn-icon" href=""> <img src={settingsIcon} alt="" /> </a> */}
                    <button data-toggle="modal" data-target=".bs-example-modal-new"
                        className="btn-blue-icon" onClick={() => this.props.handler()}>{this.props.btnCaption ? this.props.btnCaption : 'Add New +'} </button>
                </div>
            </div>
        )
    }
}

export default SearchHeading
