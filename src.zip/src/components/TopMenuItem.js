import React, { Component } from 'react'


class TopMenuItem extends Component {

    constructor(props) {
        super(props)

        this.state = {
            image: this.props.icon
        }
    }

    mouseEnter = () => {
        this.setState({ image: this.props.hoverIcon });
    }

    mouseLeave = () => {
        this.setState({ image: this.props.icon });
    }


    render() {
        return (
            <li className={this.props.liClassName} style={{
                backgroundImage: `url(${this.state.image})`
            }} onMouseEnter={this.mouseEnter} onMouseLeave={this.mouseLeave}>
                <a className={this.props.aClassName} href="#" onClick={this.props.handler}>{this.props.Caption}</a>
            </li>
        )
    }
}

export default TopMenuItem
