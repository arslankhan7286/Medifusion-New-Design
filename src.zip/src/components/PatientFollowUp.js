import React, { Component } from 'react'


import { MDBDataTable, MDBBtn } from "mdbreact";

import Label from "./Label";
import Input from "./Input";


import SearchHeading from "./SearchHeading";


import axios from 'axios';

import $ from "jquery";

import GridHeading from './GridHeading';
import NewPatientPlanModel from './NewPatientPlanModel';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'




export class PatientFollowUp extends Component {
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/PatientFollowup/';
        
 //Authorization Token
 this.config = {
    headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
};



        this.searchModel = {

            // reasonID: '',
            actionID: '',
            groupID: '',

            practice: '',
            planName: '',
            visitID: 0,
            accountNum: '',
            planID: ''






        }

        this.state = {
            searchModel: this.searchModel,
            data: [],
            id: 0,
            resData: [],
            actionData: [],
            groupData: []
        }
        this.searchPatientFollowup = this.searchPatientFollowup.bind(this);

        this.handleChange = this.handleChange.bind(this);
        this.clearFields = this.clearFields.bind(this);
        this.openPatientFollowupPopup = this.openPatientFollowupPopup.bind(this);
        this.closePatientFollowupPopup = this.closePatientFollowupPopup.bind(this);



    }


    componentWillMount() {
        axios.get(this.url + 'GetProfiles' ,  this.config)
            .then(response => {

                this.setState({
                    resData: response.data.reason,
                    groupData: response.data.group,
                    actionData: response.data.action
                })

                console.log(response.data);
            }).catch(error => {
                console.log(error);
            });
    }



    openPatientFollowupPopup = (id) => {


        this.setState({ showPopup: true, id: id });
    }


    closePatientFollowupPopup() {

        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    clearFields = event => {
        this.setState({
            searchModel: this.searchModel
        });
    };







    handleChange = event => {
        console.log(event.target.name);
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                [event.target.name]: event.target.value === 'Please Select' ? null : event.target.value
            }
        });
    };


    searchPatientFollowup = (e) => {

        e.preventDefault()
        console.log('search', this.state.searchModel)


        axios.post(this.url + 'FindPatientFollowUp', this.state.searchModel  , this.config)
            .then(response => {
                console.log(response)

                let newList = []
                response.data.map((row, i) => {

                    newList.push({
                        id: row.id,

                        patientID: <MDBBtn className='gridBlueBtn' size="sm" onClick={() => this.openPatientFollowupPopup(row.patientID)}>{row.patientID}</MDBBtn>,

                        followUpDate: row.followUpDate,
                        tickleDate: row.tickleDate,
                        patientAmount: row.patientAmount,
                        action: row.action,
                        reason: row.reason,
                        group: row.group,

                    });
                });

                this.setState({ data: newList });

            }).catch(error => {
                console.log(error)
            });

        e.preventDefault();
    }











    render() {

        console.log(this.state.searchModel)
        const data = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 250
                }
                ,
                {
                    label: "Patient ID ",
                    field: "patientID ",
                    sort: "asc",
                    width: 250
                },
                {
                    label: "Follow Up Date",
                    field: "followUpDate  ",
                    sort: "asc",
                    width: 250
                },
                {
                    label: "Tickle Date",
                    field: "tickleDate ",
                    sort: "asc",
                    width: 250
                }, {
                    label: "Patient Amount",
                    field: "patientAmount ",
                    sort: "asc",
                    width: 250
                }, {
                    label: "ACTION",
                    field: "action ",
                    sort: "asc",
                    width: 250
                }, {
                    label: "REASON",
                    field: "reason ",
                    sort: "asc",
                    width: 250
                }, {
                    label: "GROUP",
                    field: "group ",
                    sort: "asc",
                    width: 250
                }


            ],
            rows: this.state.data

        };

        let popup = ''

        if (this.state.showPopup) {
            popup = <NewPatientPlanModel onClose={() => this.closePatientFollowupPopup} id={this.state.id}></NewPatientPlanModel>
        }
        else
            popup = <React.Fragment></React.Fragment>
        return (
            <React.Fragment>
                <div>
                    <div>
                        <div>
                            <div className="mainHeading row">

                                <div className="col-md-6 headingLeft">
                                    <h1>PATIENT FOLLOW UP SEARCH</h1>

                                </div>
                            </div>

                            <div className="container-fluid">
                                <form
                                    onSubmit={event => this.searchPatientFollowup(event)}
                                >
                                    <div
                                        className="mainTable fullWidthTable"
                                        style={{ maxWidth: "1500px" }}
                                    >
                                        <div className="row-form">
                                            <div className="mf-4">
                                                <label>Reason</label>
                                                <select name="reasonID" id="reasonID"
                                                    value={this.state.searchModel.reasonID} onChange={this.handleChange}>
                                                    {this.state.resData.map(s => (
                                                        <option key={s.id} value={s.id}>
                                                            {s.description}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="mf-4">
                                                <label>Action</label>
                                                <select name="actionID" id="actionID"
                                                    value={this.state.searchModel.actionID} onChange={this.handleChange}>
                                                    {this.state.actionData.map(s => (
                                                        <option key={s.id} value={s.id}>
                                                            {s.description}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="mf-4">
                                                <label>Group</label>
                                                <select name="groupID" id="groupID"
                                                    value={this.state.searchModel.groupID} onChange={this.handleChange}>
                                                    {this.state.groupData.map(s => (
                                                        <option key={s.id} value={s.id}>
                                                            {s.description}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>


                                        </div>


                                        <div className="row-form">
                                            <div className="mf-4">
                                                <Label name="Practice "></Label>
                                                <Input
                                                    type="text"
                                                    name="practice"
                                                    id="practice"
                                                    value={this.state.searchModel.practice}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>
                                            <div className="mf-4">
                                                <Label name="Plan"></Label>
                                                <Input
                                                    type="text"
                                                    name="plan"
                                                    id="plan"
                                                    value={this.state.searchModel.plan}
                                                    onChange={() => this.handleChange}
                                                //onKeyPress={event => this.handleNumericCheck(event)}
                                                ></Input>
                                            </div>
                                            <div className="mf-4">
                                                <Label name="Visit #"></Label>
                                                <Input
                                                    type="text"
                                                    name="visitID"
                                                    id="visitID"
                                                    value={this.state.searchModel.visitID}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>



                                        </div>

                                        <div className="row-form">
                                            <div className="mf-4">
                                                <Label name="Account #"></Label>
                                                <Input
                                                    type="text"
                                                    name="accountNum"
                                                    id="accountNum"
                                                    value={this.state.searchModel.accountNum}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>
                                            <div className="mf-4"></div>
                                            <div className="mf-4"></div>

                                        </div>


                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <Input
                                                    type="submit"
                                                    name="search"
                                                    id="search"
                                                    className="btn-blue"
                                                    value="Search"
                                                ></Input>
                                                <Input
                                                    type="button"
                                                    name="clear"
                                                    id="clear"
                                                    value="Clear"
                                                    className="btn-grey"
                                                    onClick={event => this.clearFields(event)}
                                                ></Input>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div className="mf-12 table-grid mt-15">
                                <div className="row headingTable">
                                    <div className="mf-6">
                                        <h1>PATIENT FOLLOW UP SEARCH RESULT</h1>
                                    </div>
                                    <div className="mf-6 headingRightTable">
                                        <a href="javascript:;">
                                            <img src="images/setting-icon.png" alt="" />
                                        </a>
                                    </div>
                                </div>



                                <div className="tableGridContainer">
                                    <MDBDataTable
                                        responsive={true}
                                        striped
                                        bordered
                                        searching={false}
                                        data={data}
                                        displayEntries={false}
                                        sortable={true}
                                        scrollX={false}
                                        scrollY={false}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {popup}

            </React.Fragment>
        )
    }
}
function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(PatientFollowUp);
  
