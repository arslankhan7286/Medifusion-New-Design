import React, { Component } from 'react'


import facilityIcon from "../images/facility-icon.png";
import facilityHIcon from "../images/facility-icon-hover.png";
import locationIcon from "../images/location-icon.png";
import locationHIcon from "../images/location-icon-hover.png";

import LeftMenuItem from "./LeftMenuItem";

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

export class NewPaymentLeftMenu extends Component {
    constructor(props) {
        super(props)

        this.NewPaymentLeftMenu = {
            Category: "",
            Icon: "",
            hIcon: "",
            expanded: true,
            SubCategories: [
                {
                    SubCategory: "Visit",
                    Icon: facilityIcon,
                    hIcon: facilityHIcon,
                    handler: () => this.props.selectTabPageAction("CHARGE"),
                    selected: false
                }
            ]
        };


        this.state = {
            NewPaymentLeftMenu: {}
        }
    }
    componentWillMount() {

        this.setState({
            NewPaymentLeftMenu: this.NewPaymentLeftMenu
        });

    }
    render() {
        let leftMenuElements = (
            <LeftMenuItem data={this.state.NewPaymentLeftMenu}></LeftMenuItem>
        );


        return leftMenuElements;
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(NewPaymentLeftMenu);