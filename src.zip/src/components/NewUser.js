import React, { Component, Fragment } from 'react'
import $ from 'jquery';
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import axios from 'axios';
import Input from './Input';
import leftNavMenusReducer from '../reducers/leftNavMenusReducer';
import Swal from 'sweetalert2'
import { Tabs, Tab } from "react-tab-view";
import { MDBDataTable, MDBBtn, MDBTableHead, MDBTableBody, MDBTable } from 'mdbreact';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


export class NewUser extends Component {

    
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/account/';
        this.assignPracticesUrl = process.env.REACT_APP_URL + "/userPractices/";
        this.errorField = 'errorField';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        console.log(this.props.email)

        this.userModel = {
            id: 0,
            firstName: '',
            lastName: '',
            clientID: '',
            userRole : '',
            email: '',
            password: 123,
            cnfrmPass:123,
            practiceID:"",
            isActive:false
        }

        this.userPracticesModel={
            clientID : null,
            practiceID : null,
            currentUserID : null , 
            email:"",
            upaStatus : false,

            clientName:"",
            practiceName:"",
        }


        this.validationModel = {
            firstNameValField: '',
            lastNameValField: '',
            clientValField: '',            
            roleValField: '',
            emailValField: '',
            passwordValField: '',   
            cnfrmPassValField:"",  
            practiceValField:"",    
            validation: false
        }

        this.state = {
            editId: this.props.userID,
            userModel: this.userModel,
            validationModel: this.validationModel,
            userPracticesModel : this.userPracticesModel,
            userPracticesArr : [],
            userPracticesArrRes:[],
            maxHeight: '361',
            loading: false,
            cnfrmPass:"",
            userRole:[],
            clientID:[],
            clientPractices:[],
            data:[],
            email:this.props.email,
            id:0
        }

        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.saveUser = this.saveUser.bind(this);
        this.delete = this.delete.bind(this);
        this.handleClientChange = this.handleClientChange.bind(this);
        this.addPracticeRow = this.addPracticeRow.bind(this);
        this.deletePracticeRow = this.deletePracticeRow.bind(this);
        this.handlePracticeChange = this.handlePracticeChange.bind(this);
        this.handleUserPracticeClientChange = this.handleUserPracticeClientChange.bind(this);
        this.isNull  = this.isNull.bind(this);
        this.savePractices = this.savePractices.bind(this);
       
    }

    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find('.modal-content');
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
        var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight })
    }
    
    componentWillMount(){
        this.setState({id : this.props.email ? 1 : 0})
    }

  async  componentDidMount() {
        this.setModalMaxHeight($('.modal'));
        // if ($('.modal.in').length != 0) {
        //     this.setModalMaxHeight($('.modal.in'));
        // }

        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);


        //Authorization Token
        var config = {
            headers: {'Authorization': "Bearer  " + this.props.loginObject.token}
        };

        // Account Get Profiles
         axios.get(this.url + 'getProfiles' ,  this.config)
                .then(response => {
                    console.log("Get Profiles Response : " , response.data);
                    this.setState({ clientID: response.data.clients , userRole : response.data.list });
                }).catch(error => {
                    
                    if (error.response) {
                        if(error.response.status){
                            Swal.fire("Unauthorized Access" , "" , "error");
                            return
                        }
                      } else if (error.request) {
                        console.log(error.request);
                        return
                      } else {
                        console.log('Error', error.message);
                        console.log(JSON.stringify(error));
                        Swal.fire("Something went Wrong" , "" , "error");
                        return
                      }
                });



        if (this.state.email) {
           await axios.get(this.url + 'findUser/' + this.state.email  , this.config)
                .then(response => {
                    console.log("Find User Response : ", response.data);
                    // this.assignUserPractices(response.data.assignedUserPractices)

                     // Account Get Practices
                        axios.get(this.url + 'GetClientPractices/'+ response.data.clientID ,  this.config)
                        .then(res => {
                            this.setState({
                                clientPractices: res.data ,
                                userModel:{
                                    ...this.state.userModel,
                                    firstName:response.data.firstName,
                                    lastName : response.data.lastName,
                                    userRole : response.data.userRole,
                                    clientID : response.data.clientID,
                                    email:response.data.email,
                                    practiceID: response.data.practiceID
                                },
                                 userPracticesArr : response.data.assignedUserPractices
                            });

                          
                            

                        }).catch(error => {
                            
                            if (error.response) {
                                if(error.response.status){
                                    Swal.fire("Unauthorized Access" , "" , "error");
                                    return
                                }
                            } else if (error.request) {
                                console.log(error.request);
                                return
                            } else {
                                console.log('Error', error.message);
                                console.log(JSON.stringify(error));
                                Swal.fire("Something went Wrong" , "" , "error");
                                return
                            }
                        });


                }).catch(error => {
                    if (error.response) {
                        if(error.response.status){
                            Swal.fire("Unauthorized Access" , "" , "error");
                            return
                        }
                      } else if (error.request) {
                        console.log(error.request);
                        return
                      } else {
                        console.log('Error', error.message);
                        console.log(JSON.stringify(error));
                        Swal.fire("Something went Wrong" , "" , "error");
                        return
                      }
                });
        }


    }
  
    handleChange = event => {
        console.log(event.target)
        event.preventDefault();
        this.setState({
            userModel: {
                ...this.state.userModel,
                [event.target.name]: event.target.value            }
        });
    };

    // Handle clientID Change
    handleClientChange(event){
        console.log(event.target)
        event.preventDefault();

        this.setState({
            userModel: {
                ...this.state.userModel,
                [event.target.name]: event.target.value            }
        });

         //Authorization Token
         var config = {
            headers: {'Authorization': "Bearer  " + this.props.loginObject.token}
        };

        // Account Get Practices
         axios.get(this.url + 'GetClientPractices/'+ event.target.value ,  this.config)
                .then(response => {
                    console.log("Get Profiles Response : " , response.data);
                    this.setState({ clientPractices: response.data  });
                }).catch(error => {
                    
                    if (error.response) {
                        if(error.response.status){
                            Swal.fire("Unauthorized Access" , "" , "error");
                            return
                        }
                      } else if (error.request) {
                        console.log(error.request);
                        return
                      } else {
                        console.log('Error', error.message);
                        console.log(JSON.stringify(error));
                        Swal.fire("Something went Wrong" , "" , "error");
                        return
                      }
                });
    }

    // Handle Practice Change
    handlePracticeChange(event){
        console.log(event.target)
        this.setState({
            userPracticesModel: {
                ...this.state.userPracticesModel,
                [event.target.name]: event.target.value            }
        });
    }

    //Handle user Pratices Client Change
    handleUserPracticeClientChange(event){
        this.setState({
            userPracticesModel: {
                ...this.state.userPracticesModel,
                [event.target.name]: event.target.value            }
        });

        var clientID = 0
        if(this.isNull(event.target.value)){
            clientID = 0;
        }else{
            clientID =  event.target.value
        }

         //Authorization Token
         var config = {
            headers: {'Authorization': "Bearer  " + this.props.loginObject.token}
        };

        // Account Get Profiles
         axios.get(this.url + 'GetClientPractices/'+ clientID ,  this.config)
                .then(response => {
                    console.log("Get Profiles Response : " , response.data);
                    this.setState({ clientPractices: response.data  });
                }).catch(error => {
                    
                    if (error.response) {
                        if(error.response.status){
                            Swal.fire("Unauthorized Access" , "" , "error");
                            return
                        }
                      } else if (error.request) {
                        console.log(error.request);
                        return
                      } else {
                        console.log('Error', error.message);
                        console.log(JSON.stringify(error));
                        Swal.fire("Something went Wrong" , "" , "error");
                        return
                      }
                });

    }


    
    handleCheck() {
        this.setState({
            userModel: {
                ...this.state.userModel,
                isActive: !this.state.userModel.isActive
            }
        });
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    };

    isNull(value) {
        if (value === '' || value === null || value === undefined || value == "Please Select")
            return true;
        else return false;
    }


    saveUser = (e) => {
        this.setState({ loading: true })

        console.log(this.state.userModel);

        var myVal = this.validationModel;
        myVal.validation = false;

        if (this.isNull(this.state.userModel.lastName)) {
            myVal.lastNameValField = <span className="validationMsg">Last Name is Required</span>
            myVal.validation = true
        } else {
            myVal.lastNameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.userModel.firstName)) {
            myVal.firstNameValField = <span className="validationMsg"> First Name is Required</span>
            myVal.validation = true
        } else {
            myVal.firstNameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.userModel.userRole)) {
            myVal.roleValField = <span className="validationMsg"> userRole is Required</span>
            myVal.validation = true
        } else {
            myVal.roleValField = ''
            if (myVal.validation === false) myVal.validation = false
        }   
        
        if (this.isNull(this.state.userModel.clientID)) {
            myVal.clientValField = <span className="validationMsg"> clientID is Required</span>
            myVal.validation = true
        } else {
            myVal.clientValField = ''
            if (myVal.validation === false) myVal.validation = false
        }   

         
        if (this.isNull(this.state.userModel.email)) {
            myVal.emailValField = <span className="validationMsg"> Email is Required</span>
            myVal.validation = true
        } else {
            myVal.emailValField = ''
            if (myVal.validation === false) myVal.validation = false
        }   

        if (this.isNull(this.state.userModel.practiceID)) {
            myVal.practiceValField = <span className="validationMsg"> Practice is Required</span>
            myVal.validation = true
        } else {
            myVal.practiceValField = ''
            if (myVal.validation === false) myVal.validation = false
        }  

        if (this.isNull(this.state.userModel.password)) {
            myVal.passwordValField = <span className="validationMsg"> Password is Required</span>
            myVal.validation = true
        } else {
            myVal.passwordValField = ''
            if (myVal.validation === false) myVal.validation = false
        } 

        if (this.isNull(this.state.userModel.cnfrmPass)) {
            myVal.cnfrmPassValField = <span className="validationMsg">Confirm Password is Required</span>
            myVal.validation = true
        } else {
            myVal.cnfrmPassValField = ''
            if (myVal.validation === false) myVal.validation = false
        } 
        
        if (this.state.userModel.password != this.state.userModel.cnfrmPass ) {
            myVal.passwordValField = <span className="validationMsg">Password Did"t Maatch</span>
            myVal.cnfrmPassValField = <span className="validationMsg">Password Did"t Maatch</span>
            myVal.validation = true
        } else {
            myVal.passwordValField = '';
            myVal.cnfrmPassValField = ''
            if (myVal.validation === false) myVal.validation = false
        } 
        


        this.setState({
            validationModel: myVal
        });

        if (myVal.validation === true) {
            this.setState({ loading: false });
            Swal.fire("Please Select All Fields Properly" ,"" , "error");
            return;
        }

         //Authorization Token
         var config = {
            headers: {'Authorization': "Bearer  " + this.props.loginObject.token}
        };

        axios.post(this.url + 'CreateAccount', this.state.userModel ,  this.config)
            .then(response => {
                console.log(response.data);

                this.setState({ userModel: response.data, editId: response.data.id  , loading:false});
                Swal.fire(
                    'Account Created Successfully',
                    '',
                    'success'
                )
            }).catch(error => {
                console.log(error);
                this.setState({loading:false})

                if (error.response) {
                    if(error.response.status){
                        Swal.fire("Unauthorized Access" , "" , "error");
                        return
                    }
                  } else if (error.request) {
                    console.log(error.request);
                    return
                  } else {
                    console.log('Error', error.message);
                    console.log(JSON.stringify(error));
                    Swal.fire("Something went Wrong" , "" , "error");
                    return
                  }
                  

                
            });

           
            $("#btnCancel").click();
        this.setState({ loading: false });
        e.preventDefault();
    };

    delete = e => {
        
        Swal.fire({
            title: "Are you sure, you want to delete this record?",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then(result => {
            if (result.value) {               

                // this.setState({loading:true})
                // axios
                //     .delete(this.url + "deleteClient/" + this.state.editId)
                //     .then(response => {
                //         this.setState({loading:false})
                //         console.log("Delete Response :", response);
                //         Swal.fire("Record Deleted Successfully", "", "success");
                //     })
                //     .catch(error => {
                //         this.setState({loading:false})
                
                // if (error.response) {
                //     if(error.response.upaStatus){
                //         Swal.fire("Unauthorized Access" , "" , "error");
                //         return
                //     }
                //   } else if (error.request) {
                //     console.log(error.request);
                //     return
                //   } else {
                //     console.log('Error', error.message);
                //     console.log(JSON.stringify(error));
                //  Swal.fire("Record Not Deleted!", "Record can not be delete, as it is being referenced in other screens.", "error");
                //     return
                //   }
                //         
                //     });

                // $("#btnCancel").click();
            }
        });
    };

    //Add Practice Row
   async addPracticeRow(){

    // try{            
    //     var practice;
    //    await this.state.userPracticesArr.map((practice , index) => {
    //         if((practice.practiceID == practiceID && practice.clientID == clientID)){
    //             practice = [...this.state.userPracticesArr];
    //             practice[index].upaStatus = false
    //             this.setState({
    //                 userPracticesArr : practice
    //             })
    //         }
    //     });
    //    }catch{}

        
        try{           
         var client = await this.state.clientID.filter( client => client.id == this.state.userPracticesModel.clientID);
         var practice = await this.state.clientPractices.filter( practice => practice.id == this.state.userPracticesModel.practiceID);

        var obj ={
            clientID : this.state.userPracticesModel.clientID,
            practiceID : this.state.userPracticesModel.practiceID,
            currentUserID : null , 
            email:this.props.email,
            upaStatus : true,
            clientName : client[0].description,
            practiceName: practice[0].description,
        }
        await this.setState({
            userPracticesArr : this.state.userPracticesArr.concat(obj)
        })
        }catch{}

       


    }

    //Delete Practice Row
   async deletePracticeRow(clientID , practiceID){
        try{            
            var practice;
           await this.state.userPracticesArr.map((practice , index) => {
                if((practice.practiceID == practiceID && practice.clientID == clientID)){
                    practice = [...this.state.userPracticesArr];
                    practice[index].upaStatus = false
                    this.setState({
                        userPracticesArr : practice
                    })
                }
            });
           }catch{}
   

    }

    //Save Practices
    savePractices(){

        console.log("UsernPractices Model : " , this.state.userPracticesArr)

        var config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        axios.post(this.assignPracticesUrl + 'assignPractices'  ,   this.state.userPracticesArr , this.config)
        .then(response => {
            console.log("Assign Practices Response : " , response.data);
            // this.setState({ client: response.data.clients , role : response.data.roles });
        })
        .catch(error => {
                    
                    if (error.response) {
                        if(error.response.status){
                            //Swal.fire("Unauthorized Access" , "" , "error");
                            console.log(error.response.false)
                            return
                        }
                    } else if (error.request) {
                        console.log(error.request);
                        return
                    } else {
                        console.log('Error', error.message);
                        console.log(JSON.stringify(error));
                        //Swal.fire("Something went Wrong" , "" , "error");
                        return
                    }

                    console.log(error)
                });



    }

    render() {        
        console.log("User Practice Array in Render :" , this.state.userPracticesArr)
        const isActive = this.state.userModel.isActive;

        let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }
        const headers = [
            "User Info",
            "Practices",
            "Rights"
          ];

          var rowData = [];
          this.state.userPracticesArr.map(practice =>{
             if(practice.upaStatus == true){
                var obj={
                    id:practice.upaStatus,
                    clientName : practice.clientName,
                    practiceName : practice.practiceName,
                    delete : <div style={{width:"100px"}}>
                        <MDBBtn className='gridBlueBtn' onClick={() => this.deletePracticeRow(practice.clientID , practice.practiceID)} >Delete</MDBBtn>
                    </div>
                }
                rowData.push(obj);
             }
          })

          const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 150,
                },
                {
                    label: 'CLIENT',
                    field: 'clientName',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'PRACTICE',
                    field: 'practiceName',
                    sort: 'asc',
                    width: 270
                },
                
                {
                    label: 'DELETE',
                    field: 'delete',
                    sort: 'asc',
                    width: 100
                }
                
            ],
            rows:
            rowData
        };
      

        return (
            <React.Fragment>
                {spiner}
                <div id='myModal' className="modal fade bs-example-modal-new show" tabIndex="-1" userRole="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div className="modal-dialog modal-lg">

                        <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>

                        <div className="modal-content" style={{ overflow: 'hidden' }}>

                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">{this.state.editId > 0 ? this.state.userModel.name + " - " + this.state.userModel.organizationName + " "  :"NEW USER"}</h1>
                                        </div>
                                        <div className="mf-6 popupHeadingRight">
                                            <div className="lblChkBox" onClick={this.handleCheck}>
                                                <input type="checkbox" checked={!isActive} id="isActive" name="isActive" />
                                                <label htmlFor="markInactive">
                                                    <span>Mark Inactive</span>
                                                </label>
                                            </div>
                                            <Input type='button' value='Delete' className="btn-blue" onClick={this.delete}>Delete</Input>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                
                               








                    <div class="mainTable fullWidthTable">
                        <div class="row-form">
                        <div class="mf-12">
                            <Tabs headers={headers} style={{ cursor: "default" }}>
                                <Tab>
                                       <div style={{marginTop:"50px"}}>
                                        <div className="mainTable">

                                                <div className="row-form">
                                                    <div className="mf-6">
                                                        <label>Last Name
                                                            <span className="redlbl"> *</span>
                                                        </label>

                                                        <div className="textBoxValidate">
                                                            <Input 
                                                            className={this.state.validationModel.firstNameValField ? this.errorField : ""}
                                                                type="text" value={this.state.userModel.lastName} name='lastName' id='lastName'
                                                                max='20'
                                                                onChange={() => this.handleChange}
                                                            />
                                                            {this.state.validationModel.firstNameValField}
                                                        </div>

                                                    </div>


                                                    <div className="mf-6">
                                                        <label>First Name <span className="redlbl"> *</span></label>

                                                        <div className="textBoxValidate">
                                                            <Input className={this.state.validationModel.lastNameValField ? this.errorField : ""}
                                                                type="text" value={this.state.userModel.firstName} name="firstName" id="firstName"
                                                                max='20' onChange={() => this.handleChange} />
                                                            {this.state.validationModel.lastNameValField}
                                                        </div>

                                                    </div>
                                                </div>

                                                <div className="row-form">
                                                    <div className="mf-6">
                                                    <label>Role <span className="redlbl"> *</span></label>
                                                        <div >
                                                        <select
                                                            style={{borderColor : this.state.validationModel.roleValField ? "red" : ""}}
                                                            name="userRole"
                                                            id="userRole"
                                                            value={this.state.userModel.userRole}
                                                            onChange={this.handleChange}
                                                        >
                                                            {this.state.userRole.map(s => (
                                                            <option key={s} value={s}>
                                                                {s}
                                                            </option>
                                                            ))}
                                                        </select>
                                                        <div className="textBoxValidate"> {this.state.validationModel.roleValField}</div>
                                                        </div>
                                                    </div>

                                                    <div className="mf-6">
                                                        <label >Client<span className="redlbl"> *</span></label>
                                                        <div >
                                                            <select
                                                                    style={{borderColor : this.state.validationModel.clientValField ? "red" : ""}}
                                                                    name="clientID"
                                                                    id="clientID"
                                                                    value={this.state.userModel.clientID}
                                                                    onChange={this.handleClientChange}
                                                                >
                                                                    {this.state.clientID.map(s => (
                                                                    <option key={s.id} value={s.id}>
                                                                        {s.description}
                                                                    </option>
                                                                    ))}
                                                                </select>
                                                        <div className="textBoxValidate">{this.state.validationModel.clientValField}</div>
                                                            
                                                        </div>
                                                    </div>                      

                                                </div>

                                                <div className="row-form">
                                                    <div className="mf-6">
                                                        <label> Email <span className="redlbl"> *</span></label>
                                                        <div className="textBoxValidate">
                                                            <Input
                                                            disabled={this.state.id > 0 ? "disable"  : ""}
                                                                className={this.state.validationModel.emailValField ? this.errorField : ""}
                                                                type="text" value={this.state.userModel.email} name="email" id="email" max="30"
                                                                onChange={() => this.handleChange} />
                                                        
                                                            {this.state.validationModel.emailValField}
                                                        </div>
                                                    </div>
                                                    <div className="mf-6">
                                                    <label>Practice <span className="redlbl"> *</span></label>
                                                        <div >
                                                        <select
                                                            style={{borderColor : this.state.validationModel.practiceValField ? "red" : ""}}
                                                            name="practiceID"
                                                            id="practiceID"
                                                            value={this.state.userModel.practiceID}
                                                            onChange={this.handleChange}
                                                        >
                                                            {this.state.clientPractices.map(s => (
                                                            <option key={s.id} value={s.id}>
                                                                {s.description}
                                                            </option>
                                                            ))}
                                                        </select>
                                                        <div className="textBoxValidate"> {this.state.validationModel.practiceValField}</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="row-form">
                                                    <div className="mf-6">
                                                        <label>Password <span className="redlbl"> *</span></label>
                                                        <div className="textBoxValidate">
                                                            <input
                                                              disabled={this.state.id > 0 ? "disable"  : ""}
                                                                className={this.state.validationModel.passwordValField ? this.errorField : ""}
                                                                type="password" value={this.state.userModel.password} name="password" id="password" max='15'
                                                                onChange={this.handleChange} />
                                                        
                                                            {this.state.validationModel.passwordValField}
                                                        </div>
                                                    </div>

                                                    <div className="mf-6">
                                                        <label>Confirm Password <span className="redlbl"> *</span></label>
                                                        <div className="textBoxValidate">
                                                            <input
                                                            disabled={this.state.id > 0 ? "disable"  : ""}
                                                                className={this.state.validationModel.cnfrmPassValField ? this.errorField : ""}
                                                                type="password" 
                                                            value={this.state.userModel.cnfrmPass} name="cnfrmPass" id="cnfrmPass" max='15'
                                                                onChange={this.handleChange} 
                                                                />                                               
                                                            {this.state.validationModel.cnfrmPassValField}
                                                        </div>
                                                    </div>

                                                </div>   

                                            </div>

                                        <div className="modal-footer">
                                                <div className="mainTable">
                                                <div className="row-form row-btn">
                                                    <div className="mf-12">
                                                        <button className="btn-blue" onClick={this.saveUser}>Save </button>
                                                        <button id='btnCancel' className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>Cancel </button>
                                                    </div>
                                                </div>
                                                </div>
                                        </div>
                                </div>
                                </Tab>
                                <Tab>
                                <div style={{marginTop:"5px"}}>
                                    <div className="mainTable">
                                        <div className="row-form">
                                            
                                            <div className="mf-4">
                                                                    <label >Client></label>
                                                                    <div >
                                                                        <select
                                                                                //style={{borderColor : this.state.validationModel.clientValField ? "red" : ""}}
                                                                                name="clientID"
                                                                                id="clientID"
                                                                                value={this.state.userPracticesModel.clientID}
                                                                                onChange={this.handleUserPracticeClientChange}
                                                                            >
                                                                                {this.state.clientID.map(s => (
                                                                                <option key={s.id} value={s.id}>
                                                                                    {s.description}
                                                                                </option>
                                                                                ))}
                                                                            </select>
                                                                    {/* <div className="textBoxValidate">{this.state.validationModel.clientValField}</div> */}
                                                                        
                                                                    </div>
                                                                </div>                      
                                            <div className="mf-4">
                                                                <label>Practice</label>
                                                                    <div >
                                                                    <select
                                                                        // style={{borderColor : this.state.validationModel.practiceValField ? "red" : ""}}
                                                                        name="practiceID"
                                                                        id="practiceID"
                                                                        value={this.state.userPracticesModel.practiceID}
                                                                        onChange={this.handlePracticeChange}
                                                                    >
                                                                        {this.state.clientPractices.map(s => (
                                                                        <option key={s.id} value={s.id}>
                                                                            {s.description}
                                                                        </option>
                                                                        ))}
                                                                    </select>
                                                                    {/* <div className="textBoxValidate"> {this.state.validationModel.practiceValField}</div> */}
                                                                    </div>
                                                                </div>
                                            <div className="mf-4">
                                                <div >
                                                <button className="btn-blue" style={{marginLeft : "100px" , marginTop:"0px" , width:"150px"}}
                                                    onClick={this.addPracticeRow}>Add + </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mf-12 table-grid mt-15">
                                        {/* <GridHeading Heading='USER SEARCH RESULT'></GridHeading> */}

                                        <div className="tableGridContainer">
                                            <MDBDataTable
                                                responsive={true}
                                                striped
                                                bordered
                                                searching={false}
                                                data={data}
                                                displayEntries={false}
                                                sortable={true}
                                                scrollX={false}
                                                scrollY={false}
                                            />
                                        </div>
                                    </div>

                                    <div className="row-form">
                                            
                                            <div className="mf-4"></div>                                           
                                            <div className="mf-4">
                                                <div  style={{marginTop:"50px"}}>
                                                    <button className="btn-blue"
                                                        onClick={this.savePractices}>Save </button>
                                                        <button id='btnCancel' className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>Cancel </button>
                                                </div>
                                            </div>
                                            <div className="mf-4"></div>
                                    </div>
                                    
                                </div>
                                </Tab>
                                <Tab>
                                <h1>Tab 3</h1>
                                </Tab>
                            </Tabs>
                        </div>
                        </div>
              </div>

                               


                            </div>

                        </div>

                    </div>

                </div>
            </React.Fragment >
        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(NewUser);