import React, { Component } from "react";

import facilityIcon from "../images/facility-icon.png";
import facilityHIcon from "../images/facility-icon-hover.png";
import locationIcon from "../images/location-icon.png";
import locationHIcon from "../images/location-icon-hover.png";
import provIcon from "../images/provider-icon.png";
import provHIcon from "../images/provider-icon-hover.png";
import refprovIcon from "../images/referring-icon.png";
import refprovHIcon from "../images/referring-icon-hover.png";

import LeftMenuItem from "./LeftMenuItem";

import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";

class PatientLeftMenu extends Component {
  constructor(props) {
    super(props);
    console.log("Props ID : ", this.props.id);
    this.setupLeftMenu1 = {
      Category: "",
      Icon: "",
      hIcon: "",
      expanded: true,
      SubCategories: [
        {
          SubCategory: "Demographics",
          Icon: facilityIcon,
          hIcon: facilityHIcon,
          handler: () => this.props.selectTabPageAction("DEMOGRAPHICS"),
          selected: false
        },
        {
          SubCategory: "Plan",
          Icon: locationIcon,
          hIcon: locationHIcon,
          handler: () => this.props.selectTabPageAction("PLAN"),
          selected: false
        },
        {
          SubCategory: "Payment",
          Icon: locationIcon,
          hIcon: locationHIcon,
          handler: () => this.props.selectTabPageAction("PAYMENT"),
          selected: false
        }
      ]
    };

    this.setupLeftMenu2 = {
      Category: "",
      Icon: "",
      hIcon: "",
      expanded: true,
      SubCategories: [
        {
          SubCategory: "Demographics",
          Icon: facilityIcon,
          hIcon: facilityHIcon,
          handler: () => this.props.selectTabPageAction("DEMOGRAPHICS"),
          selected: false
        }
      ]
    };

    this.state = {
      setupLeftMenu: {}
    };
  }

  componentWillMount() {
    if (this.props.id > 0) {
      this.setState({
        setupLeftMenu: this.setupLeftMenu1
      });
    } else {
      this.setState({
        setupLeftMenu: this.setupLeftMenu2
      });
    }
  }
  render() {
    console.log(this.state.setupLeftMenu);
    let leftMenuElements = (
      <LeftMenuItem data={this.state.setupLeftMenu}></LeftMenuItem>
    );
    return leftMenuElements;
  }
}

function mapStateToProps(state) {
  return {};
}

function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    { selectTabPageAction: selectTabPageAction },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(PatientLeftMenu);
