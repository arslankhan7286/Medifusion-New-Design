import React, { Component } from 'react'

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

export class HCFA1500 extends Component {
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/ElectronicSubmission/';
        this.file = "https://www.plasticsurgery.org/documents/Health-Policy/Coding-Payment/ICD-10/ICD-10-Medical-Diagnosis-Codes.pdf";
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

    }


    componentDidMount() {

    }

    render() {

        return (
            < React.Fragment >

                <div className="container" style={{ position: "fixed" }}>
                    <div className="row">

                        <iframe
                            style={{ marginLeft: "200px" }}
                            className="pdf"
                            width="800"
                            height="650"
                            frameBorder="5"
                            src={`https://docs.google.com/gview?url=${this.file}&embedded=true`}
                        ></iframe>
                    </div>
                </div>

            </React.Fragment >
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(HCFA1500);
