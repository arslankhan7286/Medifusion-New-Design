import React, { Component } from 'react'


import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";


import LeftMenuItem from "./LeftMenuItem";




import facilityIcon from "../images/facility-icon.png";
import facilityHIcon from "../images/facility-icon-hover.png";
import locationIcon from "../images/location-icon.png";
import locationHIcon from "../images/location-icon-hover.png";




export class NewManualPostingMenu extends Component {
    constructor(props) {
        super(props)

        this.NewPaymentLeftMenu = {
            Category: "",
            Icon: "",
            hIcon: "",
            expanded: true,
            SubCategories: [
                {
                    SubCategory: "Manual Posting",
                    Icon: facilityIcon,
                    hIcon: facilityHIcon,
                    handler: () => this.props.selectTabPageAction("ManualPosting"),
                    selected: false
                }
            ]
        };

        this.state = {
            NewPaymentLeftMenu: {}
        }
    }


    componentWillMount() {

        this.setState({
            NewPaymentLeftMenu: this.NewPaymentLeftMenu
        });

    }


    render() {

        let leftMenuElements = (
            <LeftMenuItem data={this.state.NewPaymentLeftMenu}></LeftMenuItem>
        );

        return leftMenuElements;
    }
}

function mapStateToProps(state) {
    return {};
}

function matchDispatchToProps(dispatch) {
    return bindActionCreators(
        { selectTabPageAction: selectTabPageAction },
        dispatch
    );
}

export default connect(
    mapStateToProps,
    matchDispatchToProps
)(NewManualPostingMenu)
