import React, { Component } from 'react'

import Input from './Input'
import Label from './Label'
import $ from 'jquery';



import Swal from 'sweetalert2'
import axios from 'axios';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'



export class NewReason extends Component {
    constructor(props) {
        super(props)

        // this.url = 'http://192.168.110.44/database/api/Reason/'
        this.url = process.env.REACT_APP_URL + '/Reason/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };


        this.reasonModel = {
            name: '',
            description: '',
            biller: '',
            isActive: true
        }
        this.validationModel = {
            valname: '',
            valdescription: '',
            valbiller: '',

        }


        this.state = {
            editId: this.props.id,
            reasonModel: this.reasonModel,
            validationModel: this.validationModel,
            data: [],
            id: 0,
            showPopup: false

        }


        this.saveReason = this.saveReason.bind(this);
        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);

        this.handleChange = this.handleChange.bind(this);

    }

    componentDidMount() {
        this.setModalMaxHeight($('.modal'));


        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);



        if (this.state.editId > 0) {
            axios.get(this.url + 'FindReason/' + this.state.editId , this.config)
                .then(response => {
                    console.log(response.data);
                    this.setState({ reasonModel: response.data });
                }).catch(error => {
                    console.log(error);
                });
        }


    }

    saveReason = (e) => {



        var myVal = this.validationModel;
        myVal.validation = false;

        if (this.isNull(this.state.reasonModel.name)) {
            myVal.valname = <span className="validationMsg">Enter Name</span>
            myVal.validation = true
        }
        else {
            myVal.valname = ''
            if (myVal.validation === false) myVal.validation = false
        }


        if (this.isNull(this.state.reasonModel.description)) {
            myVal.valdescription = <span className="validationMsg">Enter Description</span>
            myVal.validation = true
        }
        else {
            myVal.valdescription = ''
            if (myVal.validation === false) myVal.validation = false
        }



        if (this.isNull(this.state.reasonModel.biller)) {
            myVal.valbiller = <span className="validationMsg">Enter Biller </span>
            myVal.validation = true
        }
        else {
            myVal.valbiller = ''
            if (myVal.validation === false) myVal.validation = false
        }

        this.setState({
            validationModel: myVal
        });

        if (myVal.validation === true) {
            return;
        }

        this.setState({
            validationModel: myVal
        });

        if (myVal.validation === true) {
            return;
        }






        console.log(this.state.reasonModel);
        e.preventDefault();
        axios.post(this.url + 'SaveReason', this.state.reasonModel , this.config)
            .then(response => {

                this.setState({ data: response.data });

                Swal.fire(
                    'Record Saved Successfully',
                    '',
                    'success'
                )



            }).catch(error => {
                let errorList = []
                if (error.response !== null && error !== null) {
                    errorList = error.response;
                    console.log(errorList);
                }
                else console.log(error);
            });

        e.preventDefault();
    }
    handleChange = event => {
        this.setState({
            reasonModel: {
                ...this.state.reasonModel,
                [event.target.name]: event.target.value
            }
        });
    };



    isNull(value) {
        if (value === '' || value === null || value === undefined || value === 'Please Select')
            return true;
        else return false;
    }
    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find(".modal-content");
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
        var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight });
    }

    render() {
        return (
            <React.Fragment>
                <div id='myModal' className="modal fade bs-example-modal-new show" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div className="modal-dialog modal-lg">

                        <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>

                        <div className="modal-content" style={{ overflow: 'hidden' }}>

                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">{this.state.editId > 0 ? this.state.reasonModel.name  : "NEW REASON" }</h1>
                                        </div>
                                        <div className="mf-6 popupHeadingRight">
                                            <div className="lblChkBox" onClick={this.handleCheck}>
                                                <input type="checkbox" checked={!this.state.reasonModel.isActive} id="isActive" name="isActive" />
                                                <label htmlFor="markInactive">
                                                    <span>Mark Inactive</span>
                                                </label>
                                            </div>
                                            <Input type='button' value='Delete' className="btn-blue" onClick={this.delete}>Delete</Input>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div className="mainTable">

                                    {/* <div className="mf-12 headingOne mt-25">
                                        <p>EDI Status Payer Information</p>
                                    </div> */}
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Name<span className="redlbl"> *</span></label>
                                            <div className="textBoxValidate">
                                                <Input
                                                    className={this.state.validationModel.valname ? this.errorField : ""}

                                                    type="text"
                                                    value={this.state.reasonModel.name}
                                                    name="name"
                                                    id="name"
                                                    max="11"
                                                    onChange={() => this.handleChange}
                                                />
                                                {this.state.validationModel.valname}
                                            </div>
                                        </div>
                                        <div className="mf-6">
                                            <label>Description<span className="redlbl"> *</span></label>
                                            <div className="textBoxValidate">
                                                <Input
                                                    className={this.state.validationModel.valdescription ? this.errorField : ""}
                                                    type="text"
                                                    value={this.state.reasonModel.description}
                                                    name="description"
                                                    id="description"
                                                    max="100"
                                                    onChange={() => this.handleChange}
                                                />
                                                {this.state.validationModel.valdescription}
                                            </div></div>
                                    </div>


                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Biller<span className="redlbl"> *</span></label>
                                            <Input
                                                className={this.state.validationModel.valbiller ? this.errorField : ""}
                                                type="text"
                                                value={this.state.reasonModel.biller}
                                                name="biller"
                                                id="biller"
                                                max="100"
                                                onChange={() => this.handleChange}
                                            />

                                            {this.state.validationModel.valbiller}

                                        </div>

                                        <div className="mf-6">
                                            &nbsp;
                                        </div>

                                    </div>


                                </div>


                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <button className="btn-blue" onClick={this.saveReason}>Save </button>
                                                <button id='btnCancel' className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>Cancel </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </React.Fragment >
        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(NewReason);
