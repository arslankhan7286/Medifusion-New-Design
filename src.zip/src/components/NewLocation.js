import React, { Component, Fragment } from 'react'
import $ from 'jquery';
import taxonomyIcon from '../images/code-search-icon.png'
import axios from 'axios';
import Input from './Input';

import Swal from 'sweetalert2'
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

export class NewLocation extends Component {
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/Location/'
        this.errorField = 'errorField';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };


        this.locationModel = {
            "id": 0,
            "name": "",
            "organizationName": "",
            "practiceID": '',
            "npi": "",
            "posid": '',
            "address1": "",
            "address2": "",
            "city": "",
            "state": "",
            "zipCode": "",
            "cliaNumber": "",
            "fax": "",
            "website": "",
            "email": "",
            "phoneNumber": '',
            "notes": '',
            "isActive": true,
            "isDeleted": false,
        }

        this.validationModel = {
            nameValField: '',
            organizationNameValField: '',
            practiceIDValField: '',
            npiValField: '',
            posidValField: '',
            address1ValField: '',
            address2ValField: '',
            cityValField: '',
            stateValField: '',
            zipCodeValField: '',
            cliaNumberValField: '',
            faxValField: '',
            websiteValField: '',
            emailValField: '',
            phoneNumberValField: '',
            notesValField: '',
            isActiveValField: true
        }

        this.state = {
            editId: this.props.id,
            locationModel: this.locationModel,
            validationModel: this.validationModel,
            maxHeight: '361',
            practicesData: [],
            posData: []
        }

        //this.dropdownData = {}

        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
        this.handleChange = this.handleChange.bind(this);

        this.saveLocation = this.saveLocation.bind(this);
        this.handleCheck = this.handleCheck.bind(this);
        this.delete = this.delete.bind(this);
    }



    handleCheck() {
        this.setState({
            locationModel: {
                ...this.state.locationModel,
                isActive: !this.state.locationModel.isActive
            }
        });
    }

    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find('.modal-content');
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
        var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight })
    }



    componentWillMount() {
        axios.get(this.url + 'GetProfiles' , this.config)
            .then(response => {
                this.setState({ practicesData: response.data.practice, posData: response.data.posCodes })
                console.log(response.data);
            }).catch(error => {
                console.log(error);
            });
    }

    componentDidMount() {
        this.setModalMaxHeight($('.modal'));

        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);


        if (this.state.editId > 0) {
            axios.get(this.url + 'FindLocation/' + this.state.editId , this.config)
                .then(response => {
                    console.log(response.data);
                    this.setState({ locationModel: response.data });
                }).catch(error => {
                    console.log(error);
                });
        }
    }

    handleChange = event => {
        event.preventDefault();
        this.setState({
            locationModel: { ...this.state.locationModel, [event.target.name]: event.target.value.toUpperCase() }
        });
        console.log(this.locationModel)
    };


    isNull(value) {
        if (value === '' || value === null || value === undefined || value === 'Please Select')
            return true;
        else return false;
    }

    saveLocation = (e) => {
        console.log(this.state.locationModel);
        e.preventDefault();
        this.setState({loading:true})

        var myVal = this.validationModel;
        myVal.validation = false;

        if (this.isNull(this.state.locationModel.name)) {
            myVal.nameValField = <span className="validationMsg">Enter Name</span>
            myVal.validation = true
        } else {
            myVal.nameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        if (this.isNull(this.state.locationModel.organizationName)) {
            myVal.organizationNameValField = <span className="validationMsg">Enter Organization Name</span>
            myVal.validation = true
        } else {
            myVal.organizationNameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.locationModel.npi)) {
            myVal.npiValField = <span className="validationMsg">Enter NPI</span>
            myVal.validation = true
        } else if (this.state.locationModel.npi.length < 10) {
            myVal.npiValField = <span className="validationMsg">NPI length should be 10</span>
            myVal.validation = true
        } else {
            myVal.npiValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.locationModel.practiceID)) {
            myVal.practiceIDValField = <span className="validationMsg">Select Facility</span>
            myVal.validation = true
        } else {
            myVal.practiceIDValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.locationModel.posid)) {
            myVal.posidValField = <span className="validationMsg">Select POS</span>
            myVal.validation = true
        } else {
            myVal.posidValField = ''
            if (myVal.validation === false) myVal.validation = false
        }



        if (this.isNull(this.state.locationModel.zipCode) === false && this.state.locationModel.zipCode.length > 0) {
            if (this.state.locationModel.zipCode.length < 5) {
                myVal.zipCodeValField = <span className="validationMsg">Zip should be of alleast 5 digits</span>
                myVal.validation = true
            } else if (this.state.locationModel.zipCode.length > 5 && this.state.locationModel.zipCode.length < 9) {
                myVal.zipCodeValField = <span className="validationMsg">Zip should be of either 5 or 9 digits</span>
                myVal.validation = true
            } else {
                myVal.zipCodeValField = ''
                if (myVal.validation === false) myVal.validation = false
            }
        } else {
            myVal.zipCodeValField = ''
            if (myVal.validation === false) myVal.validation = false
        }




      if ((this.state.locationModel.cliaNumber.length  > 0) && (this.state.locationModel.cliaNumber.length < 10)) {
            myVal.cliaNumberValField = <span className="validationMsg">cliaNumber length should be 10</span>
            myVal.validation = true
        } else {
            myVal.cliaNumberValField = ''
            if (myVal.validation === false) myVal.validation = false
        }





        if (this.isNull(this.state.locationModel.phoneNumber) === false && this.state.locationModel.phoneNumber.length < 10) {
            myVal.phoneNumberValField = <span className="validationMsg">Phone # length should be 10</span>
            myVal.validation = true
        } else {
            myVal.phoneNumberValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.locationModel.fax) === false && this.state.locationModel.fax.length < 10) {
            myVal.faxValField = <span className="validationMsg">Fax # length should be 10</span>
            myVal.validation = true
        } else {
            myVal.faxValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        this.setState({
            validationModel: myVal
        });

        if (myVal.validation === true) {
            this.setState({loading:false})
            return;
        }


        axios.post(this.url + 'SaveLocation', this.state.locationModel , this.config)
            .then(response => {
                this.setState({ locationModel: response.data, editId: response.data.id  , loading:false});
                Swal.fire(
                    'Record Saved Successfully',
                    '',
                    'success'
                )

            }).catch(error => {
                this.setState({loading:false})

                let errorList = []
                if (error.response !== null && error.response.data !== null) {
                    errorList = error.response.data;
                    console.log(errorList);
                }
                else
                    console.log(errorList);
                console.log('Something went wrong. Plese check console.')
            });

        e.preventDefault();
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }

    delete = e => {
        Swal.fire({
            title: "Are you sure, you want to delete this record?",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then(result => {
            if (result.value) {
                this.setState({loading:true})
                axios
                    .delete(this.url + "DeleteLocation/" + this.state.editId , this.config)
                    .then(response => {
                        this.setState({loading:false})
                        console.log("Delete Response :", response);
                        Swal.fire("Record Deleted Successfully", "", "success");
                    })
                    .catch(error => {
                        this.setState({loading:false})
                        Swal.fire("Record Not Deleted!", "Record can not be delete, as it is being referenced in other screens.", "error");
                    });

                $("#btnCancel").click();
            }
        });
    };


    render() {


        const isActive = this.state.locationModel.isActive;
        const usStates = [
            { value: "", display: "Select State" },
            { value: "AL", display: "AL - Alabama" },
            { value: "AK", display: "AK - Alaska" },
            { value: "AZ", display: "AZ - Arizona" },
            { value: "AR", display: "AR - Arkansas" },
            { value: "CA", display: "CA - California" },
            { value: "CO", display: "CO - Colorado" },
            { value: "CT", display: "CT - Connecticut" },
            { value: "DE", display: "DE - Delaware" },
            { value: "FL", display: "FL - Florida" },
            { value: "GA", display: "GA - Georgia" },
            { value: "HI", display: "HI - Hawaii" },
            { value: "ID", display: "ID - Idaho" },
            { value: "IL", display: "IL - Illinois" },
            { value: "IN", display: "IN - Indiana" },
            { value: "IA", display: "IA - Iowa" },
            { value: "KS", display: "KS - Kansas" },
            { value: "KY", display: "KY - Kentucky" },
            { value: "LA", display: "LA - Louisiana" },
            { value: "ME", display: "ME - Maine" },
            { value: "MD", display: "MD - Maryland" },
            { value: "MA", display: "MA - Massachusetts" },
            { value: "MI", display: "MI - Michigan" },
            { value: "MN", display: "MN - Minnesota" },
            { value: "MS", display: "MS - Mississippi" },
            { value: "MO", display: "MO - Missouri" },
            { value: "MT", display: "MT - Montana" },
            { value: "NE", display: "NE - Nebraska" },
            { value: "NV", display: "NV - Nevada" },
            { value: "NH", display: "NH - New Hampshire" },
            { value: "NJ", display: "NJ - New Jersey" },
            { value: "NM", display: "NM - New Mexico" },
            { value: "NY", display: "NY - New York" },
            { value: "NC", display: "NC - North Carolina" },
            { value: "ND", display: "ND - North Dakota" },
            { value: "OH", display: "OH - Ohio" },
            { value: "OK", display: "OK - Oklahoma" },
            { value: "OR", display: "OR - Oregon" },
            { value: "PA", display: "PA - Pennsylvania" },
            { value: "RI", display: "RI - Rhode Island" },
            { value: "SC", display: "SC - South Carolina" },
            { value: "SD", display: "SD - South Dakota" },
            { value: "TN", display: "TN - Tennessee" },
            { value: "TX", display: "TX - Texas" },
            { value: "UT", display: "UT - Utah" },
            { value: "VT", display: "VT - Vermont" },
            { value: "VA", display: "VA - Virginia" },
            { value: "WA", display: "WA - Washington" },
            { value: "WV", display: "WV - West Virginia" },
            { value: "WI", display: "WI - Wisconsin" },
            { value: "WY", display: "WY - Wyoming" }
        ]

        let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }

        return (
            <React.Fragment>
                {spiner}
                <div id='myModal' class="modal fade bs-example-modal-new show" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div class="modal-dialog modal-lg">

                        <button onClick={this.props.onClose()} type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                        <div className="modal-content" style={{ overflow: 'hidden' }}>
                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">{this.state.editId > 0 ? this.state.locationModel.name.toUpperCase() + " - " + this.state.locationModel.id : "NEW LOCATION"}</h1>
                                        </div>
                                        <div className="mf-6 popupHeadingRight">
                                            <div className="lblChkBox" onClick={this.handleCheck}>
                                                <input
                                                    type="checkBox"
                                                    id="isActive"
                                                    name="isActive"
                                                    checked={!isActive}
                                                />
                                                <label htmlFor="markInactive">
                                                    <span>Mark Inactive</span>
                                                </label>
                                            </div>
                                            <Input type="button" value="Delete" className="btn-blue" onClick={this.delete}>Delete</Input>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div class="mainTable">
                                    <div class="row-form">

                                        <div class="mf-6">
                                            <label>Name<span className="redlbl"> *</span></label>
                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.nameValField ? this.errorField : ""}
                                                    type="text" value={this.state.locationModel.name} max='20' name='name' id='name' onChange={() => this.handleChange}></Input>
                                                {this.state.validationModel.nameValField}
                                            </div>
                                        </div>

                                        <div class="mf-6">
                                            <label>Organization Name<span className="redlbl"> *</span></label>
                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.organizationNameValField ? this.errorField : ""}
                                                    type="text" value={this.state.locationModel.organizationName} max='30' name="organizationName" id="organizationName" onChange={() => this.handleChange}></Input>
                                                {this.state.validationModel.organizationNameValField}
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Practice<span className="redlbl"> *</span></label>

                                            <div className="selectBoxValidate">
                                                <select className={this.state.validationModel.practiceIDValField ? this.errorField : ""}
                                                    name='practiceID' id='practiceID' value={this.state.locationModel.practiceID} onChange={this.handleChange}>
                                                    {this.state.practicesData.map((s) => <option key={s.id} value={s.id}>{s.description}</option>)}
                                                </select>
                                                {this.state.validationModel.practiceIDValField}
                                            </div>
                                        </div>
                                        <div class="mf-6">
                                            &nbsp;
                                        </div>
                                    </div>
                                    <div class="mf-12 headingOne mt-25">
                                        <p>Legal Information</p>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>NPI<span className="redlbl"> *</span></label>

                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.npiValField ? this.errorField : ""}
                                                    type="text" value={this.state.locationModel.npi} name="npi" id="npi" max='10'
                                                    onChange={() => this.handleChange}
                                                    onKeyPress={event => this.handleNumericCheck(event)}></Input>
                                                {this.state.validationModel.npiValField}
                                            </div>
                                        </div>

                                        <div class="mf-6">
                                            <label>POS<span className="redlbl"> *</span></label>
                                            <div className="selectBoxValidate">
                                                <select className={this.state.validationModel.posidValField ? this.errorField : ""}
                                                    name='posid' id='posid' value={this.state.locationModel.posid} onChange={this.handleChange}>
                                                    {this.state.posData.map((s) => <option key={s.id} value={s.id}>{s.description}</option>)}
                                                </select>
                                                {this.state.validationModel.posidValField}
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row-form">






                                        <div className="mf-6 mf-icon">
                                            <label>CLIA</label>

                                            <div className="textBoxValidate">
                                                <Input
                                                    className={this.state.validationModel.cliaNumberValField ? this.errorField : ""}
                                                    type="text" value={this.state.locationModel.cliaNumber} name="cliaNumber" id="cliaNumber" max='10'
                                                    onChange={() => this.handleChange} />

                                                {this.state.validationModel.cliaNumberValField}
                                            </div>

                                        </div>
                                        <div class="mf-6">
                                            &nbsp;
                                        </div>
                                    </div>
                                    <div class="mf-12 headingOne mt-25">
                                        <p>Address Information</p>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Address 1</label>
                                            <Input type="text" value={this.state.locationModel.address1} max='50' name="address1" id="address1" max='55' onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-6">
                                            <label>Address 2</label>
                                            <Input type="text" value={this.state.locationModel.address2} max='50' name="address2" id="address2" max='55' onChange={() => this.handleChange}></Input>
                                        </div>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>City - State</label>
                                            <div class="textBoxTwoField">
                                                <Input type="text" value={this.state.locationModel.city} max='20' name="city" id="city" onChange={() => this.handleChange} />

                                                <select name='state' id='state' value={this.state.locationModel.state} onChange={this.handleChange}>
                                                    {usStates.map((s) => <option key={s.value} value={s.value}>{s.display}</option>)}
                                                </select>
                                            </div>
                                        </div>
                                        <div class="mf-6">
                                            <label>Zip Code -  Phone</label>


                                            <div class="textBoxTwoField textBoxValidate">
                                                <div className="twoColValidate">
                                                    <Input className={this.state.validationModel.zipCodeValField ? this.errorField : ""}
                                                        type="text" value={this.state.locationModel.zipCode} max='9' name="zipCode" id="zipCode" onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)}></Input>
                                                    {this.state.validationModel.zipCodeValField}
                                                </div>

                                                <div className="twoColValidate">
                                                    <Input className={this.state.validationModel.phoneNumberValField ? this.errorField : ""}
                                                        type="text" value={this.state.locationModel.phoneNumber} max='10' name="phoneNumber" id="phoneNumber" onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)}></Input>
                                                    {this.state.validationModel.phoneNumberValField}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Fax</label>
                                            <div className="textBoxValidate">
                                                <Input type="text" value={this.state.locationModel.fax}
                                                    className={this.state.validationModel.faxValField ? this.errorField : ""}
                                                    max='10' name="fax" id="fax" onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)}></Input>
                                                {this.state.validationModel.faxValField}
                                            </div>
                                        </div>
                                        <div class="mf-6">
                                            <label>Website</label>
                                            <Input type="text" value={this.state.locationModel.website} name="website" id="website" max='50' onChange={() => this.handleChange}></Input>
                                        </div>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Email</label>
                                            <Input type="text" value={this.state.locationModel.email} name="email" id="email" max='30' onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-6">
                                            &nbsp;
                                    </div>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-12 field_full-8">
                                            <label>Notes:</label>
                                            <textarea value={this.state.locationModel.notes} name="notes" id="notes" cols="30" rows="10" onChange={this.handleChange} ></textarea>
                                        </div>

                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <div class="mainTable">
                                        <div class="row-form row-btn">
                                            <div class="mf-12">
                                                <button class="btn-blue" onClick={this.saveLocation}>Save </button>
                                                <button id='btnCancel' class="btn-grey" data-dismiss="modal" onClick={this.props.onClose()} >Cancel </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </React.Fragment >

        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        // id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(NewLocation);