import React from 'react'

import settingIcon from '../images/setting-icon.png'

function GridHeading(props) {
    return (
        <div className="row headingTable">
            <div className="mf-6">
                <h1>{props.Heading}</h1>
            </div>
            <div className="mf-6 headingRightTable">
                <a href="javascript:;"><img src={settingIcon} alt="" /></a>
            </div>
        </div>
    )
}

export default GridHeading
