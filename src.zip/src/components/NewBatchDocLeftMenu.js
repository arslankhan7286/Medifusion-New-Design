import React, { Component } from 'react'
import LeftMenuItem from "./LeftMenuItem";
import facilityIcon from "../images/facility-icon.png";
import facilityHIcon from "../images/facility-icon-hover.png";
import locationIcon from "../images/location-icon.png";
import locationHIcon from "../images/location-icon-hover.png";


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'




export class NewBatchDocLeftMenu extends Component {
    constructor(props) {
        super(props)


        this.NewBatchDocLeftMenu = {
            Category: "",
            Icon: "",
            hIcon: "",
            expanded: true,
            SubCategories: [
                {
                    SubCategory: "BatchDocument",
                    Icon: facilityIcon,
                    hIcon: facilityHIcon,
                    handler: () => this.props.selectTabPageAction("BatchDocument"),
                    selected: false
                },
                {
                    SubCategory: "DocumentType",
                    Icon: facilityIcon,
                    hIcon: facilityHIcon,
                    handler: () => this.props.selectTabPageAction("DocumentType"),
                    selected: false
                }
            ]
        };

        this.state = {
            NewBatchDocLeftMenu: {}
        }
    }



    componentWillMount() {

        this.setState({
            NewBatchDocLeftMenu: this.NewBatchDocLeftMenu
        });

    }

    render() {
        let leftMenuElements = (
            <LeftMenuItem data={this.state.NewBatchDocLeftMenu}></LeftMenuItem>
        );


        return leftMenuElements;

    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(NewBatchDocLeftMenu);
