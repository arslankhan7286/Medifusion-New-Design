import React, { Component } from 'react'

import $ from "jquery";



import { MDBDataTable, MDBBtn } from "mdbreact";

import Label from "./Label";
import Input from "./Input";

import axios from 'axios';

import Swal from 'sweetalert2'
import { Tabs, Tab } from 'react-tab-view';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


export class NewPatientPlanModel extends Component {
    constructor(props) {
        super(props)
        this.url = process.env.REACT_APP_URL + '/PatientFollowup/';
        
 //Authorization Token
 this.config = {
    headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
};


        this.patientPlanModel = {
            "visitID": '',
            "reasonID": '',
            "actionID": '',
            "groupID": '',
            "practiceID": '',
            "locationID": '',
            "providerID": '',
            "referingProviderID": '',
            "insurancePlanID": '',
            "patientID": '',

            "followUpDate": '',
            "folowupAge": '',
            "tickleDate": '',
            "statement1SentDate": '',
            "statement2SentDate": '',
            "status": '',
            "addedBy": '',

            "updatedBy": '',

            notes: ''


        }
        this.patientModal = {
            "patientID": '',
            "patientName": '',
            "accountNumber": '',
            "dob": '',
            "practiceID": '',

            "practiceName": '',
            "locationID": '',
            "locationName": '',
            "providerID": '',
            "providerName": '',
            "refProviderID": '',
            "refProviderName": '',
            "supProviderID": '',
            "supProviderName": '',

            "reasonID": '',
            "reason": "",
            "actionID": '',
            "action": "",
            "groupID": '',
            "group": "",

            "planName": '',
            "insuredName": '',
            "insuredID": '',

        }

        this.state = {
            patientPlanModel: this.patientPlanModel,
            patientModal: this.patientModal,
            editId: this.props.id,
            data: [],
            id: 0,

            resData: [],
            remCodeData: [],
            groupData: [],
            actionData: [],
            adjData: [],
            locData: [],
            proData: [],
            refproData: [],
            supproData: [],
            practionData: [],

            submissionData: '',

            isActive: true





        }
        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find('.modal-content');
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
        var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight })
    }

    componentDidMount() {


        this.setModalMaxHeight($('.modal'));

        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);
        if (this.state.editId > 0) {
            alert(this.state.editId)
            // console.log('http://192.168.110.44/Database/api/patientFollowUp/FindPatientFollowUpCharge/2')
            axios.get(this.url + 'FindPatientFollowUpCharge/' + this.state.editId , this.config)


                .then(response => {
                    console.log(this.state.editId)
                    this.setState({ patientPlanModel: response.data });
                }).catch(error => {
                    console.log(error);
                });
        }
    }


    componentWillMount() {
        axios.get(this.url + 'FindPatientInfo/' + this.props.id , this.config)


            .then(response => {
                console.log(response)

                let newList = []
                response.data.map((row, i) => {

                    newList.push({
                        id: row.id,

                        // patientID: <MDBBtn className='gridBlueBtn' size="sm" onClick={() => this.openPatientFollowupPopup(row.patientID)}>{row.patientID}</MDBBtn>,

                        patientID: row.patientID,
                        patientName: row.patientName,
                        accountNumber: row.accountNumber,
                        dob: row.dob,
                        practiceID: row.practiceID,

                        practiceName: row.practiceName,
                        locationID: row.locationID,
                        locationName: row.locationName,
                        providerID: row.providerID,
                        providerName: row.providerName,
                        refProviderID: row.refProviderID,
                        refProviderName: row.refProviderName,
                        supProviderID: row.supProviderID,
                        supProviderName: row.supProviderName,

                        groupID: row.groupID,
                        group: row.group,
                        actionID: row.actionID,
                        action: row.action,
                        reasonID: row.reasonID,
                        reason: row.reason,

                        planName: row.planName,
                        insuredName: row.insuredName,
                        insuredID: row.insuredID,


                    });
                });



                this.setState({ data: newList });

            }).catch(error => {
                console.log(error);
            });
    }



    componentDidMount() {

        // console.log('http://192.168.110.44/Database/api/PlanFollowUp/FindPlanFollowUp/')
        // console.log('http://192.168.110.44/Database/api/PatientFollowup/FindPatientFollowUp/')



        this.setModalMaxHeight($('.modal'));

        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);


        if (this.state.editId > 0) {
            console.log(this.state.editId)
            //FindPatientInfo
            //FindPatientFollowUp
            axios.get(this.url + 'FindPatientFollowUp/' + this.state.editId ,this.config)
                .then(response => {
                    console.log(response.data);
                    this.setState({ patientPlanModel: response.data });
                }).catch(error => {
                    console.log(error);
                });

            axios.get(this.url + 'FindPatientInfo/' + this.state.editId ,this.config)
                .then(response => {
                    console.log(response.data);
                    this.setState({ patientModal: response.data });
                }).catch(error => {
                    console.log(error);
                });


            console.log('http://192.168.110.44/Database/api/patientFollowUp/FindPatientFollowUpCharge/2')

            axios.get(this.url + 'FindPatientFollowUpCharge/' + this.state.editId , this.config)
                .then(response => {
                    console.log(response)

                    let newList = []
                    response.data.map((row, i) => {

                        newList.push({
                            id: row.id,

                            // patientID: <MDBBtn className='gridBlueBtn' size="sm" onClick={() => this.openPatientFollowupPopup(row.patientID)}>{row.patientID}</MDBBtn>,

                            visitID: row.visitID,
                            chargeID: row.chargeID,
                            plan: row.plan,
                            dos: row.dos,
                            cpt: row.cpt,
                            billedAmount: row.billedAmount,
                            allowedAmount: row.allowedAmount,
                            paidAmount: row.paidAmount,

                            copay: row.copay,
                            deductible: row.deductible,
                            coInsurance: row.coInsurance,
                            patientPaid: row.patientPaid



                        });
                    });

                    this.setState({ data: newList });

                }).catch(error => {
                    console.log(error)
                });

        }


    }


    handleChange = event => {


        event.preventDefault();


        this.setState({
            patientPlanModel: {
                ...this.state.patientPlanModel,
                [event.target.name]: event.target.value
            }
        });
    };
    componentWillMount() {
        axios.get(this.url + 'GetProfiles' ,this.config)
            .then(response => {

                this.setState({
                    resData: response.data.reason,
                    groupData: response.data.group,
                    actionData: response.data.action
                })

                console.log(response.data);
            }).catch(error => {
                console.log(error);
            });
    }



    savePatientFollowupModel = (e) => {
        console.log(this.state.patientPlanModel)
        axios.post(this.url + 'SavePatientFollowUp', this.state.patientPlanModel ,this.config)

            .then(response => {
                this.setState({ patientPlanModel: response.data, editId: response.data.id });
                console.log(response.data)
                console.log(response)

                Swal.fire(
                    'Record Saved Successfully',
                    '',
                    'success'
                )
                this.componentWillMount()
            }).catch(error => {
                let errorsList = []
                if (error.response !== null && error.response.data !== null) {
                    errorsList = error.response.data
                    console.log(errorsList)

                } else {
                    console.log(error);
                    alert('Something went wrong. Plese check console.')
                }
            });

        e.preventDefault();



    }



    render() {
        const headers = ['Patient Details', 'Other 1', 'Other 2'];


        var addtickleDate = this.state.patientPlanModel.tickleDate ? this.state.patientPlanModel.tickleDate.replace("T00:00:00", "") : "";
        var addFollowUpDate = this.state.patientPlanModel.followUpDate ? this.state.patientPlanModel.followUpDate.replace("T00:00:00", "") : "";

          var statY = this.state.patientPlanModel.statement1SentDate ? this.state.patientPlanModel.statement1SentDate.slice(0, 4) : "";
        var statM = this.state.patientPlanModel.statement1SentDate ? this.state.patientPlanModel.statement1SentDate.slice(5, 7) : "";
        var statD = this.state.patientPlanModel.statement1SentDate ? this.state.patientPlanModel.statement1SentDate.slice(8, 10) : "";


        var stat1Y = this.state.patientPlanModel.statement2SentDate ? this.state.patientPlanModel.statement2SentDate.slice(0, 4) : "";
        var stat1M = this.state.patientPlanModel.statement2SentDate ? this.state.patientPlanModel.statement2SentDate.slice(5, 7) : "";
        var stat1D = this.state.patientPlanModel.statement2SentDate ? this.state.patientPlanModel.statement2SentDate.slice(8, 10) : "";

        const data = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 150
                }
                ,
                {
                    label: "VISIT",
                    field: "visit",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "CHARGE ID",
                    field: "chargeID",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PLAN",
                    field: "plan",
                    sort: "asc",
                    width: 150
                }, {
                    label: "DOS",
                    field: "dos",
                    sort: "asc",
                    width: 300
                }
                ,
                {
                    label: "CPT",
                    field: "cpt",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "BILLED AMT",
                    field: "billedAMT",
                    sort: "asc",
                    width: 150
                }, {
                    label: "ALLOWED AMT",
                    field: "allowedAMT",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PAID AMT",
                    field: "paidAMT",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "COPAY",
                    field: "copay",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "DEDUCTIBLE",
                    field: "deductible",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "CO-INS",
                    field: "coins",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PAT.PAID",
                    field: "patPaid",
                    sort: "asc",
                    width: 150
                }
            ],
            rows: this.state.data

        };





        return (
            <React.Fragment>
                <div id='myModal' className="modal fade bs-example-modal-new show" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div className="modal-dialog modal-lg">

                        <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>

                        <div className="modal-content" style={{ overflow: 'hidden' }}>




                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div className="mainTable fullWidthTable">
                                    <div className="row-form">

                                        <div className="mf-12">

                                            <Tabs headers={headers} style={{ cursor: "default" }}>
                                                <Tab>
                                                    <div style={{ marginTop: "20px" }}>
                                                        <div className="mainTable fullWidthTable wSpace" style={{ maxWidth: "100%" }}>

                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Reason"></Label>

                                                                    <div className="selectBoxValidate">
                                                                        <select name="reasonID" id="reasonID"
                                                                            value={this.state.patientPlanModel.reasonID} onChange={this.handleChange}>
                                                                            {this.state.resData.map(s => (
                                                                                <option key={s.id} value={s.id}>
                                                                                    {s.description}
                                                                                </option>
                                                                            ))}
                                                                        </select>
                                                                    </div>

                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Action"></Label>

                                                                    <div className="selectBoxValidate">
                                                                        <select name="actionID" id="actionID"
                                                                            value={this.state.patientPlanModel.actionID} onChange={this.handleChange}>
                                                                            {this.state.actionData.map(s => (
                                                                                <option key={s.id} value={s.id}>
                                                                                    {s.description}
                                                                                </option>
                                                                            ))}
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Group"></Label>

                                                                    <div className="selectBoxValidate">
                                                                        <select name="groupID" id="groupID"
                                                                            value={this.state.patientPlanModel.groupID} onChange={this.handleChange}>
                                                                            {this.state.groupData.map(s => (
                                                                                <option key={s.id} value={s.id}>
                                                                                    {s.description}
                                                                                </option>
                                                                            ))}
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>



                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Follow up Date"></Label>


                                                                    <div className="textBoxValidate">
                                                                        <input
                                                                            style={{
                                                                                width: "215px",
                                                                                marginLeft: "0px"
                                                                            }}
                                                                            className="myInput"
                                                                            type="date"
                                                                            name="followUpDate"
                                                                            id="followUpDate"
                                                                            value={addFollowUpDate}
                                                                            onChange={this.handleChange}
                                                                        ></input>
                                                                    </div>



                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Follow up Age "></Label>

                                                                    <Input type="text" value={this.state.patientPlanModel.age} name="age" id="age" onChange={() => this.handleChange}></Input>

                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Tickle Date"></Label>

                                                                    <div className="textBoxValidate">
                                                                        <input
                                                                            style={{
                                                                                width: "215px",
                                                                                marginLeft: "0px"
                                                                            }}
                                                                            className="myInput"
                                                                            type="date"
                                                                            name="tickleDate"
                                                                            id="tickleDate"
                                                                            value={addtickleDate}
                                                                            onChange={this.handleChange}
                                                                        ></input>
                                                                    </div>



                                                                </div>
                                                            </div>
                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Statment 1 Sent Date"></Label>


                                                                    <div className="textBoxValidate">
                                                                        <Input disabled="disabled" type="text" value={statM + '/' + statD + '/' + statY} name="statement1SentDate" id="statement1SentDate" onChange={() => this.handleChange}></Input>

                                                                    </div>


                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Statment 2 Sent Date"></Label>
                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={stat1M + '/' + stat1D + '/' + stat1Y} name="statement2SentDate" id="statement2SentDate" onChange={() => this.handleChange}></Input>
                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Status"></Label>
                                                                    <div className="textBoxValidate">

                                                                        <Input type="text" value={this.state.patientPlanModel.status} name="status" id="status" onChange={() => this.handleChange}></Input>
                                                                    </div>

                                                                </div>
                                                            </div>

                                                            <div className="row-form">
                                                                <div className="mf-12 field_full-12">
                                                                    <label>Notes:</label>
                                                                    <textarea
                                                                        name="notes"
                                                                        id="notes"
                                                                        cols="30"
                                                                        rows="10"
                                                                        value={this.state.patientPlanModel.notes}
                                                                        onChange={this.handleChange}
                                                                    ></textarea>
                                                                </div>
                                                            </div>
                                                            <div className="headingOne mt-25">
                                                                <p>Submission Info</p>
                                                            </div>




                                                            <div className="mf-12 table-grid mt-15">

                                                                <div className="tableGridContainer">
                                                                    <MDBDataTable
                                                                        responsive={true}
                                                                        striped
                                                                        bordered
                                                                        searching={false}
                                                                        data={data}
                                                                        displayEntries={false}
                                                                        sortable={true}
                                                                        scrollX={false}
                                                                        scrollY={false}
                                                                    />
                                                                </div>
                                                            </div>





                                                            <div className="row-form">
                                                                {/* <div className="mf-4">
                                                                    <Label name="Practice"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.practiceName} name="practiceName" id="practiceName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Location"></Label>

                                                                    <div className="textBoxValidate">
                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.locationName} name="locationName" id="locationName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Provider"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.providerName} name="providerName" id="providerName" onChange={() => this.handleChange}></Input>


                                                                    </div>
                                                                </div> */}
                                                            </div>


                                                            <div className="row-form">
                                                                {/* <div className="mf-4">
                                                                    <Label name="Ref. Provider"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.refProviderName} name="refProviderName" id="refProviderName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Sup. Provider "></Label>

                                                                    <div className="textBoxValidate">


                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.supProviderName} name="supProviderName" id="supProviderName" onChange={() => this.handleChange}></Input>


                                                                    </div>



                                                                </div>
                                                                <div className="mf-4">
                                                                    &nbsp;
                                                                </div> */}
                                                            </div>
                                                            <div className="headingOne mt-25">
                                                                <p>Patient Detail</p>
                                                            </div>
                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Account #"></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientModal.accountNumber} name="accountNumber" id="accountNumber" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Patient name"></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientModal.patientName} name="patientName" id="patientName" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="DOB"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input type="text" disabled="disabled" value={this.state.patientModal.dob} name="dob" id="dob" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div className="row-form">
                                                                <div className="mf-4">
                                                                    <Label name="Plan Name"></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientModal.planName} name="planName" id="planName" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Insured Name"></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientModal.insuredName} name="insuredName" id="insuredName" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Insured ID "></Label>

                                                                    <Input type="text" disabled="disabled" value={this.state.patientModal.insuredID} name="insuredID" id="insuredID" onChange={() => this.handleChange}></Input>
                                                                </div>
                                                            </div>








                                                        </div>
                                                    </div>
                                                </Tab>
                                                <Tab>
                                                    <div style={{ marginTop: "20px" }}>
                                                        <div className="mainTable fullWidthTable wSpace" style={{ maxWidth: "100%" }}>



                                                            <div className="headingOne mt-25">
                                                                <p>Submission Info</p>
                                                            </div>



                                                            <div className="headingOne mt-25">
                                                                <p>Legal Entities</p>
                                                            </div>





                                                        </div>
                                                    </div>
                                                </Tab>
                                                <Tab>
                                                    <div style={{ marginTop: "20px" }}>
                                                        <div className="mainTable fullWidthTable wSpace" style={{ maxWidth: "100%" }}>



                                                            <div className="headingOne mt-25">
                                                                <p>Submission Info</p>
                                                            </div>



                                                            <div className="headingOne mt-25">
                                                                <p>Legal Entities</p>
                                                            </div>





                                                        </div>
                                                    </div>
                                                </Tab>
                                            </Tabs>


                                        </div>
                                    </div>



                                </div>
                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <button className="btn-blue" onClick={this.savePatientFollowupModel}>Save </button>
                                                <button id='btnCancel' className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>Cancel </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>

                    </div>

                </div>


            </React.Fragment >
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(NewPatientPlanModel);
