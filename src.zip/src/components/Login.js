import  React, {Component} from 'react';
import loginLogo from '../images/medi-fusion-login-logo.png';
import axios from  'axios';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {userInfo} from '../actions/userInfo';

import Swal from 'sweetalert2';

class Login extends Component{
    constructor(props){
        super(props);

        this.url = process.env.REACT_APP_URL + '/account/';

        this.loginModel={
            email:"",
            password:""
        }

        this.state={
            loginModel : this.loginModel            
        }

        this.handleLogin = this.handleLogin.bind(this);
        this.handleChange = this.handleChange.bind(this)
    }

    handleLogin(){

        axios.post(this.url + 'login', this.state.loginModel)
            .then(response => {
                this.props.loginAction(response.data,true);

                
                // Get User Info
                axios({ url: this.url + "getUserInfo" ,
                method: "get",
                headers : {
                 Authorization: "Bearer  " + response.data,
                 
                }})
                    .then(response => {
                         this.props.userInfo(response.data);  
                         console.log("User Info Rsponse : " , response.data)                      
                    }).catch(error => {
                        console.log(JSON.stringify(error));
                    });  


            }).catch(error => {
                //this.setState({loading:false})
                
                if (error.response) {
                    if(error.response.status){
                        Swal.fire("Unauthorized Access" , "" , "error")
                    }
                  } else if (error.request) {
                    console.log(error.request);
                  } else {
                    console.log('Error', error.message);
                  }
                  console.log(JSON.stringify(error));
                  Swal.fire("LOGIN FAILED","Please Login Again" , "error")
            });      
    }

    handleChange(event){
        this.setState({
            loginModel:{
                ...this.state.loginModel,
                [event.target.name]: event.target.value
            }
})
    }

    render(){

      
      
        return(
                <div className="login-bg-img" >
                <div className="container login-form"  style={{marginTop:"0px"}}>
                    <div className="row" >
                        <div className="mf-6" style={{marginTop:"100px" , marginRight:"0px"}}>
                            <div  style={{backgroundColor:"white"}} >
                                <div className="mf-12 text-center">
                                    <img src={loginLogo} alt=""/>
                                </div>
                                <div className="mf-12 pL-75">
                                    <p>User Name </p>
                                    <input type="text" value={this.state.loginModel.email} name="email" id="email" onChange={this.handleChange}></input>
                                </div>
                                <div className="mf-12 pL-75">
                                    <p>Password </p>
                                    <input type="password" value={this.state.loginModel.password} name="password" id="password" onChange={this.handleChange}></input>
                                </div>
                                <div className="mf-12 pL-75">
                                    <a href="#">Forgot Password?</a>
                                </div>
                                <div className="mf-12 pL-75">
                                    <a className="login-btn" href="#"
                                    //  onClick={this.props.handler()}
                                    onClick={this.handleLogin}
                                    >Login</a>
                                </div>
                            </div>
                        </div>
                        <div class="mf-6 login-formBg-img" style={{marginTop:"100px" , marginLeft:"0px"}} >
                        
                        </div>

                    </div>
                </div>
                </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus
    };
}


function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction , loginAction  ,userInfo:userInfo }, dispatch);
}



export default connect(mapStateToProps, matchDispatchToProps)(Login);