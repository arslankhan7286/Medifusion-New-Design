import React, { Component } from 'react'

import logoIcon from '../images/logo-Medi-Fusion.jpg'
import bellIcon from '../images/bell-icon.png'
import msgIcon from '../images/message-icon.png'
import profPic from '../images/profile.jpg'
import TopMenuItem from './TopMenuItem'
import axios from  'axios';
import dashboardIcon from '../images/dashboard-icon.png'
import dashboardHoverIcon from '../images/dashboard-icon-hover.png'
import schdulerIcon from '../images/scheduler-icon.png'
import schedlerHoverIcon from '../images/scheduler-icon-hover.png'

import patientIcon from '../images/patient-icon.png'
import patientHoverIcon from '../images/patient-icon-hover.png'
import chargesIcon from '../images/charges-icon.png'
import chargesHoverIcon from '../images/charges-icon-hover.png'
import subIcon from '../images/submissions-icon.png'
import subHoverIcon from '../images/submissions-icon-hover.png'
import payIcon from '../images/scheduler-icon.png'
import payHoverIcon from '../images/scheduler-icon-hover.png'
import followIcon from '../images/scheduler-icon.png'
import followHoverIcon from '../images/scheduler-icon-hover.png'
import reportsIcon from '../images/scheduler-icon.png'
import reportsHoverIcon from '../images/scheduler-icon-hover.png'
import setupIcon from '../images/scheduler-icon.png'
import setupHoverIcon from '../images/scheduler-icon-hover.png'
import logoutPic from  '../images/logout-icon.png';
import settingIcon from '../images/setting-icon-blue.png'
import Swal from 'sweetalert2'

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


class Header extends Component {    
    constructor(props) {
        super(props);

        this.url = process.env.REACT_APP_URL + '/account/';
          //Authorization Token
          this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };      


        this.userPracticeModel = {
            userPracticeID : 0
        }

        this.state = {
            userPractices : [],
            userPracticeModel  : this.userPracticeModel,
       }

        this.handleLogout = this.handleLogout.bind(this);
        this.handleUserPracticeChange = this.handleUserPracticeChange.bind(this);
    }


    //Selected TAB
    selectTab(tab) {
        console.log(tab);
        this.setState({ selectedTab: tab });
    }

    // Handle Logout
    handleLogout(){
        Swal.fire({
            title: "Are you sure, you want to Logout?",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, Logout"
        }).then(result => {
            if (result.value) {
                this.props.loginAction("",false);
                // axios
                //     .delete(this.url + "DeletePractice/" + this.state.editId , config)
                //     .then(response => {
                //         this.setState({loading:false})
                //         console.log("Delete Response :", response);
                //         Swal.fire("Record Deleted Successfully", "", "success");
                //     })
                //     .catch(error => {
                //         this.setState({loading:false})
                //         Swal.fire("Record Not Deleted!", "Record can not be delete, as it is being referenced in other screens.", "error");
                //     });
                // Swal.fire("Logout Successfully", "", "success");

            }
        });
    }

    //Handle User Practice Change
  async  handleUserPracticeChange(event){
       
        var practiceID = event.target.value;
        if( practiceID === "Please Select"){
            console.log(event.target.value)
           await this.setState({
                userPracticeModel :{
                    ...this.state.userPracticeModel,
                    userPracticeID  : "null"
                }
            })    
            return
        }

        Swal.fire({
            title: "Are you sure, you want to Change this Practice?",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, Change it!"
        }).then(result => {
            if (result.value) {

                 // Get User Info
         axios.get(this.url + "switchPractice/" + practiceID  , this.config)
         .then(response => {
             this.setState({
                userPracticeModel :{
                    ...this.state.userPracticeModel,
                    userPracticeID  : practiceID
                }
            })             
         }).catch(error => {
            if (error.response) {
                if(error.response.status){
                    console.log(JSON.stringify(error));
                }
              } else if (error.request) {
                console.log(error.request);
              } else {
                console.log('Error', error.message);
              }
              console.log(JSON.stringify(error));
         });  

            }
        });

       
    }


    render() {

        return (
            <React.Fragment>
                <div className="fixed-top top-header">                   

                    <header>
                            <div className="logoContainer">
                            <img src={logoIcon} alt="" />
                            </div>
                            <div className="headerRight">
                                <div className="headerRightInner">
                                    <a className="notificationIcon"> 
                                    <img src={bellIcon} alt="" />
                                        <span>8</span>
                                    </a>
                                    <a className="messageIcon"> 
                                    <img src={msgIcon} alt="" />
                                        <span>3</span>
                                    </a>
                                    <div className="profileDetail" > 
                                    <img src={profPic} alt="" />
                                        <div className="userProfileHeader">
                                            <a ><span title="Welcome John Doe">{this.props.userInfo.userInfo.name  ? "Welcome " + this.props.userInfo.userInfo.name  : "Welcome"}</span></a>
                                            <select clasName="niceSelectContainer"
                                                 name="userPracticeID"
                                                 id="userPracticeID"
                                                 value={ ((this.state.userPracticeModel.userPracticeID > 1) || (this.state.userPracticeModel.userPracticeID == null) )? this.state.userPracticeModel.userPracticeID :  this.props.userInfo.userInfo.practiceID}
                                                 onChange={this.handleUserPracticeChange}>
                                                { this.props.userInfo.userInfo.userPractices.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                    ))}
                                            </select>
                                        </div>
                                    </div>
                                    <a className="headerSettingsIcon" title="Settings" > 
                                        <img src={settingIcon} alt="Settings"/> 
                                    </a>
                                    <a className="headerSettingsIcon" title="Logout" onClick={this.handleLogout}> 
                                        <img src={logoutPic}/> 
                                    </a>
                                </div>
                            </div>
                        </header>

                    <nav className="navbar navbar-expand-md navbar-dark bg-primary primary-menu">
                     
                        <div className="collapse navbar-collapse" id="navbarNavDropdown">
                            <ul className="navbar-nav">
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Dashboard' icon={dashboardIcon} hoverIcon={dashboardHoverIcon} handler={() => this.props.selectTabAction('Dashoboard')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Scheduler' icon={schdulerIcon} hoverIcon={schedlerHoverIcon} handler={() => this.props.selectTabAction('Scheduler')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Patient' icon={patientIcon} hoverIcon={patientHoverIcon} handler={() => this.props.selectTabAction('Patient')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Charges' icon={chargesIcon} hoverIcon={chargesHoverIcon} handler={() => this.props.selectTabAction('Charges')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Documents' icon={chargesIcon} hoverIcon={chargesHoverIcon} handler={() => this.props.selectTabAction('Documents')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Submissions' icon={subIcon} hoverIcon={subHoverIcon} handler={() => this.props.selectTabAction('Submissions')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Payments' icon={payIcon} hoverIcon={payHoverIcon} handler={() => this.props.selectTabAction('Payments')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Followup' icon={followIcon} hoverIcon={followHoverIcon} handler={() => this.props.selectTabAction('Followup')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Reports' icon={reportsIcon} hoverIcon={reportsHoverIcon} handler={() => this.props.selectTabAction('Reports')}></TopMenuItem>
                                <TopMenuItem liClassName='nav-item' aClassName='nav-link' Caption='Setup' icon={setupIcon} hoverIcon={setupHoverIcon} handler={() => this.props.selectTabAction('Setup')}></TopMenuItem>
                            </ul>
                        </div>
                    </nav>
                </div>

            </React.Fragment>
        );
    }
}



function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo != null  ? state.loginInfo : {userInfo : {
            userPractices : [] , name : "",practiceID:null
        }}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }

  export default connect(mapStateToProps, matchDispatchToProps)(Header);