import React, { Component } from 'react'

import facilityIcon from '../images/facility-icon.png'
import facilityHIcon from '../images/facility-icon-hover.png'
import locationIcon from '../images/location-icon.png'
import locationHIcon from '../images/location-icon-hover.png'
import provIcon from '../images/provider-icon.png'
import provHIcon from '../images/provider-icon-hover.png'
import refprovIcon from '../images/referring-icon.png'
import refprovHIcon from '../images/referring-icon-hover.png'


import LeftMenuItem from './LeftMenuItem'


import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction'



class Submissions extends Component {

    constructor(props) {
        super(props)

        let setupLeftMenu = [
            {
                Category: '', Icon: '', hIcon: '', expanded: true,
                SubCategories: [{
                    SubCategory: 'Electronic Submission', Icon: facilityIcon, hIcon: facilityHIcon, handler: () => this.props.selectTabPageAction('ELECTRONIC SUBMISSION'), selected: false
                }, {
                    SubCategory: 'Paper Submission', Icon: locationIcon, hIcon: locationHIcon, handler: () => this.props.selectTabPageAction('PAPER SUBMISSION'), selected: false
                }, {
                    SubCategory: 'Submission Log', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('SUBMISSION LOG'), selected: false
                },
                ]
            }
        ]

        this.state = {
            leftNavigationMenus: setupLeftMenu
        }
    }

    render() {

        // console.log("===========================")
        // console.log(this.props.leftMenusFromSetup)
        console.log(this.props.leftNavigationMenus)


        //console.log(this.state.setupLeftMenu)



        let leftMenuElements = []
        this.state.leftNavigationMenus.map((catogry, i) => {
            leftMenuElements.push(
                <LeftMenuItem data={catogry}></LeftMenuItem >
            )
        })

        // this.props.leftNavigationMenus.map((catogry, i) => {
        //     leftMenuElements.push(
        //         <LeftMenuItem data={catogry}></LeftMenuItem >
        //     )
        // })

        return (
            leftMenuElements
        )
    }
}



function mapStateToProps(state) {
    console.log(state.leftNavigationMenus)
    return {
        leftNavigationMenus: state.leftNavigationMenus
    };
}

function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(Submissions);