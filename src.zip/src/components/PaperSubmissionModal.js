import React, { Component } from 'react'

import { MDBDataTable } from 'mdbreact';
import GridHeading from './GridHeading';
import { saveAs } from 'file-saver';
import PDFViewPopup from "./PDFViewPopup";

import axios from 'axios';



import $ from 'jquery';



//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'



export class PaperSubmissionModal extends Component {
    constructor(props) {
        super(props)
        this.url = process.env.REACT_APP_URL + '/PaperSubmission/';

         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };


        this.state = {
            totalClaim: this.props.totalVisits,
            processedClaims: this.props.data.processedClaims,
            data: this.props.data.errorVisits,
            isFileSub: this.props.data.isFileSubmitted,
            logSubmitId: this.props.data.submissionLogID,
            viewPdf: false,
            id: 0
        }
        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
        this.downloadHcfaFile = this.downloadHcfaFile.bind(this);
        this.viewHCFAFile = this.viewHCFAFile.bind(this);
    }
    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find(".modal-content");
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 500 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
        var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight });
    }
    viewHCFAFile() {
        //this.props.selectTabAction("viewHCFAFile");
        this.setState({ viewPdf: true })
    }

    downloadHcfaFile() {
        console.log(this.logSubmitId);

        axios.get(
            this.url + 'DownloadHCFAFile/' + this.state.logSubmitId, {
            headers: {
                'Content-Type': 'application/json',
                Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"
            },
            responseType: 'blob',
        })
            .then(function (res) {
                var blob = new Blob([res.data], {
                    type: 'application/pdf',
                });

                saveAs(blob, 'hcfa.pdf');
            });

    }

    componentDidMount() {

        this.setModalMaxHeight($('.modal'));

    }

    closePDFViewPopup = () => {
        $('#myModal1').hide()
        this.setState({ viewPdf: false });
    }

    render() {

        console.log(this.props.data)
        console.log(this.state.data)

        let downloadBtn = ''
        if (this.state.processedClaims > 0)
            downloadBtn = (
                <React.Fragment>
                    <button data-toggle="modal" data-target=".bs-example-modal-new" className="btn-blue-icon"
                        onClick={() => this.downloadHcfaFile()}>Download HCFA File</button>
                    {/* <button data-toggle="modal" data-target=".bs-example-modal-new" className="btn-blue-icon"
                        onClick={() => this.viewHCFAFile()}>View HCFA File</button> */}
                </React.Fragment>
            )

        let popup = '';
        if (this.state.viewPdf === true) {
            popup = <PDFViewPopup onClose={() => this.closePDFViewPopup}></PDFViewPopup>
        } else
            popup = <React.Fragment></React.Fragment>
        // viewPdfHtml = (
        //     <React.Fragment>
        //         <viewHCFAFile></viewHCFAFile>
        //     </React.Fragment>
        // )

        let newList = []
        this.state.data.map((row, i) => {
            newList.push({
                id: row.id,
                visitid: row.id,
                description: row.description
            });
        });
        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 150,
                },
                {
                    label: 'VISIT #',
                    field: 'id',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'ERROR MESSAGE ',
                    field: 'description',
                    sort: 'asc',
                    width: 150
                },
            ],
            rows: newList
        };

        return (

            <React.Fragment>
                <div id='myModal' className="modal fade bs-example-modal-new show" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div className="modal-dialog modal-lg">

                        <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>

                        <div className="modal-content" style={{ overflow: 'hidden' }}>

                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">PAPER SUBMISSION SEARCH RESULT </h1>
                                        </div>
                                        <div className="mf-6 popupHeadingRight">

                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div className="mainTable">


                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Total Claim Numbers </label>
                                            <input type="text" value={this.props.data.visits.length} disabled="true" name="payer4" id="payer4" onChange={() => this.handleChange}
                                            />
                                        </div>
                                        <div className="mf-6 popupHeadingRight" >
                                            {downloadBtn}
                                        </div>
                                    </div>


                                    <div className="row-form">


                                        <div className="mf-6">
                                            <label>Processed Claims  </label>
                                            <input type="text" value={this.props.data.processedClaims} disabled="true" name="payer4" id="payer4" onChange={() => this.handleChange}
                                            />
                                        </div>

                                        <div className="mf-6">
                                            &nbsp;
                                        </div>
                                    </div>


                                </div>



                                <div className="mf-12 table-grid mt-15">

                                    <GridHeading Heading='PAPER SUBMITION ERROR MESSAGES'></GridHeading>

                                    <div className="tableGridContainer">
                                        <MDBDataTable
                                            responsive={true}
                                            striped
                                            bordered
                                            searching={false}
                                            data={data}
                                            displayEntries={false}
                                            sortable={true}
                                            scrollX={false}
                                            scrollY={false}
                                        />
                                    </div>
                                </div>


                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <button id='btnCancel' className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>ok </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>


                {popup}
            </React.Fragment>
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(PaperSubmissionModal);
  
