import React, { Component } from 'react'

import Label from "./Label";
import Input from "./Input";
import settingIcon from "../images/setting-icon.png";
import SearchHeading from "./SearchHeading";
import { MDBDataTable } from "mdbreact";
import $ from "jquery";
import Swal from "sweetalert2";
import axios from "axios";
import NewReason from './NewReason';
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import { MDBBtn } from "mdbreact";

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


export class Reason extends Component {
    constructor(props) {

        super(props)
        this.url = 'http://192.168.110.44/database/api/Reason/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        this.searchModel = {
            name: "",
            description: "",
            biller: "",

            isActive: true

        }

        this.state = {
            searchModel: this.searchModel,
            data: [],
            id: 0,
            showPopup: false,
            loading:false
        }
        this.handleChange = this.handleChange.bind(this);
        this.searchReason = this.searchReason.bind(this);
        this.openReasonPopup = this.openReasonPopup.bind(this);
        this.closeReasonPopup = this.closeReasonPopup.bind(this);
    }
    closeReasonPopup() {

        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    openReasonPopup = (id) => {

        this.setState({ showPopup: true, id: id });

    }


    searchReason = (e) => {
        e.preventDefault()
        console.log(this.state)
        this.setState({loading:true})
        axios.post(this.url + 'FindReasons', this.state.searchModel  , this.config)
            .then(response => {

                let newList = []
                response.data.map((row, i) => {
                    console.log(row)
                    newList.push({
                        id: row.id,
                        name: <MDBBtn className="gridBlueBtn" size="sm" onClick={() => this.openReasonPopup(row.id)}>{row.name}</MDBBtn>,
                        description: row.description,

                    });
                });

                this.setState({ data: newList , loading:false });

            }).catch(error => {
                this.setState({loading:false})
                console.log(error)
            });

        e.preventDefault();
    }


    clearFields = event => {
        this.setState({
            searchModel: this.searchModel
        });
    };


    handleChange = event => {
        console.log(event);

        event.preventDefault();
        console.log(event.target.value)
        this.setState({

            searchModel: { ...this.state.searchModel, [event.target.name]: event.target.value }
        });
    };
    render() {
        const data = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "Name",
                    field: "name",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "Description",
                    field: "description",
                    sort: "asc",
                    width: 270
                }
            ],
            rows: this.state.data
        };

        let popup = ''

        if (this.state.showPopup) {
            popup = <NewReason onClose={() => this.closeReasonPopup} id={this.state.id}></NewReason>
        }
        else
            popup = <React.Fragment></React.Fragment>


            let spiner = ''
            if (this.state.loading == true) {
                spiner = (
                    <GifLoader
                        loading={true}
                        imageSrc={Eclips}
                        // imageStyle={imageStyle}
                        overlayBackground="rgba(0,0,0,0.5)"
                    />
                )
            }

        return (
            <React.Fragment>
                {spiner}
                <SearchHeading heading="REASON SEARCH" handler={() => this.openReasonPopup(0)}></SearchHeading>

                <form onSubmit={event => this.searchReason(event)}>
                    <div className="mainTable">
                        <div className="row-form">
                            <div className="mf-6">
                                <Label name="Name"></Label>

                                <Input
                                    type="text" name="name" id="name" max="5" value={this.state.searchModel.name} onChange={() => this.handleChange}
                                />
                            </div>
                            <div className="mf-6">
                                <Label name="Description"></Label>
                                <Input
                                    max="100" type="text" name="description" id="description" value={this.state.searchModel.description} onChange={() => this.handleChange}
                                />
                            </div>
                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name="Biller"></Label>
                                <Input
                                    type="text" name="biller" id="biller" max="11" value={this.state.searchModel.biller} onChange={() => this.handleChange}

                                />
                            </div>
                            <div className="mf-6">

                            </div>
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">
                                <Input
                                    type="submit"
                                    name="search"
                                    id="search"
                                    className="btn-blue"
                                    value="Search"
                                />
                                <Input
                                    type="button"
                                    name="clear"
                                    id="clear"
                                    className="btn-grey"
                                    value="Clear"
                                    onClick={event => this.clearFields(event)}
                                />
                            </div>
                        </div>
                    </div>
                </form>

                <div className="mf-12 table-grid mt-15">
                    <div className="row headingTable">
                        <div className="mf-6">
                            <h1>REASON SEARCH RESULT</h1>
                        </div>
                        <div className="mf-6 headingRightTable">
                            <a href="javascript:;">
                                <img src={settingIcon} alt="" />
                            </a>
                        </div>
                    </div>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                        />
                    </div>
                </div>
                {popup}
            </React.Fragment>
        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(Reason);
