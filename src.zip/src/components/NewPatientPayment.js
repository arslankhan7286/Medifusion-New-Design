import React, { Component } from "react";
import $ from "jquery";
import axios from "axios";
import Input from "./Input";
import Swal from "sweetalert2";
import { MDBDataTable } from "mdbreact";


import { isNullOrUndefined } from "util";
import { tsExpressionWithTypeArguments } from "@babel/types";
import { EOVERFLOW } from "constants";
import GridHeading from './GridHeading';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'



class NewPatientPayment extends Component{
    constructor(props) {
        super(props);

        this.searchPayment =process.env.REACT_APP_URL + "/PatientPayment/";
        this.patientPaymentChargesUrl = process.env.REACT_APP_URL + "/patientPayment/";
         //Authorization Token
         this.config = {
          headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
      };



        this.validationModel = {
          paymentMethodValField: "",
          paymentDateValField: "",
          paymentAmountValField: "",
          checkNumberValField: "",
          descriptionValField: "",
          statusValField:"",
          allocatedAmountValField:"",
        };

        this.newpatientPaymentModel={

            id: 0,
            dos: "",
            submitDate: "",
            plan: "",
            cpt: "",
            billedAmount: "",
            writeOff: "",
            allowedAmount: "",
            paidAmount: "",
            copay: "",
            coIns: "",
            deductible: "",
            allocatedAmount: "",
            remainingAmount:"",
            paymentMethod: "",
            paymentDate: "",
            paymentAmount: "",
            checkNumber: "",
            description: "",
            status: "O",
            patientID: this.props.patientid,
            patientPaymentCharges: []
            
        }

        this.patientPaymentCharges={
          id: 0,
          patientPaymentID: 0,
          visitID: null,
          chargeID: null,
          allocatedAmount: 0.0
        }
    
        this.state={
            data: [],
            newpatientPaymentModel:this.newpatientPaymentModel,
            validationModel: this.validationModel,
            maxHeight: "361",
            editId: this.props.id,
            //remainingAmount: 0,
        };
        this.handleChange = this.handleChange.bind(this);
    }

    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find(".modal-content");
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
        var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);
    
        this.setState({ maxHeight: maxHeight });
      }
    
     async componentDidMount() {

      console.log("test did mount : " ,this.state.newpatientPaymentModel)
        console.log("ID : ", this.props.id);
        this.setModalMaxHeight($(".modal"));
        var zIndex = 1040 + 10 * $(".modal:visible").length;
        $(this).css("z-Index", zIndex);
        setTimeout(function() {
          $(".modal-backdrop")
            .not(".modal-stack")
            .css("z-Index", zIndex - 1)
            .addClass("modal-stack");
        }, 0);
        

        if(this.state.editId == 0){
          axios
          .get(this.patientPaymentChargesUrl + "FindpatientPaymentCharges/" + this.props.patientid  , this.config)
          .then(response => {
              this.setState({data:response.data})        
              response.data.map((row, i) => {              
              this.setState({newpatientPaymentModel : {
                ...this.state.newpatientPaymentModel ,
                patientPaymentCharges:this.state.newpatientPaymentModel.patientPaymentCharges.concat(this.patientPaymentCharges),
              } });
              })
          }) 
         .catch(error => {
            Swal.fire("Something Wrong", "Please Check Server Connection", "error");
            console.log(error);
          });
        } else{
            //top fileters vlaues
            axios
            .get(this.searchPayment + "FindPatientPayment/"+ this.state.editId ,  this.config)
            .then(response => {
              console.log("Patient Data : " , response.data)
                this.setState({ newpatientPaymentModel: response.data                              
                });
                //this.setState({ remainingAmount: this.state.newpatientPaymentModel.paymentAmount - this.state.newpatientPaymentModel.allocatedAmount});
            }) 
            .catch(error => {
              Swal.fire("Something Wrong", "Please Check Server Connection", "error");
                console.log(error);
            });
            /// edit mode grid            
            axios
            .get(this.patientPaymentChargesUrl + "FindPatientChargesByPaymentID/" + this.state.editId)
            .then(response => {
              console.log("Charge Data :" , response.data)
                this.setState({newpatientPaymentModel : {
                  ...this.state.newpatientPaymentModel ,
                  patientPaymentCharges:response.data,
                } });           
                this.setState({ data: response.data });
            }) 
            .catch(error => {
              Swal.fire("Something Wrong", "Please Check Server Connection", "error");
              console.log(error);
            });
          
          }        
      }

        isNull(value) {
          if (
            value === "" ||
            value === null ||
            value === undefined ||
            value === "Please Select"
          )
            return true;
          else return false;
        }
    
        //sum of allocated amount entered by user
        sumofallocatedamount(){
          var sumAlloAmt=0;
          this.state.newpatientPaymentModel.patientPaymentCharges.map(charge =>{

            sumAlloAmt += Number(parseFloat(charge.allocatedAmount).toFixed(2))
          })
          // var remAmt= 0;
          // remAmt=;
          this.setState({remainingAmount: this.state.newpatientPaymentModel.paymentAmount-sumAlloAmt,
                        allocatedAmount : sumAlloAmt     });
          
        }

    
      SavePayment = e => {
          //console.log("save model",this.state.newpatientPaymentModel);
          e.preventDefault();
          // this.sumofallocatedamount();
          var myval=this.validationModel;
          myval.validation=false;

          if(this.state.newpatientPaymentModel.allocatedAmount > this.state.newpatientPaymentModel.paymentAmount){
            myval.allocatedAmountValField=(
              <span className="validationMsg">Allocated Amount Is Greater</span>
            )
            myval.validation=true;

          }else{
            myval.allocatedAmountValField = "";
            if (myval.validation === false) myval.validation = false;
          }

          if(this.isNull(this.state.newpatientPaymentModel.paymentMethod)){
            myval.paymentMethodValField=(
              <span className="validationMsg">Select Payment Method</span>
            )
            myval.validation=true;
          }else{
            myval.paymentMethodValField = "";
            if (myval.validation === false) myval.validation = false;
          }

          if(this.isNull(this.state.newpatientPaymentModel.paymentDate)){
            myval.paymentDateValField=(
              <span className="validationMsg">Enter Date</span>
            )
            myval.validation=true;
          }else{
            myval.paymentDateValField = "";
            if (myval.validation === false) myval.validation = false;
          }

          if(this.isNull(this.state.newpatientPaymentModel.paymentAmount)){
            myval.paymentAmountValField=(
              <span className="validationMsg">Enter Amount</span>
            )
            myval.validation=true;
          }else{
            myval.paymentAmountValField = "";
            if (myval.validation === false) myval.validation = false;
          }

          if(this.state.newpatientPaymentModel.paymentMethod == 'CHECK'){
            if(this.isNull(this.state.newpatientPaymentModel.checkNumber)){
              myval.checkNumberValField=(
                <span className="validationMsg">Enter Check Number</span>
              )
              myval.validation=true;
            }else{
              myval.checkNumberValField = "";
              if (myval.validation === false) myval.validation = false;
            }
          }else{
            myval.statusValField = "";
            if (myval.validation === false) myval.validation = false;
          }
          
          if(this.isNull(this.state.newpatientPaymentModel.description)){
            myval.descriptionValField=(
              <span className="validationMsg">Enter Discription</span>
            )
            myval.validation=true;
          }else{
            myval.descriptionValField = "";
            if (myval.validation === false) myval.validation = false;
          }

          if(this.isNull(this.state.newpatientPaymentModel.status)){
            myval.statusValField=(
              <span className="validationMsg">Select Status</span>
            )
            myval.validation=true;
          }else{
            myval.statusValField = "";
            if (myval.validation === false) myval.validation = false;
          }

          this.setState({
            validationModel: myval
          });
      
          if (myval.validation === true) {
            return;
          }
          //console.log("after log model",this.newpatientPaymentModel)
          axios
            .post(this.searchPayment + "SavePatientPayment", this.state.newpatientPaymentModel ,  this.config)
            .then(response => {
              
              console.log("save data console",response.data)
              this.setState({
                 newpatientPaymentModel: response.data,

                 editId: response.data.id
              });
              
              Swal.fire("Record Saved Successfully", "", "success");
              $("#btnCancel").click();
              alert(test);
              console.log(response.data);
              this.componentDidMount();
            })
      
            .catch(error => {
              try {
                let errorsList = [];
                if (error.response !== null && error.response.data !== null) {
                  errorsList = error.response.data;
                  console.log(errorsList);
                }
              } catch {
                console.log(error);
              }
            });

  e.preventDefault();

        };

        handleChange = event => {
          event.preventDefault();
          this.setState({
            newpatientPaymentModel: {
              ...this.state.newpatientPaymentModel,
              [event.target.name]: event.target.value
            }
          });
        };

      async  handlePatientChargeChange(event , index){

        var patientCharge = [...this.state.newpatientPaymentModel.patientPaymentCharges];       
        var name = event.target.name
        patientCharge[index][name] = event.target.value;
        patientCharge[index]["visitID"] = this.state.data[index].visitID;
        patientCharge[index]["chargeID"] = this.state.data[index].chargeID;

        var sumAlloAmt=0;
        await this.state.newpatientPaymentModel.patientPaymentCharges.map(charge =>{
          ///kch krnaa ha
          sumAlloAmt += Number(parseFloat(charge.allocatedAmount).toFixed(2))
        });

        this.setState({
          newpatientPaymentModel : {
            ...this.state.newpatientPaymentModel, 
            allocatedAmount : sumAlloAmt,
            remainingAmount : this.state.newpatientPaymentModel.paymentAmount - sumAlloAmt,
            patientPaymentCharges : patientCharge
          }
        });

        }
        

    render(){

      var paymentDate= this.state.newpatientPaymentModel.paymentDate.slice(0,10);
        const paymentMethod = [
            { value: "", display: "Select Status" },
            { value: "CASH", display: "Cash" },
            { value: "CHECK", display: "Check" },
        ];
        const status = [
            { value: "", display: "Select Status" },
            { value: "O", display: "Open" },
            { value: "C", display: "Close" },
        ];

        let newList = []         
        this.state.data.map((charge , i ) =>{
              var dos= charge.dos == null ? "  ":charge.dos ; // handle null condition
              var submitDate= charge.submitDate == "" ? " ": charge.submitDate;
              var plan= charge.plan == null ? " ": charge.plan;
              var cpt= charge.cpt == null ? " ": charge.cpt;
              var billedAmount= charge.billedAmount == null ? " ": charge.billedAmount;
              var writeOff= charge.writeOff == null ? " ": charge.writeOff;
              var allowedAmount= charge.allowedAmount == null ? " ": charge.allowedAmount;
              var paidAmount= charge.paidAmount == null ? " ": charge.paidAmount;
              var copay= charge.copay == null ? " ": charge.copay;
              var coIns= charge.coInsurance == null ? " ": charge.coInsurance;
              var deductible= charge.deductible == null ? " ":charge.deductible;
              
           newList.push({
              
                id: charge.chargeID,
                dos: dos,
                submitDate: submitDate,
                plan: plan,
                cpt: cpt,
                billedAmount:billedAmount,
                writeOff: writeOff,
                allowedAmount: allowedAmount,
                paidAmount: paidAmount,
                copay:  copay,
                coIns: coIns,
                deductible: deductible,
                allocatedAmount: 
                    <input type="number " name="allocatedAmount"
                       value={charge.allocatedAmount} 
                        onChange={(event) => this.handlePatientChargeChange(event,i)}></input> ,                     // this filed in write mode and all others above in read mode     
          });
        });
  
          const data = {
          columns: [
            {
              label: "ID",
              field: "id",
              sort: "asc",
              //width: 150
            },
            {
              label: "DOS",
              field: "dos",
              sort: "asc",
              //width: 150
            },
            {
              label: "SUBMIT DATE",
              field: "submitDate",
              sort: "asc",
              //width: 150
            },
            {
              label: "PLAN",
              field: "plan",
              sort: "asc",
              //width: 150
            },
            {
              label: "CPT",
              field: "cpt",
              sort: "asc",
              //width: 150
            },
            {
              label: "BILLED AMOUNT",
              field: "billedAmount",
              sort: "asc",
              //width: 150
            },
            {
              label: "WRITE OFF",
              field: "writeOff",
              sort: "asc",
              //width: 150
            },
            {
              label: "ALLOWED AMOUNT",
              field: "allowedAmount",
              sort: "asc",
              //width: 150
            },
            {
              label: "PAID AMOUNT",
              field: "paidAmount",
              sort: "asc",
              //width: 150
            },
            {
              label: "COPAY",
              field: "copay",
              sort: "asc",
              //width: 150
            },
            {
              label: "CO. INS",
              field: "coIns",
              sort: "asc",
              //width: 150
            },
            {
              label: "DEDUCTIBLE",
              field: "deductible",
              sort: "asc",
              //width: 150
            },
            {
              label: "ALLOCATION AMOUNT",
              field: "allocatedAmount",
              sort: "asc",
              //width: 150
            }
            
          ],
          rows: newList
        };

        return(
                <React.Fragment>
                      <div
                      id="myModal1"
                      className="modal fade bs-example-modal-new show"
                      tabIndex="-1"
                      role="dialog"
                      aria-labelledby="myLargeModalLabel"
                      aria-hidden="true"
                      style={{ display: "block", paddingRight: "17px" }}
                    >
                        <div className="modal-dialog modal-lg text-nowrap" >
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                            <div className="modal-content" style={{ overflow: "hidden" }}>
                                <div className="modal-body">
                                    <div className="mainTable fullwidthTable wSpace">
                                        <div className="row-form">
                                            <div className="mf-4">
                                            <label style={{ marginleft: "0% !important"}}>Payment Method</label>
                                                <select
                                                    name="paymentMethod"
                                                    id="paymentMethod"
                                                    value={this.state.newpatientPaymentModel.paymentMethod}
                                                    onChange={this.handleChange}
                                                >
                                                    {paymentMethod.map(s => (
                                                    <option key={s.value} value={s.value}>
                                                    {s.display}
                                                    </option>
                                                    ))}
                                                </select>
                                                <div className="textBoxValidate">{this.state.validationModel.paymentMethodValField}</div>
                                            </div>
                                            <div className="mf-4">
                                                <label>Payment Date</label>
                                                <div className="textBoxValidate">
                                                    <input type="date" name="paymentDate" id="paymentDate"
                                                    // value={this.state.newpatientPaymentModel.paymentDate}
                                                    value={paymentDate}
                                                    onChange={this.handleChange}
                                                      />{this.state.validationModel.paymentDateValField}
                                                </div>
                                            </div>
                                            <div className="mf-4">
                                                <label>Payment Amount</label>
                                                <div className="textBoxValidate">
                                                <input 
                                                type="text" value={this.state.newpatientPaymentModel.paymentAmount} 
                                                name="paymentAmount" id="paymentAmount" onChange={this.handleChange}
                                                />{this.state.validationModel.paymentAmountValField}
                                            </div>
                                            </div>
                                        </div>
                                        <div className="row-form">
                                            <div className="mf-4">
                                                <label>Check # </label>
                                                <div className="textBoxValidate">
                                                <input type="text" value={this.state.newpatientPaymentModel.checkNumber} 
                                                name="checkNumber" id="checkNumber" onChange={this.handleChange}
                                                />{this.state.validationModel.checkNumberValField}
                                                </div>
                                            </div>
                                            <div className="mf-4 mf-icon">
                                                <label>Description</label>
                                                <div className="textBoxValidate">
                                                <input type="text" value={this.state.newpatientPaymentModel.description} 
                                                name="description" id="description" onChange={this.handleChange}
                                                />{this.state.validationModel.descriptionValField}
                                                </div>
                                            </div>
                                            {/* <!-- read only fields--> */}
                                            <div className="mf-4">
                                                <label>Status</label>
                                                
                                                <select disabled
                                                    name="status"
                                                    id="status"
                                                    value={this.state.newpatientPaymentModel.status}
                                                    onChange={this.handleChange}
                                                >
                                                    {status.map(s => (
                                                    <option key={s.value} value={s.value}
                                                    >
                                                    {s.display}
                                                    </option>
                                                    ))}
                                                </select>
                                                <div className="textBoxValidate">{this.state.validationModel.statusValField}</div>
                                            </div>
                                        </div>

                                        <div className="row-form">
                                          <div className="mf-4">
                                            <label>Allocated Amount</label>
                                                  <div className="textBoxValidate">
                                                  <input readOnly
                                                  type="text" value={this.state.newpatientPaymentModel.allocatedAmount} 
                                                  name="allocatedAmount" id="paymentAmount" onChange={this.handleChange}
                                                  />{this.state.validationModel.allocatedAmountValField}
                                                  </div>
                                          </div>
                                          <div className="mf-4">
                                            <label>Remaining Amount</label>
                                                  <div className="textBoxValidate">
                                                  <input readOnly
                                                  type="text" value={this.state.newpatientPaymentModel.remainingAmount} 
                                                  name="remainingAmount" id="paymentAmount" onChange={this.handleChange}
                                                  />
                                                  </div>
                                          </div>
                                          <div className="mf-4">
                                            {/* empty div */}
                                          </div>
                                        </div>
                                      
                                        <div className="mf-12 table-grid mt-15">
                                        <GridHeading Heading='OPEN SERVICE LINE ITEMS'></GridHeading>

                                        <div className="tableGridContainer">
                                            <MDBDataTable
                                                responsive={true}
                                                striped
                                                bordered
                                                searching={false}
                                                data={data}
                                                displayEntries={false}
                                                sortable={true}
                                                scrollX={false}
                                                scrollY={false}
                                            />
                                        </div>
                                    </div>
                                        <div className="modal-footer">
                                        <div className="mainTable">
                                            <div className="row-form row-btn">
                                                <div className="mf-12">
                                                    <button className="btn-blue" onClick={this.SavePayment}>Save </button>
                                                    <button className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>Cancel </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                
                                </div>
                            </div>
                        </div>
                        
                    </div>        
              </React.Fragment> 
        );
    
    }

}


function mapStateToProps(state) {
  console.log("state from Header Page" , state);
  return {
      selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
      selectedTabPage: state.selectedTabPage,
      selectedPopup: state.selectedPopup,
      id: state.selectedTab !== null ? state.selectedTab.id : 0,
      setupLeftMenu: state.leftNavigationMenus,
      loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
      userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(NewPatientPayment);