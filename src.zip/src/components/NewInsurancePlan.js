import React, { Component, Fragment } from 'react'
import $ from 'jquery';


import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import taxonomyIcon from '../images/code-search-icon.png'

import axios from 'axios';
import Input from './Input';

import Swal from 'sweetalert2'


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

export class NewInsurancePlan extends Component {

    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/InsurancePlan/'
        this.errorField = 'errorField';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };


        this.insurancePlanModel = {
            "id": 0,
            "planName": '',
            "description": '',
            "insuranceID": '',
            "planTypeID": '',
            "isCapitated": false,
            "submissionType": '',
            "outstandingDays" :'30',
            "payerID": '',
            "edi837PayerID": null,
            "edi270PayerID": null,
            "edi276PayerID": null,
            "formType": '',
            "isActive": true,
            "isDeleted": false,
            "notes": null
        }


        this.validationModel = {
            planNameValField: null,
            descriptionValField: null,
            insuranceIDValField: '',
            planTypeIDValField: '',
            isCapitatedValField: false,
            submissionTypeValField: null,
            payerIDValField: null,
            edi837PayerIDValField: 0,
            edi270PayerIDValField: 0,
            edi276PayerIDValField: 0,
            formTypeValField: null,
            isActiveValField: true
        }

        this.state = {
            editId: this.props.id,
            insurancePlanModel: this.insurancePlanModel,
            validationModel: this.validationModel,
            maxHeight: '361',
            insuranceData: [],
            planData: [],
            payer837: [],
            payer276: [],
            payer270: [],
            payer1: '',
            payer2: '',
            payer3: '',
            payer4: '',
            payer5: '',
            payer6: '',
            loading:false



        }

        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleCheck = this.handleCheck.bind(this);
        this.handleCheckBox = this.handleCheckBox.bind(this);
        this.saveInsurancePlan = this.saveInsurancePlan.bind(this);
        //  this.handleSameAsAddress = this.handleSameAsAddress.bind(this);
        this.delete = this.delete.bind(this);
    }

    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find('.modal-content');
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
        var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight })
    }

    componentDidMount() {
        this.setModalMaxHeight($('.modal'));


        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);


        if (this.state.editId > 0) {
            axios.get(this.url + 'FindInsurancePlan/' + this.state.editId , this.config)
                .then(response => {
                    console.log(response.data);
                    this.setState({ insurancePlanModel: response.data });
                }).catch(error => {
                    console.log(error);
                });
        }


    }
    componentWillMount() {
        axios.get(this.url + 'GetProfiles' , this.config)
            .then(response => {

                this.setState({
                    insuranceData: response.data.insurance, planData: response.data.planType,
                    payer837: response.data.x12_837_Payer,
                    payer276: response.data.x12_276_Payer,
                    payer270: response.data.x12_270_Payer,
                })

                console.log(response.data.x12_837_Payer);
                console.log(response.data.x12_276_Payer);
                console.log(response.data.x12_270_Payer);

            }).catch(error => {
                console.log(error);
            });
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }


    handleChange = event => {
        event.preventDefault();
        var index = event.target.value;

        if (event.target.name === "edi837PayerID") {
            this.state.payer837.map((roww, i) => {

                if (roww.id == event.target.value) { // QA ERROR SLOVE 
                    console.log("roww" + roww.id)

                    index = i
                    this.setState({
                        payer1: this.state.payer837[index].description2.toUpperCase(),
                        payer2: this.state.payer837[index].description3.toUpperCase()

                    })
                }

                return
            })
        }
        else if (event.target.name === "edi270PayerID") {

            this.state.payer270.map((roww, i) => {
                if (roww.id == event.target.value) { // QA ERROR SLOVE 

                    index = i
                    this.setState({
                        payer3: this.state.payer270[index].description2.toUpperCase(),
                        payer4: this.state.payer270[index].description3.toUpperCase()

                    })
                }
                return
            })
        }
        else if (event.target.name === "edi276PayerID") {

            this.state.payer276.map((roww, i) => {
                if (roww.id == event.target.value) { // QA ERROR SLOVE 

                    index = i
                    this.setState({
                        payer5: this.state.payer276[index].description2.toUpperCase(),
                        payer6: this.state.payer276[index].description3.toUpperCase()

                    })
                }
                return
            })
        }
        console.log("Index", event.target.name)


        this.setState({
            insurancePlanModel: {
                ...this.state.insurancePlanModel,
                [event.target.name]: event.target.value === 'Please Select' ? null : event.target.value
            }
        });



        console.log(this.state)
    };

    foucsOut = event => {
        console.log(event)
        event.preventDefault();

        this.setState({
            insurancePlanModel: {
                ...this.state.insurancePlanModel,
                [event.target.name]: event.target.value
            }
        });
    };



    handleCheck() {
        this.setState({
            insurancePlanModel: {
                ...this.state.insurancePlanModel,
                isActive: !this.state.insurancePlanModel.isActive


            }
        });
    }
    handleCheckBox() {
        this.setState({
            insurancePlanModel: {
                ...this.state.insurancePlanModel,
                isCapitated: !this.state.insurancePlanModel.isCapitated

            }
        })
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }


    delete = e => {
        Swal.fire({
            title: "Are you sure, you want to delete this record?",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then(result => {
            if (result.value) {
                this.setState({loading:true})
                axios
                    .delete(this.url + "DeleteInsurancePlan/" + this.state.editId  ,this.config)
                    .then(response => {
                        this.setState({loading:false})

                        console.log("Delete Response :", response);
                        Swal.fire("Record Deleted Successfully", "", "success");
                    })
                    .catch(error => {
                        this.setState({loading:false})

                        Swal.fire("Record Not Deleted!", "Record can not be delete, as it is being referenced in other screens.", "error");
                    });

                $("#btnCancel").click();
            }
        });
    };


    isNull(value) {
        if (value === '' || value === null || value === undefined || value === 'Please Select')
            return true;
        else return false;
    }


    saveInsurancePlan = (e) => {
        console.log(this.state.insurancePlanModel);

        this.setState({loading:true})

        var myVal = this.validationModel;
        myVal.validation = false;

        if (this.state.insurancePlanModel.planName === '') {
            myVal.planNameValField = <span className="validationMsg">Enter Plan Name</span>
            myVal.validation = true
        } else {
            myVal.planNameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.state.insurancePlanModel.description === '') {
            myVal.descriptionValField = <span className="validationMsg">Enter Description</span>
            myVal.validation = true
        } else {
            myVal.descriptionValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        if (this.isNull(this.state.insurancePlanModel.insuranceID)) {
            myVal.insuranceIDValField = <span className="validationMsg">Select Insurance</span>
            myVal.validation = true
        } else {
            myVal.insuranceIDValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.insurancePlanModel.planTypeID)) {
            myVal.planTypeIDValField = <span className="validationMsg">Select Plan Type</span>
            myVal.validation = true
        } else {
            myVal.planTypeIDValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        if (this.state.insurancePlanModel.submissionType === 'P') {
            console.log('paperp')
            if (this.isNull(this.state.insurancePlanModel.formType)) {
                myVal.formTypeValField = <span className="validationMsg">Select HCFA Template</span>
                myVal.validation = true
            } else {
                myVal.formTypeValField = ''
                if (myVal.validation === false) myVal.validation = false
            }


        }



        this.setState({
            validationModel: myVal
        });

        if (myVal.validation === true) {
            myVal = {}
            this.setState({loading:false})

            return;
        }





        axios.post(this.url + 'SaveInsurancePlan', this.state.insurancePlanModel , this.config)
            .then(response => {
                this.setState({ insurancePlanModel: response.data, editId: response.data.id  , loading:false});
                Swal.fire(
                    'Record Saved Successfully',
                    '',
                    'success'
                )
            }).catch(error => {
                this.setState({loading:false})

                let errorsList = []
                if (error.response !== null && error.response.data !== null) {
                    errorsList = error.response.data
                    console.log(errorsList)

                } else {
                    console.log(error);
                    alert('Something went wrong. Plese check console.')
                }
            });

        e.preventDefault();
    }


    render() {
        const submissionType = [
            { value: "", display: "Select Title" },
            { value: "P", display: "Paper" },
            { value: "E", display: "Electronic" }
        ]
        const formType = [
            { value: "", display: "Select Title" },
            { value: "HCFA 1500", display: "HCFA 1500" },
            { value: "PLAIN 1500", display: "Plain 1500" }
        ]

        const isActive = this.state.insurancePlanModel.isActive;
        const isCapitated = this.state.insurancePlanModel.isCapitated;


        

        let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }
        return (
            <React.Fragment>
                {spiner}
                <div id='myModal' className="modal fade bs-example-modal-new show" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div className="modal-dialog modal-lg">

                        <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>

                        <div className="modal-content" style={{ overflow: 'hidden' }}>

                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">{this.state.editId  > 0 ? this.state.insurancePlanModel.planName.toUpperCase() + " - " +this.state.insurancePlanModel.id : "NEW INSURANCE PLAN "  }</h1>
                                        </div>
                                        <div className="mf-6 popupHeadingRight">
                                            <div className="lblChkBox" onClick={this.handleCheck}>
                                                <input type="checkbox" checked={!isActive} id="isActive" name="isActive" />
                                                <label htmlFor="markInactive">
                                                    <span>Mark Inactive</span>
                                                </label>
                                            </div>
                                            <Input type='button' value='Delete' className="btn-blue" onClick={this.delete}>Delete</Input>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div className="mainTable">

                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Plan Name
                                                <span className="redlbl"> *</span>
                                            </label>

                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.planNameValField ? this.errorField : ""}
                                                    type="text" value={this.state.insurancePlanModel.planName} name='planName' id='planName'
                                                    max='20'
                                                    onChange={() => this.handleChange}
                                                />
                                                {this.state.validationModel.planNameValField}
                                            </div>

                                        </div>


                                        <div className="mf-6">
                                            <label> Description <span className="redlbl"> *</span></label>

                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.descriptionValField ? this.errorField : ""}
                                                    type="text" value={this.state.insurancePlanModel.description} name="description" id="description"
                                                    max='30' onChange={() => this.handleChange} />
                                                {this.state.validationModel.descriptionValField}
                                            </div>

                                        </div>
                                    </div>

                                    <div className="row-form">

                                        <div class="mf-6">
                                            <label>Insurance <span className="redlbl"> *</span></label>

                                            <div className="selectBoxValidate">
                                                <select
                                                    className={this.state.validationModel.insuranceIDValField ? this.errorField : ""}
                                                    name='insuranceID' id='insuranceID' value={this.state.insurancePlanModel.insuranceID} onChange={this.handleChange}>
                                                    {this.state.insuranceData.map((s) => <option key={s.id} value={s.id}>{s.description}</option>)}
                                                </select>
                                                {this.state.validationModel.insuranceIDValField}
                                            </div>

                                        </div>


                                        <div class="mf-6">
                                            <label>Plan Type</label>

                                            <div className="selectBoxValidate">
                                                <select
                                                    className={this.state.validationModel.planTypeIDValField ? this.errorField : ""}
                                                    name='planTypeID' id='planTypeID' value={this.state.insurancePlanModel.planTypeID} onChange={this.handleChange}>
                                                    {this.state.planData.map((s) => <option key={s.id} value={s.id}>{s.description}</option>)}
                                                </select>
                                                {this.state.validationModel.planTypeIDValField}
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Is capitated</label>
                                            <div className="textBoxValidate">
                                                <div className="lblChkBox" onClick={this.handleCheckBox}>
                                                    <input type="checkbox" checked={isCapitated} id="isCapitated" name="isCapitated" />
                                                    <label htmlFor="markInCapitated">
                                                        <span></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="mf-6">
                                            <label>Submission Type</label>
                                            <select name="submissionType" id="submissionType" value={this.state.insurancePlanModel.submissionType} onChange={this.handleChange}>
                                                {submissionType.map(s => (
                                                    <option key={s.value} value={s.value}>
                                                        {s.display}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label> Outstanding Days </label>
                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.descriptionValField ? this.errorField : ""}
                                                    type="text" value={this.state.insurancePlanModel.outstandingDays} name="outstandingDays" id="outstandingDays"
                                                    max='2' onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)} />
                                                    {/* //{this.state.validationModel.descriptionValField} */}
                                            </div>
                                        </div>
                                        <div className="mf-6"></div>
                                    </div>

                                    <div className="mf-12 headingOne mt-25">
                                        <p>Electronic Insurances</p>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>EDI Submission Payer</label>
                                            <select name="edi837PayerID" id="edi837PayerID" value={this.state.insurancePlanModel.edi837PayerID} onChange={this.handleChange}>
                                                {this.state.payer837.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="mf-6">

                                            <label>Payer ID - Receiver</label>
                                            <div className="textBoxTwoField">
                                                <Input type="text" value={this.state.payer1} disabled="true" name="payer1" id="payer1" onChange={() => this.handleChange}
                                                />

                                                <Input type="text" value={this.state.payer2} disabled="true" name="payer2" id="payer2" onChange={() => this.handleChange}
                                                />
                                            </div>
                                        </div>
                                    </div>


                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>EDI Eligibility Payer</label>
                                            <select name="edi270PayerID" id="edi270PayerID" value={this.state.insurancePlanModel.edi270PayerID} onChange={this.handleChange}>
                                                {this.state.payer270.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="mf-6">

                                            <label>Payer ID - Receiver</label>
                                            <div className="textBoxTwoField">
                                                <Input type="text" value={this.state.payer3} disabled="true" name="payer3" id="payer3" onChange={() => this.handleChange}
                                                />

                                                <Input type="text" value={this.state.payer4} disabled="true" name="payer4" id="payer4" onChange={() => this.handleChange}
                                                />
                                            </div>
                                        </div>
                                    </div>


                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>EDI Status Payer</label>
                                            <select name="edi276PayerID" id="edi276PayerID" value={this.state.insurancePlanModel.edi276PayerID} onChange={this.handleChange}>
                                                {this.state.payer276.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="mf-6">
                                            <label>Payer ID - Receiver</label>
                                            <div className="textBoxTwoField">
                                                <Input type="text" value={this.state.payer5} disabled="true" name="payer5" id="payer5" onChange={() => this.handleChange}
                                                />
                                                <Input type="text" value={this.state.payer6} disabled="true" name="payer6" id="payer6" onChange={() => this.handleChange}
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="mf-12 headingOne mt-25">
                                        <p>Electronic Insurances</p>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6 mf-icon">
                                            <label>HCFA Template</label>


                                            <div className="textBoxTwoField">


                                                <select name="formType" id="formType" value={this.state.insurancePlanModel.formType} onChange={this.handleChange}>
                                                    {formType.map(s => (
                                                        <option key={s.value} value={s.value}>
                                                            {s.display}
                                                        </option>
                                                    ))}
                                                </select>



                                                {this.state.validationModel.formTypeValField}
                                            </div>
                                        </div>

                                        <div className="mf-6">
                                            &nbsp;
                                        </div>

                                    </div>


                                </div>


                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <button className="btn-blue" onClick={this.saveInsurancePlan}>Save </button>
                                                <button id='btnCancel' className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>Cancel </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </React.Fragment >
        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        // id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(NewInsurancePlan);
