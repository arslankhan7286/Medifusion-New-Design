import React, { Component, Fragment } from "react";
import $ from "jquery";
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import taxonomyIcon from "../images/code-search-icon.png";



import axios from "axios";
import Input from "./Input";
import Swal from "sweetalert2";

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

class NewRefferingProvider extends Component {
  constructor(props) {
    super(props);

    this.errorField = 'errorField'
    this.url = process.env.REACT_APP_URL + '/RefProvider/';
     //Authorization Token
     this.config = {
      headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
  };



    //reffering provider object
    this.refProviderModel = {
      title: "",
      name: "",
      lastName: "",
      firstName: "",
      middleInitial: "",
      npi: "",
      ssn: "",
      taxonomyCode: "",
      address1: "",
      address2: "",
      city: "",
      state: "",
      zipCode: "",
      officePhoneNum: "",
      email: "",
      deaNumber: "",
      upinNumber: "",
      licenseNumber: "",
      isActive: true,
      isDeleted: false,
      notes: "",
      addedBy: "",
      updatedBy: ""
    };

    this.validationModel = {
      titleValField: '',
      nameValField: '',
      lastNameValField: '',
      firstNameValField: '',
      middleInitialValField: '',
      npiValField: '',
      ssnValField: '',
      taxonomyCodeValField: '',
      address1ValField: '',
      address2ValField: '',
      cityValField: '',
      stateValField: '',
      zipCodeValField: '',
      officePhoneNumValField: '',
      emailValField: '',
      deaNumberValField: '',
      upinNumberValField: '',
      licenseNumberValField: '',
      isActiveValField: true,
      isDeletedValField: false,
      notesValField: ''
    };


    this.state = {
      editId: this.props.id,
      refProviderModel: this.refProviderModel,
      validationModel: this.validationModel,
      maxHeight: "361",
      loading:false,
   
    };

    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.saveNewReffProvider = this.saveNewReffProvider.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }
  componentDidMount() {
    this.setModalMaxHeight($(".modal"));
    // if ($('.modal.in').length != 0) {
    //     this.setModalMaxHeight($('.modal.in'));
    // }

    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function () {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    if (this.state.editId > 0) {
      axios.get(this.url + "FindRefProvider/" + this.state.editId , this.config)
        .then(response => {
          this.setState({ refProviderModel: response.data });
        })
        .catch(error => {
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
            console.log(errorsList);
          } else console.log(error);
        });
    }
  }

  handleChange = event => {
    event.preventDefault();
    this.setState({
      refProviderModel: {
        ...this.state.refProviderModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  isNull(value) {
    if (value === '' || value === null || value === undefined || value === 'Please Select')
      return true;
    else return false;
  }


  saveNewReffProvider = e => {

this.setState({loading:true})
    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.refProviderModel.name)) {
      myVal.nameValField = <span className="validationMsg">Enter Name</span>
      myVal.validation = true
    } else {
      myVal.nameValField = ''
      if (myVal.validation === false) myVal.validation = false
    }


    if (this.isNull(this.state.refProviderModel.lastName)) {
      myVal.lastNameValField = <span className="validationMsg">Enter Last Name</span>
      myVal.validation = true
    } else {
      myVal.lastNameValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    if (this.isNull(this.state.refProviderModel.firstName)) {
      myVal.firstNameValField = <span className="validationMsg">Enter First Name</span>
      myVal.validation = true
    } else {
      myVal.firstNameValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    if (this.isNull(this.state.refProviderModel.npi)) {
      myVal.npiValField = <span className="validationMsg">Enter NPI</span>
      myVal.validation = true
    } else if (this.state.refProviderModel.npi.length < 10) {
      myVal.npiValField = <span className="validationMsg">NPI length should be 10</span>
      myVal.validation = true
    } else {
      myVal.npiValField = ''
      if (myVal.validation === false) myVal.validation = false
    }


    if (this.isNull(this.state.refProviderModel.taxonomyCode) === false && this.state.refProviderModel.taxonomyCode.length < 10) {
      myVal.taxonomyCodeValField = <span className="validationMsg">Taxonomy Code length should be 10</span>
      myVal.validation = true
    } else {
      myVal.taxonomyCodeValField = ''
      if (myVal.validation === false) myVal.validation = false
    }


    if (this.isNull(this.state.refProviderModel.zipCode) === false && this.state.refProviderModel.zipCode.length > 0) {
      if (this.state.refProviderModel.zipCode.length < 5) {
        myVal.zipCodeValField = <span className="validationMsg">Zip should be of alleast 5 digits</span>
        myVal.validation = true
      } else if (this.state.refProviderModel.zipCode.length > 5 && this.state.refProviderModel.zipCode.length < 9) {
        myVal.zipCodeValField = <span className="validationMsg">Zip should be of either 5 or 9 digits</span>
        myVal.validation = true
      } else {
        myVal.zipCodeValField = ''
        if (myVal.validation === false) myVal.validation = false
      }
    } else {
      myVal.zipCodeValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    if (this.isNull(this.state.refProviderModel.officePhoneNum) === false && this.state.refProviderModel.officePhoneNum.length < 10) {
      myVal.officePhoneNumValField = <span className="validationMsg">Phone # length should be 10</span>
      myVal.validation = true
    } else {
      myVal.officePhoneNumValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    if (this.isNull(this.state.refProviderModel.ssn) === false && this.state.refProviderModel.ssn.length < 9) {
      myVal.ssnValField = <span className="validationMsg">SSN length should be 9</span>
      myVal.validation = true
    } else {
      myVal.ssnValField = ''
      if (myVal.validation === false) myVal.validation = false
    }


    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({loading:false})

      return;
    }


    axios.post(this.url + "SaveRefProvider", this.state.refProviderModel  ,this.config)
      .then(response => {
        this.setState({ refProviderModel: response.data, editId: response.data.id , loading:false });
        Swal.fire("Record Saved Successfully", "", "success");
        $("#btnCancel").click();
      })
      .catch(error => {
        this.setState({loading:false})

        let errorsList = [];
        if (error.response !== null && error.response.data !== null) {
          errorsList = error.response.data;
          console.log(errorsList);
        } else console.log(error);
      });

    e.preventDefault();
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  handleCheck() {
    this.setState({
      refProviderModel: {
        ...this.state.refProviderModel,
        isActive: !this.state.refProviderModel.isActive
      }
    });
  }

  delete = e => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.setState({loading:true})
        axios
          .delete(this.url + "DeleteRefProvider/" + this.state.editId  ,this.config)
          .then(response => {
            this.setState({loading:false})
            console.log("Delete Response :", response);
            Swal.fire("Record Deleted Successfully", "", "success");
          })
          .catch(error => {
            this.setState({loading:false})
            Swal.fire("Record Not Deleted!", "Record can not be delete, as it is being referenced in other screens.", "error");
          });

        $("#btnCancel").click();
      }
    });
  };


  render() {
    const isActive = this.state.refProviderModel.isActive;
    const usStates = [
      { value: "", display: "Select State" },
      { value: "AL", display: "AL - Alabama" },
      { value: "AK", display: "AK - Alaska" },
      { value: "AZ", display: "AZ - Arizona" },
      { value: "AR", display: "AR - Arkansas" },
      { value: "CA", display: "CA - California" },
      { value: "CO", display: "CO - Colorado" },
      { value: "CT", display: "CT - Connecticut" },
      { value: "DE", display: "DE - Delaware" },
      { value: "FL", display: "FL - Florida" },
      { value: "GA", display: "GA - Georgia" },
      { value: "HI", display: "HI - Hawaii" },
      { value: "ID", display: "ID - Idaho" },
      { value: "IL", display: "IL - Illinois" },
      { value: "IN", display: "IN - Indiana" },
      { value: "IA", display: "IA - Iowa" },
      { value: "KS", display: "KS - Kansas" },
      { value: "KY", display: "KY - Kentucky" },
      { value: "LA", display: "LA - Louisiana" },
      { value: "ME", display: "ME - Maine" },
      { value: "MD", display: "MD - Maryland" },
      { value: "MA", display: "MA - Massachusetts" },
      { value: "MI", display: "MI - Michigan" },
      { value: "MN", display: "MN - Minnesota" },
      { value: "MS", display: "MS - Mississippi" },
      { value: "MO", display: "MO - Missouri" },
      { value: "MT", display: "MT - Montana" },
      { value: "NE", display: "NE - Nebraska" },
      { value: "NV", display: "NV - Nevada" },
      { value: "NH", display: "NH - New Hampshire" },
      { value: "NJ", display: "NJ - New Jersey" },
      { value: "NM", display: "NM - New Mexico" },
      { value: "NY", display: "NY - New York" },
      { value: "NC", display: "NC - North Carolina" },
      { value: "ND", display: "ND - North Dakota" },
      { value: "OH", display: "OH - Ohio" },
      { value: "OK", display: "OK - Oklahoma" },
      { value: "OR", display: "OR - Oregon" },
      { value: "PA", display: "PA - Pennsylvania" },
      { value: "RI", display: "RI - Rhode Island" },
      { value: "SC", display: "SC - South Carolina" },
      { value: "SD", display: "SD - South Dakota" },
      { value: "TN", display: "TN - Tennessee" },
      { value: "TX", display: "TX - Texas" },
      { value: "UT", display: "UT - Utah" },
      { value: "VT", display: "VT - Vermont" },
      { value: "VA", display: "VA - Virginia" },
      { value: "WA", display: "WA - Washington" },
      { value: "WV", display: "WV - West Virginia" },
      { value: "WI", display: "WI - Wisconsin" },
      { value: "WY", display: "WY - Wyoming" }
    ];

    const titles = [
      { value: "", display: "Select Title" },
      { value: "MR", display: "MR" },
      { value: "MRS", display: "MRS" }
    ];

    let spiner = ''
    if (this.state.loading == true) {
        spiner = (
            <GifLoader
                loading={true}
                imageSrc={Eclips}
                // imageStyle={imageStyle}
                overlayBackground="rgba(0,0,0,0.5)"
            />
        )
    }

    return (
      <React.Fragment>
        {spiner}
        <div
          id="myModal1"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          aria-hidden="true"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            <button
              // onClick={this.props.onClose()}
              type="button"
              className="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true"></span>
            </button>
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">{this.state.editId > 0 ? this.state.refProviderModel.name + " - " + this.state.refProviderModel.id : "NEW REFERRING PROVIDER"}</h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkBox"
                          id="isActive"
                          name="isActive"
                          checked={!isActive}
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                      >
                        Delete
                      </Input>
                    </div>
                  </div>
                </div>
              </div>

              <div className="modal-body" style={{ maxHeight: this.state.maxHeight }} >
                <div className="mainTable">


                  <div className="row-form">
                    <div className="mf-6">
                      <label>Name <span className="redlbl"> *</span></label>

                      <div className="textBoxValidate">
                        <Input
                          className={this.state.validationModel.nameValField ? this.errorField : ""}
                          type="text"
                          value={this.state.refProviderModel.name}
                          name="name"
                          id="name"
                          max="20"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.nameValField}
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>Title</label>
                      <select
                        name="title"
                        id="title"
                        value={this.state.refProviderModel.title}
                        onChange={this.handleChange}>
                        {titles.map(s => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>


                  <div className="row-form" >

                    <div className="mf-6">

                      <label>Last Name <span className="redlbl"> *</span></label>

                      <div className="textBoxValidate textBoxTwoDigit">

                        <Input
                          className={this.state.validationModel.lastNameValField ? this.errorField : ""}
                          type="text"
                          value={this.state.refProviderModel.lastName}
                          name="lastName"
                          id="lastName"
                          max="25"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.lastNameValField}

                        <label>MI</label>
                        <Input
                          type="text"
                          max="3"
                          value={this.state.refProviderModel.middleInitial}
                          name="middleInitial"
                          id="middleInitial"
                          onChange={() => this.handleChange}
                        />
                      </div>


                    </div>

                    <div className="mf-6">
                      <label>First Name <span className="redlbl"> *</span></label>

                      <div className="textBoxValidate">
                        <Input
                          className={this.state.validationModel.firstNameValField ? this.errorField : ""}
                          type="text"
                          value={this.state.refProviderModel.firstName}
                          name="firstName"
                          id="firstName"
                          max="25"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.firstNameValField}
                      </div>

                    </div>
                  </div>


                  <div className="mf-12 headingOne mt-25">
                    <p>Legal Information</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>NPI <span className="redlbl"> *</span></label>

                      <div className="textBoxValidate">
                        <Input
                          className={this.state.validationModel.npiValField ? this.errorField : ""}
                          type="text"
                          value={this.state.refProviderModel.npi}
                          name="npi"
                          id="npi"
                          max="10"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        />
                        {this.state.validationModel.npiValField}
                      </div>

                    </div>
                    <div className="mf-6">
                      <label>SSN</label>
                      <div className="textBoxValidate">
                        <Input
                          className={this.state.validationModel.ssnValField ? this.errorField : ""}
                          type="text"
                          value={this.state.refProviderModel.ssn}
                          name="ssn"
                          id="ssn"
                          max="9"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        />
                        {this.state.validationModel.ssnValField}
                      </div>

                    </div>
                  </div>
                  <div className="row-form">






                    <div className="mf-6 mf-icon">
                      <label>Taxonomy Code</label>

                      <div className="textBoxValidate">
                        <Input
                          className={this.state.validationModel.taxonomyCodeValField ? this.errorField : ""}
                          type="text" value={this.state.refProviderModel.taxonomyCode} name="taxonomyCode" id="taxonomyCode" max='10'
                          onChange={() => this.handleChange} />
                        <img src={taxonomyIcon} />
                        {this.state.validationModel.taxonomyCodeValField}
                      </div>

                    </div>
                    <div className="mf-6"></div>
                  </div>

                  <div className="mf-12 headingOne mt-25">
                    <p>Address Information</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Address 1</label>
                      <Input
                        type="text"
                        value={this.state.refProviderModel.address1}
                        name="address1"
                        id="address1"
                        max='55'
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Address 2</label>
                      <Input
                        type="text"
                        value={this.state.refProviderModel.address2}
                        name="address2"
                        id="address2"
                        max='55'
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>City - State</label>
                      <div className="textBoxTwoField">
                        <Input
                          type="text"
                          value={this.state.refProviderModel.city}
                          name="city"
                          id="city"
                          max="20"
                          onChange={() => this.handleChange}
                        />
                        <select
                          name="state"
                          id="state"
                          value={this.state.refProviderModel.state}
                          onChange={this.handleChange}
                        >
                          {usStates.map(s => (
                            <option key={s.value} value={s.value}>
                              {s.display}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Zip Code - Phone</label>
                      <div className="textBoxTwoField textBoxValidate">

                        <div className="twoColValidate">
                          <Input
                            className={this.state.validationModel.zipCodeValField ? this.errorField : ""}
                            type="text"
                            value={this.state.refProviderModel.zipCode}
                            name="zipCode"
                            id="zipCode"
                            onChange={() => this.handleChange}
                            max="9"
                            onKeyPress={event => this.handleNumericCheck(event)}
                          />
                          {this.state.validationModel.zipCodeValField}
                        </div>


                        <div className="twoColValidate">
                          <Input
                            className={this.state.validationModel.officePhoneNumValField ? this.errorField : ""}
                            type="text"
                            value={this.state.refProviderModel.officePhoneNum}
                            name="officePhoneNum"
                            id="officePhoneNum"
                            max="10"
                            onChange={() => this.handleChange}
                            onKeyPress={event => this.handleNumericCheck(event)}
                          />
                          {this.state.validationModel.officePhoneNumValField}
                        </div>

                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Email</label>
                      <Input
                        type="text"
                        value={this.state.refProviderModel.email}
                        name="email"
                        id="email"
                        max='30'
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">&nbsp;</div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12 field_full-8">
                      <label>Notes:</label>
                      <textarea
                        name="notes"
                        id="notes"
                        cols="30"
                        rows="10"
                        value={this.state.refProviderModel.notes}
                        onChange={this.handleChange}
                      ></textarea>
                    </div>
                  </div>
                </div>

                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <button
                          className="btn-blue"
                          onClick={this.saveNewReffProvider}
                        >
                          Save{" "}
                        </button>
                        <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={this.props.onClose()}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}


function mapStateToProps(state) {
  console.log("state from Header Page" , state);
  return {
      selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
      selectedTabPage: state.selectedTabPage,
      selectedPopup: state.selectedPopup,
      // id: state.selectedTab !== null ? state.selectedTab.id : 0,
      setupLeftMenu: state.leftNavigationMenus,
      loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
      userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(NewRefferingProvider);


