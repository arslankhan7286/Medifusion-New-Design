import React, { Component } from 'react'
import Label from './Label'
import Input from './Input'
import axios from 'axios';
import { MDBDataTable, MDBInput, MDBBtn } from 'mdbreact';
import GridHeading from './GridHeading';
import PaperSubmissionModal from './PaperSubmissionModal'
//import viewHCFAFile from './viewHCFAFile';
import GPopup from './GPopup';

import $ from 'jquery';
import Swal from 'sweetalert2'
import { isNullOrUndefined } from "util";


import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";

import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'



export class PaperSubmission extends Component {
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/PaperSubmission/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };


        this.paperModel = {
            "formType": '',
            "accountNum": '',
            "visitID": 0,
            "practice": '',
            "provider": '',
            "planName": '',
            "payerID": ''
        }

        this.submitModel = {
            "formType": '',
            "clientID": 1,
            "visits": [],
            "processedClaims": 0,
            "isFileSubmitted": false,
            "ErrorVisits": [],
            "filePath": '',
            "errorMessage": '',
            "sessionId": '',
            "submissionLogID": 0
        }

        this.state = {
            paperModel: this.paperModel,
            submitModel: this.submitModel,
            data: [],
            initialData: [],
            revData: [],
            selectedAll: false,
            checked: [],
            output: {},
            showPopup: false,
            id: 0,
            showPopup: false,
            showPracticePopup: false,
            showLocationPopup: false,
            showProviderPopup: false,
            showPatientPopup : false,
            showVisitPopup : false,
            loading: false
        }

        this.selectedVisits = []

        this.handleChange = this.handleChange.bind(this);
        this.clearFields = this.clearFields.bind(this);
        this.toggleCheck = this.toggleCheck.bind(this);
        this.isChecked = this.isChecked.bind(this);
        this.selectALL = this.selectALL.bind(this);
        this.submitCheckedVisits = this.submitCheckedVisits.bind(this);
        this.searchPaperSub = this.searchPaperSub.bind(this);
        this.closesubmitPlanPopup = this.closesubmitPlanPopup.bind(this);
        this.opensubmitPlanPopup = this.opensubmitPlanPopup.bind(this);
        this.openPatientPopup = this.openPatientPopup.bind(this);
        this.closePatientPopup = this.closePatientPopup.bind(this);
        this.openVisitPopUp = this.openVisitPopUp.bind(this);
        this.closeVisitPopup = this.closeVisitPopup.bind(this);
    }


    //Open Patient Popup
    openPatientPopup = (id) => {
        this.setState({ showPatientPopup: true, id: id });
    }

    //Close Patient Popup
    closePatientPopup = () => {
        $('#myModal').hide()
        this.setState({ showPatientPopup: false });
    }


    //Open Visit Popup
    openVisitPopUp = (id) => {
        this.setState({ showVisitPopup: true, id: id });
    }

    //Close Visit Popup
    closeVisitPopup = () => {
        $('#myModal').hide()
        this.setState({ showVisitPopup: false });
    }

    openPracticePopup = (id) => {
        this.setState({ showPracticePopup: true, id: id });
    }

    closePracticePopup = () => {
        $('#myModal').hide()
        this.setState({ showPracticePopup: false });
    }

    openLocationPopup = (id) => {
        this.setState({ showLocationPopup: true, id: id });
    }

    closeLocationPopup = () => {
        $('#myModal').hide()
        this.setState({ showLocationPopup: false });
    }

    openProviderPopup = (id) => {
        this.setState({ showProviderPopup: true, id: id });
    }

    closeProviderPopup = () => {
        $('#myModal').hide()
        this.setState({ showProviderPopup: false });
    }

    isChecked = id => {
        //return this.state.submitModel.visits.filter(name => name === id)[0] ? true : false
        return this.selectedVisits.filter(name => name === id)[0] ? true : false
    }

    // Search Paper Submission
    searchPaperSub = (e) => {
        e.preventDefault()

        if (this.state.paperModel.formType === '' || this.state.paperModel.formType === null || this.state.paperModel.formType === undefined) {
            Swal.fire(
                {
                    type: 'error',
                    text: 'Please Select the HCFA Template ',
                })
            return
        }
        this.setState({ loading: true })

        axios.post(this.url + 'FindVisits', this.state.paperModel  , this.config)
            .then(response => {
                console.log(response.data)

                let newList = []
                response.data.map((row, i) => {
                    newList.push({
                        id: row.id,
                        //check: <MDBInput type="checkbox" id={row.visitID} onChange={this.toggleCheck} checked={this.isChecked(row.visitID)} />,
                        ischeck: (
                            <div class="lblChkBox">
                                <input type="checkbox" id={row.visitID} name={row.visitID} onChange={this.toggleCheck}
                                    checked={this.isChecked(row.visitID)} />
                                <label for={row.visitID}>
                                    <span></span>
                                </label>
                            </div>),
                        visitID: <MDBBtn className='gridBlueBtn' onClick={() => this.openVisitPopUp(row.visitID)} > {row.visitID}</MDBBtn>,
                        dos: row.dos,
                        accountNum: <MDBBtn className='gridBlueBtn' onClick={() => this.openPatientPopup(row.patientID)} > {row.accountNum}</MDBBtn>,
                        patient: row.patient,
                        practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPracticePopup(row.practiceID)} > {row.practice}</MDBBtn>,
                        location: <MDBBtn className='gridBlueBtn' onClick={() => this.openLocationPopup(row.locationID)} > {row.location}</MDBBtn>,
                        provider: <MDBBtn className='gridBlueBtn' onClick={() => this.openProviderPopup(row.providerID)} > {row.provider}</MDBBtn>,
                        totalAmount: isNullOrUndefined(row.totalAmount) ? '' : '$' + row.totalAmount,
                        validationMessage: row.validationMessage
                    });

                });

                //setTimeout(function () {
                this.setState({ data: newList, initialData: response.data, loading: false });
                //}.bind(this), 3000);

                // this.setState({
                //     data: newList,
                //     initialData: response.data,
                //     loading: false
                // });

            }).catch(error => {
                //setTimeout(function () {
                this.setState({ loading: false });
                //}.bind(this), 3000);
                console.log(error)
            });

        e.preventDefault();
    }

    selectALL = e => {

        let newValue = !this.state.selectedAll
        this.setState({ ...this.state, selectedAll: newValue })

        let newList = []
        this.selectedVisits = []
        this.state.initialData.map((row, i) => {

            if (newValue === true)
                this.selectedVisits.push(Number(row.visitID));

            newList.push({
                id: row.id,
                //ischeck: <MDBInput type="checkbox" id={row.visitID} onChange={this.toggleCheck} checked={this.isChecked(row.visitID)} />,
                ischeck: (
                    <div class="lblChkBox">
                        <input type="checkbox" id={row.visitID} name={row.visitID} onChange={this.toggleCheck}
                            checked={this.isChecked(row.visitID)} />
                        <label for={row.visitID}>
                            <span></span>
                        </label>
                    </div>),
                visitID: row.visitID,
                dos: row.dos,
                accountNum: row.accountNum,
                patient: row.patient,
                Practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPracticePopup(row.practiceID)} > {row.practice}</MDBBtn>,
                location: <MDBBtn className='gridBlueBtn' onClick={() => this.openLocationPopup(row.locationID)} > {row.location}</MDBBtn>,
                provider: <MDBBtn className='gridBlueBtn' onClick={() => this.openProviderPopup(row.providerID)} > {row.provider}</MDBBtn>,
                totalAmount: row.totalAmount,
                validationMessage: row.validationMessage
            });
        });

        this.setState({ data: newList, submitModel: { ...this.state.submitModel, visits: this.selectedVisits } });
    }


    toggleCheck = e => {

        let checkedArr = this.selectedVisits;
        let newList = []

        checkedArr.filter(name => name === Number(e.target.id))[0]
            ? checkedArr = checkedArr.filter(name => name !== Number(e.target.id))
            : checkedArr.push(Number(e.target.id));

        this.selectedVisits = checkedArr

        this.state.initialData.map((row, i) => {
            newList.push({
                id: row.id,
                //ischeck: <MDBInput type="checkbox" id={row.visitID} onChange={this.toggleCheck} checked={this.isChecked(row.visitID)} />,
                ischeck: (
                    <div class="lblChkBox">
                        <input type="checkbox" id={row.visitID} name={row.visitID} onChange={this.toggleCheck}
                            checked={this.isChecked(row.visitID)} />
                        <label for={row.visitID}>
                            <span></span>
                        </label>
                    </div>),
                visitID: row.visitID,
                dos: row.dos,
                accountNum: row.accountNum,
                patient: row.patient,
                Practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPracticePopup(row.practiceID)} > {row.practice}</MDBBtn>,
                location: <MDBBtn className='gridBlueBtn' onClick={() => this.openLocationPopup(row.locationID)} > {row.location}</MDBBtn>,
                provider: <MDBBtn className='gridBlueBtn' onClick={() => this.openProviderPopup(row.providerID)} > {row.provider}</MDBBtn>,
                totalAmount: row.totalAmount,
                validationMessage: row.validationMessage
            });
        });

        this.setState({ data: newList, submitModel: { ...this.state.submitModel, visits: this.selectedVisits } });
    }

    opensubmitPlanPopup = (id) => {
        this.setState({ showPopup: true, id: id });
    }
    closesubmitPlanPopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
        $("#searchID").click();
    }


    submitCheckedVisits = (e) => {

        console.log(this.state.submitModel);

        if (this.state.submitModel.visits === null || this.state.submitModel.visits.length === 0) {
            Swal.fire(
                {
                    type: 'info',
                    text: 'Please Select the Visit(s)',
                })
            return
        }
        else {
            this.setState({ ...this.state, loading: true })

            axios.post(this.url + 'SubmitVisits', this.state.submitModel  , this.config)
                .then(response => {
                    this.setState({ loading: false });
                    console.log(response.data);
                    if (isNullOrUndefined(response.data.errorMessage) === false && response.data.errorMessage.length > 0) {
                        Swal.fire(
                            {
                                type: 'error',
                                text: response.data.errorMessage,
                            })
                    } else if (response.data.isisFileSubmitted === true) {

                        Swal.fire(
                            {
                                type: 'success',
                                text: 'File Submitted Successfully',
                            })
                    } else {
                        this.setState({
                            output: response.data,
                            showPopup: true,
                            loading:false
                        });
                    }
                }).catch(error => {
                    this.setState({ loading: false });
                    let errorList = []
                    if (error.response !== null && error !== null) {
                        errorList = error.response;
                        console.log(errorList);
                        Swal.fire({
                            type: 'error',
                            text: 'error meeas',
                            // text: error.response,
                        })
                    }
                    else console.log(error);
                });

            
        }
    }


    componentWillMount() {
        axios.get(this.url + 'GetProfiles' ,  this.config)
            .then(response => {
                console.log(response.data);
                this.setState({
                    revData: response.data.receivers,
                })
            }).catch(error => {
                console.log(error);
            });
    }


    handleChange = event => {
        this.setState({
            paperModel: { ...this.state.paperModel, [event.target.name]: event.target.value.toUpperCase() },
            submitModel: { ...this.state.submitModel, [event.target.name]: event.target.value.toUpperCase() }
        });
        console.log(this.state)
        event.preventDefault();
    };


    clearFields = event => {
        this.setState({
            paperModel: this.paperModel
        });
    };

    render() {
        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 0,
                },
                {
                    //label: <MDBInput type="checkbox" onChange={this.selectALL} />,
                    label: (
                        <div class="lblChkBox">
                            <input type="checkbox" id='selectAll' name='selectAll' onChange={this.selectALL} />
                            <label for='selectAll'>
                                <span></span>
                            </label>
                        </div>),
                    field: 'ischeck',
                    sort: '',
                    width: 50
                },
                {
                    label: 'VISIT #',
                    field: 'visitID',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'DOS',
                    field: 'dos',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'ACCOUNT # ',
                    field: 'accountNum ',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'PATIENT',
                    field: 'patient',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'PRACTICE',
                    field: 'practice',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'LOCATION',
                    field: 'location',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'PROVIDER',
                    field: 'provider',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'AMOUNT',
                    field: 'totalAmount ',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'VALIDATION MSG',
                    field: 'validationMessage',
                    sort: 'asc',
                    width: 250
                }
            ],
            rows: this.state.data
        };
        const formType = [
            { value: "", display: "Select Title" },
            { value: "HCFA 1500", display: "HCFA 1500" },
            { value: "PLAIN 1500", display: "Plain 1500" }
        ]


        let popup = ''

        if (this.state.showPopup) {
            popup = <PaperSubmissionModal onClose={() => this.closesubmitPlanPopup} id={this.state.id} data={this.state.output}></PaperSubmissionModal>
        } else if (this.state.showPracticePopup) {
            popup = <NewPractice onClose={() => this.closePracticePopup} practiceID={this.state.id}></NewPractice>
        } else if (this.state.showLocationPopup) {
            popup = <NewLocation onClose={() => this.closeLocationPopup} id={this.state.id}></NewLocation>
        } else if (this.state.showProviderPopup) {
            popup = <NewProvider onClose={() => this.closeProviderPopup} id={this.state.id}></NewProvider>
        }  else if (this.state.showPatientPopup) {
            popup = <GPopup onClose={() => this.closePatientPopup} popupName="patient" id={this.state.id}></GPopup>
        } else if (this.state.showVisitPopup ) {
            popup = <GPopup onClose={() => this.closeVisitPopup} popupName="visit" id={this.state.id}></GPopup>
        }else
            popup = <React.Fragment></React.Fragment>


        let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }


        return (
            < React.Fragment >
                {spiner}
                <div className="mainHeading row">
                    <div className="col-md-6">
                        <h1>PAPER SUBMITION SEARCH</h1>
                    </div>

                </div>

                <form onSubmit={event => this.searchPaperSub(event)}>
                    <div className="mainTable">

                        <div className="row-form">
                            <div className="mf-6">
                                <label>HCFA Template</label>
                                <select name="formType" id="formType" value={this.state.paperModel.formType} onChange={this.handleChange}>
                                    {formType.map(s => (
                                        <option key={s.value} value={s.value}>
                                            {s.display}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div className="mf-6">
                                &nbsp;
                                        </div>

                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Account NO'></Label>
                                <Input type='text' name='accountNum' id='accountNum' value={this.state.paperModel.accountNum} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Visit ID'></Label>
                                <Input type='text' name='visitID' id='visitID'
                                    value={this.state.paperModel.visitID} onChange={() => this.handleChange} />
                            </div>
                        </div>
                        <div className="row-form">

                            <div className="mf-6">
                                <Label name='Practice'></Label>
                                <Input type='text' name='practice' id='practice' value={this.state.paperModel.practice} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Provider'></Label>
                                <Input type='text' name='provider' id='provider'
                                    value={this.state.paperModel.provider} onChange={() => this.handleChange} />
                            </div>


                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Plan Name'></Label>
                                <Input type='text' name='planName' id='planName' value={this.state.paperModel.planName} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Payer ID'></Label>
                                <Input type='text' name='payerID' id='payerID' max='9'
                                    value={this.state.paperModel.payerID} onChange={() => this.handleChange} />
                            </div>
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">

                                <Input type='button' name='name' id='name' className='btn-blue' value='Submit' onClick={() => this.submitCheckedVisits()} />
                                <Input type='submit' name='name' id='searchID' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>

                </form>


                <div className="mf-12 table-grid mt-15">

                    <GridHeading Heading='PAPER SUBMITION SEARCH RESULT'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            responsive={true}
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

                {popup}
            </React.Fragment >
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(PaperSubmission);


