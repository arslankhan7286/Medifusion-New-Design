import React, { Component } from 'react'
import LeftMenuItem from './LeftMenuItem'

import Setup from './Setup'
import Practice from './Practice'
import Provider from './Provider'
import ReferringProvider from './ReferringProvider'
import Insurance from './Insurance'
import Location from './Location'

import InsurancePlan from './InsurancePlan'
import CPT from './CPT'
import leftNavMenusReducer from '../reducers/leftNavMenusReducer'
import Patient from './Patient'
import PatientPlan from './PatientPlan'
import ChargeSearch from './ChargeSearch';
import PatientPayment from './PatientPayment'

import PatientLeftMenu from './PatientLeftMenu'
import NewPatient from './NewPatient'
import Submissions from './Submissions'
import ICD from './ICD'
import Modifier from './Modifier'
import POS from './POS'
import InsurancePlanAddress from './InsurancePlanAddress'
import EDISubmitPayer from './EDISubmitPayer'
import EDIEligibilityPayer from './EDIEligibilityPayer'
import EDIStatusPayer from './EDIStatusPayer'
import NewCharge from './NewCharge'
import PaymentSearch from './PaymentSearch'
import NewChargeLeftMenu from './NewChargeLeftMenu'

import ElectronicSubmission from './ElectronicSubmission'
import PaperSubmission from './PaperSubmission'
import SubmissionLog from './SubmissionLog'

import NewPaymentLeftMenu from './NewPaymentLeftMenu'
import NewManualPostingMenu from './NewManualPostingMenu'
import ManualPosting from './ManualPosting'
import NewPayment from './NewPayment'

import AdjustmentCode from './AdjustmentCode'
import RemarkCode from './RemarkCode'
import HCFA1500 from './HCFA1500';
import NewBatchDocLeftMenu from './NewBatchDocLeftMenu';
import BatchDocument from './BatchDocument';
import PlanFollowup from './PlanFollowup';
import Followup from './Followup';
import PatientFollowUp from './PatientFollowUp'
import Group from './Group'
import Reason from './Reason'
import Action from './Action';
import Client from './Client';
import User from './User';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

class MainPage extends Component {

    // constructor(props) {
    //     super(props)
    //     this.state = {
    //         //selectedTab: 'Setup'
    //     }
    // }

    render() {

        let leftNavigation = '';
        let mainContent = '';

        //console.log(this.props.setupLeftMenu)

        //alert(this.props.selectedTab)
        //alert(this.props.selectedTabPage)

        let selectedTab = this.props.selectedTab
        let selectedTabPage = this.props.selectedTabPage

        //alert(selectedTab);
        //alert(selectedTabPage);

        //switch (this.props.selectedTab) {
        switch (selectedTab) {
            case 'Setup':
                leftNavigation = <Setup leftMenusFromSetup={this.props.setupLeftMenu} ></Setup>;
                break;

            case 'Submissions':
                leftNavigation = <Submissions></Submissions>;
                break;

            case 'Patient':
                mainContent = <Patient></Patient>
                leftNavigation = undefined
                break;

            case "NewPatient":
                leftNavigation = <PatientLeftMenu id={this.props.id}></PatientLeftMenu>;
                mainContent = <NewPatient></NewPatient>;
                if (selectedTabPage !== 'DEMOGRAPHICS' && selectedTabPage !== 'PLAN' && selectedTabPage !== 'PAYMENT')
                    selectedTabPage = 'DEMOGRAPHICS'
                break;

            case 'Charges':
                mainContent = <ChargeSearch></ChargeSearch>
                leftNavigation = undefined
                break;

                case "Documents":
                    leftNavigation = <NewBatchDocLeftMenu></NewBatchDocLeftMenu>;
                    mainContent = <BatchDocument id={this.props.id}></BatchDocument>;
    
                    if (selectedTabPage !== 'Documents' && selectedTabPage !== 'HCFA1500')
                        selectedTabPage = 'Documents'
                    break;
    

            case "NewCharge":
                leftNavigation = <NewChargeLeftMenu></NewChargeLeftMenu>;
                mainContent = <NewCharge id={this.props.id}></NewCharge>;

                if (selectedTabPage !== 'CHARGE' && selectedTabPage !== 'HCFA1500')
                    selectedTabPage = 'CHARGE'
                break;

            case "Payments":

                mainContent = <PaymentSearch id={this.props.id}></PaymentSearch>
                leftNavigation = undefined;
                break;


            case "NewPayment":
                leftNavigation = <NewPaymentLeftMenu></NewPaymentLeftMenu>;
                mainContent = <NewPayment id={this.props.id}></NewPayment>

                if (selectedTabPage !== 'PAYMENT' && selectedTabPage !== 'HCFA1500')
                    selectedTabPage = 'PAYMENT'
                break;
                case 'Followup':
                        leftNavigation = <Followup></Followup>;
                        break;
            case "ManualPosting":
                leftNavigation = <NewManualPostingMenu></NewManualPostingMenu>;
                mainContent = <ManualPosting></ManualPosting>

                if (selectedTabPage !== 'ManualPosting' && selectedTabPage !== 'ManualPosting')
                    selectedTabPage = 'ManualPosting'
                break;

                
            // case null:
            //     leftNavigation = ''
            //     break;
        }




        if (leftNavigation !== undefined) {
            //switch (this.props.selectedTabPage) {
            switch (selectedTabPage) {
                case  "CLIENT" :
                    mainContent=<Client></Client>
                    break;
                    case  "USER" :
                            mainContent=<User></User>
                            break;
                case 'PRACTICE':
                    mainContent = <Practice></Practice>;
                    break
                case 'LOCATION':
                    mainContent = <Location></Location>
                    break;
                case 'PROVIDER':
                    mainContent = <Provider></Provider>
                    break;
                case 'REFERRING PROVIDER':
                    mainContent = <ReferringProvider></ReferringProvider>
                    break;
                case 'INSURANCE':
                    mainContent = <Insurance></Insurance>
                    break;
                case 'INSURANCE PLAN':
                    mainContent = <InsurancePlan></InsurancePlan>
                    break;
                case 'INSURANCE PLAN ADDRESS':
                    mainContent = <InsurancePlanAddress></InsurancePlanAddress>
                    break;
                case "ICD":
                    mainContent = <ICD></ICD>
                    break;
                case 'CPT':
                    mainContent = <CPT></CPT>
                    break;
                case "MODIFIERS":
                    mainContent = <Modifier></Modifier>
                    break;
                case "POS":
                    mainContent = <POS></POS>
                    break;
                case 'EDI SUBMIT PAYER':
                    mainContent = <EDISubmitPayer></EDISubmitPayer>
                    break;
                case 'EDI ELIGIBILITY PAYER':
                    mainContent = <EDIEligibilityPayer></EDIEligibilityPayer>
                    break;
                case 'EDI STATUS PAYER':
                    mainContent = <EDIStatusPayer></EDIStatusPayer>
                    break;
                case "CLAIM STATUS CATEGORY CODES":
                    mainContent = <div>CLAIM STATUS CATEGORY CODES</div>
                    break;
                case "CLAIM STATUS CODES":
                    mainContent = <div>CLAIM STATUS CODES</div>
                    break;
                case "ADJUSTMENT CODES":
                    mainContent = <AdjustmentCode></AdjustmentCode>
                    break;
                case "REMARK CODES":
                    mainContent = <RemarkCode></RemarkCode>
                    break;

                case "DEMOGRAPHICS":
                    mainContent = <NewPatient></NewPatient>;
                    break;

                case "PLAN":
                    mainContent = <PatientPlan></PatientPlan>;
                    break;

                    case "PAYMENT":
                    mainContent = <PatientPayment></PatientPayment>;
                    break;

                case 'ELECTRONIC SUBMISSION':
                    mainContent = <ElectronicSubmission></ElectronicSubmission>
                    break;

                case 'PAPER SUBMISSION':
                    mainContent = <PaperSubmission></PaperSubmission>
                    break;

                case 'SUBMISSION LOG':
                    mainContent = <SubmissionLog></SubmissionLog>
                    break;

                case "CHARGE":
                    mainContent = <NewCharge id={this.props.id}></NewCharge>;
                    break;

                case "HCFA1500":
                    //mainContent = <HCFA1500 id={this.props.id}></HCFA1500>;
                    mainContent = <div>HCFA1500</div>
                    break;

                case "PAYMENT":
                    mainContent = <NewPayment></NewPayment>;
                    break;

                case "ManualPosting":
                    mainContent = <ManualPosting></ManualPosting>
                    break;
                    
                case 'PLAN FOLLOW UP':
                    mainContent = <PlanFollowup></PlanFollowup>
                    break;
                case 'PATIENT FOLLOW UP':
                    mainContent = <PatientFollowUp></PatientFollowUp>
                    break;
                    case 'GROUP':
                            mainContent = <Group></Group>
                            break;
                        case 'REASON':
                            mainContent = <Reason></Reason>
                            break;
                        case 'ACTION':
                            mainContent = <Action></Action>
                            break;
        

                case "HISTORY":
                    mainContent = <p>History</p>;
                    break;

            }
        }

        let leftNavigationJSX = ''
        let classN = ''
        if (leftNavigation !== undefined) {
            leftNavigationJSX = (
                <div id="sidebar-container" className="sidebar-expanded d-none d-md-block col-2">
                    <ul className="list-group sticky-top sticky-offset">
                        {leftNavigation}
                    </ul>
                </div>
            )

            classN = 'col-10 py-3'
        } else classN = 'col py-3'




        return (
            <div className="row" id="body-row">

                {leftNavigationJSX}

                {/* <div id="sidebar-container" className="sidebar-expanded d-none d-md-block col-3">
                    <ul className="list-group sticky-top sticky-offset">
                        {leftNavigation}
                    </ul>
                </div> */}

                <div className={classN} >
                    <div className="col-md-12">
                        {mainContent}
                    </div>
                </div>
            </div>
        )
    }
}



function mapStateToProps(state) {
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(MainPage);
  
