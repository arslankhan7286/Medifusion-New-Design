import React, { Component } from 'react'

import Label from "./Label";
import Input from "./Input";

import NewGroup from './NewGroup'

import settingIcon from "../images/setting-icon.png";


import SearchHeading from "./SearchHeading";
import { MDBDataTable  ,MDBBtn } from "mdbreact";
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

import searchIcon from '../images/search-icon.png'
import refreshIcon from '../images/refresh-icon.png'
import newBtnIcon from '../images/new-page-icon.png'
import settingsIcon from '../images/setting-icon.png'

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


import $ from "jquery";
import Swal from "sweetalert2";
import axios from "axios";
export class Group extends Component {
    constructor(props) {
        super(props)
        this.url = 'http://192.168.110.44/Database/api/Group/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };
        this.searchModel = {
            name: "",
            description: "",
            biller: ""

        }

        this.state = {
            searchModel: this.searchModel,
            data: [],
            showPopup: false,
            loading:false
        }

        this.handleChange = this.handleChange.bind(this);
        this.searchGroup = this.searchGroup.bind(this);
        this.openGroupPopup = this.openGroupPopup.bind(this);
        this.closeGroupPopup = this.closeGroupPopup.bind(this);
        this.clearFields = this.clearFields.bind(this);
    }

    clearFields = event => {
        this.setState({
            searchModel: this.searchModel
        });
    };


    closeGroupPopup() {

        $('#myModal').hide()
        this.setState({ showPopup: false });
    }
    openGroupPopup = (id) => {

        this.setState({ showPopup: true, id: id });
    }

    searchGroup = (e) => {
        e.preventDefault()
        console.log(this.state);
        this.setState({loading : true})
        axios.post(this.url + 'FindGroups', this.state.searchModel , this.config)
            .then(response => {

                let newList = []
                response.data.map((row, i) => {
                    console.log(row)
                    newList.push({
                        id: row.id,
                        name: 
                         <MDBBtn className="gridBlueBtn" size="sm" onClick={() => this.openGroupPopup(row.id)}>{row.name}</MDBBtn>,
                        description: row.description,
                        biller: row.biller

                    });
                });

                this.setState({ data: newList  ,loading:false });

            }).catch(error => {
                this.setState({loading:false})
                console.log(error)
            });

        e.preventDefault();
    }


    handleChange = event => {
        console.log(event);

        event.preventDefault();
        console.log(event.target.value)
        this.setState({

            searchModel: { ...this.state.searchModel, [event.target.name]: event.target.value }
        });
    };




    render() {

        const data = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "NAME",
                    field: "name",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "DESCRIPTION",
                    field: "description",
                    sort: "asc",
                    width: 270
                },
                {
                    label: "BILLER",
                    field: "biller",
                    sort: "asc",
                    width: 270
                }
            ],
            rows: this.state.data
        };


        let popup = ''

        if (this.state.showPopup) {
            popup = <NewGroup onClose={() => this.closeGroupPopup} id={this.state.id}></NewGroup>
        }
        else
            popup = <React.Fragment></React.Fragment>





            let spiner = ''
            if (this.state.loading == true) {
                spiner = (
                    <GifLoader
                        loading={true}
                        imageSrc={Eclips}
                        // imageStyle={imageStyle}
                        overlayBackground="rgba(0,0,0,0.5)"
                    />
                )
            }



        return (
            <React.Fragment>

                {spiner}


<SearchHeading heading="GROUP SEARCH" handler={() => this.openGroupPopup(0)}></SearchHeading>
                

                <form onSubmit={event => this.searchGroup(event)}>
                    <div className="mainTable">
                        <div className="row-form">
                            <div className="mf-6">
                                <Label name="Name"></Label>

                                <Input
                                    type="text" name="name" id="name" max="5" value={this.state.searchModel.name} onChange={() => this.handleChange}
                                />
                            </div>
                            <div className="mf-6">
                                <Label name="Description"></Label>
                                <Input
                                    max="100" type="text" name="description" id="description" value={this.state.searchModel.description} onChange={() => this.handleChange}
                                />
                            </div>
                        </div>

                        <div className="row-form">
                            {/* <div className="mf-6">
                                <Label name="Biller"></Label>
                                <Input
                                    type="text" name="biller" id="biller" max="11" value={this.state.searchModel.biller} onChange={() => this.handleChange}

                                />
                            </div>
                            <div className="mf-6">

                            </div> */}
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">
                                <Input
                                    type="submit"
                                    name="search"
                                    id="search"
                                    className="btn-blue"
                                    value="Search"
                                />
                                <Input
                                    type="button"
                                    name="clear"
                                    id="clear"
                                    className="btn-grey"
                                    value="Clear"
                                    onClick={event => this.clearFields(event)}
                                />
                            </div>
                        </div>
                    </div>
                </form>

                <div className="mf-12 table-grid mt-15">
                    <div className="row headingTable">
                        <div className="mf-6">
                            <h1>GROUP SEARCH RESULT</h1>
                        </div>
                        <div className="mf-6 headingRightTable">
                            <a href="javascript:;">
                                <img src={settingIcon} alt="" />
                            </a>
                        </div>
                    </div>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                        />
                    </div>
                </div>
                {popup}
            </React.Fragment>
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(Group);
