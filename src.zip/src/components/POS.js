import React, { Component } from "react";
import SearchHeading from "./SearchHeading";
import NewPOS from "./NewPOS";
import Label from "./Label";
import Input from "./Input";
import $ from "jquery";
import axios from "axios";
import { MDBDataTable } from "mdbreact";
import { MDBBtn } from "mdbreact";
import Swal from "sweetalert2";
import settingIcon from "../images/setting-icon.png";


import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'




class POS extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/pos/";
     //Authorization Token
     this.config = {
      headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
  };


    this.searchModel = {
      posCode: "",
      name:"",
      description: ""
    };

    this.state = {
      searchModel: this.searchModel,
      data: [],
      showPopup: false,
      id: 0,
      loading:false
    };
  }

  //search insurance plan address
  searchPOS = e => {
    this.setState({loading:true})
    axios
      .post(this.url + "findpos", this.state.searchModel  , this.config)
      .then(response => {
        console.log("POS Grid Search Response : ", response.data);
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            posCode: (
              <span>
                <MDBBtn className='gridBlueBtn' onClick={() => this.openPOSPopup(row.id)} >
                  {row.posCode}
                </MDBBtn>
              </span>
            ),
            name:row.name,
            description: row.description
        
          });
        });
        this.setState({ data: newList  , loading:false });
      })
      .catch(error => {
        this.setState({loading:false})
        Swal.fire("Something Wrong", "Please Check Server Connection", "error");
        let errorsList = [];
        if (error.response !== null && error.response.data !== null) {
          errorsList = error.response.data;
          console.log(errorsList);
        } else console.log(error);
      });
    e.preventDefault();
  };

  //handle Change
  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  //clear fields button
  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  //open facility popup
  openPOSPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  //close facility popup
  closePOSPopup = () => {
    $("#myModal1").hide();
    this.setState({ showPopup: false });
  };

  //handle numeric change
  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "POS CODE",
          field: "posCode",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "DESCRIPTION",
          field: "description",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.data
    };

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewPOS onClose={() => this.closePOSPopup} id={this.state.id}></NewPOS>
      );
    } else popup = <React.Fragment></React.Fragment>;

    
    let spiner = ''
    if (this.state.loading == true) {
        spiner = (
            <GifLoader
                loading={true}
                imageSrc={Eclips}
                // imageStyle={imageStyle}
                overlayBackground="rgba(0,0,0,0.5)"
            />
        )
    }



    return (
      <React.Fragment>
        {spiner}
        <SearchHeading
          heading="POS SEARCH"
          handler={() => this.openPOSPopup(0)}
        ></SearchHeading>
        <form onSubmit={event => this.searchPOS(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="POS"></Label>
                <Input
                  type="text"
                  name="posCode"
                  id="posCode"
                  max="20"
                  value={this.state.searchModel.posCode}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Name"></Label>
                <Input
                  type="text"
                  name="name"
                  id="name"
                  max="20"
                  value={this.state.searchModel.name}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>
              <div className="row-form" style={{marginLeft: "-14em"}}>
                <div className="mf-12">
                  <Label name="Description"></Label>
                  <Input
                    max="15"
                    type="text"
                    name="description"
                    id="description"
                    value={this.state.searchModel.description}
                    onChange={() => this.handleChange}
                  />
                </div>
              </div>
            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="search"
                  id="search"
                  className="btn-blue"
                  value="Search"
                />
                <Input
                  type="button"
                  name="clear"
                  id="clear"
                  className="btn-grey"
                  value="Clear"
                  onClick={event => this.clearFields(event)}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <div className="row headingTable">
            <div className="mf-6">
              <h1>POS SEARCH RESULT</h1>
            </div>
            <div className="mf-6 headingRightTable">
              <a href="javascript:;">
                <img src={settingIcon} alt="" />
              </a>
            </div>
          </div>

          <div className="tableGridContainer">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>

        </div>
        {popup}
      </React.Fragment >
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page" , state);
  return {
      selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
      selectedTabPage: state.selectedTabPage,
      selectedPopup: state.selectedPopup,
      id: state.selectedTab !== null ? state.selectedTab.id : 0,
      setupLeftMenu: state.leftNavigationMenus,
      loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
      userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(POS);
