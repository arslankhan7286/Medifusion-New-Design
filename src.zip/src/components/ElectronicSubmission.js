import React, { Component } from 'react'
import Label from './Label'
import Input from './Input'
import axios from 'axios';
import { MDBDataTable, MDBBtn, MDBInput } from 'mdbreact';
import GridHeading from './GridHeading';
import ElectronicSubmissionModel from './ElectronicSubmissionModel'
import $ from 'jquery';
import Swal from 'sweetalert2'
import { isNullOrUndefined } from "util";
import GPopup from './GPopup';

import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";


import GifLoader from 'react-gif-loader';
import Eclips from '../images/loading_spinner.gif';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

export class ElectronicSubmission extends Component {
    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/ElectronicSubmission/';
        
 //Authorization Token
 this.config = {
    headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
};

        this.electModel = {
            "receiverID": '',
            "accountNum": '',
            "visitID": 0,
            "practice": '',
            "provider": '',
            "planName": '',
            "payerID": '',
        }
        this.submitModel = {
            "receiverID": 0,
            "clientID": 1,
            "SubmissionLogID": 0,
            "visits": []
        }
        this.display = 'Record displaying Submit Successfully'
        this.state = {
            electModel: this.electModel,
            submitModel: this.submitModel,
            data: [],
            initialData: [],
            revData: [],
            ischeck: {},
            id: 0,
            checked: [],
            output: {},
            popupName:"",
            showPopup: false,
            showPracticePopup: false,
            showLocationPopup: false,
            showProviderPopup: false,
            patientPopup:false,
            visitPopup : false,
            loading: false
        }

        this.selectedVisits = []
        this.searchElectronicSub = this.searchElectronicSub.bind(this);

        this.handleChange = this.handleChange.bind(this);
        this.clearFields = this.clearFields.bind(this);

        this.submitCheckedVisits = this.submitCheckedVisits.bind(this);
        this.toggleCheck = this.toggleCheck.bind(this);
        this.isChecked = this.isChecked.bind(this);
        this.selectALL = this.selectALL.bind(this);
        this.openPatientPopup = this.openPatientPopup.bind(this);
        this.opensubmitPlanPopup = this.opensubmitPlanPopup.bind(this);
        this.closePatientPopup = this.closePatientPopup.bind(this);
        this.closesubmitPlanPopup = this.closesubmitPlanPopup.bind(this);
        this.openVisitPopup = this.openVisitPopup.bind(this);
        this.closeVisitPopUp = this.closeVisitPopUp.bind(this)
    }

    openPracticePopup = (id) => {
        this.setState({ showPracticePopup: true, id: id });
    }

    closePracticePopup = () => {
        $('#myModal').hide()
        this.setState({ showPracticePopup: false });
    }

    openLocationPopup = (id) => {
        this.setState({ showLocationPopup: true, id: id });
    }

    closeLocationPopup = () => {
        $('#myModal').hide()
        this.setState({ showLocationPopup: false });
    }

    openPatientPopup(name , id){
        this.setState({popupName:name ,  patientPopup: true, id: id });
    }

    closePatientPopup(name , id){
        this.setState({popupName:"" , patientPopup : false})
    }

    //Open Visit Popup
    openVisitPopup(name , id){
        this.setState({popupName:name ,  visitPopup: true, id: id });
    }


    //Close Visit Popup
    closeVisitPopUp(){
        this.setState({popupName:"" , visitPopup : false})
    }
    


    openProviderPopup = (id) => {
        this.setState({ showProviderPopup: true, id: id });
    }

    closeProviderPopup = () => {
        $('#myModal').hide()
        this.setState({ showProviderPopup: false });
    }


    isChecked = id => {
        //return this.state.submitModel.visits.filter(name => name === id)[0] ? true : false
        return this.selectedVisits.filter(name => name === id)[0] ? true : false
    }



    searchElectronicSub = (e) => {
        e.preventDefault()
        console.log(this.state.electModel)


        if (this.state.electModel.receiverID === '' || this.state.electModel.receiverID === null || this.state.electModel.receiverID === undefined) {
            Swal.fire(
                {
                    type: 'error',
                    text: 'Please Select the Receiver',
                })
            return
        }

        this.setState({ loading: true })
        axios.post(this.url + 'FindVisits', this.state.electModel ,  this.config)
            .then(response => {
                this.setState({ loading: false });
                console.log(response.data)
                let newList = []
                response.data.map((row, i) => {
                    //console.log(row)
                    newList.push({

                        id: row.id,
                        // ischeck: <MDBInput type="checkbox" id={row.visitID} containerClass='mr-5' onChange={this.toggleCheck}
                        //     checked={this.isChecked(row.visitID)} />,
                        ischeck: (
                            <div class="lblChkBox">
                                <input type="checkbox" id={row.visitID} name={row.visitID} onChange={this.toggleCheck}
                                    checked={this.isChecked(row.visitID)} />
                                <label for={row.visitID}>
                                    <span></span>
                                </label>
                            </div>),
                        visitID: <MDBBtn className='gridBlueBtn' onClick={() => this.openVisitPopup("visit" ,row.visitID)} > {row.visitID}</MDBBtn>,
                        dos: row.dos,
                        accountNum:<MDBBtn className='gridBlueBtn' onClick={() => this.openPatientPopup("patient" , row.patientID)} > {row.accountNum}</MDBBtn> ,
                        patient: row.patient,
                        practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPracticePopup(row.practiceID)} > {row.practice}</MDBBtn>,
                        location: <MDBBtn className='gridBlueBtn' onClick={() => this.openLocationPopup(row.locationID)} > {row.location}</MDBBtn>,
                        provider: <MDBBtn className='gridBlueBtn' onClick={() => this.openProviderPopup(row.providerID)} > {row.provider}</MDBBtn>,
                        totalAmount: isNullOrUndefined(row.totalAmount) ? '' : '$' + row.totalAmount,
                        validationMessage: row.validationMessage
                    });
                });


                //setTimeout(function () {
                this.setState({ data: newList, initialData: response.data, loading: false });
                //}.bind(this), 3000);


            }).catch(error => {
                //setTimeout(function () {
                this.setState({ loading: false });
                //}.bind(this), 3000);

                console.log(error)
            });
        e.preventDefault();
    }



    selectALL = e => {

        let newValue = !this.state.selectedAll
        this.setState({ ...this.state, selectedAll: newValue })

        let newList = []
        this.selectedVisits = []
        this.state.initialData.map((row, i) => {

            if (newValue === true)
                this.selectedVisits.push(Number(row.visitID));

            newList.push({
                id: row.id,
                //ischeck: <MDBInput type="checkbox" id={row.visitID} onChange={this.toggleCheck} checked={this.isChecked(row.visitID)} />,
                ischeck: (
                    <div class="lblChkBox">
                        <input type="checkbox" id={row.visitID} name={row.visitID} onChange={this.toggleCheck}
                            checked={this.isChecked(row.visitID)} />
                        <label for={row.visitID}>
                            <span></span>
                        </label>
                    </div>),
                visitID: row.visitID,
                dos: row.dos,
                accountNum: row.accountNum,
                patient: row.patient,
                Practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPracticePopup(row.practiceID)} > {row.practice}</MDBBtn>,
                location: <MDBBtn className='gridBlueBtn' onClick={() => this.openLocationPopup(row.locationID)} > {row.location}</MDBBtn>,
                provider: <MDBBtn className='gridBlueBtn' onClick={() => this.openProviderPopup(row.providerID)} > {row.provider}</MDBBtn>,
                totalAmount: row.totalAmount,
                validationMessage: row.validationMessage
            });
        });

        this.setState({ data: newList, submitModel: { ...this.state.submitModel, visits: this.selectedVisits } });
    }


    toggleCheck = e => {

        let checkedArr = this.selectedVisits;
        let newList = []

        checkedArr.filter(name => name === Number(e.target.id))[0]
            ? checkedArr = checkedArr.filter(name => name !== Number(e.target.id))
            : checkedArr.push(Number(e.target.id));

        this.selectedVisits = checkedArr

        this.state.initialData.map((row, i) => {
            newList.push({
                id: row.id,
                // ischeck: <MDBInput type="checkbox" id={row.visitID} containerClass='mr-5' onChange={this.toggleCheck}
                //     checked={this.isChecked(row.visitID)} />,
                ischeck: (
                    <div class="lblChkBox">
                        <input type="checkbox" id={row.visitID} name={row.visitID} onChange={this.toggleCheck}
                            checked={this.isChecked(row.visitID)} />
                        <label for={row.visitID}>
                            <span></span>
                        </label>
                    </div>),
                visitID: row.visitID,
                dos: row.dos,
                accountNum: row.accountNum,
                patient: row.patient,
                Practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPracticePopup(row.practiceID)} > {row.practice}</MDBBtn>,
                location: <MDBBtn className='gridBlueBtn' onClick={() => this.openLocationPopup(row.locationID)} > {row.location}</MDBBtn>,
                provider: <MDBBtn className='gridBlueBtn' onClick={() => this.openProviderPopup(row.providerID)} > {row.provider}</MDBBtn>,
                totalAmount: row.totalAmount,
                validationMessage: row.validationMessage
            });
        });

        //this.setState({ data: newList });
        this.setState({ data: newList, submitModel: { ...this.state.submitModel, visits: this.selectedVisits } });
    };


    opensubmitPlanPopup = (id) => {
        this.setState({ showPopup: true, id: id });
    }
    closesubmitPlanPopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
        $("#searchID").click();
    }

    submitCheckedVisits = (e) => {
        if (this.selectedVisits === null || this.selectedVisits.length === 0) {
            Swal.fire(
                {
                    type: 'info',
                    text: 'Please Select the Visit(s)',
                })
            return
        }
        else {
            console.log(this.state.submitModel)
            this.setState({ loading: true })

            axios.post(this.url + 'SubmitVisits', this.state.submitModel ,  this.config)
                .then(response => {
                    console.log(response.data);

                    if (isNullOrUndefined(response.data.errorMessage) === false) {
                        Swal.fire(
                            {
                                type: 'error',
                                text: response.data.errorMessage,
                            })
                    } else if (response.data.isisFileSubmitted === true) {

                        Swal.fire(
                            {
                                type: 'success',
                                text: 'File Submitted Successfully',
                            })
                    } else {
                        this.setState({
                            output: response.data,
                            showPopup: true,
                            loading:false
                        });
                    }

                }).catch(error => {
                    this.setState({ loading: false })
                    let errorList = []
                    if (error.response !== null && error !== null) {
                        errorList = error.response;
                        console.log(errorList);
                        Swal.fire({
                            type: 'error',
                            text: 'error meeas',
                        })
                    }
                    else console.log(error);
                });

           
        }
    }

    componentWillMount() {
        axios.get(this.url + 'GetProfiles' ,  this.configs)
            .then(response => {
                console.log(response.data);
                this.setState({
                    revData: response.data.receivers,
                })
            }).catch(error => {
                console.log(error);
            });
    }

    handleChange = event => {
        event.preventDefault();
        this.setState({
            electModel: { ...this.state.electModel, [event.target.name]: event.target.value.toUpperCase() },
            submitModel: { ...this.state.submitModel, [event.target.name]: event.target.value.toUpperCase() }
        });
    };
    clearFields = event => {
        this.setState({
            electModel: this.electModel
        });
    };

    render() {

        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 0,
                },
                {
                    //label: <MDBInput type="checkbox" onChange={this.selectALL} />,
                    label: (
                        <div class="lblChkBox">
                            <input type="checkbox" id='selectAll' name='selectAll' onChange={this.selectALL} />
                            <label for='selectAll'>
                                <span></span>
                            </label>
                        </div>),
                    field: 'ischeck',
                    sort: '',
                    width: 50
                },

                {
                    label: 'VISIT #',
                    field: 'visitID',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'DOS',
                    field: 'dos',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'ACCOUNT #',
                    field: 'accountNum ',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'PATIENT',
                    field: 'patient',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'PRACTICE',
                    field: 'practice',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'LOCATION',
                    field: 'location',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'PROVIDER',
                    field: 'provider',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'AMOUNT',
                    field: 'totalAmount',
                    sort: 'asc',
                    width: 80
                },
                {
                    label: 'VALIDATION MESSAGE',
                    field: 'validationMessage',
                    sort: 'asc',
                    width: 400
                }
            ],
            rows: this.state.data
        };


        let popup = ''

        if (this.state.showPopup) {
            popup = <ElectronicSubmissionModel onClose={() => this.closesubmitPlanPopup} id={this.state.id} data={this.state.output}></ElectronicSubmissionModel>
        } else if (this.state.showPracticePopup) {
            popup = <NewPractice onClose={() => this.closePracticePopup} id={this.state.id}></NewPractice>
        } else if (this.state.showLocationPopup) {
            popup = <NewLocation onClose={() => this.closeLocationPopup} id={this.state.id}></NewLocation>
        } else if (this.state.showProviderPopup) {
            popup = <NewProvider onClose={() => this.closeProviderPopup} id={this.state.id}></NewProvider>
        } else if (this.state.patientPopup) {
            popup = <GPopup onClose={() => this.closePatientPopup} id={this.state.id} popupName={this.state.popupName}></GPopup>
        }else if (this.state.patientPopup) {
            popup = <GPopup onClose={() => this.closePatientPopup} id={this.state.id} popupName={this.state.popupName}></GPopup>
        }else if (this.state.visitPopup) {
            popup = <GPopup onClose={() => this.closeVisitPopUp} id={this.state.id} popupName={this.state.popupName}></GPopup>
        }else
            popup = <React.Fragment></React.Fragment>


        let spiner = ''
        if (this.state.loading == true) {


            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }



        return (
            < React.Fragment >

                {spiner}
                <div className="mainHeading row">
                    <div className="col-md-6">
                        <h1>ELECTRONIC SUBMISSION SEARCH</h1>
                    </div>
                    <div className="col-md-6 headingRight">

                    </div>
                </div>


                <form onSubmit={event => this.searchElectronicSub(event)}>
                    <div className="mainTable">

                        <div className="row-form">
                            <div class="mf-6">
                                <label>Receiver </label>

                                <div className="selectBoxValidate">
                                    <select name="receiverID" id="receiverID"
                                        value={this.state.electModel.receiverID} onChange={this.handleChange}>
                                        {this.state.revData.map(s => (
                                            <option key={s.id} value={s.id}>
                                                {s.description}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            </div>


                            <div className="mf-6">
                                <label>&nbsp;</label>
                            </div>

                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Account NO'></Label>
                                <Input type='text' name='accountNum' id='accountNum' value={this.state.electModel.accountNum} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Visit ID'></Label>
                                <Input type='text' name='visitID' id='visitID'
                                    value={this.state.electModel.visitID} onChange={() => this.handleChange} />
                            </div>
                        </div>
                        <div className="row-form">

                            <div className="mf-6">
                                <Label name='Practice'></Label>
                                <Input type='text' name='practice' id='practice' value={this.state.electModel.practice} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Provider'></Label>
                                <Input type='text' name='provider' id='provider'
                                    value={this.state.electModel.provider} onChange={() => this.handleChange} />
                            </div>


                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Plan Name'></Label>
                                <Input type='text' name='planName' id='planName' value={this.state.electModel.planName} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Payer ID'></Label>
                                <Input type='text' name='payerID' id='payerID' max='9'
                                    value={this.state.electModel.payerID} onChange={() => this.handleChange} />
                            </div>
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">

                                <Input type='button' name='name' id='name' className='btn-blue' value='Submit' onClick={() => this.submitCheckedVisits()} />
                                <Input type='submit' name='name' id='searchID' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>

                </form>


                <div className="mf-12 table-grid mt-15">

                    <GridHeading Heading='ELECTRONIC SUBMITION SEARCH RESULT'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            responsive={true}
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

                {popup}
            </React.Fragment >
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(ElectronicSubmission);
