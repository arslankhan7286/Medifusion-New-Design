import React, { Component } from 'react'

import facilityIcon from '../images/facility-icon.png'
import facilityHIcon from '../images/facility-icon-hover.png'
import locationIcon from '../images/location-icon.png'
import locationHIcon from '../images/location-icon-hover.png'
import provIcon from '../images/provider-icon.png'
import provHIcon from '../images/provider-icon-hover.png'
import refprovIcon from '../images/referring-icon.png'
import refprovHIcon from '../images/referring-icon-hover.png'


import LeftMenuItem from './LeftMenuItem'


import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction'



class Setup extends Component {

    constructor(props) {
        super(props)

        // let setupLeftMenu = [
        //     {
        //         Category: 'ADMIN', Icon: '', hIcon: '', expanded: true,
        //         SubCategories: [{
        //             SubCategory: 'Facility', Icon: facilityIcon, hIcon: facilityHIcon, handler: () => this.props.selectTabPageAction('FACILITY'), selected: false
        //         }, {
        //             SubCategory: 'Location', Icon: locationIcon, hIcon: locationHIcon, handler: () => this.props.selectTabPageAction('LOCATION'), selected: false
        //         }, {
        //             SubCategory: 'Provider', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('PROVIDER'), selected: false
        //         }, {
        //             SubCategory: 'Referring Provider', Icon: refprovIcon, hIcon: refprovHIcon, handler: () => this.props.selectTabPageAction('REF_PROVIDER'), selected: false
        //         }
        //             // , {
        //             //     SubCategory: 'Employer', Icon: locationIcon, hIcon: locationIcon, handler: () => this.props.selectTabPageAction('EMPLOYER'), selected: false
        //             // }
        //         ]
        //     }
        //     , {
        //         Category: 'INSURANCE', Icon: '', handler: '', expanded: false,
        //         SubCategories: [{
        //             SubCategory: 'Insurance', Icon: facilityIcon, hIcon: facilityHIcon, handler: () => this.props.selectTabPageAction('INSURANCE'), selected: false
        //         }, {
        //             SubCategory: 'Insurance Plan', Icon: locationIcon, hIcon: locationHIcon, handler: () => this.props.selectTabPageAction('INSURANCE_PLAN'), selected: false
        //         }, {
        //             SubCategory: 'Insurance Plan Address', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('INS_PLAN_ADDRESS'), selected: false
        //         }, {
        //             SubCategory: 'EDI Submit Payer', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('EDI_SUBMIT_PAYER'), selected: false
        //         }, {
        //             SubCategory: 'EDI Eligibility Payer', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('EDI_ELIG_PAYER'), selected: false
        //         }, {
        //             SubCategory: 'EDI Status Payer', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('EDI_CS_PAYER'), selected: false
        //         }]
        //     }, {
        //         Category: 'CODING', Icon: '', handler: '', expanded: false,
        //         SubCategories: [{
        //             SubCategory: 'ICD', Icon: facilityIcon, hIcon: facilityHIcon, handler: () => this.props.selectTabPageAction('ICD'), selected: false
        //         }, {
        //             SubCategory: 'CPT', Icon: locationIcon, hIcon: locationHIcon, handler: () => this.props.selectTabPageAction('CPT'), selected: false
        //         }, {
        //             SubCategory: 'Modifiers', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('MODIFIER'), selected: false
        //         }, {
        //             SubCategory: 'POS', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('POS'), selected: false
        //         }]
        //     }, {
        //         Category: 'EDI CODES', Icon: '', handler: '', expanded: false,
        //         SubCategories: [{
        //             SubCategory: 'Claim Status Category Codes', Icon: facilityIcon, hIcon: facilityHIcon, handler: () => this.props.selectTabPageAction('CS_CAT_CODES'), selected: false
        //         }, {
        //             SubCategory: 'Claim Status Codes', Icon: locationIcon, hIcon: locationHIcon, handler: () => this.props.selectTabPageAction('CS_CODES'), selected: false
        //         }, {
        //             SubCategory: 'Remit Codes', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('REMIT_CODES'), selected: false
        //         }, {
        //             SubCategory: 'Remark Codes', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('REMARK_CODES'), selected: false
        //         }]
        //     }
        // ]

        this.state = {
            //leftNavigationMenus: setupLeftMenu
            leftNavigationMenus: props.leftMenusFromSetup !== props.leftNavigationMenus && !props.leftMenusFromSetup ? props.leftMenusFromSetup : props.leftNavigationMenus
            //leftNavigationMenus: this.props.leftMenusFromSetup
        }


    }

    render() {

        // console.log("===========================")
        // console.log(this.props.leftMenusFromSetup)
        console.log(this.props.leftNavigationMenus)


        //console.log(this.state.setupLeftMenu)



        let leftMenuElements = []
        this.state.leftNavigationMenus.map((catogry, i) => {
            leftMenuElements.push(
                <LeftMenuItem data={catogry}></LeftMenuItem >
            )
        })

        // this.props.leftNavigationMenus.map((catogry, i) => {
        //     leftMenuElements.push(
        //         <LeftMenuItem data={catogry}></LeftMenuItem >
        //     )
        // })

        return (
            leftMenuElements
        )
    }
}



function mapStateToProps(state) {
    console.log(state.leftNavigationMenus)
    return {
        leftNavigationMenus: state.leftNavigationMenus
    };
}

function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(Setup);