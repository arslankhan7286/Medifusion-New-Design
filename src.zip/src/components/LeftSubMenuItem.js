import React, { Component } from 'react'

export class LeftSubMenuItem extends Component {

    constructor(props) {
        super(props)

        this.state = {
            image: this.props.data.selected ? this.props.data.hIcon : this.props.data.Icon,
            expanded: this.props.expanded,
            selected: this.props.data.selected
        }
    }

    mouseEnter = () => {
        if (this.state.selected === false) {
            this.setState({ image: this.props.data.hIcon });
        }
    }

    mouseLeave = () => {
        if (this.state.selected === false) {
            this.setState({ image: this.props.data.Icon });
        }
    }

    render() {
        //console.log(this.state.expanded)
        //alert(this.state.expanded)

        //console.log(this.props.data.SubCategory + " , " + this.state.selected)

        return (
            // <div id={this.props.data.SubCategory} className={(this.state.expanded) ? 'collapse show sidebar-submenu' : 'sidebar-submenu collapse'}>
            <a href="#" className={this.state.selected ? 'list-group-item list-group-item-action bg-dark text-white nav-facility active'
                : 'list-group-item list-group-item-action bg-dark text-white nav-facility'}
                style={{ backgroundImage: `url(${this.state.image})` }}
                onMouseEnter={this.mouseEnter} onMouseLeave={this.mouseLeave}
                // onClick={() => this.props.data.handler()}
                onClick={() => this.props.handler()}
            >
                {this.props.data.SubCategory}
            </a>
            // </div>
        )
    }
}

export default LeftSubMenuItem
