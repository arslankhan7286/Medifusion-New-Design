import React, { Component } from "react";

import Input from "./Input";
import Label from "./Label";
import axios from "axios";
import Swal from "sweetalert2";
import $ from "jquery";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import calenderPic from "../images/dob-icon.png";
import patientPic from "../images/profile-pic.png";


import { isNull, isNullOrUndefined } from "util";
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';


import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";
import NewRefferingProvider from "./NewRefferingProvider";


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import { loginAction } from '../actions/LoginAction';
import { selectTabAction } from '../actions/selectTabAction'


class NewPatient extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/patient/";
    this.errorField = 'errorField'
    let patientPopupId = 0;
    patientPopupId = this.props.popupPatientId;
    //Authorization Token
    this.config = {
      headers: { Authorization: "Bearer  " + this.props.loginObject.token, Accept: "*/*" }
    };





    //Patient Model
    this.patientModel = {
      accountNum: "",
      medicalRecordNumber: "",
      title: "",
      lastName: "",
      middleInitial: "",
      firstName: "",
      ssn: "",
      dob: "",
      gender: "",
      maritalStatus: "",
      race: "",
      ethinicity: "",
      address1: "",
      address2: "",
      city: "",
      state: "",
      zipCode: "",
      phoneNumber: "",
      mobileNumber: "",
      email: "",
      practiceID: null,
      locationId: null,
      providerID: null,
      refProviderID: null,
      notes: "",
      isDeleted: false,
      isActive: true
    };


    this.validationModel = {
      accountNumValField: '',
      medicalRecordNoValField: '',
      titleValField: '',
      lastNameValField: '',
      middleInitialValField: '',
      firstNameValField: '',
      ssnValField: '',
      dobValField: '',
      genderValField: '',
      maritalStatusValField: '',
      raceValField: '',
      ethinicityValField: '',
      address1ValField: '',
      address2ValField: '',
      cityValField: '',
      stateValField: '',
      zipCodeValField: '',
      phoneNumberValField: '',
      mobileNumberValField: '',
      emailValField: '',
      practiceIDValField: '',
      locationIdValField: '',
      providerIDValField: '',
      refProviderIDValField: '',
      notesValField: '',
      isDeletedValField: false,
      isActiveValField: true
    };




    this.state = {
      editId: patientPopupId > 0 ? this.props.popupPatientId : this.props.id,
      patientPopupId: 0,
      patientModel: this.patientModel,
      validationModel: this.validationModel,
      practice: [],
      location: [],
      provider: [],
      refProvider: [],
      file: "",
      imagePreviewUrl: patientPic,
      popupName: '',
      id: 0,
      loading: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleNumericCheck = this.handleNumericCheck.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
    this.savePatient = this.savePatient.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);

    this.openPopup = this.openPopup.bind(this);
    this.closePopup = this.closePopup.bind(this);

  }



  openPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  }

  closePopup = () => {
    $('#myModal').hide()
    this.setState({ popupName: '' });
  }


  componentWillMount() {

    this.setState({ patientPopupId: this.props.popupPatientId })
    axios.get(this.url + "GetProfiles/" + this.state.editId, this.config).then(response => {
      console.log("Get Profiles : ", response.data)
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          accountNum: response.data.accountNumber
        },
        practice: response.data.practice,
        location: response.data.location,
        provider: response.data.provider,
        refProvider: response.data.refProvider
      });



    });


  }

  isNull(value) {
    if (value === '' || value === null || value === undefined || value === 'Please Select')
      return true;
    else return false;
  }

  replace(field, replaceWhat, replaceWith) {
    console.log('date in replace: ' + field)
    if (this.isNull(field))
      return field;
    else return field.replace(replaceWhat, replaceWith);
  }

  componentDidMount() {
    axios
      .get(this.url + "findPatient/" + this.state.editId, this.config)
      .then(response => {
        console.log("Response Data : ", response.data);
        this.setState({
          patientModel: response.data
        });
      })
      .catch(error => {
        console.log(error);
      });
  }
  handleChange = event => {

    console.log(event.target.value);
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };


  savePatient(e) {
    e.preventDefault();
    this.setState({ loading: true });

    // TODO: do something with -> this.state.file
    console.log("handle uploading-", this.state.file);
    console.log(this.state.patientModel)

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.patientModel.accountNum)) {
      myVal.accountNumValField = <span className="validationMsg">Enter Account#</span>
      myVal.validation = true
    } else {
      myVal.accountNumValField = ''
      if (myVal.validation === false) myVal.validation = false
    }


    if (this.isNull(this.state.patientModel.lastName)) {
      myVal.lastNameValField = <span className="validationMsg">Enter Last Name</span>
      myVal.validation = true
    } else {
      myVal.lastNameValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    if (this.isNull(this.state.patientModel.firstName)) {
      myVal.firstNameValField = <span className="validationMsg">Enter First Name</span>
      myVal.validation = true
    } else {
      myVal.firstNameValField = ''
      if (myVal.validation === false) myVal.validation = false
    }


    if (this.isNull(this.state.patientModel.zipCode) === false && this.state.patientModel.zipCode.length > 0) {
      if (this.state.patientModel.zipCode.length < 5) {
        myVal.zipCodeValField = <span className="validationMsg">Zip should be of alleast 5 digits</span>
        myVal.validation = true
      } else if (this.state.patientModel.zipCode.length > 5 && this.state.patientModel.zipCode.length < 9) {
        myVal.zipCodeValField = <span className="validationMsg">Zip should be of either 5 or 9 digits</span>
        myVal.validation = true
      } else {
        myVal.zipCodeValField = ''
        if (myVal.validation === false) myVal.validation = false
      }
    } else {
      myVal.zipCodeValField = ''
      if (myVal.validation === false) myVal.validation = false
    }



    if (this.isNull(this.state.patientModel.phoneNumber) === false && this.state.patientModel.phoneNumber.length < 10) {
      myVal.phoneNumberValField = <span className="validationMsg">Phone # length should be 10</span>
      myVal.validation = true
    } else {
      myVal.phoneNumberValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    if (this.isNull(this.state.patientModel.mobileNumber) === false && this.state.patientModel.mobileNumber.length < 10) {
      myVal.mobileNumberValField = <span className="validationMsg">Phone # length should be 10</span>
      myVal.validation = true
    } else {
      myVal.mobileNumberValField = ''
      if (myVal.validation === false) myVal.validation = false
    }














    if (this.isNull(this.state.patientModel.ssn) === false && this.state.patientModel.ssn.length < 9) {
      myVal.ssnValField = <span className="validationMsg">ssn # length should be 9</span>
      myVal.validation = true
    } else {
      myVal.ssnValField = ''
      if (myVal.validation === false) myVal.validation = false
    }















    if (this.isNull(this.state.patientModel.practiceID)) {
      myVal.practiceIDValField = <span className="validationMsg">Select Practice</span>
      myVal.validation = true
    } else {
      myVal.practiceIDValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    if (this.isNull(this.state.patientModel.locationId)) {
      myVal.locationIdValField = <span className="validationMsg">Select Location</span>
      myVal.validation = true
    } else {
      myVal.locationIdValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    if (this.isNull(this.state.patientModel.providerID)) {
      myVal.providerIDValField = <span className="validationMsg">Select Provider</span>
      myVal.validation = true
    } else {
      myVal.providerIDValField = ''
      if (myVal.validation === false) myVal.validation = false
    }

    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      return;
    }

    e.preventDefault();
    axios
      .post(this.url + "savePatient", this.state.patientModel, this.config)
      .then(response => {
        this.setState({ patientModel: response.data, editId: response.data.id });
        this.setState({ loading: false });
        Swal.fire("Record Saved Successfully", "", "success");
        $("#btnCancel").click();
      })
      .catch(error => {
        this.setState({ loading: false });
        Swal.fire(
          "Something Wrong",
          "Please Enter All Fields Correctly",
          "error"
        );
        let errorsList = [];
        if (error.response !== null && error.response !== null) {
          errorsList = error.response;
          console.log(errorsList);
        } else console.log(error);
        return;
      });
  }

  cancelBtn = e => {
    this.props.selectTabAction("Patient");

  };
  handleCheck() {
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        isActive: !this.state.patientModel.isActive
      }
    });
  }
  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  handleDateChange = date => {
    console.log("Date", date.target.value);

    this.setState({
      patientModel: {
        ...this.state.patientModel,
        dob: date.target.value
      }
    });
  };

  deletePatient = e => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        axios
          .delete(this.url + "DeletePatient/" + this.state.editId, this.config)
          .then(response => {
            console.log("Delete Response :", response);
            Swal.fire("Record Deleted Successfully", "", "success");
            $("#btnCancel").click();
            this.props.selectTabAction("Patient");
          })
          .catch(error => {
            console.log(error)

            Swal.fire("Record Not Deleted!", "Record can not be deleted, as it is being referenced in other screens.", "error");

            let errorsList = [];
            if (isNullOrUndefined(error.response) === false && error.response.data !== null) {
              errorsList = error.response.data;
              console.log(errorsList);
            } else console.log(error);
          });




      }
    });
  };

  _handleSubmit(e) {
    e.preventDefault();
    // TODO: do something with -> this.state.file
    console.log("handle uploading-", this.state.file);
  }

  _handleImageChange(e) {
    e.preventDefault();

    let reader = new FileReader();
    let file = e.target.files[0];

    reader.onloadend = () => {
      console.log('file:', file)
      this.setState({
        file: file,
        imagePreviewUrl: reader.result
      });
    };

    reader.readAsDataURL(file);
  }

  render() {
    let { imagePreviewUrl } = this.state;
    let $imagePreview = null;
    if (imagePreviewUrl) {
      $imagePreview = <img src={imagePreviewUrl} />;
    } else {
      $imagePreview = <div></div>;
    }

    let active = this.state.patientModel.isActive;

    const usStates = [
      { value: "", display: "Select State" },
      { value: "AL", display: "AL - Alabama" },
      { value: "AK", display: "AK - Alaska" },
      { value: "AZ", display: "AZ - Arizona" },
      { value: "AR", display: "AR - Arkansas" },
      { value: "CA", display: "CA - California" },
      { value: "CO", display: "CO - Colorado" },
      { value: "CT", display: "CT - Connecticut" },
      { value: "DE", display: "DE - Delaware" },
      { value: "FL", display: "FL - Florida" },
      { value: "GA", display: "GA - Georgia" },
      { value: "HI", display: "HI - Hawaii" },
      { value: "ID", display: "ID - Idaho" },
      { value: "IL", display: "IL - Illinois" },
      { value: "IN", display: "IN - Indiana" },
      { value: "IA", display: "IA - Iowa" },
      { value: "KS", display: "KS - Kansas" },
      { value: "KY", display: "KY - Kentucky" },
      { value: "LA", display: "LA - Louisiana" },
      { value: "ME", display: "ME - Maine" },
      { value: "MD", display: "MD - Maryland" },
      { value: "MA", display: "MA - Massachusetts" },
      { value: "MI", display: "MI - Michigan" },
      { value: "MN", display: "MN - Minnesota" },
      { value: "MS", display: "MS - Mississippi" },
      { value: "MO", display: "MO - Missouri" },
      { value: "MT", display: "MT - Montana" },
      { value: "NE", display: "NE - Nebraska" },
      { value: "NV", display: "NV - Nevada" },
      { value: "NH", display: "NH - New Hampshire" },
      { value: "NJ", display: "NJ - New Jersey" },
      { value: "NM", display: "NM - New Mexico" },
      { value: "NY", display: "NY - New York" },
      { value: "NC", display: "NC - North Carolina" },
      { value: "ND", display: "ND - North Dakota" },
      { value: "OH", display: "OH - Ohio" },
      { value: "OK", display: "OK - Oklahoma" },
      { value: "OR", display: "OR - Oregon" },
      { value: "PA", display: "PA - Pennsylvania" },
      { value: "RI", display: "RI - Rhode Island" },
      { value: "SC", display: "SC - South Carolina" },
      { value: "SD", display: "SD - South Dakota" },
      { value: "TN", display: "TN - Tennessee" },
      { value: "TX", display: "TX - Texas" },
      { value: "UT", display: "UT - Utah" },
      { value: "VT", display: "VT - Vermont" },
      { value: "VA", display: "VA - Virginia" },
      { value: "WA", display: "WA - Washington" },
      { value: "WV", display: "WV - West Virginia" },
      { value: "WI", display: "WI - Wisconsin" },
      { value: "WY", display: "WY - Wyoming" }
    ];

    const titles = [
      { value: "", display: "Select Title" },
      { value: "MR.", display: "MR" },
      { value: "MRS.", display: "MRS." }
    ];

    const gender = [
      { value: "", display: "Select Gender" },
      { value: "M", display: "MALE" },
      { value: "F", display: "FEMALE" },
      { value: "U", display: "UNKNOWN" }
    ];

    const matitalStatus = [
      { value: "", display: "MARITAL STATUS" },
      { value: "SINGLE", display: "SINGLE" },
      { value: "MARRIED", display: "MARRIED" },
      { value: "DIVORCED", display: "DIVORCED" },
      { value: "WIDOW", display: "WIDOW" }
    ];

    let popup = "";
    if (this.state.popupName === 'practice') {
      popup = <NewPractice onClose={() => this.closePopup()} practiceID={this.state.id}></NewPractice>
    } else if (this.state.popupName === 'location') {
      popup = <NewLocation onClose={() => this.closePopup} id={this.state.id}></NewLocation>
    } else if (this.state.popupName === 'provider') {
      popup = <NewProvider onClose={() => this.closePopup} id={this.state.id}></NewProvider>
    } else if (this.state.popupName === 'refprovider') {
      popup = <NewRefferingProvider onClose={() => this.closePopup} id={this.state.id}></NewRefferingProvider>
    } else
      popup = <React.Fragment></React.Fragment>

    //Spinner
    let spiner = ''
    if (this.state.loading == true) {
      spiner = (
        <GifLoader
          loading={true}
          imageSrc={Eclips}
          // imageStyle={imageStyle}
          overlayBackground="rgba(0,0,0,0.5)"
        />
      )
    }
    return (
      <div>
        {spiner}
        <div className="col py-3">
          <div className="col-md-12">
            <div className="mainHeading row">
              <div className="col-md-6">
                <h1>{this.state.editId > 0 ? this.state.patientModel.lastName + " - " + this.state.patientModel.firstName + " - " + this.state.patientModel.accountNum : "NEW PATIENT"}</h1>
              </div>
              <div className="col-md-6 headingRight">
                <div className="lblChkBox">
                  <input
                    type="checkbox"
                    id="markInactive"
                    name="markInactive"
                    checked={active}
                    onChange={this.handleCheck}
                  />
                  <label htmlFor="markInactive">
                    <span>Active</span>
                  </label>
                </div>
                <Input
                  type="button"
                  value="Delete"
                  className="btn-blue"
                  onClick={this.deletePatient}
                >
                  Delete
                </Input>
              </div>
            </div>
            <div className="mf-12 headingtwo mt-25">
              <p>Demographics</p>
            </div>
            <div className="mainTable fullWidthTable wSpace">
              <div className="row-form">
                <div className="mf-2 profileSection">
                  {/* <div className="row-form">
                    <div className="mf-12">
                      {$imagePreview}
                      <input
                        id="file-input"
                        type="file"
                        onChange={e => this._handleImageChange(e)}
                      />
                    </div>
                  </div> */}
                  <div className="row-form uploadFile">
                    <div className="image-upload">
                      <label htmlFor="file-input">{$imagePreview}</label>
                      <input
                        id="file-input"
                        type="file"
                        onChange={e => this._handleImageChange(e)}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12">
                      <label>
                        {/* <h2>Jordan Jackson</h2> */}
                        <h2></h2>
                      </label>
                      <label>
                        {/* <p className="smallText">Age 27 Years</p> */}
                        <p className="smallText"></p>
                      </label>
                    </div>
                  </div>
                </div>
                <div className="mf-10">
                  <div className="row-form">
                    <div className="mf-6">
                      <label name="Account#" >Account#<span className="redlbl"> *</span></label>
                      <Input
                        className={this.state.validationModel.accountNumValField ? this.errorField : ""}
                        type="text"
                        name="accountNum"
                        id="accountNum"
                        max="20"
                        value={this.state.patientModel.accountNum}
                        onChange={() => this.handleChange}
                      /> {this.state.validationModel.accountNumValField}
                    </div>
                    <div className="mf-6">
                      <Label name="MRN"></Label>
                      <Input
                        type="text"
                        name="medicalRecordNumber"
                        id="medicalRecordNumber"
                        max="20"
                        value={this.state.patientModel.medicalRecordNumber}
                        onChange={() => this.handleChange}
                      ></Input>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Title</label>
                      <select
                        name="title"
                        id="title"
                        value={this.state.patientModel.title}
                        onChange={this.handleChange}>
                        {titles.map(s => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="mf-6">
                      <label name="Last Name">Last Name<span className="redlbl"> *</span></label>
                      <Input
                        className={this.state.validationModel.lastNameValField ? this.errorField : ""}
                        type="text"
                        name="lastName"
                        id="lastName"
                        max="25"
                        value={this.state.patientModel.lastName}
                        onChange={() => this.handleChange}
                      /> {this.state.validationModel.lastNameValField}
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <Label name="Middle Initial"></Label>
                      <Input
                        type="text"
                        name="middleInitial"
                        id="middleInitial"
                        max="3"
                        value={this.state.patientModel.middleInitial}
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label name="FirstName">First Name<span className="redlbl"> *</span></label>
                      <Input
                        className={this.state.validationModel.firstNameValField ? this.errorField : ""}
                        type="text"
                        name="firstName"
                        id="firstName"
                        max="25"
                        value={this.state.patientModel.firstName}
                        onChange={() => this.handleChange} />
                      {this.state.validationModel.firstNameValField}
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <Label name="SSN"></Label>
                      <div className="textBoxValidate">
                        <Input
                          type="text"
                          name="ssn"
                          id="ssn"
                          max="9"
                          value={this.state.patientModel.ssn}
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        ></Input>
                        {this.state.validationModel.ssnValField}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>DOB</label>
                      <div className="textBoxValidate">
                        <input
                          // style={{
                          //   marginLeft: "1px",
                          //   marginTop: "2px",
                          //   fontSize: "23px",
                          //   lineHeight: "23px",
                          //   width: "280px",
                          //   right: "3px"
                          // }}
                          // className="myInput"
                          type="date"
                          name="dob"
                          id="dob"
                          value={this.replace(this.state.patientModel.dob, "T00:00:00", "")}
                          onChange={this.handleDateChange}
                        ></input>
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Gender</label>
                      <select
                        name="gender"
                        id="gender"
                        value={this.state.patientModel.gender}
                        onChange={this.handleChange}
                      >
                        {gender.map(s => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="mf-6">
                      <label>Marital Status</label>
                      <select
                        name="maritalStatus"
                        id="maritalStatus"
                        value={this.state.patientModel.maritalStatus}
                        onChange={this.handleChange} >
                        {matitalStatus.map(s => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Race</label>
                      <select name="" id=""></select>
                    </div>
                    <div className="mf-6">
                      <label>Ethinicity</label>
                      <select name="" id=""></select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mf-12 headingtwo mt-25">
              <p>Address Information</p>
            </div>
            <div className="mainTable fullWidthTable wSpace">
              <div className="row-form">
                <div className="mf-6">
                  <Label name="Address1"></Label>
                  <Input
                    type="text"
                    name="address1"
                    id="address1"
                    max="55"
                    value={this.state.patientModel.address1}
                    onChange={() => this.handleChange}
                  ></Input>
                </div>
                <div className="mf-6">
                  <Label name="Address2"></Label>
                  <Input
                    type="text"
                    name="address2"
                    id="address2"
                    max="55"
                    value={this.state.patientModel.address2}
                    onChange={() => this.handleChange}
                  ></Input>
                </div>
              </div>
              <div className="row-form">
                <div className="mf-6">
                  <label>City - State</label>
                  <div className="textBoxTwoField">
                    <Input
                      type="text"
                      name="city"
                      id="city"
                      max="20"
                      value={this.state.patientModel.city}
                      onChange={() => this.handleChange}
                    ></Input>
                    <select
                      name="state"
                      id="state"
                      value={this.state.patientModel.state}
                      onChange={this.handleChange}
                    >
                      {usStates.map(s => (
                        <option key={s.value} value={s.value}>
                          {s.display}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="mf-6">
                  <label>Zip Code - Phone</label>

                  <div className="textBoxTwoField textBoxValidate">
                    <div className="twoColValidate">
                      <Input
                        className={this.state.validationModel.zipCodeValField ? this.errorField : ""}
                        type="text"
                        name="zipCode"
                        id="zipCode"
                        max="9"
                        value={this.state.patientModel.zipCode}
                        onChange={() => this.handleChange}
                        onKeyPress={event => this.handleNumericCheck(event)}
                      />
                      {this.state.validationModel.zipCodeValField}
                    </div>

                    <div className="twoColValidate">
                      <Input
                        className={this.state.validationModel.phoneNumberValField ? this.errorField : ""}
                        type="text"
                        name="phoneNumber"
                        id="phoneNumber"
                        max="10"
                        value={this.state.patientModel.phoneNumber}
                        onChange={() => this.handleChange}
                        onKeyPress={event => this.handleNumericCheck(event)} />
                      {this.state.validationModel.phoneNumberValField}
                    </div>

                  </div>


                  {/* <div className="textBoxTwoField">


                  </div> */}
                </div>
              </div>
              <div className="row-form">
                <div className="mf-6">
                  <Label name="Mobile#"></Label>
                  <Input
                    className={this.state.validationModel.mobileNumberValField ? this.errorField : ""}
                    type="text"
                    name="mobileNumber"
                    id="mobileNumber"
                    max="10"
                    value={this.state.patientModel.mobileNumber}
                    onChange={() => this.handleChange}
                    onKeyPress={event => this.handleNumericCheck(event)} />
                  {this.state.validationModel.mobileNumberValField}
                </div>
                <div className="mf-6">
                  <Label name="Email"></Label>
                  <Input
                    type="text"
                    name="email"
                    id="email"
                    max="30"
                    value={this.state.patientModel.email}
                    onChange={() => this.handleChange}
                  ></Input>
                </div>
              </div>
            </div>
            <div className="mf-12 headingtwo mt-25">
              <p>Legal Entities</p>
            </div>

            <div className="mainTable fullWidthTable wSpace">
              <div className="row-form">
                <div className="mf-6">

                  <label className={this.state.patientModel.practiceID ? 'txtUnderline' : ''}
                    onClick={this.state.patientModel.practiceID ? () => this.openPopup('practice', this.state.patientModel.practiceID) : undefined}>
                    Practice <span className="redlbl"> *</span ></label>


                  <select
                    className={this.state.validationModel.practiceIDValField ? this.errorField : ""}
                    name="practiceID"
                    id="practiceID"
                    value={this.state.patientModel.practiceID}
                    onChange={this.handleChange}>
                    {this.state.practice.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.description}
                      </option>
                    ))}
                  </select>
                  {this.state.validationModel.practiceIDValField}
                </div>
                <div className="mf-6">
                  <label
                    className={this.state.patientModel.locationId ? 'txtUnderline' : ''}
                    onClick={this.state.patientModel.locationId ? () => this.openPopup('location', this.state.patientModel.locationId) : undefined}>
                    Location  <span className="redlbl"> *</span></label>
                  <select
                    className={this.state.validationModel.locationIdValField ? this.errorField : ""}
                    name="locationId"
                    id="locationId"
                    value={this.state.patientModel.locationId}
                    onChange={this.handleChange}>
                    {this.state.location.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.description}
                      </option>
                    ))}
                  </select>
                  {this.state.validationModel.locationIdValField}
                </div>
              </div>
              <div className="row-form">
                <div className="mf-6">

                  <label
                    className={this.state.patientModel.providerID ? 'txtUnderline' : ''}
                    onClick={this.state.patientModel.providerID ? () => this.openPopup('provider', this.state.patientModel.providerID) : undefined}>
                    Provider  <span className="redlbl"> *</span></label>

                  <select
                    className={this.state.validationModel.providerIDValField ? this.errorField : ""}
                    name="providerID"
                    id="providerID"
                    value={this.state.patientModel.providerID}
                    onChange={this.handleChange}>
                    {this.state.provider.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.description}
                      </option>
                    ))}
                  </select>
                  {this.state.validationModel.providerIDValField}
                </div>
                <div className="mf-6">
                  <label
                    className={this.state.patientModel.refProviderID ? 'txtUnderline' : ''}
                    onClick={this.state.patientModel.refProviderID ? () => this.openPopup('refprovider', this.state.patientModel.refProviderID) : undefined}>
                    Ref Provider</label>

                  <select
                    name="refProviderID"
                    id="refProviderID"
                    value={this.state.patientModel.refProviderID}
                    onChange={this.handleChange}>
                    {this.state.refProvider.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.description}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="row-form">
                <div className="mf-12 field_full-8">
                  <label>Notes:</label>
                  <textarea
                    name="notes"
                    id="notes"
                    cols="30"
                    rows="10"
                    value={this.state.patientModel.notes}
                    onChange={this.handleChange}
                  ></textarea>
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <div className="mainTable">
                <div className="row-form row-btn">
                  <div className="mf-12">
                    <button className="btn-blue" onClick={this.savePatient}>
                      Save{" "}
                    </button>
                    <button
                      className="btn-grey"
                      data-dismiss="modal"
                      onClick={this.state.patientPopupId > 0 ? this.props.onClose() : this.cancelBtn}
                    >
                      Cancel{" "}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {popup}

      </div>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken ? state.loginToken : { toekn: "", isLogin: false },
    userInfo: state.loginInfo ? state.loginInfo : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction, loginAction: loginAction, selectTabAction: selectTabAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(NewPatient);