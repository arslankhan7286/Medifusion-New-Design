import React, { Component, Fragment } from 'react'
import $ from 'jquery';
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import taxonomyIcon from '../images/code-search-icon.png';
import axios from 'axios';
import Input from './Input';
import leftNavMenusReducer from '../reducers/leftNavMenusReducer';
import Swal from 'sweetalert2';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import { loginAction } from '../actions/LoginAction';
import { selectTabAction } from '../actions/selectTabAction'

export class NewPractice extends Component {

    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/Practice/';
        this.accountUrl = process.env.REACT_APP_URL + '/account/';
        this.errorField = 'errorField';

        //Authorization Token
        this.config = {
            headers: { Authorization: "Bearer  " + this.props.loginObject.token, Accept: "*/*" }
        };


        this.practiceModel = {
            'id': 0,
            'name': '',
            'organizationName': '',
            'taxID': '',
            'npi': '',
            'taxonomyCode': '',
            "cliaNumber": '',
            clientID: null,
            'address1': '',
            'address2': '',
            'city': '',
            'state': '',
            'zipCode': '',
            'officePhoneNum': '',
            'email': '',
            'website': '',
            'faxNumber': '',
            'payToAddress1': '',
            'payToAddress2': '',
            'payToCity': '',
            'payToState': '',
            'payToZipCode': '',
            'defaultLocationID': 0,
            'workingHours': '',
            'notes': '',
            'isActive': true,
            'isDeleted': false,
            'sameAsAddress': false
        }


        this.validationModel = {
            nameValField: '',
            organizationNameValField: '',
            npiValField: '',
            taxIDValField: '',
            taxonomyCodeValField: '',
            cliaNumberValField: '',
            address1ValField: '',
            address2ValField: '',
            cityValField: '',
            stateValField: '',
            zipCodeValField: '',
            officePhoneNumValField: '',
            emailValField: '',
            websiteValField: '',
            faxNumberValField: '',
            payToAddress1ValField: '',
            payToAddress2ValField: '',
            payToCityValField: '',
            payToStateValField: '',
            payToZipCodeValField: '',
            notesValField: '',
            clientValField: "",
            validation: false
        }

        this.state = {
            editId: this.props.practiceID,
            practiceModel: this.practiceModel,
            validationModel: this.validationModel,
            maxHeight: '361',
            loading: false,
            client: [],
        }

        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.savePractice = this.savePractice.bind(this);
        //this.handleSameAsAddress = this.handleSameAsAddress.bind(this);
        this.delete = this.delete.bind(this);
    }

    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find('.modal-content');
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
        var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight })
    }

    componentDidMount() {
        this.setModalMaxHeight($('.modal'));
        // if ($('.modal.in').length != 0) {
        //     this.setModalMaxHeight($('.modal.in'));
        // }
        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);

        axios.get(this.accountUrl + 'getProfiles', this.config)
            .then(response => {
                console.log("Get Profiles Response : ", response.data);
                this.setState({ client: response.data.clients });
            })
            .catch(error => {

                if (error.response) {
                    if (error.response.status) {
                        //Swal.fire("Unauthorized Access" , "" , "error");
                        console.log(error.response.status)
                        return
                    }
                } else if (error.request) {
                    console.log(error.request);
                    return
                } else {
                    console.log('Error', error.message);
                    console.log(JSON.stringify(error));
                    //Swal.fire("Something went Wrong" , "" , "error");
                    return
                }

                console.log(error)
            });




        if (this.state.editId > 0) {

            console.log("Toekn : ", this.props.loginObject.token)

            var config = {
                headers: { 'Authorization': "Bearer  " + this.props.loginObject.token }
            };

            axios({
                url: this.url + 'FindPractice/' + this.state.editId,
                method: "get",
                headers: {
                    Authorization: "Bearer  " + this.props.loginObject.token,
                    Accept: "*/*"
                }
            })
                .then(response => {
                    console.log(response.data);
                    this.setState({ practiceModel: response.data });
                }).catch(error => {
                    if (error.response) {
                        if (error.response.status) {
                            Swal.fire("Unauthorized Access", "", "error")
                        }
                    } else if (error.request) {
                        console.log(error.request);
                    } else {
                        console.log('Error', error.message);
                        Swal.fire("Something Wrong", "Please Try Again", "error")
                    }
                    console.log(JSON.stringify(error));
                });
        }


    }

    handleSameAsAddress = event => {
        //event.preventDefault();

        //alert('same address')
        // this.setState({
        //     practiceModel: {
        //         ...this.state.practiceModel,
        //         sameAsAddress: !this.state.practiceModel.sameAsAddress
        //     }
        // });

        // if (this.state.practiceModel.sameAsAddress) {
        //     this.setState({
        //         practiceModel: {
        //             ...this.state.practiceModel,
        //             payToAddress1: this.state.practiceModel.address1,
        //             paytoAddress2: this.state.practiceModel.address2,
        //             payToCity: this.state.practiceModel.city,
        //             paytoState: this.state.practiceModel.state,
        //             paytoZipCode: this.state.practiceModel.zipCode
        //         }
        //     });
        // } else {
        //     this.setState({
        //         practiceModel: {
        //             ...this.state.practiceModel,
        //             paytoAddress: '',
        //             payToCity: '',
        //             paytoState: '',
        //             paytoZipCode: '',
        //         }
        //     });
        // }



    };

    handleChange = event => {
        event.preventDefault();
        this.setState({
            practiceModel: {
                ...this.state.practiceModel,
                [event.target.name]: event.target.value.toUpperCase()
            }
        });
    };

    handleCheck() {
        this.setState({
            practiceModel: {
                ...this.state.practiceModel,
                isActive: !this.state.practiceModel.isActive
            }
        });
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }


    isNull(value) {
        if (value === '' || value === null || value === undefined)
            return true;
        else return false;
    }


    savePractice = (e) => {
        this.setState({ loading: true })

        console.log(this.state.practiceModel);

        var myVal = this.validationModel;
        myVal.validation = false;

        if (this.isNull(this.state.practiceModel.name)) {
            myVal.nameValField = <span className="validationMsg">Enter Name</span>
            myVal.validation = true
        } else {
            myVal.nameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.practiceModel.organizationName)) {
            myVal.organizationNameValField = <span className="validationMsg">Enter Organization Name</span>
            myVal.validation = true
        } else {
            myVal.organizationNameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.practiceModel.npi)) {
            myVal.npiValField = <span className="validationMsg">Enter NPI</span>
            myVal.validation = true
        } else if (this.state.practiceModel.npi.length < 10) {
            myVal.npiValField = <span className="validationMsg">NPI length should be 10</span>
            myVal.validation = true
        } else {
            myVal.npiValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.practiceModel.taxID)) {
            myVal.taxIDValField = <span className="validationMsg">Enter Tax ID</span>
            myVal.validation = true
        } else if (this.state.practiceModel.taxID.length < 9) {
            myVal.taxIDValField = <span className="validationMsg">Tax ID length should be 9</span>
            myVal.validation = true
        } else {
            myVal.taxIDValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        if (this.isNull(this.state.practiceModel.taxonomyCode) === false && this.state.practiceModel.taxonomyCode.length < 10) {
            myVal.taxonomyCodeValField = <span className="validationMsg">Taxonomy Code length should be 9</span>
            myVal.validation = true
        } else if (this.isNull(this.state.practiceModel.clientID)) {
            myVal.clientValField = <span className="validationMsg">Select Client</span>
            myVal.validation = true
        } else {
            myVal.clientValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        console.log(this.state.practiceModel.cliaNumber.length)



        if ((this.state.practiceModel.cliaNumber.length > 10) && (this.state.practiceModel.cliaNumber.length < 10)) {
            myVal.cliaNumberValField = <span className="validationMsg">cliaNumber length should be 10</span>
            myVal.validation = true
        } else {
            myVal.cliaNumberValField = ''
            if (myVal.validation === false) myVal.validation = false
        }




        if (this.isNull(this.state.practiceModel.zipCode) === false && this.state.practiceModel.zipCode.length > 0) {
            if (this.state.practiceModel.zipCode.length < 5) {
                myVal.zipCodeValField = <span className="validationMsg">Zip should be of alleast 5 digits</span>
                myVal.validation = true
            } else if (this.state.practiceModel.zipCode.length > 5 && this.state.practiceModel.zipCode.length < 9) {
                myVal.zipCodeValField = <span className="validationMsg">Zip should be of either 5 or 9 digits</span>
                myVal.validation = true
            } else {
                myVal.zipCodeValField = ''
                if (myVal.validation === false) myVal.validation = false
            }
        } else {
            myVal.zipCodeValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        if (this.isNull(this.state.practiceModel.payToZipCode) === false && this.state.practiceModel.payToZipCode.length > 0) {
            if (this.state.practiceModel.payToZipCode.length < 5) {
                myVal.payToZipCodeValField = <span className="validationMsg">Zip should be of alleast 5 digits</span>
                myVal.validation = true
            } else if (this.state.practiceModel.payToZipCode.length > 5 && this.state.practiceModel.payToZipCode.length < 9) {
                myVal.payToZipCodeValField = <span className="validationMsg">Zip should be of either 5 or 9 digits</span>
                myVal.validation = true
            } else {
                myVal.payToZipCodeValField = ''
                if (myVal.validation === false) myVal.validation = false
            }
        } else {
            myVal.payToZipCodeValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.practiceModel.faxNumber) === false && this.state.practiceModel.faxNumber.length < 10) {
            myVal.faxNumberValField = <span className="validationMsg">Fax # length should be 10</span>
            myVal.validation = true
        } else {
            myVal.faxNumberValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.practiceModel.officePhoneNum) === false && this.state.practiceModel.officePhoneNum.length < 10) {
            myVal.officePhoneNumValField = <span className="validationMsg">Phone # length should be 10</span>
            myVal.validation = true
        } else {
            myVal.officePhoneNumValField = ''
            if (myVal.validation === false) myVal.validation = false
        }



        this.setState({
            validationModel: myVal
        });

        if (myVal.validation === true) {
            this.setState({ loading: false });
            return;
        }

        var config = {
            headers: { 'Authorization': "Bearer  " + this.props.loginObject.token }
        };

        axios.post(this.url + 'SavePractice', this.state.practiceModel, config)
            .then(response => {
                console.log(response.data);

                this.setState({ practiceModel: response.data, editId: response.data.id, loading: false });
                Swal.fire(
                    'Record Saved Successfully',
                    '',
                    'success'
                )
            }).catch(error => {
                console.log(error);
                this.setState({ loading: false })
                let errorsList = []
                if (error.response !== null && error.response.data !== null) {
                    errorsList = error.response.data
                    console.log(errorsList)

                } else {
                    console.log(error);
                    if (error.response) {
                        if (error.response.status) {
                            Swal.fire("Unauthorized Access", "", "error")
                        }
                    } else if (error.request) {
                        console.log(error.request);
                    } else {
                        console.log('Error', error.message);
                        Swal.fire("Something Wrong", "Please Select All Fields Properly", "error")
                    }
                    console.log(JSON.stringify(error));

                }
            });

        this.setState({ loading: false });
        e.preventDefault();
    }


    delete = e => {
        var config = {
            headers: { 'Authorization': "Bearer  " + this.props.loginObject.token }
        };

        Swal.fire({
            title: "Are you sure, you want to delete this record?",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then(result => {
            if (result.value) {
                this.setState({ loading: true })
                axios
                    .delete(this.url + "DeletePractice/" + this.state.editId, config)
                    .then(response => {
                        this.setState({ loading: false })
                        console.log("Delete Response :", response);
                        Swal.fire("Record Deleted Successfully", "", "success");
                    })
                    .catch(error => {
                        this.setState({ loading: false })
                        Swal.fire("Record Not Deleted!", "Record can not be delete, as it is being referenced in other screens.", "error");
                        if (error.response) {
                            if (error.response.status) {
                                Swal.fire("Unauthorized Access", "", "error")
                            }
                        } else if (error.request) {
                            console.log(error.request);
                        } else {
                            console.log('Error', error.message);
                        }
                        console.log(JSON.stringify(error));
                    });

                $("#btnCancel").click();
            }
        });
    };

    render() {

        const usStates = [
            { value: '', display: 'Select State' },
            { value: 'AL', display: 'AL - Alabama' },
            { value: 'AK', display: 'AK - Alaska' },
            { value: 'AZ', display: 'AZ - Arizona' },
            { value: 'AR', display: 'AR - Arkansas' },
            { value: 'CA', display: 'CA - California' },
            { value: 'CO', display: 'CO - Colorado' },
            { value: 'CT', display: 'CT - Connecticut' },
            { value: 'DE', display: 'DE - Delaware' },
            { value: 'FL', display: 'FL - Florida' },
            { value: 'GA', display: 'GA - Georgia' },
            { value: 'HI', display: 'HI - Hawaii' },
            { value: 'ID', display: 'ID - Idaho' },
            { value: 'IL', display: 'IL - Illinois' },
            { value: 'IN', display: 'IN - Indiana' },
            { value: 'IA', display: 'IA - Iowa' },
            { value: 'KS', display: 'KS - Kansas' },
            { value: 'KY', display: 'KY - Kentucky' },
            { value: 'LA', display: 'LA - Louisiana' },
            { value: 'ME', display: 'ME - Maine' },
            { value: 'MD', display: 'MD - Maryland' },
            { value: 'MA', display: 'MA - Massachusetts' },
            { value: 'MI', display: 'MI - Michigan' },
            { value: 'MN', display: 'MN - Minnesota' },
            { value: 'MS', display: 'MS - Mississippi' },
            { value: 'MO', display: 'MO - Missouri' },
            { value: 'MT', display: 'MT - Montana' },
            { value: 'NE', display: 'NE - Nebraska' },
            { value: 'NV', display: 'NV - Nevada' },
            { value: 'NH', display: 'NH - New Hampshire' },
            { value: 'NJ', display: 'NJ - New Jersey' },
            { value: 'NM', display: 'NM - New Mexico' },
            { value: 'NY', display: 'NY - New York' },
            { value: 'NC', display: 'NC - North Carolina' },
            { value: 'ND', display: 'ND - North Dakota' },
            { value: 'OH', display: 'OH - Ohio' },
            { value: 'OK', display: 'OK - Oklahoma' },
            { value: 'OR', display: 'OR - Oregon' },
            { value: 'PA', display: 'PA - Pennsylvania' },
            { value: 'RI', display: 'RI - Rhode Island' },
            { value: 'SC', display: 'SC - South Carolina' },
            { value: 'SD', display: 'SD - South Dakota' },
            { value: 'TN', display: 'TN - Tennessee' },
            { value: 'TX', display: 'TX - Texas' },
            { value: 'UT', display: 'UT - Utah' },
            { value: 'VT', display: 'VT - Vermont' },
            { value: 'VA', display: 'VA - Virginia' },
            { value: 'WA', display: 'WA - Washington' },
            { value: 'WV', display: 'WV - West Virginia' },
            { value: 'WI', display: 'WI - Wisconsin' },
            { value: 'WY', display: 'WY - Wyoming' }
        ]

        const isActive = this.state.practiceModel.isActive;

        let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }


        return (
            <React.Fragment>
                {spiner}
                <div id='myModal' className="modal fade bs-example-modal-new show" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div className="modal-dialog modal-lg">

                        <button
                            //  onClick={this.props.onClose()}
                            className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>

                        <div className="modal-content" style={{ overflow: 'hidden' }}>

                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">{this.state.editId > 0 ? this.state.practiceModel.name.toUpperCase() + " - " + this.state.practiceModel.id : "NEW PRACTICE"}</h1>
                                        </div>
                                        <div className="mf-6 popupHeadingRight">
                                            <div className="lblChkBox" onClick={this.handleCheck}>
                                                <input type="checkbox" checked={!isActive} id="isActive" name="isActive" />
                                                <label htmlFor="markInactive">
                                                    <span>Mark Inactive</span>
                                                </label>
                                            </div>
                                            <Input type='button' value='Delete' className="btn-blue" onClick={this.delete}>Delete</Input>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div className="mainTable">

                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Name
                                                <span className="redlbl"> *</span>
                                            </label>

                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.nameValField ? this.errorField : ""}
                                                    type="text" value={this.state.practiceModel.name} name='name' id='name'
                                                    max='15'
                                                    onChange={() => this.handleChange}
                                                />
                                                {this.state.validationModel.nameValField}
                                            </div>

                                        </div>


                                        <div className="mf-6">
                                            <label>Organization Name <span className="redlbl"> *</span></label>

                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.organizationNameValField ? this.errorField : ""}
                                                    type="text" value={this.state.practiceModel.organizationName} name="organizationName" id="organizationName"
                                                    max='30' onChange={() => this.handleChange} />
                                                {this.state.validationModel.organizationNameValField}
                                            </div>

                                        </div>
                                    </div>

                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>NPI <span className="redlbl"> *</span></label>
                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.npiValField ? this.errorField : ""}
                                                    type="text" value={this.state.practiceModel.npi} name="npi" id="npi" max='10' onChange={() => this.handleChange}
                                                    onKeyPress={event => this.handleNumericCheck(event)} />
                                                {this.state.validationModel.npiValField}
                                            </div>
                                        </div>

                                        <div className="mf-6">


                                            <label>Tax ID <span className="redlbl"> *</span></label>
                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.taxIDValField ? this.errorField : ""}
                                                    type="text" value={this.state.practiceModel.taxID} name="taxID" id="taxID" max='9' onChange={() => this.handleChange}
                                                    onKeyPress={event => this.handleNumericCheck(event)} />
                                                {this.state.validationModel.taxIDValField}
                                            </div>

                                        </div>
                                    </div>

                                    <div className="row-form">
                                        <div className="mf-6 mf-icon">
                                            <label>Taxonomy Code</label>

                                            <div className="textBoxValidate">
                                                <Input
                                                    className={this.state.validationModel.taxonomyCodeValField ? this.errorField : ""}
                                                    type="text" value={this.state.practiceModel.taxonomyCode} name="taxonomyCode" id="taxonomyCode" max='10'
                                                    onChange={() => this.handleChange} />
                                                <img src={taxonomyIcon} />
                                                {this.state.validationModel.taxonomyCodeValField}
                                            </div>
                                        </div>

                                        <div className="mf-6 mf-icon">
                                            <label>CLIA</label>

                                            <div className="textBoxValidate">
                                                <Input
                                                    className={this.state.validationModel.cliaNumberValField ? this.errorField : ""}
                                                    type="text" value={this.state.practiceModel.cliaNumber} name="cliaNumber" id="cliaNumber" max='10'
                                                    onChange={() => this.handleChange} />

                                                {this.state.validationModel.cliaNumberValField}
                                            </div>

                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label >Client
                                            <span className="redlbl"> *</span>
                                            </label>


                                            <select
                                                className={this.state.validationModel.clientValField ? this.errorField : ""}
                                                name="clientID"
                                                id="clientID"
                                                value={this.state.practiceModel.clientID}
                                                onChange={this.handleChange}
                                            >
                                                {this.state.client.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>
                                            <div className="textBoxValidate"> {this.state.validationModel.clientValField}</div>

                                        </div>
                                        <div className="mf-6"></div>
                                    </div>



                                    <div className="mf-12 headingOne mt-25">
                                        <p>Address Information</p>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Address 1</label>
                                            <Input type="text" value={this.state.practiceModel.address1} name="address1" id="address1" max='55' onChange={() => this.handleChange} />
                                        </div>
                                        <div className="mf-6">
                                            <label>Address 2</label>
                                            <Input type="text" value={this.state.practiceModel.address2} name="address2" id="address2" max='55' onChange={() => this.handleChange} />
                                        </div>
                                    </div>


                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>City - State</label>
                                            <div className="textBoxTwoField textBoxValidate">

                                                <div className="twoColValidate">
                                                    <Input className={this.state.validationModel.cityValField ? this.errorField : ""}
                                                        type="text" value={this.state.practiceModel.city} name="city" id="city" max='20' onChange={() => this.handleChange} />
                                                    {this.state.validationModel.cityValField}
                                                </div>

                                                <div className="twoColValidate">
                                                    <select className={this.state.validationModel.stateValField ? this.errorField : ""}
                                                        name='state' id='state' value={this.state.practiceModel.state} onChange={this.handleChange}>
                                                        {usStates.map((s) => <option key={s.value} value={s.value}>{s.display}</option>)}
                                                    </select>
                                                    {this.state.validationModel.stateValField}
                                                </div>
                                            </div>
                                        </div>


                                        <div className="mf-6">
                                            <label>Zip Code -  Fax</label>

                                            <div className="textBoxTwoField textBoxValidate">
                                                <div className="twoColValidate">
                                                    <Input className={this.state.validationModel.zipCodeValField ? this.errorField : ""}
                                                        type="text" value={this.state.practiceModel.zipCode} max='9' name="zipCode" id="zipCode"
                                                        onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)} />
                                                    {this.state.validationModel.zipCodeValField}
                                                </div>

                                                <div className="twoColValidate">
                                                    <Input className={this.state.validationModel.faxNumberValField ? this.errorField : ""}
                                                        type="text" value={this.state.practiceModel.faxNumber} max='10' name="faxNumber" id="faxNumber" onChange={() => this.handleChange}
                                                        onKeyPress={event => this.handleNumericCheck(event)} />
                                                    {this.state.validationModel.faxNumberValField}
                                                </div>

                                            </div>
                                        </div>


                                    </div>


                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label> Phone</label>
                                            <div className="twoColValidate">
                                                <Input className={this.state.validationModel.officePhoneNumValField ? this.errorField : ""}
                                                    type="text" value={this.state.practiceModel.officePhoneNum} max='10' name="officePhoneNum" id="officePhoneNum" onChange={() => this.handleChange}
                                                    onKeyPress={event => this.handleNumericCheck(event)} />
                                                {this.state.validationModel.officePhoneNumValField}
                                            </div>

                                        </div>
                                        <div className="mf-6">
                                            <label>Website</label>
                                            <div className="twoColValidate">
                                                <Input className={this.state.validationModel.websiteValField ? this.errorField : ""}
                                                    type="text" value={this.state.practiceModel.website} name="website" id="website" max='50' onChange={() => this.handleChange} />
                                                {this.state.validationModel.websiteValField}
                                            </div>

                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-12 field_full-8">
                                            <label> Email</label>
                                            <Input type="text" value={this.state.practiceModel.email} name="email" id="email" max='30' onChange={() => this.handleChange} />
                                        </div>
                                    </div>
                                    <div className="row-form headingOneChkBox mt-25">
                                        <div className="mf-6">
                                            <p>Pay to Address Information</p>
                                        </div>
                                        {/* AZIZ: 28/10/2019 - COMMETING 'SAME AS ADDRESS' FOR NOW - TECHNICALITY ISSUE */}
                                        <div className="mf-6 popupHeadingRight">
                                            {/* <div className="lblChkBox">
                                                <Input type="checkbox" id="sameAsAddress" name="sameAsAddress" onChange={() => this.handleSameAsAddress} />
                                                <label htmlFor="sameAsAddress">
                                                    <span> Same As Address </span>
                                                </label>
                                            </div> */}
                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Address 1</label>
                                            <Input type="text" value={this.state.practiceModel.payToAddress1} name="payToAddress1" id="payToAddress1" max='55' onChange={() => this.handleChange} />
                                        </div>
                                        <div className="mf-6">
                                            <label>Address 2</label>
                                            <Input type="text" value={this.state.practiceModel.payToAddress2} name="payToAddress2" id="payToAddress2" max='55' onChange={() => this.handleChange} />
                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>City - State</label>
                                            <div className="textBoxTwoField">
                                                <Input type="text" value={this.state.practiceModel.payToCity} name="payToCity" id="payToCity" max='20' onChange={() => this.handleChange} />

                                                <select name='payToState' id='payToState' value={this.state.practiceModel.payToState} onChange={this.handleChange}>
                                                    {usStates.map((s) => <option key={s.value} value={s.value}>{s.display}</option>)}
                                                </select>

                                            </div>
                                        </div>
                                        <div className="mf-6">
                                            {/* <label>Zip Code -  Fax</label> */}
                                            <label>Zip Code</label>
                                            <div className="textBoxTwoField">
                                                <Input type="text" className={this.state.validationModel.payToZipCodeValField ? this.errorField : ""}
                                                    value={this.state.practiceModel.payToZipCode} max='9' name="payToZipCode" id="payToZipCode" onChange={() => this.handleChange}
                                                    onKeyPress={event => this.handleNumericCheck(event)} />

                                                {this.state.validationModel.payToZipCodeValField}
                                            </div>
                                        </div>
                                    </div>



                                    <div className="row-form">
                                        <div className="mf-12 field_full-8">
                                            <label>Notes:</label>
                                            <textarea value={this.state.practiceModel.notes} name="notes" id="notes" cols="30" rows="10" onChange={this.handleChange} ></textarea>


                                        </div>

                                    </div>
                                </div>


                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <button className="btn-blue" onClick={this.savePractice}>Save </button>
                                                <button id='btnCancel' className="btn-grey" data-dismiss="modal"
                                                    onClick={this.props.onClose ? this.props.onClose() : () => this.props.onClose()}
                                                >Cancel </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </React.Fragment >
        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page", state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        // id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject: state.loginToken ? state.loginToken : { toekn: "", isLogin: false },
        userInfo: state.loginInfo ? state.loginInfo : { userPractices: [], name: "", practiceID: null }
    };
}
function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction, loginAction: loginAction, selectTabAction: selectTabAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(NewPractice);
