import React, { Component } from 'react'


import $ from "jquery";


import Input from "./Input";


import { saveAs } from 'file-saver';



import axios from 'axios';
import { MDBDataTable, MDBBtn } from 'mdbreact';
import GridHeading from './GridHeading';


import Swal from 'sweetalert2';



//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'

export class BatchDocumentPopup extends Component {
    constructor(props) {
        super(props)
        this.url = 'http://192.168.110.44/Database/api/BatchDocument/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        this.searchModel = {

            batchNum: '',
            description: '',
            billerID: '',


            category: '',
            practiceID: '',
            locationID: '',

            ProviderID: '',

            chargesNumberOfDOS: '',
            chargesNumberOfDOSEntered: '',
            chargesTotalCopay: '',


            chargesNumberOfVisits: '',
            chargesNumberOfVisitsEntered: '',
            chargesCopayApplied: '',
            chargesStartDate: null,
            chargesEndTime: null,
            chargeNotes: '',

            admitNumberOfPatients: '',
            admitNumberOfPatientsEntered: '',
            admitStartDate: null,
            admitEndDate: null,
            admitNotes: '',

            paymentCheckDate: null,
            paymentAssignedDate: null,
            paymentTotalAmount: '',

            paymentPlanAmount: '',
            paymentPlanAppliedAmount: '',

            paymentPatientAmount: '',
            paymentPatientAppliedAmount: '',

            paymentCopay: '',
            paymentCopayApplied: '',


            paymentStartDate: '',
            paymentEndDate: '',
            paymentNotes: '',

            status: '',

            addpayDate: '',
            addedBy: '',

            updatedBy: '',
            updatedDate: null,
            documentTypeID: null,

            documentInfo: this.documentInfo,

        }
        this.documentInfo = {
            content: '',
            name: '',
            size: '',
            type: '',
            clientID: 0
        }

        this.state = {
            searchModel: this.searchModel,
            maxHeight: '361',

            facData: [],
            cateData: [],
            billData: [],

            locData: [],
            proData: [],
            "isActive": true,
            editId: this.props.id

        }
        this.closeNewDocument = this.closeNewDocument.bind(this);
        this.importEra = this.importEra.bind(this);
        this.downloadDocument = this.downloadDocument.bind(this);
    }

    componentDidMount() {
        this.setModalMaxHeight($('.modal'));


        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);

        if (this.state.editId > 0) {
            axios.get(this.url + 'FindBatchDocument/' + this.state.editId , this.config)
                .then(response => {
                    console.log("find open data" + response);
                    this.setState({ searchModel: response.data });
                    console.log(this.state.searchModel);
                }).catch(error => {
                    console.log(error);
                });
        }

    }
    importEra(e) {
        alert('hey buddy')
        e.preventDefault();

        let reader = new FileReader();
        reader.readAsDataURL(e.target.files[0]);
        let file = e.target.files[0];

        reader.onloadend = (e) => {
            // var url = 'https://localhost:44306/api/payment/ImportEraFile/'

            let obj = this.documentInfo
            obj.content = reader.result;
            obj.name = file.name;
            obj.size = file.size;
            obj.type = file.type;
            obj.clientID = 1

            console.log('log', obj)

            this.setState({
                searchModel: {
                    ...this.state.searchModel,
                    documentInfo: obj

                }
            });


        }
    }
    componentWillMount() {
        http://192.168.110.44/Database/api/BatchDocument/GetProfiles
        axios.get(this.url + 'GetProfiles' , this.config)
            .then(response => {

                this.setState({
                    billData: response.data.biller,
                    cateData: response.data.category,
                    facData: response.data.practice,
                    locData: response.data.location,
                    proData: response.data.provider

                })

                console.log(response.data);
            }).catch(error => {
                console.log(error);
            });
    }



    handleChange = event => {


        event.preventDefault();


        this.setState({
            searchModel: {
                ...this.state.searchModel,
                [event.target.name]: event.target.value
            }
        });
    };


    closeNewDocument() {

        console.log('clicked')
        this.props.selectTabAction("Documents");
    }




    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find(".modal-content");
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
        var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight });
    }
    downloadDocument = (id) => {
        let contentType = ''
        let outputfile = ''

        this.fileURl = this.url + "DownloadBatchDocument/" + id

        //console.log(this.fileURl)
        alert(this.fileURl)


        axios.get(
            this.fileURl, {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"
                },
                responseType: 'blob',
            })
            .then(function (res) {
                var blob = new Blob([res.data], {
                    type: contentType,
                });

                saveAs(blob, outputfile);
            }).catch(error => {
                if (error.response.status === 404) {
                    console.log(error.response.status)
                    Swal.fire(
                        {
                            type: 'info',
                            text: 'File Not Found on server',
                        })
                }
            });;




    }

    saveBatchDocuments = (e) => {
        console.log(this.state.searchModel)
        axios.post(this.url + 'SaveBatchDocument', this.state.searchModel , this.config)
            .then(response => {
                this.setState({ searchModel: response.data });
                Swal.fire(
                    'Record Saved Successfully',
                    '',
                    'success'
                )

            }).catch(error => {
                let errorList = []
                if (error.response !== null && error.response !== null) {
                    errorList = error.response;
                    console.log(errorList);
                }
                else
                    console.log(errorList);
                console.log('Something went wrong. Plese check console.')
            });

        e.preventDefault();
    }

    render() {

        let buttonDownload = (
            <React.Fragment>
                {/* <label>Download Document</label> */}
                <button className="btn-blue" onClick={() => this.downloadDocument(this.state.searchModel.id)}>Download Document</button>
            </React.Fragment>
        )

        const data = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 150
                }
                ,
                {
                    label: "COD",
                    field: "cod",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "Patients",
                    field: "patients",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "Patients Entered",
                    field: "patEntered",
                    sort: "asc",
                    width: 150
                }, {
                    label: "Visits",
                    field: "visits",
                    sort: "asc",
                    width: 150
                }
                ,
                {
                    label: "Visits  Entered",
                    field: "visitsEntered",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "Co Payment",
                    field: "coPayement",
                    sort: "asc",
                    width: 150
                }
            ],
            rows: this.state.data
        };


        const isActive = this.state.searchModel.isActive;


        var payCheckDate = this.state.searchModel.paymentCheckDate ? this.state.searchModel.paymentCheckDate.replace("T00:00:00", "") : "";
        var payAssigDate = this.state.searchModel.paymentAssignedDate ? this.state.searchModel.paymentAssignedDate.replace("T00:00:00", "") : "";
        var addpayBatchDate = this.state.searchModel.addedDate ? this.state.searchModel.addedDate.replace("T00:00:00", "") : "";
        var updatedpayBatchDate = this.state.searchModel.updatedDate ? this.state.searchModel.updatedDate.replace("T00:00:00", "") : "";

        return (
            <React.Fragment>
                <div id='myModal' className="modal fade bs-example-modal-new show" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }}>

                    <div className="modal-dialog modal-lg">

                        <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>

                        <div className="modal-content" style={{ overflow: 'hidden' }}>

                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">

                                            <h1 className="modal-title">{this.state.editId > 0 ? this.state.searchModel.batchNum : "NEW--BATCH DOCUMENT"}</h1>

                                        </div>

                                    </div>
                                </div>
                            </div>


                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div className="mainTable">


                                    <div className="row-form">
                                        <div className="mf-4">
                                            <label>Batch Number<span className="redlbl"> *</span></label>
                                            <div >
                                                <Input
                                                    type="text"
                                                    value={this.state.searchModel.batchNum}
                                                    name="batchNum"
                                                    id="batchNum"
                                                    onChange={() => this.handleChange}
                                                />
                                            </div>
                                        </div>
                                        <div className="mf-4">
                                            <label>Description<span className="redlbl"> *</span></label>
                                            <div >
                                                <Input
                                                    type="text"
                                                    value={this.state.searchModel.description}
                                                    name="description"
                                                    id="description"
                                                    onChange={() => this.handleChange}
                                                />
                                            </div>
                                        </div>
                                        <div className="mf-4">


                                            <label>Biller</label>
                                            <select name="billerID" id="billerID"
                                                value={this.state.searchModel.billerID} onChange={this.handleChange}>
                                                {this.state.billData.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>




                                        </div>
                                    </div>

                                    <div className="row-form">
                                        <div class="mf-4">
                                            <label>Category</label>
                                            <select name="category" id="category"
                                                value={this.state.searchModel.category} onChange={this.handleChange}>
                                                {this.state.cateData.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>





                                        </div>
                                        <div class="mf-4">
                                            <label>Practice</label>
                                            <select name="practiceID" id="practiceID"
                                                value={this.state.searchModel.practiceID} onChange={this.handleChange}>
                                                {this.state.facData.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>





                                        </div>
                                        <div class="mf-4">
                                            <label>location</label>

                                            <select name="locationID" id="locationID"
                                                value={this.state.searchModel.locationID} onChange={this.handleChange}>
                                                {this.state.locData.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>



                                        </div>
                                    </div>


                                    <div class="row-form">
                                        <div class="mf-4">
                                            <label>ProviderID</label>



                                            <select name="ProviderID" id="ProviderID"
                                                value={this.state.searchModel.ProviderID} onChange={this.handleChange}>
                                                {this.state.proData.map(s => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.description}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                        <div class="mf-8">
                                            &nbsp;
                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            {/* <label>Choose File</label> */}
                                            <label for="btnImportEra" style={{ visibility: 'visible' }}></label>
                                            <input className="btn-blue-icon"
                                                id="btnImportEra"
                                                type="file"
                                                onChange={e => this.importEra(e)}
                                            />
                                        </div>


                                        <div className="mf-6">

                                            {this.state.editId > 0 ? buttonDownload : ''}

                                        </div>
                                    </div>


                                    <div class="mf-12 headingOne mt-25 headingtwo">
                                        <p>Charges Batch Detail</p>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-4">
                                            <label>DOS #</label>





                                            <Input type="text" value={this.state.searchModel.chargesNumberOfDOS} name="chargesNumberOfDOS" id="chargesNumberOfDOS" onChange={() => this.handleChange} ></Input>





                                        </div>
                                        <div class="mf-4">
                                            <label># DOS Entered</label>
                                            <Input type="text" disabled="disabled" value={this.state.searchModel.chargesNumberOfDOSEntered} name="chargesNumberOfDOSEntered" id="chargesNumberOfDOSEntered" onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-4">
                                            <label>Co Payment</label>
                                            <Input type="text" value={this.state.searchModel.chargesTotalCopay} name="chargesTotalCopay" id="chargesTotalCopay" onChange={() => this.handleChange}></Input>
                                        </div>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-4">
                                            <label>Visits #</label>
                                            <Input type="text" value={this.state.searchModel.chargesNumberOfVisits} name="chargesNumberOfVisits" id="chargesNumberOfVisits" onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-4">
                                            <label># Visits Entered </label>
                                            <Input type="text" disabled="disabled" value={this.state.searchModel.chargesNumberOfVisitsEntered} name="chargesNumberOfVisitsEntered" id="chargesNumberOfVisitsEntered" onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-4">
                                            <label>Patient Amount</label>
                                            <Input type="text" value={this.state.searchModel.chargesCopayApplied} name="chargesCopayApplied" id="chargesCopayApplied" onChange={() => this.handleChange}></Input>
                                        </div>
                                    </div>


                                    <div className="mf-12 table-grid mt-15">
                                        <GridHeading Heading='Batch Documents'></GridHeading>

                                        <div className="tableGridContainer">

                                            <MDBDataTable
                                                striped
                                                bordered
                                                searching={false}
                                                data={data}
                                                displayEntries={false}
                                                sortable={true}
                                                scrollX={false}
                                            />



                                        </div>

                                    </div>

                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Start Time</label>
                                            <div class="textBoxValidate">

                                                <input type="datetime-local" name="chargesStartDate"
                                                    id="chargesStartDate"
                                                    value={this.state.searchModel.chargesStartDate}
                                                    onChange={this.handleChange} class="form-control" />



                                            </div>
                                        </div>
                                        <div class="mf-6">
                                            <label>End Time </label>
                                            <div class="textBoxValidate">

                                                <input type="datetime-local" name="chargesEndTime"
                                                    id="chargesEndTime"
                                                    value={this.state.searchModel.chargesEndTime}
                                                    onChange={this.handleChange} class="form-control" />







                                            </div>
                                        </div>



                                    </div>

                                    <div class="row-form">



                                        <div class="mf-8 field_full-8">
                                            <label>Notes</label>
                                            <textarea name="chargeNotes" value={this.state.searchModel.chargeNotes} id="chargeNotes" cols="30" rows="10"></textarea>
                                        </div>
                                        <div class="mf-4">
                                            &nbsp;
                                        </div>


                                    </div>
                                    <div class="mf-12 headingOne mt-25 headingtwo">
                                        <p>Patient Admit Batch Detail</p>
                                    </div>


                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Patients</label>
                                            <Input type="text" value={this.state.searchModel.admitNumberOfPatients} name="admitNumberOfPatients" id="admitNumberOfPatients" onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-6">
                                            <label>Patients Entered</label>
                                            <Input type="text" disabled="disabled" value={this.state.searchModel.admitNumberOfPatientsEntered} name="admitNumberOfPatientsEntered" id="admitNumberOfPatientsEntered" onChange={() => this.handleChange} ></Input>
                                        </div>

                                    </div>

                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Start Time</label>
                                            <div class="textBoxValidate">

                                                <input type="datetime-local" name="admitStartDate"
                                                    id="admitStartDate"
                                                    value={this.state.searchModel.admitStartDate}
                                                    onChange={this.handleChange} class="form-control" />



                                            </div>
                                        </div>
                                        <div class="mf-6">
                                            <label>End Time </label>
                                            <div class="textBoxValidate">

                                                <input type="datetime-local" name="admitEndDate"
                                                    id="admitEndDate"
                                                    value={this.state.searchModel.admitEndDate}
                                                    onChange={this.handleChange} class="form-control" />







                                            </div>
                                        </div>
                                        <div class="mf-4">
                                            &nbsp;
                                        </div>


                                    </div>
                                    <div class="row-form">
                                        <div class="mf-8 field_full-8">
                                            <label>Notes</label>
                                            <textarea name="admitNotes" id="admitNotes" value={this.state.searchModel.admitNotes} cols="30" rows="10"></textarea>
                                        </div>
                                        <div class="mf-4">
                                            &nbsp;
                                </div>
                                    </div>

                                    <div class="mf-12 headingOne mt-25 headingtwo">
                                        <p>Payment Batch Detail</p>
                                    </div>

                                    <div class="row-form">
                                        <div class="mf-6">



                                            <label>Check Date</label>
                                            <div class="textBoxValidate">
                                                <input
                                                    style={{
                                                        width: "215px",
                                                        marginLeft: "0px"
                                                    }}
                                                    className="myInput"
                                                    type="date"
                                                    name="paymentCheckDate"
                                                    id="paymentCheckDate"
                                                    value={payCheckDate}
                                                    onChange={this.handleChange}
                                                ></input>
                                            </div>




                                        </div>
                                        <div class="mf-6">

                                            <label>Assigned Date</label>
                                            <div class="textBoxValidate">
                                                <input
                                                    style={{
                                                        width: "215px",
                                                        marginLeft: "0px"
                                                    }}
                                                    className="myInput"
                                                    type="date"
                                                    name="paymentAssignedDate"
                                                    id="paymentAssignedDate"
                                                    value={payAssigDate}
                                                    onChange={this.handleChange}
                                                ></input>
                                            </div>

                                        </div>
                                        {/* <div class="mf-4">
                                            &nbsp;
                                        </div> */}
                                    </div>

                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Total Amount</label>
                                            <Input type="text" value={this.state.searchModel.paymentTotalAmount} name="paymentTotalAmount" id="paymentTotalAmount" onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-6">
                                            &nbsp;
                                </div>
                                    </div>

                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Plan Amount</label>
                                            <Input type="text" value={this.state.searchModel.paymentPlanAmount} name="paymentPlanAmount" id="paymentPlanAmount" onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-6">
                                            <label>Plan Assigned Amount</label>
                                            <Input type="text" value={this.state.searchModel.paymentPlanAppliedAmount} name="paymentPlanAppliedAmount" id="paymentPlanAppliedAmount" onChange={() => this.handleChange}></Input>
                                        </div>
                                        {/* <div class="mf-4">
                                            &nbsp;
                                </div> */}
                                    </div>

                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Patient Amount</label>
                                            <Input type="text" value={this.state.searchModel.paymentPatientAmount} name="paymentPatientAmount" id="paymentPatientAmount" onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-6">
                                            <label>Patient Assigned Amount</label>
                                            <Input type="text" value={this.state.searchModel.paymentPatientAppliedAmount} name="paymentPatientAppliedAmount" id="paymentPatientAppliedAmount" onChange={() => this.handleChange}></Input>
                                        </div>
                                        {/* <div class="mf-4">
                                            &nbsp;
                                </div> */}
                                    </div>

                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Copay Amount </label>
                                            <Input type="text" value={this.state.searchModel.paymentCopay} name="paymentCopay" id="paymentCopay" onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div class="mf-6">
                                            <label>Copay Assigned Amount </label>
                                            <Input type="text" value={this.state.searchModel.paymentCopayApplied} name="paymentCopayApplied" id="paymentCopayApplied" onChange={() => this.handleChange}></Input>
                                        </div>
                                        {/* <div class="mf-4">
                                            &nbsp;
                                </div> */}
                                    </div>

                                    <div class="row-form">


                                        <div class="mf-6">
                                            <label>Start Time</label>
                                            <div class="textBoxValidate">


                                                <input type="datetime-local" name="paymentStartDate"
                                                    id="paymentStartDate"
                                                    value={this.state.searchModel.paymentStartDate}
                                                    onChange={this.handleChange} class="form-control" />







                                                {/* <input
                                                    style={{
                                                        width: "215px",
                                                        marginLeft: "0px"
                                                    }}
                                                    className="myInput"
                                                    type="date"
                                                    name="patBatchSTime"
                                                    id="patBatchSTime"
                                                    value={patbatchSTime}
                                                    onChange={this.handleChange}
                                                ></input> */}
                                            </div>
                                        </div>




                                        <div class="mf-6">

                                            <label>End Time</label>
                                            <div class="textBoxValidate">


                                                <input type="datetime-local" name="paymentEndDate"
                                                    id="paymentEndDate"
                                                    value={this.state.searchModel.paymentEndDate}
                                                    onChange={this.handleChange} class="form-control" />









                                                {/* <input
                                                    style={{
                                                        width: "215px",
                                                        marginLeft: "0px"
                                                    }}
                                                    className="myInput"
                                                    type="date"
                                                    name="patBatchETime"
                                                    id="patBatchETime"
                                                    value={patbatchETime}
                                                    onChange={this.handleChange}
                                                ></input> */}
                                            </div>

                                        </div>
                                        {/* <div class="mf-4">
                                            &nbsp;
                                        </div> */}
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-8 field_full-8">
                                            <label>Notes</label>
                                            <textarea name="paymentNotes" id="paymentNotes" value={this.state.searchModel.paymentNotes} cols="30" rows="10"></textarea>
                                        </div>
                                        <div class="mf-4">
                                            &nbsp;
                                </div>
                                    </div>
                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Status</label>
                                            <input type="text" value={this.state.searchModel.status} name="status" id="status"></input>
                                        </div>
                                        <div class="mf-6">
                                            <label>&nbsp; </label>
                                            <input type="text" disabled="disabled" value="" name="" id=""></input>
                                        </div>
                                        {/* <div class="mf-4">
                                            &nbsp;
                                </div> */}
                                    </div>


                                    <div class="row-form">

                                        <div class="mf-6">
                                            <label>Added By </label>
                                            <Input type="text" value={this.state.searchModel.addedBy} name="addedBy" id="addedBy" onChange={() => this.handleChange}></Input>
                                        </div>


                                        <div class="mf-6">
                                            <label>Added Date</label>
                                            <div class="textBoxValidate">
                                                <input
                                                    style={{
                                                        width: "215px",
                                                        marginLeft: "0px"
                                                    }}
                                                    className="myInput"
                                                    type="date"
                                                    name="addedDate"
                                                    id="addedDate"
                                                    value={addpayBatchDate}
                                                    onChange={this.handleChange}
                                                ></input>
                                            </div>
                                        </div>





                                        {/* <div class="mf-4">
                                            &nbsp;
                                         </div> */}
                                    </div>

                                    <div class="row-form">
                                        <div class="mf-6">
                                            <label>Update By </label>
                                            <Input type="text" value={this.state.searchModel.updatedBy} name="updatedBy" id="updatedBy" onChange={() => this.handleChange}></Input>
                                        </div>

                                        <div class="mf-6">
                                            <label>Updated Date</label>

                                            <input
                                                style={{
                                                    width: "215px",
                                                    marginLeft: "0px"
                                                }}
                                                className="myInput"
                                                type="date"
                                                name="updatedDate"
                                                id="updatedDate"
                                                value={updatedpayBatchDate}
                                                onChange={this.handleChange}
                                            ></input>

                                        </div>


                                    </div>

                                </div>


                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <button className="btn-blue" onClick={this.saveBatchDocuments}>Save </button>
                                                <button id='btnCancel' className="btn-grey" data-dismiss="modal"
                                                    onClick={this.props.onClose()}
                                                >Cancel </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>









                            </div>

                        </div>

                    </div>

                </div>
            </React.Fragment >
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(BatchDocumentPopup);
  