import React, { Component } from "react";
import { MDBBtn } from "mdbreact";
import $ from "jquery";
import axios from "axios";
import { MDBDataTable } from "mdbreact";
import Swal from "sweetalert2";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
// import moment from "react-moment";
import calenderPic from "../images/dob-icon.png";

import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Input from "./Input";
import Eclips from '../images/loading_spinner.gif'
import GifLoader from 'react-gif-loader';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import { loginAction } from '../actions/LoginAction';
import { selectTabAction } from '../actions/selectTabAction'

import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";

class Patient extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/patient/";
    this.id = 0;
    //Authorization Token
    this.config = {
      headers: { Authorization: "Bearer  " + this.props.loginObject.token, Accept: "*/*" }
    };



    this.searchModel = {
      lastName: "",
      firstName: "",
      accountNum: "",
      medicalRecordNumber: "",
      ssn: "",
      dob: "",
      insuredID: "",
      practice: "",
      location: "",
      provider: "",
      plan: "",
      active: true
    };

    this.state = {
      searchModel: this.searchModel,
      data: [],
      showpracticePopup: false,
      showLocationPopup: false,
      showProviderPopup: false,
      loading: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handleNumericCheck = this.handleNumericCheck.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
    this.newPatientPopup = this.newPatientPopup.bind(this);
    //this.openPopup = this.openPopup.bind(this);
  }



  openpracticePopup = (id) => {
    this.setState({ showpracticePopup: true, id: id });
  }

  closepracticePopup = () => {
    $('#myModal').hide()
    this.setState({ showpracticePopup: false });
  }


  openLocationPopup = (id) => {
    this.setState({ showLocationPopup: true, id: id });
  }

  closeLocationPopup = () => {
    $('#myModal').hide()
    this.setState({ showLocationPopup: false });
  }


  openProviderPopup = (id) => {
    this.setState({ showProviderPopup: true, id: id });
  }

  closeProviderPopup = () => {
    $('#myModal').hide()
    this.setState({ showProviderPopup: false });
  }

  isNull(value) {
    if (value === '' || value === null || value === undefined || value === 'Please Select'
      || value === 'Please Coverage' || value === 'Please Relationship')
      return true;
    else return false;
  }

  replace(field, replaceWhat, replaceWith) {
    if (this.isNull(field))
      return field;
    else return field.replace(replaceWhat, replaceWith);
  }


  handleChange = event => {
    event.preventDefault();

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  async handleSearch(event) {
    event.preventDefault();

    await this.setState({ loading: true })
    await axios
      .post(this.url + "FindPatients", this.state.searchModel, this.config)
      .then(response => {
        console.log(response.data);
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            accountNo: <MDBBtn className='gridBlueBtn' onClick={() => this.newPatientPopup(row.id)} > {row.accountNum}</MDBBtn>,
            lastName: row.lastName,
            firstName: row.firstName,
            medicalRecordNumber: row.medicalRecordNumber,
            ssn: row.ssn,
            dob: row.dob,
            practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openpracticePopup(row.practiceID)} > {row.practice}</MDBBtn>,
            location: <MDBBtn className='gridBlueBtn' onClick={() => this.openLocationPopup(row.locationID)} > {row.location}</MDBBtn>,
            provider: <MDBBtn className='gridBlueBtn' onClick={() => this.openProviderPopup(row.providerID)} > {row.provider}</MDBBtn>,
          });
        });

        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false })
        Swal.fire("Something Wrong", "Please Seach Again", "error");
        try {
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
            console.log(errorsList);
          } else console.log(error);
        } catch { }
      });
  };

  clearFields = event => {
    this.setState({ searchModel: this.searchModel });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  handleCheck() {
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        active: !this.state.searchModel.active
      }
    });
  }

  handleDateChange = date => {
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        dob: date.target.value
      }
    });
  };

  openPopup(id) {
    alert("Popup");
    console.log(id);
  }

  newPatientPopup(id) {
    this.props.selectTabAction("NewPatient", id);
  }
  render() {
    var newDate = new Date(this.state.searchModel.dob);
    var day = newDate.getDate();
    var month = newDate.getMonth() + 1;
    var year = newDate.getFullYear();
    newDate = year + "-" + month + "-" + day;
    const tableData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "ACCOUNT #",
          field: "accountNo",
          sort: "asc",
          width: 150
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          width: 150
        },
        {
          label: "FIRST NAME",
          field: "firstName",
          sort: "asc",
          width: 150
        },
        {
          label: "MEDICAL RECORD #",
          field: "medicalRecordNumber",
          sort: "asc",
          width: 150
        },
        {
          label: "SSN",
          field: "ssn",
          sort: "asc",
          width: 150
        },
        {
          label: "DOB",
          field: "dob",
          sort: "asc",
          width: 150
        },
        {
          label: "PRACTICE",
          field: "practice",
          sort: "asc",
          width: 150
        },
        {
          label: "LOCATION",
          field: "location",
          sort: "asc",
          width: 150
        },
        {
          label: "PROVIDER",
          field: "provider",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.data
    };


    let popup = ''

    if (this.state.showpracticePopup) {
      popup = <NewPractice onClose={() => this.closepracticePopup} practiceID={this.state.id}></NewPractice>
    } else if (this.state.showLocationPopup) {
      popup = <NewLocation onClose={() => this.closeLocationPopup} id={this.state.id}></NewLocation>
    } else if (this.state.showProviderPopup) {
      popup = <NewProvider onClose={() => this.closeProviderPopup} id={this.state.id}></NewProvider>
    } else
      popup = <React.Fragment></React.Fragment>


    //Spinner
    let spiner = ''
    if (this.state.loading == true) {
      spiner = (
        <GifLoader
          loading={true}
          imageSrc={Eclips}
          // imageStyle={imageStyle}
          overlayBackground="rgba(0,0,0,0.5)"
        />
      )
    }

    return (
      <React.Fragment>
        {spiner}
        <div>
          <div>
            <div>
              <SearchHeading
                heading="PATIENT SEARCH"
                handler={() => this.newPatientPopup(0)}
              ></SearchHeading>

              <div className="container-fluid">
                <form
                  onSubmit={event => {
                    this.handleSearch(event);
                  }}
                >
                  <div
                    className="mainTable fullWidthTable"
                    style={{ maxWidth: "1500px" }}
                  >
                    <div className="row-form">
                      <div className="mf-3">
                        <Label name="Last Name"></Label>
                        <Input
                          type="text"
                          name="lastName"
                          id="lastName"
                          max="20"
                          value={this.state.searchModel.lastName}
                          onChange={() => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="First Name"></Label>
                        <Input
                          type="text"
                          name="firstName"
                          id="firstName"
                          max="20"
                          value={this.state.searchModel.firstName}
                          onChange={() => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="Account#"></Label>
                        <Input
                          type="text"
                          name="accountNum"
                          id="accountNum"
                          value={this.state.searchModel.accountNum}
                          onChange={event => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="MRN"></Label>
                        <Input
                          type="text"
                          name="medicalRecordNumber"
                          id="medicalRecordNumber"
                          max="20"
                          value={this.state.searchModel.medicalRecordNumber}
                          onChange={event => this.handleChange}
                        ></Input>
                      </div>
                    </div>
                    <div className="row-form">
                      <div className="mf-3">
                        <Label name="SSN"></Label>
                        <Input
                          type="text"
                          name="ssn"
                          id="ssn"
                          max="9"
                          value={this.state.searchModel.ssn}
                          onChange={event => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="DOB"></Label>
                        <div>
                          <input
                            // className="myInput"
                            type="date"
                            name="dob"
                            id="dob"
                            // value={newDate}
                            value={this.replace(this.state.searchModel.dob, "T00:00:00", "")}
                            onChange={this.handleDateChange}
                          ></input>
                        </div>

                        {/* <DatePicker
                          dateFormat="MM/dd/yyyy"
                          isClearable
                          showYearDropdown
                          selected={this.state.searchModel.dob}
                          onChange={this.handleDateChange}
                        /> */}
                      </div>
                      <div className="mf-3">
                        <Label name="Insured ID"></Label>
                        <Input
                          type="text"
                          name="insuredID"
                          id="insuredID"
                          value={this.state.searchModel.insuredID}
                          onChange={event => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="Practice"></Label>
                        <Input
                          type="text"
                          name="practice"
                          id="practice"
                          value={this.state.searchModel.practice}
                          onChange={event => this.handleChange}
                        ></Input>
                      </div>
                    </div>
                    <div className="row-form">
                      <div className="mf-3">
                        <Label name="Location"></Label>
                        <Input
                          type="text"
                          name="location"
                          id="location"
                          value={this.state.searchModel.location}
                          onChange={event => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="Provider"></Label>
                        <Input
                          type="text"
                          name="provider"
                          id="provider"
                          value={this.state.searchModel.provider}
                          onChange={event => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="Plan"></Label>
                        <Input
                          type="text"
                          name="plan"
                          id="plan"
                          value={this.state.searchModel.plan}
                          onChange={event => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3 popupHeadingRight">
                        <div className="lblChkBox" onClick={this.handleCheck}>
                          <input
                            type="checkBox"
                            id="isActive"
                            name="isActive"
                            checked={!this.state.searchModel.active}
                          />
                          <label htmlFor="isActive">
                            <span>Inactive</span>
                          </label>
                        </div>
                      </div>
                    </div>

                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <Input
                          type="submit"
                          name="search"
                          id="search"
                          className="btn-blue"
                          value="Search"
                        ></Input>
                        <Input
                          type="button"
                          name="clear"
                          id="clear"
                          value="Clear"
                          className="btn-grey"
                          onClick={event => this.clearFields(event)}
                        ></Input>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
              <div className="mf-12 table-grid mt-15">
                <div className="row headingTable">
                  <div className="mf-6">
                    <h1>PATIENT SEARCH RESULT</h1>
                  </div>
                  <div className="mf-6 headingRightTable">
                    <a href="javascript:;">
                      <img src="images/setting-icon.png" alt="" />
                    </a>
                  </div>
                </div>

                {popup}

                <div className="tableGridContainer">
                  <MDBDataTable
                    responsive={true}
                    striped
                    bordered
                    searching={false}
                    data={tableData}
                    displayEntries={false}
                    sortable={true}
                    scrollX={false}
                    scrollY={false}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}


function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    // selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
    // selectedTabPage: state.selectedTabPage,
    // selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    // setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken ? state.loginToken : { toekn: "", isLogin: false },
    // userInfo: state.loginInfo ? state.loginInfo : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction, loginAction: loginAction, selectTabAction: selectTabAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(Patient);