import React, { Component } from 'react'


import SearchHeading from './SearchHeading'
import Label from './Label'
import Button from './Input'
import Input from './Input'
import SearchInput2 from './SearchInput2'
import Swal from 'sweetalert2'
import axios from 'axios';
import { MDBDataTable, MDBBtn, MDBTableHead, MDBTableBody, MDBTable } from 'mdbreact';

import GridHeading from './GridHeading';
import NewPractice from './NewPractice';
import NewUser from './NewUser';

import searchIcon from '../images/search-icon.png'
import refreshIcon from '../images/refresh-icon.png'
import newBtnIcon from '../images/new-page-icon.png'
import settingsIcon from '../images/setting-icon.png'

import ReactDataGrid from 'react-data-grid';


import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import $ from 'jquery';

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


class User extends Component {


    constructor(props) {
        super(props)

        this.url = process.env.REACT_APP_URL + '/account/';
         //Authorization Token
         this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };

        this.searchModel = {
            firstName : '',
            lastName:"",
            email : '',
            client  : ''
        }

        this.state = {
            searchModel: this.searchModel,
            id: 0,
            email:"",
            data: [],
            role:[],
            client:[],
            showPopup: false,
            loading : false
        }

        this.searchUser = this.searchUser.bind(this);
        this.closeUserPopup = this.closeUserPopup.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.openUserPopup = this.openUserPopup.bind(this);

    }


    componentWillMount(){

         var config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };
        // Account Get Profiles
        //  axios({
        //      method : "get",
        //      url:this.url + 'getProfiles' ,
        //     //  headers : {Authorization: "Bearer  " + this.props.loginObject.token , 
        //     //  Accept: "*/*"}
        //  })

         axios.get(this.url + 'getProfiles'  ,  this.config)
                .then(response => {
                    console.log("Get Profiles Response : " , response.data);
                    this.setState({ client: response.data.clients , role : response.data.roles });
                })
        .catch(error => {
                    
                    if (error.response) {
                        if(error.response.status){
                            //Swal.fire("Unauthorized Access" , "" , "error");
                            console.log(error.response.status)
                            return
                        }
                      } else if (error.request) {
                        console.log(error.request);
                        return
                      } else {
                        console.log('Error', error.message);
                        console.log(JSON.stringify(error));
                        //Swal.fire("Something went Wrong" , "" , "error");
                        return
                      }

                      console.log(error)
                });

    }

    //Search User
    searchUser = (e) => {
        this.setState({loading:true})
                console.log(this.state.searchModel);

                
        //Authorization Token
        var config = {
            headers: {'Authorization': "Bearer  " + this.props.loginObject.token}
        };


                axios.post(this.url + 'findUsers', this.state.searchModel ,  this.config)
                    .then(response => {

                        let newList = []
                        response.data.map((row, i) => {
                            console.log(row)
                            newList.push({
                                id: row.userId ,
                                name: <MDBBtn className='gridBlueBtn' onClick={() => this.openUserPopup(row.email)}>{row.name}</MDBBtn>,
                                email: row.email,
                                role: row.role,
                                
                            });
                        });

                        this.setState({ data: newList ,loading:false});
                    }).catch(error => {
                        this.setState({loading:false})
                        if (error.response) {
                            if(error.response.status){
                                Swal.fire("Unauthorized Access" , "" , "error");
                                return
                            }
                          } else if (error.request) {
                            console.log(error.request);
                            return
                          } else {
                            console.log('Error', error.message);
                            console.log(JSON.stringify(error));
                            Swal.fire("Something went Wrong" , "" , "error");
                            return
                          }
                    });

        e.preventDefault();
    }

    handleChange = event => {
        event.preventDefault();
        this.setState({
            searchModel: { ...this.state.searchModel, [event.target.name]: event.target.value.toUpperCase() }
        });
    };

    clearFields = event => {
        this.setState({
            searchModel: this.searchModel
        });
    };

    openUserPopup = (email) => {
        this.setState({ showPopup: true, email: email });
    }


    closeUserPopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }

    render() {

        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 150,
                },
                {
                    label: 'NAME',
                    field: 'name',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'EMAIL',
                    field: 'email',
                    sort: 'asc',
                    width: 270
                },
                
                {
                    label: 'ROLE',
                    field: 'role',
                    sort: 'asc',
                    width: 100
                }
                
            ],
            rows:
                this.state.data
        };


        let popup = '';
        if (this.state.showPopup) {
            popup = <NewUser onClose={() => this.closeUserPopup} email={this.state.email}></NewUser>
        }
        else
            popup = <React.Fragment></React.Fragment>

            let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }


        return (

            < React.Fragment >
                {spiner}
                <SearchHeading heading='USER SEARCH' handler={() => this.openUserPopup(0)}></SearchHeading>

                <form onSubmit={this.searchUser}>
                    <div className="mainTable">

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Last Name'></Label>
                                <Input max="20" type='text' name='lastName' id='lastName' value={this.state.searchModel.lastName} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='First Name'></Label>
                                <Input max="20" type='text' name='firstName' id='firstName' value={this.state.searchModel.firstName} onChange={() => this.handleChange} />
                            </div>


                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Client'></Label>
                                
                                <select
                                    name="client"
                                    id="client"
                                    value={this.state.searchModel.client}
                                    onChange={this.handleChange}
                                >
                                    {this.state.client.map(s => (
                                    <option key={s.id} value={s.id}>
                                        {s.description}
                                    </option>
                                    ))}
                                </select>
                            </div>
                           
                            <div className="mf-6">
                                <Label name='Email'></Label>
                                <Input type='text' name='email' id='email'
                                    max='30' value={this.state.searchModel.email} onChange={() => this.handleChange} />
                            </div>
                        </div>

                     <div className="row-form row-btn">
                            <div className="mf-12">
                                <Input type='submit' name='name' id='name' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>
                </form>

                <div className="mf-12 table-grid mt-15">
                    <GridHeading Heading='USER SEARCH RESULT'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            responsive={true}
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

                {popup}

            </React.Fragment >
        )
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(User);