import React, { Component } from 'react'

import $ from 'jquery';


import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

import Swal from 'sweetalert2'
import axios from 'axios';
import Input from './Input';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import { loginAction } from '../actions/LoginAction';
import { selectTabAction } from '../actions/selectTabAction'


export class NewInsurance extends Component {
    constructor(props) {
        super(props)
        console.log(this.props.id)

        this.errorField = 'errorField'
        this.url = process.env.REACT_APP_URL + '/Insurance/';
        //Authorization Token
        this.config = {
            headers: { Authorization: "Bearer  " + this.props.loginObject.token, Accept: "*/*" }
        };

        this.insuranceModel = {
            "id": 0,
            organizationName: '',
            "name": "",
            "address1": "",
            "address2": "",
            "city": "",
            "state": "",
            "zipCode": "",
            "officePhoneNum": "",
            "email": "",
            "website": "",
            "faxNumber": "",
            "isActive": true,
            "isDeleted": false,
            "notes": "",

        }


        this.validationModel = {
            nameValField: null,
            organizationNameValField: '',
            address1ValField: null,
            address2ValField: null,
            cityValField: null,
            stateValField: null,
            zipCodeValField: null,
            officePhoneNumValField: null,
            emailValField: null,
            websiteValField: null,
            faxNumberValField: null,
            isActiveValField: true,
            isDeletedValField: false,
            notesValField: null
        }


        this.state = {
            editId: this.props.id,
            insuranceModel: this.insuranceModel,
            validationModel: this.validationModel,
            maxHeight: '361'

        }
        this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
        this.handleChange = this.handleChange.bind(this);

        this.delete = this.delete.bind(this);
        this.handleCheck = this.handleCheck.bind(this);
        this.saveInsurance = this.saveInsurance.bind(this);
    }
    setModalMaxHeight(element) {
        this.$element = $(element);
        this.$content = this.$element.find('.modal-content');
        var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
        var dialogMargin = $(window).width() < 768 ? 20 : 60;
        var contentHeight = $(window).height() - (dialogMargin + borderWidth);
        var headerHeight = this.$element.find('.modal-header').outerHeight() || 0;
        var footerHeight = this.$element.find('.modal-footer').outerHeight() || 0;
        var maxHeight = contentHeight - (headerHeight + footerHeight);

        this.setState({ maxHeight: maxHeight })
    }
    componentDidMount() {

        this.setModalMaxHeight($('.modal'));

        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-Index', zIndex);
        setTimeout(function () {
            $('.modal-backdrop').not('.modal-stack').css('z-Index', zIndex - 1).addClass('modal-stack');
        }, 0);
        if (this.state.editId > 0) {
            axios.get(this.url + 'FindInsurance/' + this.state.editId, this.config)
                .then(response => {
                    console.log("find open data" + response);
                    this.setState({ insuranceModel: response.data });
                    console.log(this.state.insuranceModel);
                }).catch(error => {
                    console.log(error);
                });
        }
    }

    handleChange = event => {
        console.log(event);

        event.preventDefault();
        console.log(event.target.value)
        this.setState({

            insuranceModel: { ...this.state.insuranceModel, [event.target.name]: event.target.value.toUpperCase() }
        });
    };
    handleCheck() {
        this.setState({
            insuranceModel: {
                ...this.state.insuranceModel,
                isActive: !this.state.insuranceModel.isActive
            }
        });
    }
    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }

    isNull(value) {
        if (value === '' || value === null || value === undefined || value === 'Please Select')
            return true;
        else return false;
    }


    saveInsurance = (e) => {

        this.setState({ loading: true })

        var myVal = this.validationModel;
        myVal.validation = false;

        if (this.isNull(this.state.insuranceModel.name)) {
            myVal.nameValField = <span className="validationMsg">Enter Name</span>
            myVal.validation = true
        } else {
            myVal.nameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.isNull(this.state.insuranceModel.organizationName)) {
            myVal.organizationNameValField = <span className="validationMsg">Enter Organization Name</span>
            myVal.validation = true
        } else {
            myVal.organizationNameValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        if (this.isNull(this.state.insuranceModel.zipCode) === false && this.state.insuranceModel.zipCode.length > 0) {
            if (this.state.insuranceModel.zipCode.length < 5) {
                myVal.zipCodeValField = <span className="validationMsg">Zip should be of atleast 5 digits</span>
                myVal.validation = true
            } else if (this.state.insuranceModel.zipCode.length > 5 && this.state.insuranceModel.zipCode.length < 9) {
                myVal.zipCodeValField = <span className="validationMsg">Zip should be of either 5 or 9 digits</span>
                myVal.validation = true
            } else {
                myVal.zipCodeValField = ''
                if (myVal.validation === false) myVal.validation = false
            }
        } else {
            myVal.zipCodeValField = ''
            if (myVal.validation === false) myVal.validation = false
        }

        if (this.state.insuranceModel.officePhoneNum.length > 0 && this.state.insuranceModel.officePhoneNum.length < 10) {
            myVal.officePhoneNumValField = <span className="validationMsg">Phone # length should be 10</span>
            myVal.validation = true
        } else {
            myVal.officePhoneNumValField = ''
            if (myVal.validation === false) myVal.validation = false
        }



        if (this.isNull(this.state.insuranceModel.faxNumber) === false && this.state.insuranceModel.faxNumber.length < 10) {
            myVal.faxNumberValField = <span className="validationMsg">Fax # length should be 10</span>
            myVal.validation = true
        } else {
            myVal.faxNumberValField = ''
            if (myVal.validation === false) myVal.validation = false
        }


        this.setState({
            validationModel: myVal
        });

        if (myVal.validation === true) {
            this.setState({ loading: false })

            return;
        }


        console.log(this.state.insuranceModel);
        e.preventDefault();
        axios.post(this.url + 'SaveInsurance', this.state.insuranceModel, this.config)
            .then(response => {

                this.setState({ insuranceModel: response.data, editId: response.data.id, loading: false });
                Swal.fire(
                    'Record Saved Successfully',
                    '',
                    'success'
                )
            }).catch(error => {
                this.setState({ loading: false })
                try {
                    let errorList = []
                    if (error.response !== null && error.response.data !== null) {
                        errorList = error.response.data;
                        console.log(errorList.Email[0])
                        if (errorList.Email[0] == "Please enter Valid Email ID") {
                            console.log(errorList.Email)
                            this.setState({
                                validationModel: {
                                    ...this.state.validationModel,
                                    emailValField: <span className="validationMsg">Enter Valid Email</span>
                                }
                            })
                        } else {
                            this.setState({
                                validation: {
                                    ...this.state.validationModel,
                                    emailValField: ""
                                }
                            })
                        }
                    }
                    else console.log(errorList);
                } catch{ }
            });

        e.preventDefault();
    }

    delete = e => {
        Swal.fire({
            title: "Are you sure, you want to delete this record?",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then(result => {
            if (result.value) {
                axios
                    .delete(this.url + "DeleteInsurance/" + this.state.editId, this.config)
                    .then(response => {
                        console.log("Delete Response :", response);
                        Swal.fire("Record Deleted Successfully", "", "success");
                    })
                    .catch(error => {
                        Swal.fire("Record Not Deleted!", "Record can not be deleted, as it is being referenced in other screens.", "error");
                    });

                $("#btnCancel").click();
            }
        });
    };


    render() {
        const usStates = [
            { value: "", display: "Select State" },
            { value: "AL", display: "AL - Alabama" },
            { value: "AK", display: "AK - Alaska" },
            { value: "AZ", display: "AZ - Arizona" },
            { value: "AR", display: "AR - Arkansas" },
            { value: "CA", display: "CA - California" },
            { value: "CO", display: "CO - Colorado" },
            { value: "CT", display: "CT - Connecticut" },
            { value: "DE", display: "DE - Delaware" },
            { value: "FL", display: "FL - Florida" },
            { value: "GA", display: "GA - Georgia" },
            { value: "HI", display: "HI - Hawaii" },
            { value: "ID", display: "ID - Idaho" },
            { value: "IL", display: "IL - Illinois" },
            { value: "IN", display: "IN - Indiana" },
            { value: "IA", display: "IA - Iowa" },
            { value: "KS", display: "KS - Kansas" },
            { value: "KY", display: "KY - Kentucky" },
            { value: "LA", display: "LA - Louisiana" },
            { value: "ME", display: "ME - Maine" },
            { value: "MD", display: "MD - Maryland" },
            { value: "MA", display: "MA - Massachusetts" },
            { value: "MI", display: "MI - Michigan" },
            { value: "MN", display: "MN - Minnesota" },
            { value: "MS", display: "MS - Mississippi" },
            { value: "MO", display: "MO - Missouri" },
            { value: "MT", display: "MT - Montana" },
            { value: "NE", display: "NE - Nebraska" },
            { value: "NV", display: "NV - Nevada" },
            { value: "NH", display: "NH - New Hampshire" },
            { value: "NJ", display: "NJ - New Jersey" },
            { value: "NM", display: "NM - New Mexico" },
            { value: "NY", display: "NY - New York" },
            { value: "NC", display: "NC - North Carolina" },
            { value: "ND", display: "ND - North Dakota" },
            { value: "OH", display: "OH - Ohio" },
            { value: "OK", display: "OK - Oklahoma" },
            { value: "OR", display: "OR - Oregon" },
            { value: "PA", display: "PA - Pennsylvania" },
            { value: "RI", display: "RI - Rhode Island" },
            { value: "SC", display: "SC - South Carolina" },
            { value: "SD", display: "SD - South Dakota" },
            { value: "TN", display: "TN - Tennessee" },
            { value: "TX", display: "TX - Texas" },
            { value: "UT", display: "UT - Utah" },
            { value: "VT", display: "VT - Vermont" },
            { value: "VA", display: "VA - Virginia" },
            { value: "WA", display: "WA - Washington" },
            { value: "WV", display: "WV - West Virginia" },
            { value: "WI", display: "WI - Wisconsin" },
            { value: "WY", display: "WY - Wyoming" }
        ]

        let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }
        const isActive = this.state.insuranceModel.isActive;
        return (
            <React.Fragment>
                {spiner}
                <div id='myModal' class="modal fade bs-example-modal-new show" tabIndex="-1"
                    role="dialog" aria-labelledby="myLargeModalLabel" style={{ display: 'block', paddingRight: '17px' }} >

                    <div className="modal-dialog modal-lg">

                        <button
                            type="button"
                            onClick={this.props.onClose()}
                            className="close"
                            data-dismiss="modal"
                            aria-label="Close"
                        >
                            <span aria-hidden="true"></span>
                        </button>
                        <div className="modal-content" style={{ overflow: 'hidden' }}>
                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">

                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">{this.state.editId > 0 ? this.state.insuranceModel.name.toUpperCase() + " - " + this.state.insuranceModel.id : "NEW INSURANCE"}</h1>
                                        </div>


                                        <div className="mf-6 popupHeadingRight">
                                            <div className="lblChkBox" onClick={this.handleCheck}>
                                                <input
                                                    type="checkBox"
                                                    id="isActive"
                                                    name="isActive"
                                                    checked={!isActive}
                                                />
                                                <label htmlFor="markInactive">
                                                    <span>Mark Inactive</span>
                                                </label>
                                            </div>
                                            <Input type="button" value="Delete" className="btn-blue" onClick={this.delete}>Delete</Input>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="modal-body" style={{ maxHeight: this.state.maxHeight }}>
                                <div className="mainTable">
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Name <span className="redlbl"> *</span></label>

                                            <div className="textBoxValidate">
                                                <Input
                                                    className={this.state.validationModel.nameValField ? this.errorField : ""}
                                                    type="text" value={this.state.insuranceModel.name} name="name" id="name"
                                                    max='20'
                                                    onChange={() => this.handleChange}></Input>
                                                {this.state.validationModel.nameValField}
                                            </div>

                                        </div>
                                        <div className="mf-6">
                                            <label>Organization Name <span className="redlbl"> *</span></label>

                                            <div className="textBoxValidate">
                                                <Input
                                                    className={this.state.validationModel.organizationNameValField ? this.errorField : ""}
                                                    type="text" value={this.state.insuranceModel.organizationName} name="organizationName"
                                                    id="organizationName" max='30' onChange={() => this.handleChange}></Input>
                                                {this.state.validationModel.organizationNameValField}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mf-12 headingOne mt-25">
                                        <p>Address Information</p>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Address 1</label>
                                            <Input type="text" value={this.state.insuranceModel.address1} name="address1" id="address1" max='55' onChange={() => this.handleChange}></Input>
                                        </div>
                                        <div className="mf-6">
                                            <label>Address 2</label>
                                            <Input type="text" value={this.state.insuranceModel.address2} name="address2" id="address2" max='55' onChange={() => this.handleChange}></Input>
                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>City - State</label>
                                            <div className="textBoxTwoField">
                                                <Input type="text" value={this.state.insuranceModel.city} name="city" id="city" max='20' onChange={() => this.handleChange} />

                                                <select name='state' id='state' value={this.state.insuranceModel.state} onChange={this.handleChange}>
                                                    {usStates.map((s) => <option key={s.value} value={s.value}>{s.display}</option>)}
                                                </select>
                                            </div>
                                        </div>
                                        <div className="mf-6">
                                            <label>Zip Code -  Phone</label>
                                            <div className="textBoxTwoField textBoxValidate">
                                                <div className="twoColValidate">
                                                    <Input
                                                        className={this.state.validationModel.zipCodeValField ? this.errorField : ""}
                                                        type="text" value={this.state.insuranceModel.zipCode} max='9' name="zipCode" id="zipCode"
                                                        onKeyPress={event => this.handleNumericCheck(event)} onChange={() => this.handleChange} />
                                                    {this.state.validationModel.zipCodeValField}
                                                </div>

                                                <div className="twoColValidate">
                                                    <Input
                                                        className={this.state.validationModel.officePhoneNumValField ? this.errorField : ""}
                                                        type="text" value={this.state.insuranceModel.officePhoneNum}
                                                        max='10' name="officePhoneNum" id="officePhoneNum"
                                                        onKeyPress={event => this.handleNumericCheck(event)} onChange={() => this.handleChange} />
                                                    {this.state.validationModel.officePhoneNumValField}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Fax</label>
                                            <div className="textBoxValidate">
                                                <Input
                                                    className={this.state.validationModel.faxNumberValField ? this.errorField : ""}
                                                    type="text" value={this.state.insuranceModel.faxNumber} max='10' name="faxNumber"
                                                    id="faxNumber" onKeyPress={event => this.handleNumericCheck(event)} onChange={() => this.handleChange} />
                                                {this.state.validationModel.faxNumberValField}
                                            </div>
                                        </div>
                                        <div className="mf-6">
                                            <label>Website</label>
                                            <Input type="text" value={this.state.insuranceModel.website} name="website" id="website" max='50' onChange={() => this.handleChange} />

                                        </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>Email</label>
                                            <div className="textBoxValidate">
                                                <Input className={this.state.validationModel.officePhoneNumValField ? this.errorField : ""} type="text" value={this.state.insuranceModel.email} name="email" id="email" max='30' onChange={() => this.handleChange} />
                                                {this.state.validationModel.emailValField}
                                            </div>
                                        </div>
                                        <div className="mf-6">
                                            &nbsp;
                                    </div>
                                    </div>
                                    <div className="row-form">
                                        <div className="mf-12 field_full-8">
                                            <label>Notes:</label>
                                            <textarea value={this.state.insuranceModel.notes} name="notes" id="notes" cols="30" rows="10" onChange={this.handleChange} ></textarea>
                                        </div>

                                    </div>
                                </div>

                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <button className="btn-blue" onClick={this.saveInsurance}>Save </button>
                                                <button className="btn-grey" data-dismiss="modal" onClick={this.props.onClose()}>Cancel </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </React.Fragment>
        )
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page", state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        // id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject: state.loginToken ? state.loginToken : { toekn: "", isLogin: false },
        userInfo: state.loginInfo ? state.loginInfo : { userPractices: [], name: "", practiceID: null }
    };
}
function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction, loginAction: loginAction, selectTabAction: selectTabAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(NewInsurance);
