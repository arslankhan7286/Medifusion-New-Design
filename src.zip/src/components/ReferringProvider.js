import React, { Component } from "react";
import { MDBBtn, MDBTable, MDBTableBody, MDBTableHead } from "mdbreact";
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Button from "./Input";
import Input from "./Input";
import SearchInput2 from "./SearchInput2";
import $ from "jquery";
import axios from "axios";
import { MDBDataTable } from "mdbreact";

import settingIcon from "../images/setting-icon.png";
import NewRefferingProvider from "./NewRefferingProvider";

//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import { loginAction } from '../actions/LoginAction';
import { selectTabAction } from '../actions/selectTabAction'



class ReferringProvider extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + '/refprovider/';
    //Authorization Token
    this.config = {
      headers: { Authorization: "Bearer  " + this.props.loginObject.token, Accept: "*/*" }
    };

    this.searchModel = {
      name: "",
      lastName: "",
      firstName: "",
      npi: "",
      ssn: "",
      taxonomyCode: ""
    };

    this.state = {
      searchModel: this.searchModel,
      data: [],
      showPopup: false,
      id: 0,
      loading: false
    };

    //binding functions to this class
    this.searchRefferingPractice = this.searchRefferingPractice.bind(this);
    this.clearFields = this.clearFields.bind(this);
    this.openRefProviderPopup = this.openRefProviderPopup.bind(this);
    this.closeRefProviderPopup = this.closeRefProviderPopup.bind(this);
  }
  searchRefferingPractice = e => {
    this.setState({ loading: true })
    axios.post(this.url + "FindRefProviders", this.state.searchModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            name: (
              <MDBBtn className='gridBlueBtn' onClick={() => this.openRefProviderPopup(row.id)} >
                {row.name}
              </MDBBtn>
            ),
            lastName: row.lastName,
            firstName: row.firstName,
            npi: row.npi,
            ssn: row.ssn,
            taxonomyCode: row.taxonomyCode,
            address: row.address,
            officePhoneNum: row.officePhoneNum
          });
        });

        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false })
        let errorsList = [];
        if (error.response !== null && error.response.data !== null) {
          errorsList = error.response.data;
          console.log(errorsList);
        } else console.log(error);
      });

    e.preventDefault();
  };

  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  //clear fields button
  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  //open facility popup
  openRefProviderPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  //close facility popup
  closeRefProviderPopup = () => {
    $("#myModal1").hide();
    this.setState({ showPopup: false });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  //Render Method
  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          width: 270
        },
        {
          label: "FIRST NAME",
          field: "firstName",
          sort: "asc",
          width: 200
        },
        {
          label: "NPI",
          field: "npi",
          sort: "asc",
          width: 100
        },
        {
          label: "SSN",
          field: "ssn",
          sort: "asc",
          width: 150
        },
        {
          label: "TAXONOMY CODE",
          field: "taxomonyCode",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDRESS, CITY, STATE, ZIP",
          field: "address",
          sort: "asc",
          width: 150
        },
        {
          label: "OFFICE PHONE #",
          field: "officePhoneNum",
          sort: "asc",
          width: 100
        }
      ],
      rows: this.state.data
    };
    let page = "";
    let popup = "";

    if (this.state.showPopup) {
      popup = (
        <NewRefferingProvider
          onClose={() => this.closeRefProviderPopup}
          id={this.state.id}
        ></NewRefferingProvider>
      );
    } else popup = <React.Fragment></React.Fragment>;


    let spiner = ''
    if (this.state.loading == true) {
      spiner = (
        <GifLoader
          loading={true}
          imageSrc={Eclips}
          // imageStyle={imageStyle}
          overlayBackground="rgba(0,0,0,0.5)"
        />
      )
    }

    return (
      <React.Fragment>
        {spiner}
        <SearchHeading
          heading="REFERRING PROVIDER SEARCH"
          handler={() => this.openRefProviderPopup(0)}
        ></SearchHeading>

        <form onSubmit={event => this.searchRefferingPractice(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Name"></Label>
                <Input
                  max="20"
                  type="text"
                  name="name"
                  id="name"
                  value={this.state.searchModel.name}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Last Name"></Label>
                <Input
                  max="15"
                  type="text"
                  name="lastName"
                  id="lastName"
                  value={this.state.searchModel.lastName}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="First Name"></Label>
                <Input
                  max="15"
                  type="text"
                  name="firstName"
                  id="firstName"
                  value={this.state.searchModel.firstName}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="NPI"></Label>
                <Input
                  type="text"
                  name="npi"
                  id="npi"
                  max="10"
                  value={this.state.searchModel.npi}
                  onChange={() => this.handleChange}
                  onKeyPress={event => this.handleNumericCheck(event)}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="SSN"></Label>
                <Input
                  type="text"
                  name="ssn"
                  id="ssn"
                  max="9"
                  value={this.state.searchModel.ssn}
                  onChange={() => this.handleChange}
                  onKeyPress={event => this.handleNumericCheck(event)}
                />
              </div>
              <div className="mf-6">
                <Label name="Taxonomy Code"></Label>
                <Input
                  type="text"
                  max="10"
                  onKeyPress={event => this.handleNumericCheck(event)}
                  name="taxonomyCode"
                  id="taxonomyCode"
                  value={this.state.searchModel.taxonomyCode}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="search"
                  id="search"
                  className="btn-blue"
                  value="Search"
                />
                <Input
                  type="button"
                  name="clear"
                  id="clear"
                  className="btn-grey"
                  value="Clear"
                  onClick={event => this.clearFields(event)}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <div className="row headingTable">
            <div className="mf-6">
              <h1>REFERRING PROVIDER SEARCH RESULT</h1>
            </div>
            <div className="mf-6 headingRightTable">
              <a href="javascript:;">
                <img src={settingIcon} alt="" />
              </a>
            </div>
          </div>

          <div className="tableGridContainer">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken ? state.loginToken : { toekn: "", isLogin: false },
    userInfo: state.loginInfo ? state.loginInfo : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction, loginAction: loginAction, selectTabAction: selectTabAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(ReferringProvider);