import React, { Component } from "react";
import { MDBBtn } from "mdbreact";
import $ from "jquery";


import axios from "axios";
import { MDBDataTable } from "mdbreact";
import Swal from "sweetalert2";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
// import moment from "react-moment";

import SearchHeading from "./SearchHeading";
import NewCharge from './NewCharge'

import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';
import Label from "./Label";
import Input from "./Input";
import GPopup from './GPopup';


//Redux Actions
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction';
import {loginAction} from '../actions/LoginAction';
import {selectTabAction} from '../actions/selectTabAction'


import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";
import NewInsurancePlan from "./NewInsurancePlan";
import { isNullOrUndefined } from "util";

class ChargeSearch extends Component {
    constructor(props) {
        super(props);

        this.url = process.env.REACT_APP_URL + "/Visit/";
        //Authorization Token
        this.config = {
            headers: {Authorization: "Bearer  " + this.props.loginObject.token , Accept: "*/*"}
        };



        this.searchModel = {
            accountNUm: "",
            lastName: "",
            firstName: "",
            subscriberID: "",

            visitID: null,
            chargeNum: "",

            payerID: "",

            chargeID: 0,
            batchID: 0,

            insuranceType: "",
            submissionType: "",

            dosFrom: "",
            dosTo: "",

            entryDateFrom: "",
            entryDateTo: "",

            isSubmitted: true,
            plan: "",

            Practice: "",
            location: "",
            provider: "",
            isPaid: true,
            isChecked: false
        };

        this.state = {
            searchModel: this.searchModel,
            data: [],
            pickerOpen: false,
            selectedDate: null,
            showPopup: false,
            popupName: '',
            id: 0
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleNumericCheck = this.handleNumericCheck.bind(this);
        this.handleCheck = this.handleCheck.bind(this);
        this.handleDosFromChange = this.handleDosFromChange.bind(this);
        this.handleDosToChange = this.handleDosToChange.bind(this);
        this.handleEnterToChange = this.handleEnterToChange.bind(this);
        this.handleEnterFromChange = this.handleEnterFromChange.bind(this);
        this.closeChargePopup = this.closeChargePopup.bind(this);
        this.clearFields = this.clearFields.bind(this);
        this.handleTable = this.handleTable.bind(this);
        this.openChargePopup = this.openChargePopup.bind(this);
        this.openVisitScreen = this.openVisitScreen.bind(this);
        this.handleDateChange = this.handleDateChange.bind(this);


        this.openPopup = this.openPopup.bind(this);
        this.closePopup = this.closePopup.bind(this);

    }


    openPopup = (name, id) => {
        this.setState({ popupName: name, id: id });
    }


    closePopup = () => {
        $('#myModal').hide()
        this.setState({ popupName: '' });
    }


    // openPracticePopup = (id) => {
    //     this.setState({ showPracticePopup: true, id: id });
    // }

    // closePracticePopup = () => {
    //     $('#myModal').hide()
    //     this.setState({ showPracticePopup: false });
    // }

    // openLocationPopup = (id) => {
    //     this.setState({ showLocationPopup: true, id: id });
    // }

    // closeLocationPopup = () => {
    //     $('#myModal').hide()
    //     this.setState({ showLocationPopup: false });
    // }

    // openProviderPopup = (id) => {
    //     this.setState({ showProviderPopup: true, id: id });
    // }

    // closeProviderPopup = () => {
    //     $('#myModal').hide()
    //     this.setState({ showProviderPopup: false });
    // }


    handleChange = event => {

        this.setState({
            searchModel: {
                ...this.state.searchModel,
                [event.target.name]: event.target.value.toUpperCase()
            }
        });

    };

    //Charge Search
    handleSearch = event => {
        event.preventDefault();
        console.log("Search Model Data : ", this.state.searchModel);
        this.setState({loading:true})

        axios
            .post(this.url + "FindVisits", this.state.searchModel , this.config)
            .then(response => {
                console.log("Find Visits Response : ",response.data);
                let newList = [];
                response.data.map(row => {
                    newList.push({
                        id: row.id,
                        visitID: (
                            <MDBBtn className='gridBlueBtn' onClick={() => this.openVisitScreen(row.visitID)} >
                                {row.visitID}
                            </MDBBtn>
                        ),
                        dosFrom: row.dos,
                        entryDate: row.entryDate,
                        accountNum: row.accountNum,
                        patient:<MDBBtn className='gridBlueBtn' onClick={() => this.openPopup('patient', row.patientID)} > {row.patient}</MDBBtn>,
                        insurancePlanName: <MDBBtn className='gridBlueBtn' onClick={() => this.openPopup('insuranceplan', row.insurancePlanID)} > {row.insurancePlanName}</MDBBtn>,
                        practice: <MDBBtn className='gridBlueBtn' onClick={() => this.openPopup('practice', row.practiceID)} > {row.practice}</MDBBtn>,
                        location: <MDBBtn className='gridBlueBtn' onClick={() => this.openPopup('location', row.locationID)} > {row.location}</MDBBtn>,
                        provider: <MDBBtn className='gridBlueBtn' onClick={() => this.openPopup('provider', row.providerID)} > {row.provider}</MDBBtn>,
                        billedAmount: isNullOrUndefined(row.billedAmount) ? '' : '$' + row.billedAmount,
                        planAmount: isNullOrUndefined(row.planAmount) ? '' : '$' + row.planAmount,
                        allowedAmount: isNullOrUndefined(row.allowedAmount) ? '' : '$' + row.allowedAmount,
                        patAmount: isNullOrUndefined(row.paidAmount) ? '' : '$' + row.paidAmount,
                        patresp: isNullOrUndefined(row.patresp) ? '' : '$' + row.patresp,
                        patientPaid: isNullOrUndefined(row.patPaid) ? '' : '$' + row.patPaid
                    });
                });

                this.setState({ data: newList , loading:false });
            })
            .catch(error => {
                this.setState({loading:false})
                Swal.fire("Something Wrong", "Please Seach Again", "error");


                console.log(error);
            });
    };


    clearFields = event => {
        this.setState({ searchModel: this.searchModel });
    };


    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }

    handleCheck() {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                active: !this.state.searchModel.active,

                isChecked: !this.state.searchModel.isChecked,
            }
        });
    }

    handleDosFromChange = (date) => {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                dosFrom: date,
            }

        });
    };

    handleDosToChange = (date) => {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                dosTo: date,
            }

        });
    };

    handleEnterToChange = (date) => {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                entryDateTo: date,
            }

        });
    };

    handleEnterFromChange = (date) => {
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                entryDateFrom: date,
            }

        });
    };

    openChargePopup(id) {

        this.setState({ showPopup: true, id: id });
        console.log(id);
    }


    closeChargePopup = () => {
        $('#myModal').hide()
        this.setState({ showPopup: false });
    }

    openVisitScreen(id) {
        this.props.selectTabAction("NewCharge", id);
    }

    controlYearLength(event) {
        var date = new Date(event.target.value);
        var date1 = date.getFullYear().toString();
        if (date1.length >= 4) {
            event.preventDefault();
            return
        }
        return true;
    }

    handleDateChange(event) {
        console.log(event.target.value);
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                dosFrom: event.target.value
            }
        })
    }
    handleTable() { }

    render() {

        const tableData = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "VISIT #",
                    field: "visitID",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "DOS",
                    field: "dosFrom",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "ENTRY DATE",
                    field: "entryDate",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "ACCOUNT#",
                    field: "accountNum",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PATIENT",
                    field: "patient",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PLAN",
                    field: "insurancePlanName ",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "Practice",
                    field: "practice",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "LOCATION",
                    field: "location",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PROVIDER",
                    field: "provider",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "BILLED AMOUNT",
                    field: "billedAmount",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PLAN AMOUNT",
                    field: "planAmount",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "ALLOWED AMOUNT",
                    field: "allowedAmount",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PAID AMOUNT",
                    field: "patAmount",
                    sort: "asc",
                    width: 150
                },

                {
                    label: "PT RESP",
                    field: "patresp",
                    sort: "asc",
                    width: 150
                },
                {
                    label: "PT PAID",
                    field: "patientPaid ",
                    sort: "asc",
                    width: 150
                }
            ],
            rows: this.state.data
        };


        var addEnterFromDate = this.state.searchModel.entryDateFrom ? this.state.searchModel.entryDateFrom.slice(0 , 10) : "";
        var addEnterToDate = this.state.searchModel.entryDateTo ? this.state.searchModel.entryDateTo.replace(0 , 10) : "";
        var addDosFromDate = this.state.searchModel.dosFrom ? this.state.searchModel.dosFrom.replace(0 , 10) : "";
        var addDosToDate = this.state.searchModel.dosTo ? this.state.searchModel.dosTo.replace(0 , 10) : "";

        const submitted = [

            { value: "", display: "All" },
            { value: "N", display: "No" },
            { value: "Y", display: "Yes" }
        ]

        const subType = [

            { value: "", display: "All" },
            { value: "E", display: "Electronic" },
            { value: "P", display: "Paper" }
        ]

        const insType = [

            { value: "", display: "All" },
            { value: "P", display: "Primary" },
            { value: "S", display: "Secondray" },
            { value: "T", display: "Tertiary" }
        ]

        const paid = [

            { value: "", display: "All" },
            { value: "N", display: "No" },
            { value: "Y", display: "Yes" },
            { value: "P", display: "Partial" }
        ]

        let spiner = ''
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            )
        }

        let advaceSearch = (
            <React.Fragment>
               
                <div className="row-form">
                    <div className="mf-3">
                        <Label name="Enter Date From "></Label>
                        <div className="textBoxValidate">
                            <input
                                style={{
                                    width: "215px",
                                    marginLeft: "0px"
                                }}
                                className="myInput"
                                type="date"
                                name="entryDateFrom"
                                id="entryDateFrom"
                                value={addEnterFromDate}
                                onChange={this.handleChange}
                            ></input>
                        </div>
                    </div>
                    <div className="mf-3">
                        <Label name="Enter Date To"></Label>


                        <div className="textBoxValidate">
                            <input
                                style={{
                                    width: "215px",
                                    marginLeft: "0px"
                                }}
                                className="myInput"
                                type="date"
                                name="entryDateTo"
                                id="entryDateTo"
                                value={addEnterToDate}
                                onChange={this.handleChange}
                            ></input>
                        </div>

                    </div>
                    <div className="mf-3">
                        <Label name="Batch #"></Label>
                        <Input
                            type="text"
                            name="batchID"
                            id="batchID"
                            value={this.state.searchModel.batchID}
                            onChange={event => this.handleChange}
                        ></Input>
                    </div>
                    <div className="mf-3">
                        <label>Insurance Type</label>
                        <select name="insuranceType" id="insuranceType" value={this.state.searchModel.insuranceType} onChange={this.handleChange}>
                            {insType.map(s => (
                                <option key={s.value} value={s.value}>
                                    {s.display}
                                </option>
                            ))}
                        </select>
                    </div>

                </div>

                <div className="row-form">
                    <div className="mf-3">
                        <Label name="Practice"></Label>
                        <Input
                            type="text"
                            name="practice"
                            id="practice"
                            value={this.state.searchModel.practice}
                            onChange={event => this.handleChange}
                        ></Input>
                    </div>
                    <div className="mf-3">
                        <Label name="Location"></Label>
                        <Input
                            type="text"
                            name="Location"
                            id="Location"
                            value={this.state.searchModel.Location}
                            onChange={event => this.handleChange}
                        ></Input>
                    </div>
                    <div className="mf-3">
                        <Label name="Provider"></Label>
                        <Input
                            type="text"
                            name="provider"
                            id="provider"
                            value={this.state.searchModel.provider}
                            onChange={event => this.handleChange}
                        ></Input>
                    </div>

                    <div className="mf-3">
                        <label>Sub Type</label>
                        <select name="submissionType" id="submissionType" value={this.state.searchModel.submissionType} onChange={this.handleChange}>
                            {subType.map(s => (
                                <option key={s.value} value={s.value}>
                                    {s.display}
                                </option>
                            ))}
                        </select>
                    </div>

                </div>


                <div className="row-form">

                    <div className="mf-3">
                        <Label name="Plan"></Label>
                        <Input
                            type="text"
                            name="plan"
                            id="plan"
                            value={this.state.searchModel.plan}
                            onChange={event => this.handleChange}
                        ></Input>
                    </div>

                    <div className="mf-3">
                        <Label name="Payer ID"></Label>
                        <Input
                            type="text"
                            name="payerID"
                            id="payerID"
                            value={this.state.searchModel.payerID}
                            onChange={event => this.handleChange}
                            onKeyPress={event => this.handleNumericCheck(event)}
                        ></Input>
                    </div>
                    <div className="mf-3">
                        <label>Submitted</label>
                        <select name="isSubmitted" id="isSubmitted" value={this.state.searchModel.isSubmitted} onChange={this.handleChange}>
                            {submitted.map(s => (
                                <option key={s.value} value={s.value}>
                                    {s.display}
                                </option>
                            ))}
                        </select>

                    </div>
                    <div className="mf-3">

                        <label>Paid</label>
                        <select name="paid" id="paid" value={this.state.searchModel.paid} onChange={this.handleChange}>
                            {paid.map(s => (
                                <option key={s.value} value={s.value}>
                                    {s.display}
                                </option>
                            ))}
                        </select>

                    </div>
                </div>
            </React.Fragment>
        )

        let popup = ''

        if (this.state.showPopup) {
            popup = <NewCharge onClose={() => this.closeChargePopup} id={this.state.id}></NewCharge>
        } else if (this.state.popupName === 'practice') {
            popup = <NewPractice onClose={() => this.closePopup} id={this.state.id}></NewPractice>
        } else if (this.state.popupName === 'location') {
            popup = <NewLocation onClose={() => this.closePopup} id={this.state.id}></NewLocation>
        } else if (this.state.popupName === 'provider') {
            popup = <NewProvider onClose={() => this.closePopup} id={this.state.id}></NewProvider>
        } else if (this.state.popupName === 'insuranceplan') {
            popup = <NewInsurancePlan onClose={() => this.closePopup} id={this.state.id}></NewInsurancePlan>
        }else if (this.state.popupName === 'patient') {
             popup = (
                <GPopup
                  onClose={() => this.closePopup}
                  id={this.state.id}
                  popupName={this.state.popupName}
                ></GPopup>
              );
        }
        else
            popup = <React.Fragment></React.Fragment>


        return (
            <React.Fragment>
                 {spiner}
                <div>
                    <div>
                        <div>
                            <SearchHeading
                                heading="VISIT SEARCH"
                                handler={() => this.openVisitScreen(0)}
                            ></SearchHeading>

                            <div className="container-fluid">
                                <form
                                    onSubmit={event => {
                                        this.handleSearch(event);
                                    }}
                                >
                                    <div
                                        className="mainTable fullWidthTable"
                                        style={{ maxWidth: "1500px" }}
                                    >
                                        <div className="row-form">
                                            <div className="mf-3">
                                                <Label name="Account #"></Label>
                                                <Input
                                                    type="text"
                                                    name="accountNUm"
                                                    id="accountNUm"
                                                    value={this.state.searchModel.accountNUm}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>
                                            <div className="mf-3">
                                                <Label name="Last Name"></Label>
                                                <Input
                                                    type="text"
                                                    name="lastName"
                                                    id="lastName"
                                                    max="20"
                                                    value={this.state.searchModel.lastName}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>
                                            <div className="mf-3">
                                                <Label name="First Name"></Label>
                                                <Input
                                                    type="text"
                                                    name="firstName"
                                                    id="firstName"
                                                    max="20"
                                                    value={this.state.searchModel.firstName}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>

                                            <div className="mf-3">
                                                <Label name="Subscriber ID"></Label>
                                                <Input
                                                    type="text"
                                                    name="subscriberID"
                                                    id="subscriberID"
                                                    value={this.state.searchModel.subscriberID}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>
                                        </div>


                                        <div className="row-form">
                                            <div className="mf-3">
                                                <Label name="Visit #"></Label>
                                                <Input
                                                    type="text"
                                                    name="visitID"
                                                    id="visitID"
                                                    value={this.state.searchModel.visitID}
                                                    onChange={() => this.handleChange}
                                                    onKeyPress={event => this.handleNumericCheck(event)}
                                                ></Input>
                                            </div>
                                            <div className="mf-3">
                                                <Label name="Charge #"></Label>
                                                <Input
                                                    type="text"
                                                    name="chargeNum"
                                                    id="chargeNum"
                                                    value={this.state.searchModel.chargeNum}
                                                    onChange={() => this.handleChange}
                                                ></Input>
                                            </div>
                                            <div className="mf-3">
                                                <Label name="DOS from"></Label>
                                                <div className="textBoxValidate">
                                                    <input
                                                        style={{
                                                            width: "215px",
                                                            marginLeft: "0px"
                                                        }}
                                                        className="myInput"
                                                        type="date"
                                                        name="dosFrom"
                                                        id="dosFrom"
                                                        value={addDosFromDate}
                                                        onChange={this.handleChange}
                                                    ></input>
                                                </div>


                                            </div>
                                            <div className="mf-3">
                                                <Label name="DOS To"></Label>
                                                <div className="textBoxValidate ">
                                                    <input
                                                        style={{
                                                            width: "215px",
                                                            marginLeft: "0px"
                                                        }}
                                                        className="myInput"
                                                        type="date"
                                                        name="dosTo"
                                                        id="dosTo"
                                                        value={addDosToDate}
                                                        onChange={this.handleChange}
                                                    ></input>
                                                </div>
                                            </div>

                                        </div>

                                        {this.state.searchModel.isChecked ? advaceSearch : ""}


                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <label>
                                                    <Input type="checkbox"
                                                        checked={this.state.isChecked}
                                                        onChange={() => this.handleCheck}
                                                    />
                                                    Advance Search!
                                                   </label>
                                                <Input
                                                    type="submit"
                                                    name="search"
                                                    id="search"
                                                    className="btn-blue"
                                                    value="Search"
                                                ></Input>
                                                <Input
                                                    type="button"
                                                    name="clear"
                                                    id="clear"
                                                    value="Clear"
                                                    className="btn-grey"
                                                    onClick={event => this.clearFields(event)}
                                                ></Input>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div className="mf-12 table-grid mt-15">
                                <div className="row headingTable">
                                    <div className="mf-6">
                                        <h1>VISIT SEARCH RESULT</h1>
                                    </div>
                                    <div className="mf-6 headingRightTable">
                                        <a href="javascript:;">
                                            <img src="images/setting-icon.png" alt="" />
                                        </a>
                                    </div>
                                </div>

                                <div className="tableGridContainer">
                                    <MDBDataTable
                                        responsive
                                        striped
                                        bordered
                                        searching={false}
                                        data={tableData}
                                        displayEntries={false}
                                        sortable={true}
                                        scrollX={false}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {popup}

            </React.Fragment>
        );
    }
}


function mapStateToProps(state) {
    console.log("state from Header Page" , state);
    return {
        selectedTab: state.selectedTab !== null ? state.selectedTab.selectedTab : '',
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject:state.loginToken ? state.loginToken : { toekn:"" , isLogin : false},
        userInfo : state.loginInfo ? state.loginInfo : {userPractices : [] , name : "",practiceID:null}
    };
  }
  function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction , loginAction : loginAction  , selectTabAction : selectTabAction}, dispatch);
  }
  
  export default connect(mapStateToProps, matchDispatchToProps)(ChargeSearch);
