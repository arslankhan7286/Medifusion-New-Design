import React, { Component, Fragment } from "react";
import $ from "jquery";
import Eclips from '../images/loading_spinner.gif';
import GifLoader from 'react-gif-loader';

import taxonomyIcon from "../images/code-search-icon.png";
import axios from "axios";
import Input from "./Input";
import Swal from "sweetalert2";
import NewPatient from './NewPatient';
import NewVisit from './NewCharge';

class GPopup extends Component {
  constructor(props) {
    super(props);

    this.state = {
      editId: this.props.id ,
      popupName : this.props.popupName    
    };

  
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  componentDidMount() {
    this.setModalMaxHeight($(".modal"));
    // if ($('.modal.in').length != 0) {
    //     this.setModalMaxHeight($('.modal.in'));
    // }

    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function () {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

  }  

  render() {

    let popup="";
    if(this.state.popupName == "patient"){
        popup = <NewPatient popupPatientId = {this.state.editId} onClose={()=>this.props.onClose()}></NewPatient>
    }else if(this.state.popupName == "visit"){
        popup =  <NewVisit popupVisitId = {this.state.editId} onClose={()=>this.props.onClose()}></NewVisit>
    }else if(this.state.popupName == "batch"){
      popup =  <NewVisit popupVisitId = {this.state.editId} onClose={()=>this.props.onClose()}></NewVisit>
  }else{
      popup = ""
    }
   
    return (
      <React.Fragment>
        <div
          id="myModal1"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          aria-hidden="true"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            <button
              onClick={this.props.onClose()}
              type="button"
              className="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true"></span>
            </button>
            <div className="modal-content" style={{ overflow: "hidden" }}>             

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable">



                            {popup}
                   



                </div>

                {/* <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <button
                          className="btn-blue"
                          onClick={this.saveNewCPT}
                        >
                          Save{" "}
                        </button>
                        <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={this.props.onClose()}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default GPopup;
