import React, { Component } from 'react'


class Action extends Component {
    constructor(props) {
        super(props)

        this.state = {

        }
    }

    render() {
        return (
            <div>
<h1>net has been broken in pakistan
    
</h1>
            </div>
        )
    }
}

export default Action
