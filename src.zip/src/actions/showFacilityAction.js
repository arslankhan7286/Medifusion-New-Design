export const showFacilityAction = (id) => {

    return {
        type: 'SHOW_FACILITY',
        payload: id
    }
};