
export const userInfo = (userInfo) => {
    return {
        type: "USER_INFO",
        payload: {
            userInfo: userInfo,
            url: 'userInfo'
        }
    };

};