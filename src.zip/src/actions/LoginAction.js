import { statement, statements } from "@babel/template";

export const loginAction = (token, login = false) => {
    return {
        type: "LOGIN_ACTION",
        payload: {
            token: token,
            isLogin: login,
            url: 'hey'
        }
    };
};

export const userInfo = (userInfo) => {
    return {
        type: "USER_INFO",
        payload: {
            userInfo: userInfo,
            url: 'userInfo'
        }
    };
};





