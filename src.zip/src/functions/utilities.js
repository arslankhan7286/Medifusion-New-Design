

// replace(field, replaceWhat, replaceWith) {
//     console.log('dob: ' + field)
//     if (this.isNull(field))
//         return field;
//     else return field.replace(replaceWhat, replaceWith);
// }