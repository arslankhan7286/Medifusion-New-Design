import facilityIcon from '../images/facility-icon.png'
import facilityHIcon from '../images/facility-icon-hover.png'
import locationIcon from '../images/location-icon.png'
import locationHIcon from '../images/location-icon-hover.png'
import provIcon from '../images/provider-icon.png'
import provHIcon from '../images/provider-icon-hover.png'
import refprovIcon from '../images/referring-icon.png'
import refprovHIcon from '../images/referring-icon-hover.png'


export default function (state = [], action) {

    //alert(action.payload)
    console.log(action.payload)
    let lefNav = []

    let selectedTab = action.payload !== undefined ? action.payload.selectedTab : ''

    switch (selectedTab) {
        case 'Patient':
            break;

        case 'Reports':
            break;
            case 'Documents':
            break;

        case 'Submissions':
            //alert('submissions');
            break;

        case "CLIENT":
        case "USER":
        case "FACILITY":
        case "LOCATION":
        case "PROVIDER":
        case "REFERRING PROVIDER":
        case "INSURANCE":
        case "INSURANCE PLAN":
        case "INSURANCE PLAN ADDRESS":
        case "CPT":
        case "ICD":
        case "MODIFIERS":
        case "POS":
        case "EDI SUBMIT PAYER":
        case "EDI ELIGIBILITY PAYER":
        case "EDI STATUS PAYER":
        case "CLAIM STATUS CATEGORY CODES":
        case "CLAIM STATUS CODES":
        case "ADJUSTMENT CODES":
        case "REMARK CODES":
        case "Setup":
            lefNav = [
                {
                    Category: 'CLIEN SETUP', Icon: '', hIcon: '', expanded: true,
                    SubCategories: [{
                        SubCategory: 'Client', Icon: facilityIcon, hIcon: facilityHIcon, selected: selectedTab === 'CLIENT' ? true : false
                    }, {
                        SubCategory: 'User', Icon: locationIcon, hIcon: locationHIcon, selected: action.payload === 'USER' ? true : false
                    }]
                },
                {
                    Category: 'ADMIN', Icon: '', hIcon: '', expanded: false,
                    SubCategories: [{
                        SubCategory: 'Practice', Icon: facilityIcon, hIcon: facilityHIcon, selected: selectedTab === 'PRACTICE' ? true : false
                    }, {
                        SubCategory: 'Location', Icon: locationIcon, hIcon: locationHIcon, selected: action.payload === 'LOCATION' ? true : false
                    }, {
                        SubCategory: 'Provider', Icon: provIcon, hIcon: provHIcon, selected: false
                    }, {
                        SubCategory: 'Referring Provider', Icon: refprovIcon, hIcon: refprovHIcon, selected: false
                    }]
                }
                , {
                    Category: 'INSURANCE', Icon: '', handler: '', expanded: false,
                    SubCategories: [{
                        SubCategory: 'Insurance', Icon: facilityIcon, hIcon: facilityHIcon, selected: false
                    }, {
                        SubCategory: 'Insurance Plan', Icon: locationIcon, hIcon: locationHIcon, selected: false
                    }, {
                        SubCategory: 'Insurance Plan Address', Icon: provIcon, hIcon: provHIcon, selected: false
                    }, {
                        SubCategory: 'EDI Submit Payer', Icon: provIcon, hIcon: provHIcon, selected: false
                    }, {
                        SubCategory: 'EDI Eligibility Payer', Icon: provIcon, hIcon: provHIcon, selected: false
                    }, {
                        SubCategory: 'EDI Status Payer', Icon: provIcon, hIcon: provHIcon, selected: false
                    }]
                }, {
                    Category: 'CODING', Icon: '', handler: '', expanded: false,
                    SubCategories: [{
                        SubCategory: 'ICD', Icon: facilityIcon, hIcon: facilityHIcon, selected: false
                    }, {
                        SubCategory: 'CPT', Icon: locationIcon, hIcon: locationHIcon, selected: false
                    }, {
                        SubCategory: 'Modifiers', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('MODIFIER'), selected: false
                    }, {
                        SubCategory: 'POS', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('POS'), selected: false
                    }]
                }, {
                    Category: 'EDI CODES', Icon: '', handler: '', expanded: false,
                    SubCategories: [{
                        SubCategory: 'Claim Status Category Codes', Icon: facilityIcon, hIcon: facilityHIcon, handler: () => this.props.selectTabPageAction('CS_CAT_CODES'), selected: false
                    }, {
                        SubCategory: 'Claim Status Codes', Icon: locationIcon, hIcon: locationHIcon, handler: () => this.props.selectTabPageAction('CS_CODES'), selected: false
                    }, {
                        SubCategory: 'Adjustment Codes', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('ADJUSTMENT CODES'), selected: false
                    }, {
                        SubCategory: 'Remark Codes', Icon: provIcon, hIcon: provHIcon, handler: () => this.props.selectTabPageAction('REMARK_CODES'), selected: false
                    }]
                }
            ]

            break;
    }

    //console.log(lefNav)
    return lefNav
}


