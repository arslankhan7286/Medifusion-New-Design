import { combineReducers } from 'redux'
import userReducer from './reducer-user'
import ActiveUserReducer from './reducer-active-user'
import selectedTabReducer from './selectedTabReducer'
import selectedTabPageReducer from './selectedTabPageReducer'
import showPracticeReducer from './showPracticeReducer'
import leftNavMenusReducer from './leftNavMenusReducer'
import LoginReducer from './LoginReducer';
import LoginInfoReducer from './LoginInfoReducer';



const allReducers = combineReducers({
    // users: userReducer,
    // activeUser: ActiveUserReducer,
    loginToken : LoginReducer,
    loginInfo : LoginInfoReducer,
    selectedTab: selectedTabReducer,
    selectedTabPage: selectedTabPageReducer,
    //selectedPopup: showPracticeReducer,
    leftNavigationMenus: leftNavMenusReducer,
    url: 'http://192.168.110.44/database/api'
});


export default allReducers;