export default function (state = null, action) {

    console.log("Action In Reducer : " , action)
    switch (action.type) {
        case "CLIENT":
        case "USER":
        case "PRACTICE":
        case "LOCATION":
        case "PROVIDER":
        case "REFERRING PROVIDER":
        case "INSURANCE":
        case "INSURANCE PLAN":
        case "INSURANCE PLAN ADDRESS":
        case "ICD":
        case "CPT":
        case "MODIFIERS":
        case "POS":
        case "CLAIM STATUS CATEGORY CODES":
        case "CLAIM STATUS CODES":
        case "REMIT CODES":
        case "REMARK CODES":
        case "EDI SUBMIT PAYER":
        case "EDI ELIGIBILITY PAYER":
        case "EDI STATUS PAYER":
        case "ELECTRONIC SUBMISSION":
        case "PAPER SUBMISSION":
        case "SUBMISSION LOG":
        case "DEMOGRAPHICS":
        case "PLAN":
            case "PAYMENT":
        case "NEWCHARGE":
        case "CHARGE":
        case "HCFA1500":
        case "Visit":
                case "PLAN FOLLOW UP":
                        case "PATIENT FOLLOW UP":
                        case "GROUP":
                        case "ACTION":
                        case "REASON":
                            case "BATCHDOCUMENT":
                                    case "DOCUMENTTYPE":
                                        case "USER_INFO":
            // return {
            //     ...state,
            //     payload: action.payload
            // }
            return action.payload;
            break;
    }
    return state;
}


