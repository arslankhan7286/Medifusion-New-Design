export default function (state = null, action) {
    switch (action.type) {
           case "USER_INFO":
                return action.payload;
                break;
    }
    console.log("State Form Login Info Reducer");
    return state;
}