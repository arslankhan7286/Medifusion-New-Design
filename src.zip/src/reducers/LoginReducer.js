export default function (state = null, action) {
    switch (action.type) {
        case "LOGIN_ACTION":
            return action.payload;
            break;
    }
    console.log("State Form Login Action Reducer");
    return state;
}