export default function () {
    return [{
        id: 1,
        first: 'aziz',
        last: 'ullah',
        age: 29
    }, {
        id: 2,
        first: 'afzal',
        last: 'ahmed',
        age: 29
    }

    ]
}