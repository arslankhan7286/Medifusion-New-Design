import React, { Component, Fragment } from "react";
import $ from "jquery";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import taxonomyIcon from "../images/code-search-icon.png";
import axios from "axios";
import Input from "./Input";
import leftNavMenusReducer from "../reducers/leftNavMenusReducer";
import Swal from "sweetalert2";
import {
  MDBDataTable,
  MDBBtn,
  MDBTableHead,
  MDBTableBody,
  MDBTable
} from "mdbreact";
import GridHeading from "./GridHeading";
import { Tabs, Tab } from "react-tab-view";
import Dropdown from "react-dropdown";
import settingsIcon from "../images/setting-icon.png";
import NewHistoryPractice from "./NewHistoryPractice";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { log } from "util";

import Hotkeys from "react-hot-keys";

export class NewSubmitter extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/Submitter/";
    // this.accountUrl = process.env.REACT_APP_URL + "/account/";
    this.zipURL = process.env.REACT_APP_URL + "/Common/";

    this.errorField = "errorField";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.saveSubmitterCount = 0;

    this.SubmitterModal = {
      id: 0,
      name: null,
      address: null,
      city: null,
      state: null,
      zipCode: null,
      email: null,
      submissionUserName: null,
      submissionPassword: null,
      manualSubmission: false,
      fileName: null,
      x12_837_NM1_41_SubmitterName: null,
      x12_837_NM1_41_SubmitterID: null,
      x12_837_ISA_02: "00",
      x12_837_ISA_04: "00",
      x12_837_ISA_06: "ZZ",
      x12_837_GS_02: null,
      submitterContactPerson: null,
      submitterContactNumber: null,
      submitterEmail: null,
      submitterFaxNumber: null,

      x12_270_NM1_41_SubmitterName: null,
      x12_270_NM1_41_SubmitterID: null,
      x12_270_ISA_02: null,
      x12_270_ISA_04: null,
      x12_270_ISA_06: null,
      x12_270_GS_02: null,

      // {SAQIB}

      x12_276_NM1_41_SubmitterName: null,
      x12_276_NM1_41_SubmitterID: null,
      x12_276_ISA_02: null,
      x12_276_ISA_04: null,
      x12_276_ISA_06: null,
      x12_276_GS_02: null,
      receiverID: 0,
      clientID: 0,
      addedBy: null,
      addedDate: "0001-01-01T00:00:00",
      updatedBy: null,
      updatedDate: null,
      isActive: false,
      receiverID: "",
      address: null,
      address2: null,
      phoneNumber: null,
      faxNumber: null,
      email: null,
      website: null
    };
    this.searchModel = {
      name: "",
      organizationName: "",
      address: "",
      receiverID: null,
      isChecked: false,
      active: false
    };

    this.validationModel = {
      nameValField: "",
      receiverValField: "",
      organizationNameValField: "",
      npiValField: "",
      taxIDValField: "",
      taxonomyCodeValField: "",
      cliaNumberValField: "",
      address1ValField: "",
      address2ValField: "",
      cityValField: "",
      stateValField: "",
      zipCodeValField: "",
      officePhoneNumValField: "",
      emailValField: "",
      websiteValField: "",
      faxNumberValField: "",
      payToAddress1ValField: "",
      payToAddress2ValField: "",
      payToCityValField: "",
      payToStateValField: "",
      payToZipCodeValField: "",
      notesValField: "",
      clientValField: "",
      validation: false,
      ssnValField: "",
      typeValField: "",
      x12_837_ISA_02ValField: "",
      x12_837_ISA_04ValField: "",
      x12_837_ISA_05ValField: "",
      x12_837_ISA_06ValField: "",

      x12_276_ISA_02ValField: "",
      x12_276_ISA_04ValField: "",
      x12_276_ISA_05ValField: "",
      x12_276_ISA_06ValField: "",

      x12_270_ISA_02ValField: "",
      x12_270_ISA_04ValField: "",
      x12_270_ISA_05ValField: "",
      x12_270_ISA_06ValField: ""
    };

    this.state = {
      editId: this.props.SubmitterID,
      SubmitterModal: this.SubmitterModal,
      validationModel: this.validationModel,
      maxHeight: "361",
      loading: false,
      ReceiverName: [],
      typePractice: false,
      typeValue: "",
      type: ""
    };

    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.SaveSubmitter = this.SaveSubmitter.bind(this);
    //this.handleSameAsAddress = this.handleSameAsAddress.bind(this);
    this.delete = this.delete.bind(this);
    this.handleChangeType = this.handleChangeType.bind(this);
    this.handleZip = this.handleZip.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    console.log("test:onKeyDown", keyName, e, handle);

    if (keyName == "alt+s") {
      // alert("save key")
      this.SaveSubmitter();
      console.log(e.which);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    console.log("test:onKeyUp", e, handle);
    if (e) {
      console.log("event has been called", e);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  async componentDidMount() {
    this.setState({ loading: true });
    await axios
      .get(this.url + "GetProfiles", this.config)
      .then(response => {
        console.log("Get Profile Receiver : ", response.data.receiver);
        this.setState({ ReceiverName: response.data.receiver });
        console.log("RecieverName", this.state.ReceiverName);
      })
      .catch(error => {
        this.setState({ loading: false });
        if (error.response) {
          if (error.response.status) {
            //Swal.fire("Unauthorized Access" , "" , "error");
            console.log(error.response.status);
            return;
          }
        } else if (error.request) {
          console.log(error.request);
          return;
        } else {
          console.log("Error", error.message);
          console.log(JSON.stringify(error));
          //Swal.fire("Something went Wrong" , "" , "error");
          return;
        }

        console.log(error);
      });
    console.log("Edit Id", this.state.editID);
    //Location
    if (this.state.editId > 0) {
      await axios

        .get(this.url + "FindSubmitter/" + this.state.editId, this.config)
        .then(response => {
          // let arrayToPush = [];

          // const pushToProvider = [];
          console.log(
            "response of findReciver in New Reciver Tab:",
            response.data
          );
          this.setState({ SubmitterModal: response.data });
        })
        .catch(error => {
          this.setState({ loading: false });
          if (error.response) {
            if (error.response.status) {
              Swal.fire("Unauthorized Access", "", "error");
            }
          } else if (error.request) {
            console.log(error.request);
          } else {
            console.log("Error", error.message);
          }
          console.log(JSON.stringify(error));
        });
    }

    await this.setModalMaxHeight($(".modal"));
    // if ($('.modal.in').length != 0) {
    //     this.setModalMaxHeight($('.modal.in'));
    // }
    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function () {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    this.setState({ loading: false });
  }
  handleSameAsAddress = event => { };

  handleZip(event) {
    var zip = event.target.value;
    console.log(zip);

    this.setState({
      SubmitterModal: {
        ...this.state.SubmitterModal,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });

    if (zip.length >= 5 && zip.length <= 9) {
      axios
        .get(this.zipURL + "GetCityStateInfo/" + zip, this.config)
        .then(response => {
          console.log("ZIP Codes Search Response : ", response.data);
          this.setState({
            SubmitterModal: {
              ...this.state.SubmitterModal,
              city: response.data.city.toUpperCase(),
              state: response.data.state_id
            }
          });
          console.log("Model of zip Code", this.state.SubmitterModal);
        })
        .catch(error => {
          this.setState({ loading: false });

          Swal.fire(
            "Something Wrong",
            "Please Check Server Connection",
            "error"
          );
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
            console.log(errorsList);
          } else console.log(error);
        });
    } else {
      // Swal.fire("Enter Valid Zip Code", "", "error");
      console.log("Zip Code length should be 5");
    }
  }

  handleChangePasswprd = event => {
    event.preventDefault();
    this.setState({
      SubmitterModal: {
        ...this.state.SubmitterModal,

        [event.target.name]: event.target.value
      }
    });
  };

  handleChange = event => {
    event.preventDefault();
    this.setState({
      SubmitterModal: {
        ...this.state.SubmitterModal,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  handleChangeType = event => {
    this.setState({
      typePractice: true,
      type: event.target.value,
      // type: event.target.value
      SubmitterModal: {
        ...this.state.SubmitterModal,
        [event.target.name]: event.target.value
      }
    });
  };

  handleCheck() {
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        active: !this.state.searchModel.active,

        isChecked: !this.state.searchModel.isChecked
      }
    });
  }

  handleCheckSubmission = () => {
    //  isChecked: !this.state.SubmitterModal.isChecked

    this.setState({
      SubmitterModal: {
        ...this.state.SubmitterModal,
        manualSubmission: !this.state.SubmitterModal.manualSubmission
      }
    });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  isNull(value) {
    if (value === "" || value === null || value === undefined) return true;
    else return false;
  }

  SaveSubmitter = e => {
    console.log("Before Update", this.saveSubmitterCount);
    if (this.saveSubmitterCount == 1) {
      return;
    }
    this.saveSubmitterCount = 1;
    if (this.state.loading == true) {
      // this.saveSubmitterCount = 0;

      return;
    }
    console.log("AFter update", this.saveSubmitterCount);
    this.setState({ loading: true });

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.SubmitterModal.name)) {
      myVal.nameValField = <span className="validationMsg">Enter Name</span>;
      myVal.validation = true;
    } else {
      myVal.nameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.SubmitterModal.receiverID)) {
      myVal.receiverValField = (
        <span className="validationMsg">Please Select Receiver Id</span>
      );
      myVal.validation = true;
    } else {
      myVal.nameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    // if (this.isNull(this.state.SubmitterModal.x12_837_ISA_01) == false) {
    //   if (this.state.SubmitterModal.x12_837_ISA_01.length < 2) {
    //     myVal.x12_837_ISA_02ValField = (
    //       <span className="validationMsg">ISA-01 length should be 2</span>
    //     );
    //     myVal.validation = true;
    //   } else {
    //     myVal.x12_837_ISA_02ValField = "";
    //     if (myVal.validation === false) myVal.validation = false;
    //   }
    // } else {
    //   myVal.x12_837_ISA_02ValField = "";
    //   if (myVal.validation === false) myVal.validation = false;
    // }

    // if (this.isNull(this.state.SubmitterModal.x12_837_ISA_03) == false) {
    //   if (this.state.SubmitterModal.x12_837_ISA_03.length < 2) {
    //     myVal.x12_837_ISA_02ValField = (
    //       <span className="validationMsg">ISA-03 length should be 2</span>
    //     );
    //     myVal.validation = true;
    //   } else {
    //     myVal.x12_837_ISA_04ValField = "";
    //     if (myVal.validation === false) myVal.validation = false;
    //   }
    // } else {
    //   myVal.x12_837_ISA_04ValField = "";
    //   if (myVal.validation === false) myVal.validation = false;
    // }

    if (this.isNull(this.state.SubmitterModal.x12_837_ISA_07) == false) {
      if (this.state.SubmitterModal.x12_837_ISA_07.length < 2) {
        myVal.x12_837_ISA_05ValField = (
          <span className="validationMsg">ISA-07 length should be 2</span>
        );
        myVal.validation = true;
      } else {
        myVal.x12_837_ISA_05ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.x12_837_ISA_05ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.SubmitterModal.x12_270_ISA_01) == false) {
      if (this.state.SubmitterModal.x12_270_ISA_01.length < 2) {
        myVal.x12_270_ISA_02ValField = (
          <span className="validationMsg">ISA-07 length should be 2</span>
        );
        myVal.validation = true;
      } else {
        myVal.x12_270_ISA_02ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.x12_270_ISA_02ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.SubmitterModal.x12_270_ISA_03) == false) {
      if (this.state.SubmitterModal.x12_270_ISA_03.length < 2) {
        myVal.x12_270_ISA_04ValField = (
          <span className="validationMsg">ISA-03 length should be 2</span>
        );
        myVal.validation = true;
      } else {
        myVal.x12_270_ISA_04ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.x12_270_ISA_04ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.SubmitterModal.x12_270_ISA_07) == false) {
      if (this.state.SubmitterModal.x12_270_ISA_07.length < 2) {
        myVal.x12_270_ISA_05ValField = (
          <span className="validationMsg">ISA-07 length should be 2</span>
        );
        myVal.validation = true;
      } else {
        myVal.x12_270_ISA_05ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.x12_270_ISA_05ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.SubmitterModal.x12_276_ISA_01) == false) {
      if (this.state.SubmitterModal.x12_276_ISA_01.length < 2) {
        myVal.x12_276_ISA_02ValField = (
          <span className="validationMsg">ISA-01 length should be 2</span>
        );
        myVal.validation = true;
      } else {
        myVal.x12_276_ISA_02ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.x12_276_ISA_02ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.SubmitterModal.x12_276_ISA_03) == false) {
      if (this.state.SubmitterModal.x12_276_ISA_03.length < 2) {
        myVal.x12_276_ISA_04ValField = (
          <span className="validationMsg">ISA-03 length should be 2</span>
        );
        myVal.validation = true;
      } else {
        myVal.x12_276_ISA_04ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.x12_276_ISA_04ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.SubmitterModal.x12_276_ISA_07) == false) {
      if (this.state.SubmitterModal.x12_276_ISA_07.length < 2) {
        myVal.x12_276_ISA_05ValField = (
          <span className="validationMsg">ISA-07 length should be 2</span>
        );
        myVal.validation = true;
      } else {
        myVal.x12_276_ISA_05ValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.x12_276_ISA_05ValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.SubmitterModal.zipCode) === false &&
      this.state.SubmitterModal.zipCode.length > 0
    ) {
      if (this.state.SubmitterModal.zipCode.length < 5) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of alleast 5 digits
          </span>
        );
        myVal.validation = true;
      } else if (
        this.state.SubmitterModal.zipCode.length > 5 &&
        this.state.SubmitterModal.zipCode.length < 9
      ) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of either 5 or 9 digits
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.zipCodeValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.zipCodeValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }
    console.log("ReportingTo");

    if (
      this.isNull(this.state.SubmitterModal.fax) === false &&
      this.state.SubmitterModal.fax.length < 10
    ) {
      myVal.faxNumberValField = (
        <span className="validationMsg">Fax # length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.faxNumberValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.SubmitterModal.phoneNumber) === false &&
      this.state.SubmitterModal.phoneNumber.length < 10
    ) {
      myVal.officePhoneNumValField = (
        <span className="validationMsg">Phone # length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.officePhoneNumValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }
    myVal.emailValField = "";
    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      this.saveSubmitterCount = 0;

      return;
    }

    console.log("SubmitterModal::>>", this.state.SubmitterModal);
    var config = {
      headers: { Authorization: "Bearer  " + this.props.loginObject.token }
    };

    axios
      .post(this.url + "SaveSubmitter", this.state.SubmitterModal, config)
      .then(response => {
        console.log("Response Data of SaveSubmitter : ", response);
        this.saveSubmitterCount = 0;
        this.setState({ SubmitterModal: response.data, loading: false });
        Swal.fire("Record Saved Successfully", "", "success");
      })
      .catch(error => {
        this.saveSubmitterCount = 0;

        console.log(error);
        this.setState({ loading: false });
        try {
          if (error.response) {
            if (error.response.status) {
              if (error.response.status == 401) {
                Swal.fire("Unauthorized Access", "", "error");
                return;
              } else if (error.response.status == 400) {
                Swal.fire(
                  "Bad Request",
                  "Failed With Status Code 400",
                  "error"
                );
                return;
              } else if (error.response.status == 404) {
                Swal.fire("Not Found", "Failed With Status Code 404", "error");
                return;
              }
            }
          } else {
            console.log("Error", error.message);
            Swal.fire("Something went Wrong", "", "error");
            return;
          }

          if (error.response.data.Email[0] == "Please enter Valid Email ID") {
            //Swal.fire("Something Wrong", error.response.data.Email[0], "error");
            myVal.emailValField = (
              <span className="validationMsg">Please enter Valid Email ID</span>
            );
            myVal.validation = true;
          } else {
            myVal.emailValField = "";
            if (myVal.validation === false) myVal.validation = false;
          }
          this.setState({
            validationModel: myVal
          });
        } catch { }
      });
    if (this.state.loading == true) {
      return;
    }

    this.setState({ loading: true });

    console.log(this.state.SubmitterModal);
  };

  delete = e => {
    var config = {
      headers: { Authorization: "Bearer  " + this.props.loginObject.token }
    };

    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.setState({ loading: true });
        axios
          .delete(this.url + "DeleteSubmitter/" + this.state.editId, config)
          .then(response => {
            this.setState({ loading: false });
            console.log("Delete Response :", response);
            Swal.fire("Record Deleted Successfully", "", "success");
          })
          .catch(error => {
            this.setState({ loading: false });
            if (this.state.editId > 0) {
              Swal.fire(
                "Record Not Deleted!",
                "Record can not be delete, as it is being reference in other screens.",
                "error"
              );
            } else {
              Swal.fire(
                "Record Not Deleted!",
                "Don't have record to delete",
                "error"
              );
            }
            if (error.response) {
              if (error.response.status) {
                Swal.fire("Unauthorized Access", "", "error");
              }
            } else if (error.request) {
              console.log(error.request);
            } else {
              console.log("Error", error.message);
            }
            console.log(JSON.stringify(error));
          });

        $("#btnCancel").click();
      }
    });
  };
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  openhistorypopup = id => {
    this.setState({ showPopup: true, id: id });
  };
  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  render() {
    const SubmissionDD = [
      { value: "", display: "Select Type" },
      { value: "SFTP", display: "SFTP" },
      { value: "FTP", display: "FTP" }
    ];

    const headers = ["Location", "Provider", "Referring Providers"];

    const locationData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "ORGANIZATION NAME",
          field: "organizationName",
          sort: "asc",
          width: 300
        },
        {
          label: "PRACTICE",
          field: "practice",
          sort: "asc",
          width: 250
        },

        {
          label: "NPI",
          field: "npi",
          sort: "asc",
          width: 200
        },
        {
          label: "PASCODE",
          field: "pascode",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDRESS",
          field: "address",
          sort: "asc",
          width: 100
        }
      ],
      rows: this.state.locationData
    };
    const providerData = {
      columns: [
        {
          label: "ID",
          field: "Id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          width: 150
        },
        {
          label: "FIRST NAME ",
          field: "firstName",
          sort: "asc",
          width: 150
        },
        {
          label: "NPI",
          field: "npi",
          sort: "asc",
          width: 150
        },

        {
          label: "SSN",
          field: "ssn",
          sort: "asc",
          width: 150
        },
        {
          label: "TEXONOMY CODE",
          field: "texonomycode",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDRESS ,CITY, STATE, ZIP",
          field: "address",
          sort: "asc",
          width: 150
        },
        {
          label: "OFFICE PHONE#",
          field: "phone",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.providerData
    };
    const RefProviderData = {
      columns: [
        {
          label: "ID",
          field: "referingId",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "referingName",
          sort: "asc",
          width: 150
        },
        {
          label: "LAST NAME",
          field: "rLastName",
          sort: "asc",
          width: 150
        },
        {
          label: "FIRST NAME ",
          field: "rFirstName",
          sort: "asc",
          width: 150
        },
        {
          label: "NPI",
          field: "referingNpi",
          sort: "asc",
          width: 150
        },

        {
          label: "SSN",
          field: "referingSsn",
          sort: "asc",
          width: 150
        },
        {
          label: "TEXONOMY CODE",
          field: "referingTexonomy",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDRESS ,CITY, STATE, ZIP",
          field: "referingAddress",
          sort: "asc",
          width: 150
        },
        {
          label: "OFFICE PHONE#",
          field: "referingPhone",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.RefProviderData
    };

    const type = [
      { value: "", display: "Select Type" },
      { value: "SP", display: "Solo Practice" },
      { value: "GP", display: "Group Practice" }
    ];
    const usStates = [
      { value: "", display: "Select State" },
      { value: "AL", display: "AL - Alabama" },
      { value: "AK", display: "AK - Alaska" },
      { value: "AZ", display: "AZ - Arizona" },
      { value: "AR", display: "AR - Arkansas" },
      { value: "CA", display: "CA - California" },
      { value: "CO", display: "CO - Colorado" },
      { value: "CT", display: "CT - Connecticut" },
      { value: "DE", display: "DE - Delaware" },
      { value: "FL", display: "FL - Florida" },
      { value: "GA", display: "GA - Georgia" },
      { value: "HI", display: "HI - Hawaii" },
      { value: "ID", display: "ID - Idaho" },
      { value: "IL", display: "IL - Illinois" },
      { value: "IN", display: "IN - Indiana" },
      { value: "IA", display: "IA - Iowa" },
      { value: "KS", display: "KS - Kansas" },
      { value: "KY", display: "KY - Kentucky" },
      { value: "LA", display: "LA - Louisiana" },
      { value: "ME", display: "ME - Maine" },
      { value: "MD", display: "MD - Maryland" },
      { value: "MA", display: "MA - Massachusetts" },
      { value: "MI", display: "MI - Michigan" },
      { value: "MN", display: "MN - Minnesota" },
      { value: "MS", display: "MS - Mississippi" },
      { value: "MO", display: "MO - Missouri" },
      { value: "MT", display: "MT - Montana" },
      { value: "NE", display: "NE - Nebraska" },
      { value: "NV", display: "NV - Nevada" },
      { value: "NH", display: "NH - New Hampshire" },
      { value: "NJ", display: "NJ - New Jersey" },
      { value: "NM", display: "NM - New Mexico" },
      { value: "NY", display: "NY - New York" },
      { value: "NC", display: "NC - North Carolina" },
      { value: "ND", display: "ND - North Dakota" },
      { value: "OH", display: "OH - Ohio" },
      { value: "OK", display: "OK - Oklahoma" },
      { value: "OR", display: "OR - Oregon" },
      { value: "PA", display: "PA - Pennsylvania" },
      { value: "RI", display: "RI - Rhode Island" },
      { value: "SC", display: "SC - South Carolina" },
      { value: "SD", display: "SD - South Dakota" },
      { value: "TN", display: "TN - Tennessee" },
      { value: "TX", display: "TX - Texas" },
      { value: "UT", display: "UT - Utah" },
      { value: "VT", display: "VT - Vermont" },
      { value: "VA", display: "VA - Virginia" },
      { value: "WA", display: "WA - Washington" },
      { value: "WV", display: "WV - West Virginia" },
      { value: "WI", display: "WI - Wisconsin" },
      { value: "WY", display: "WY - Wyoming" }
    ];

    const isActive = this.state.SubmitterModal.isActive;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <GifLoader
          loading={true}
          imageSrc={Eclips}
          overlayBackground="rgba(0,0,0,0.5)"
        />
      );
    }

    const options = [
      { value: "History", label: "History", className: "dropdown" }
    ];

    var Imag;
    Imag = (
      <div>
        <img src={settingsIcon} />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup(0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
        // disabled={this.isDisabled(this.props.rights.update)}
        // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    let typeValuefield = "";
    if (
      this.state.typePractice === true &&
      this.state.SubmitterModal.type == "SP"
    ) {
      //  alert("Hi:True" + this.state.typeValue)

      typeValuefield = (
        <div className="row-form">
          <div className="mf-6">
            <label>
              SSN <span className="redlbl"> *</span>
            </label>
            <div className="textBoxValidate">
              <Input
                className={
                  this.state.validationModel.npiValField ? this.errorField : ""
                }
                type="text"
                value={this.state.SubmitterModal.ssn}
                name="ssn"
                id="ssn"
                max="9"
                onChange={() => this.handleChange}
                onKeyPress={event => this.handleNumericCheck(event)}
              />
              {/* <Input name="ssn" id="ssn" max='9'/> */}
              {this.state.validationModel.ssnValField}
            </div>
          </div>
          <div className="mf-6"></div>
        </div>
      );
    } else {
      //alert("Hi:False" + this.state.typeValue)
    }

    return (
      <React.Fragment>
        <div
          id="myModal"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={
                  this.props.onClose
                    ? this.props.onClose()
                    : () => this.props.onClose()
                }
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {/* <h1 className="modal-title"> {this.state.editId > 0 ? this.state.SubmitterModal.code :  "NEW  RECEIVER CODES"}</h1> */}

                        {this.state.receiverID > 0
                          ? this.state.SubmitterModal.name.toUpperCase() +
                          " - " +
                          this.state.SubmitterModal.id
                          : "NEW SUBMITTER"}
                      </h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkbox"
                          checked={!isActive}
                          id="isActive"
                          name="isActive"
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                        disabled={this.isDisabled(this.props.rights.delete)}
                      >
                        Delete
                      </Input>
                      {this.state.editId > 0 ? dropdown : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable">
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        Name
                        <span className="redlbl"> *</span>
                      </label>

                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.nameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.SubmitterModal.name}
                          name="name"
                          id="name"
                          max="30"
                          onChange={() => this.handleChange}
                        />

                        {this.state.validationModel.nameValField}
                      </div>
                    </div>

                    <div className="mf-6">
                      <div className="twoColValidate">
                        <label>
                          {" "}
                          Receiver
                          <span className="redlbl"> *</span>
                        </label>
                        <select
                          className={
                            this.state.validationModel.receiverValField
                              ? this.errorField
                              : ""
                          }
                          name="receiverID"
                          id="receiverID"
                          value={this.state.SubmitterModal.receiverID}
                          onChange={this.handleChange}
                        >
                          {this.state.ReceiverName.map(s => (
                            <option key={s.id} value={s.id}>
                              {s.description}
                            </option>
                          ))}
                        </select>
                        <div className="textBoxValidate">
                          {" "}
                          {this.state.validationModel.receiverValField}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="mf-12 headingOne mt-25">
                    <p>Address Information</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Address 1</label>
                      <Input
                        type="text"
                        value={this.state.SubmitterModal.address}
                        name="address"
                        id="address"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Address 2</label>
                      <Input
                        type="text"
                        value={this.state.SubmitterModal.address2}
                        name="address2"
                        id="address2"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>City - State</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.cityValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.city}
                            name="city"
                            id="city"
                            max="20"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.cityValField}
                        </div>

                        <div className="twoColValidate">
                          <select
                            name="state"
                            id="state"
                            value={this.state.SubmitterModal.state}
                            onChange={this.handleChange}
                          >
                            {usStates.map(s => (
                              <option key={s.value} value={s.value}>
                                {s.display}
                              </option>
                            ))}
                          </select>
                          {this.state.validationModel.stateValField}
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Zip Code - Fax</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.zipCodeValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.zipCode}
                            max="9"
                            name="zipCode"
                            id="zipCode"
                            onChange={() => this.handleZip}
                            onKeyPress={event => this.handleNumericCheck(event)}
                          />
                          {this.state.validationModel.zipCodeValField}
                        </div>

                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.faxNumberValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.faxNumber}
                            max="10"
                            name="faxNumber"
                            id="faxNumber"
                            onChange={() => this.handleChange}
                            onKeyPress={event => this.handleNumericCheck(event)}
                          />
                          {this.state.validationModel.faxNumberValField}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div className="twoColValidate">
                        <label> Phone</label>
                        <Input
                          className={
                            this.state.validationModel.officePhoneNumValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.SubmitterModal.phoneNumber}
                          max="10"
                          name="phoneNumber"
                          id="phoneNumber"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        />
                        <div className="textBoxValidate">
                          {" "}
                          {this.state.validationModel.officePhoneNumValField}
                        </div>
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>Website</label>
                      <div className="twoColValidate">
                        <Input
                          className={
                            this.state.validationModel.websiteValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.SubmitterModal.website}
                          name="website"
                          id="website"
                          max="50"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.websiteValField}
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label> Email</label>
                      <Input
                        className={
                          this.state.validationModel.emailValField
                            ? this.errorField
                            : ""
                        }
                        type="text"
                        value={this.state.SubmitterModal.email}
                        name="email"
                        id="email"
                        max="60"
                        onChange={() => this.handleChange}
                      />
                      <div className="textBoxValidate">
                        {this.state.validationModel.emailValField}
                      </div>
                    </div>

                    <div className="mf-6 "></div>
                  </div>
                  {/* saqib */}

                  <div className="mf-12 headingOne mt-25">
                    <p>EDI 837 Values</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Submitter Name</label>
                      <Input
                        type="text"
                        value={
                          this.state.SubmitterModal.x12_837_NM1_41_SubmitterName
                        }
                        name="x12_837_NM1_41_SubmitterName"
                        id="x12_837_NM1_41_SubmitterName"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Submitter ID</label>
                      <Input
                        type="text"
                        value={
                          this.state.SubmitterModal.x12_837_NM1_41_SubmitterID
                        }
                        name="x12_837_NM1_41_SubmitterID"
                        id="x12_837_NM1_41_SubmitterID"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Contact Person </label>

                      <Input
                        type="text"
                        value={this.state.SubmitterModal.submitterContactPerson}
                        name="submitterContactPerson"
                        id="submitterContactPerson"
                        max="30"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Contact #</label>
                      <Input
                        type="text"
                        value={this.state.SubmitterModal.submitterContactNumber}
                        name="submitterContactNumber"
                        id="submitterContactNumber"
                        max="10"
                        onChange={() => this.handleChange}
                        onKeyPress={event => this.handleNumericCheck(event)}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>Email</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <Input
                          type="text"
                          value={this.state.SubmitterModal.submitterEmail}
                          name="submitterEmail"
                          id="submitterEmail"
                          max="60"
                          onChange={() => this.handleChange}
                        />
                        <div className="textBoxValidate">
                          {this.state.validationModel.emailValField}
                        </div>
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>Fax #</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <Input
                          type="text"
                          value={this.state.SubmitterModal.submitterFaxNumber}
                          max="9"
                          name="submitterFaxNumber"
                          id="submitterFaxNumber"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>ISA02 - ISA04</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_270_ISA_02ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_837_ISA_02}
                            max="10"
                            name="x12_837_ISA_02"
                            id="x12_837_ISA_02"
                            onChange={() => this.handleChange}
                          />
                          {/* {this.state.validationModel.x12_270_ISA_02ValField} */}
                        </div>

                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_837_ISA_04ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_837_ISA_04}
                            max="10"
                            name="x12_837_ISA_04"
                            id="x12_837_ISA_04"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.x12_837_ISA_04ValField}
                        </div>
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>ISA05 - ISA06</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_837_ISA_05ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_837_ISA_05}
                            max="2"
                            name="x12_837_ISA_05"
                            id="x12_837_ISA_05"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.x12_837_ISA_05ValField}
                        </div>

                        <div className="twoColValidate">
                          <Input
                            type="text"
                            value={this.state.SubmitterModal.x12_837_ISA_06}
                            max="15"
                            name="x12_837_ISA_06"
                            id="x12_837_ISA_06"
                            onChange={() => this.handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>GS 02</label>
                      <div className="twoColValidate">
                        <Input
                          type="text"
                          value={this.state.SubmitterModal.x12_837_GS_02}
                          name="x12_837_GS_02"
                          id="x12_837_GS_02"
                          max="15"
                          onChange={() => this.handleChange}
                        />
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Submission User Name</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <Input
                          type="text"
                          value={this.state.SubmitterModal.submissionUserName}
                          name="submissionUserName"
                          id="submissionUserName"
                          max="55"
                          onChange={() => this.handleChange}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Submission Password</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <Input
                          type="text"
                          value={this.state.SubmitterModal.submissionPassword}
                          max="30"
                          name="submissionPassword"
                          id="submissionPassword"
                          onChange={() => this.handleChangePasswprd}
                        // onKeyPress={event => this.handleNumericCheck(event)}
                        />
                      </div>
                    </div>
                    <div className="mf-2"></div>
                    <div className="mf-4">
                      <div className="lblChkBox" style={{ width: "80px" }}>
                        <input
                          type="checkbox"
                          id="manualSubmission"
                          name="manualSubmission"
                          checked={this.state.SubmitterModal.manualSubmission}
                          onChange={this.handleCheckSubmission}
                        />
                        <label htmlFor="manualSubmission">
                          Manual Submission
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="mf-12 headingOne mt-25">
                    <p>EDI 270 Values</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Submitter Name</label>
                      <Input
                        type="text"
                        value={
                          this.state.SubmitterModal.x12_270_NM1_41_SubmitterName
                        }
                        name="x12_270_NM1_41_SubmitterName"
                        id="x12_270_NM1_41_SubmitterName"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Submitter ID</label>
                      <Input
                        type="text"
                        value={
                          this.state.SubmitterModal.x12_270_NM1_41_SubmitterID
                        }
                        name="x12_270_NM1_41_SubmitterID"
                        id="x12_270_NM1_41_SubmitterID"
                        max="10"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>ISA02 - ISA04</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_270_ISA_02ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_270_ISA_02}
                            max="10"
                            name="x12_270_ISA_02"
                            id="x12_270_ISA_02"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.x12_270_ISA_02ValField}
                        </div>

                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_270_ISA_04ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_270_ISA_04}
                            max="10"
                            name="x12_270_ISA_04"
                            id="x12_270_ISA_04"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.x12_270_ISA_04ValField}
                        </div>
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>ISA05 - ISA06</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_270_ISA_05ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_270_ISA_05}
                            max="2"
                            name="x12_270_ISA_05"
                            id="x12_270_ISA_05"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.x12_270_ISA_05ValField}
                        </div>

                        <div className="twoColValidate">
                          <Input
                            type="text"
                            value={this.state.SubmitterModal.x12_270_ISA_06}
                            max="15"
                            name="x12_270_ISA_06"
                            id="x12_270_ISA_06"
                            onChange={() => this.handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>GS 02</label>
                      <div className="twoColValidate">
                        <Input
                          type="text"
                          value={this.state.SubmitterModal.x12_270_GS_02}
                          name="x12_270_GS_02"
                          id="x12_270_GS_02"
                          max="15"
                          onChange={() => this.handleChange}
                        />
                      </div>
                    </div>
                    <div className="mf-6"></div>
                  </div>

                  {/* SAQIB */}
                  <div className="mf-12 headingOne mt-25">
                    <p>EDI 276 Values</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Submitter Name</label>
                      <Input
                        type="text"
                        value={
                          this.state.SubmitterModal.x12_276_NM1_41_SubmitterName
                        }
                        name="x12_276_NM1_41_SubmitterName"
                        id="x12_276_NM1_41_SubmitterName"
                        max="30"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Submitter ID</label>
                      <Input
                        type="text"
                        value={
                          this.state.SubmitterModal.x12_276_NM1_41_SubmitterID
                        }
                        name="x12_276_NM1_41_SubmitterID"
                        id="x12_276_NM1_41_SubmitterID"
                        max="10"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>ISA02 - ISA04</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_276_ISA_02ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_276_ISA_02}
                            max="10"
                            name="x12_276_ISA_02"
                            id="x12_276_ISA_02"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.x12_276_ISA_02ValField}
                        </div>

                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_276_ISA_04ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_276_ISA_04}
                            max="10"
                            name="x12_276_ISA_04"
                            id="x12_276_ISA_04"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.x12_276_ISA_04ValField}
                        </div>
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>ISA05 - ISA06</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.x12_276_ISA_05ValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.SubmitterModal.x12_276_ISA_05}
                            max="2"
                            name="x12_276_ISA_05"
                            id="x12_276_ISA_05"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.x12_276_ISA_05ValField}
                        </div>

                        <div className="twoColValidate">
                          <Input
                            type="text"
                            value={this.state.SubmitterModal.x12_276_ISA_06}
                            max="15"
                            name="x12_276_ISA_06"
                            id="x12_276_ISA_06"
                            onChange={() => this.handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>GS 02</label>
                      <div className="twoColValidate">
                        <Input
                          type="text"
                          value={this.state.SubmitterModal.x12_276_GS_02}
                          name="x12_276_GS_02"
                          id="x12_276_GS_02"
                          max="15"
                          onChange={() => this.handleChange}
                        />
                      </div>
                    </div>
                    <div className="mf-6"></div>
                  </div>
                </div>

                <div>
                  <div className="modal-footer">
                    <div className="mainTable">
                      <div className="row-form row-btn">
                        <div className="mf-12">
                          <Hotkeys
                            keyName="alt+s"
                            onKeyDown={this.onKeyDown.bind(this)}
                            onKeyUp={this.onKeyUp.bind(this)}
                          >
                            <button
                              className="btn-blue"
                              onClick={this.SaveSubmitter}
                              disabled={this.isDisabled(
                                this.state.editId > 0
                                  ? this.props.rights.update
                                  : this.props.rights.add
                              )}
                            >
                              Save{" "}
                            </button>
                          </Hotkeys>

                          <button
                            id="btnCancel"
                            className="btn-grey"
                            data-dismiss="modal"
                            onClick={
                              this.props.onClose
                                ? this.props.onClose()
                                : () => this.props.onClose()
                            }
                          >
                            Cancel{" "}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.submitterSearch,
        add: state.loginInfo.rights.submitterCreate,
        update: state.loginInfo.rights.submitterUpdate,
        delete: state.loginInfo.rights.submitterDelete,
        export: state.loginInfo.rights.submitterExport,
        import: state.loginInfo.rights.submitterImport
      }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewSubmitter);
