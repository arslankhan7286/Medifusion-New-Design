import React, { Component } from "react";
import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Button from "./Input";
import Input from "./Input";
import SearchInput2 from "./SearchInput2";
import axios from "axios";
import {
  MDBDataTable,
  MDBBtn,
  MDBTableHead,
  MDBTableBody,
  MDBTable
} from "mdbreact";
import GridHeading from "./GridHeading";
import NewPractice from "./NewPractice";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import $ from "jquery";
import Swal from "sweetalert2";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

import Hotkeys from "react-hot-keys";

class Practice extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/Practice/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      name: "",
      organizationName: "",
      npi: "",
      taxid: "",
      address: "",
      officePhoneNum: ""
    };

    this.state = {
      searchModel: this.searchModel,
      id: 0,
      data: [],
      showPopup: false,
      loading: false
    };

    this.searchPractices = this.searchPractices.bind(this);
    this.closePracticePopup = this.closePracticePopup.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.openPracticePopup = this.openPracticePopup.bind(this);
    this.onPaste = this.onPaste.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    if (keyName == "alt+n") {
      // alert("search key")
      this.openPracticePopup(0);
    } else if (keyName == "alt+s") {
      this.searchPractices(e);
    } else if (keyName == "alt+c") {
      // alert("clear skey")
      this.clearFields(e);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }
  onKeyUp(keyName, e, handle) {
    if (e) {
      // this.onKeyDown(keyName, e , handle);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  searchPractices = e => {
    this.setState({ loading: true });

    var config = {
      headers: { Authorization: "Bearer1  " + this.props.loginObject.token }
    };

    axios
      .post(this.url + "FindPractices", this.state.searchModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            practice: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPracticePopup(row.id)}
              >
                {row.name}
              </MDBBtn>
            ),
            organizationName: row.organizationName,
            npi: row.npi,
            taxid: row.taxID,
            address: row.address,
            officePhoneNum: row.officePhoneNum
          });
        });

        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false });
        if (error.response) {
          if (error.response.status) {
            Swal.fire("Unauthorized Access", "", "error");
          }
        } else if (error.request) {
        } else {
        }
      });

    e.preventDefault();
  };

  handleChange = event => {
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  openPracticePopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  closePracticePopup = () => {
    $("#practiceModal").hide();
    this.setState({ showPopup: false });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  onPaste(event) {
    var x = event.target.value;
    x = x.trim();

    var regex = /^[0-9]+$/;
    // if (x.length > 10) {
    //   // if (x.length > 9) {
    //   x = x.trimRight();
    //   Swal.fire("Error", "Length of NPI Should be 10", "error");
    //   // }
    // } else
    if (x.length == 0) {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          [event.target.name]: x
        }
      });
      return;
    }

    if (!x.match(regex)) {
      Swal.fire("Error", "Should be Number", "error");
      return;
    } else {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          [event.target.name]: x
        }
      });
    }
  }

  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "practice",
          sort: "asc",
          width: 150
        },
        {
          label: "ORGANIZATION NAME",
          field: "organizationName",
          sort: "asc",
          width: 270
        },
        {
          label: "NPI",
          field: "npi",
          sort: "asc",
          width: 200
        },
        {
          label: "TAX ID",
          field: "taxid",
          sort: "asc",
          width: 100
        },
        {
          label: "ADDRESS",
          field: "address",
          sort: "asc",
          width: 150
        },
        {
          label: "OFFICE PHONE #",
          field: "officePhoneNum",
          sort: "asc",
          width: 100
        }
      ],
      rows: this.state.data
    };

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewPractice
          onClose={() => this.closePracticePopup}
          practiceID={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewPractice>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}

        {/* <SearchHeading heading='PRACTICE SEARCH' handler={() => this.openPracticePopup(0)}></SearchHeading> */}

        <Hotkeys
          keyName="alt+n"
          onKeyDown={this.onKeyDown.bind(this)}
          onKeyUp={this.onKeyUp.bind(this)}
        >
          <SearchHeading
            heading="PRACTICE SEARCH"
            disabled={this.isDisabled(this.props.rights.add)}
            handler={() => this.openPracticePopup(0)}
          ></SearchHeading>
        </Hotkeys>

        <form onSubmit={this.searchPractices}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Name"></Label>
                <Input
                  type="text"
                  name="name"
                  id="name"
                  max="60"
                  value={this.state.searchModel.name}
                  onChange={() => this.handleChange}
                />
              </div>

              <div className="mf-6">
                <Label name="Organization Name"></Label>
                <Input
                  type="text"
                  name="organizationName"
                  id="organizationName"
                  max="60"
                  value={this.state.searchModel.organizationName}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="NPI"></Label>
                <input
                  type="text"
                  name="npi"
                  id="npi"
                  maxLength="10"
                  value={this.state.searchModel.npi}
                  onChange={() => this.handleChange}
                  onKeyPress={event => this.handleNumericCheck(event)}
                  onInput={this.onPaste}
                />
              </div>
              <div className="mf-6">
                <Label name="Tax ID"></Label>
                <input
                  type="text"
                  name="taxid"
                  id="taxid"
                  maxLength="9"
                  value={this.state.searchModel.taxid}
                  onChange={() => this.handleChange}
                  onKeyPress={event => this.handleNumericCheck(event)}
                  onInput={this.onPaste}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Address"></Label>
                <Input
                  type="text"
                  name="address"
                  id="address"
                  max="30"
                  value={this.state.searchModel.address}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Phone #"></Label>
                <Input
                  type="text"
                  name="officePhoneNum"
                  id="officePhoneNum"
                  max="10"
                  value={this.state.searchModel.officePhoneNum}
                  onChange={() => this.handleChange}
                  onKeyPress={event => this.handleNumericCheck(event)}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Hotkeys
                  keyName="alt+s"
                  onKeyDown={this.onKeyDown.bind(this)}
                  onKeyUp={this.onKeyUp.bind(this)}
                >
                  <Input
                    type="submit"
                    name="name"
                    id="name"
                    className="btn-blue"
                    value="Search"
                    disabled={this.isDisabled(this.props.rights.search)}
                  />
                </Hotkeys>

                <Hotkeys
                  keyName="alt+c"
                  onKeyDown={this.onKeyDown.bind(this)}
                  onKeyUp={this.onKeyUp.bind(this)}
                >
                  <Input
                    type="button"
                    name="name"
                    id="name"
                    className="btn-grey"
                    value="Clear"
                    onClick={() => this.clearFields()}
                  />
                </Hotkeys>
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="PRACTICE SEARCH RESULT"
            disabled={this.isDisabled(this.props.rights.export)}
            dataObj={this.state.searchModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>

        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.practiceSearch,
          add: state.loginInfo.rights.practiceCreate,
          update: state.loginInfo.rights.practiceEdit,
          delete: state.loginInfo.rights.practiceDelete,
          export: state.loginInfo.rights.practiceExport,
          import: state.loginInfo.rights.practiceImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(Practice);
