import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import Input from "./Input";
import Label from "./Label";
import axios from "axios";
import Swal from "sweetalert2";
import $ from "jquery";
import calenderPic from "../images/dob-icon.png";
import patientPic from "../images/profile-pic.png";
import samll_doc_icon from "../images/dob-icon.png";
import Dropdown from "react-dropdown";
import settingsIcon from "../images/setting-icon.png";
import NewHistoryPractice from "./NewHistoryPractice";
import { isNull, isNullOrUndefined } from "util";
import { Tabs, Tab } from "react-tab-view";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";
import NewRefferingProvider from "./NewRefferingProvider";
import { MDBDataTable, MDBBtn, MDBCollapse } from "mdbreact";
import Select, { components } from "react-select";
import moment from "moment";
import NumberFormat from "react-number-format";
import VisitUsed from "./VisitUsed";
import TopForm from "./TopForm/TopForm";
import SendFax from "./SendFax";
import GPopup from "./GPopup";
import BatchDocumentPopup from "./BatchDocumentPopup";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { selectPatient } from "../actions/selectPatient";
import plusSrc from "../images/plus-icon.png";

class NewPatient extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/patient/";
    this.zipURL = process.env.REACT_APP_URL + "/Common/";
    this.Notesurl = process.env.REACT_APP_URL + "/Notes/";
    this.patientPlanUrl = process.env.REACT_APP_URL + "/PatientPlan/";
    this.insurancePlanAddressURL =
      process.env.REACT_APP_URL + "/InsurancePlanAddress/";

    this.batchURL = process.env.REACT_APP_URL + "/BatchDocument/";
    this.proURL = process.env.REACT_APP_URL + "/Provider/";
    this.errorField = "errorField";
    let patientPopupId = 0;
    patientPopupId = this.props.popupPatientId;
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*",
      },
    };

    this.savePatientCount = 0;
    this.currentIndex = 0;
    this.myPatientPlans = [];

    //Note Model
    this.notesModel = {
      id: 0,
      notesDate: null,
      note: null,
      noteValField: "",
      validation: false,
    };

    //Patient Model
    this.patientModel = {
      id: 0,
      accountNum: "",
      medicalRecordNumber: "",
      title: "",
      lastName: "",
      middleInitial: "",
      firstName: "",
      ssn: "",
      dob: "",
      gender: "",
      maritalStatus: "",
      race: "",
      ethinicity: "",
      address1: "",
      address2: "",
      city: "",
      state: "",
      zipCode: "",
      phoneNumber: "",
      mobileNumber: "",
      email: "",
      practiceID: null,
      locationId: null,
      providerID: null,
      refProviderID: null,
      notes: "",
      isDeleted: false,
      isActive: false,
      statementMessage: "",
      ChargeTable: [],
      statement: true,
      batchDocumentID: null,
      pageNumber: "",
      /******************************************khizer code*************************************************************/
      note: [],
      patientPlans: [],

      /*******************************************Afzaaal code*************************************************************/
      authnote: [],
      patientAuthorization: [],
      patientReferrals: [],
    };

    this.patientPlanModel = {
      id: 0,
      insurancePlanID: null,
      patientID: null,
      coverage: "",
      relationShip: "",
      lastName: "",
      firstName: "",
      middleInitial: "",
      dob: "",
      gender: "",
      address1: "",
      city: "",
      state: "",
      zipCode: "",
      subscriberId: "",
      insurancePlanAddressID: null,
      insurancePlanID: null,
      insurancePlanAddresses: [],
      isActive: true,
      authRequired: false,
      insurancePlanObject: {},

      //Validation Fiels
      lastNameValField: null,
      firstNameValField: null,
      coverageValField: null,
      relationshipValField: null,
      subscriberIDValField: null,
      insurancePlanValField: null,
      dobValField: null,
    };

    this.patientAuthModel = {
      id: 0,
      plan: "",
      providerID: "",
      icdid: "",
      cptid: "",
      authorizationNumber: "",
      startdate: "",
      enddate: "",
      visitsAllowed: 1,
      visitsUsed: 0,
      remaining: "",
      remarks: "",
      status: "AUTH REQUIRED",
      responsibleParty: "BELLMEDEX",

      insurancePlanID: null,
      patientPlanID: null,
      patientPlanModel: {},

      insurancePlanValField: null,
      providerObject: {},
      icdObject: {},
      cptObject: {},

      authorizedAmount: "",
      medicalRecordRequired: false,
      medicalNecessityRequired: false,
      addedDate: "",
      authorizationDate: "",
      commonKey: null,
    };

    this.patientReferral = {
      id: 0,
      patientID: "",
      pcpid: "",
      providerID: "",
      provider: "",
      patientPlanID: "",
      patientPlan: "",
      startDate: "",
      endDate: "",
      visitAllowed: "",
      visitUsed: 0,
      status: "",
      ReferralNo: "",
      FaxStatus: "",
      rererralForService: "",
      commonKey: null,
      insurancePlanID: null,
      patientPlanID: null,
      patientPlanModel: {},
      insurancePlanObject: {},
      insurancePlanValField: null,
      providerObject: {},
      pcpObject: {},
    };
    //Validation Model
    this.validationModel = {
      accountNumValField: "",
      medicalRecordNoValField: "",
      titleValField: "",
      lastNameValField: "",
      middleInitialValField: "",
      firstNameValField: "",
      ssnValField: "",
      dobValField: "",
      genderValField: "",
      maritalStatusValField: "",
      raceValField: "",
      ethinicityValField: "",
      address1ValField: "",
      address2ValField: "",
      cityValField: "",
      stateValField: "",
      zipCodeValField: "",
      phoneNumberValField: "",
      mobileNumberValField: "",
      emailValField: "",
      practiceIDValField: "",
      locationIdValField: "",
      providerIDValField: "",
      refProviderIDValField: "",
      notesValField: "",
      isDeletedValField: false,
      isActiveValField: true,
      dobValField: "",
      emailValField: "",
      planIDValField: "",
      providerIDValField: "",
      cptIDValField: "",
      authorizationNumberValField: "",
      startdateNumberValField: "",
      enddateValField: "",
      visitsAllowedValField: "",
      patientPlanIDRefValField: "",
      pcpIDRefValField: "",
      providerIDRefValField: "",
      greaterValField: "",
      batchDocumentIDValField: "",
      responsepagesValField: "",
      pageNumberValField: "",
    };

    this.state = {
      editId: patientPopupId > 0 ? this.props.popupPatientId : this.props.id,
      patientPopupId: 0,
      patientModel: this.patientModel,
      validationModel: this.validationModel,
      patientPlanModel: this.patientPlanModel,
      patientAuthModel: this.patientAuthModel,
      patientReferral: this.patientReferral,
      faxModel: [],
      practice: [],
      location: [],
      provider: [],
      refProvider: [],
      file: "",
      imagePreviewUrl: patientPic,
      popupName: "",
      id: 0,
      loading: false,
      today: "",
      insurancePlans: [],
      insurancePlanAddresses: [],
      patientPlans: [],
      showLPopup: false,
      showPPopup: false,
      showRPopup: false,
      collapseID: 1,
      showVPopup: false,
      showFPopup: false,
      patientAuthID: 0,
      batchDocumentID: null,
      pageNumber: "",
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleNumericCheck = this.handleNumericCheck.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
    this.savePatient = this.savePatient.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
    this.handleZip = this.handleZip.bind(this);
    this.openPopup = this.openPopup.bind(this);
    this.closePopup = this.closePopup.bind(this);
    this.handleCheckbox = this.handleCheckbox.bind(this);
    this.openLocationPopup = this.openLocationPopup.bind(this);
    this.closeLocationPopup = this.closeLocationPopup.bind(this);
    this.openProviderPopup = this.openProviderPopup.bind(this);
    this.closeProviderPopup = this.closeProviderPopup.bind(this);
    this.openRefProviderPopup = this.openRefProviderPopup.bind(this);
    this.closeRefProviderPopup = this.closeRefProviderPopup.bind(this);
    this.addRowNotes = this.addRowNotes.bind(this);
    this.addReferral = this.addReferral.bind(this);
    this.addAuthRowNotes = this.addAuthRowNotes.bind(this);
    // this.handlebatchChange = this.handlebatchChange.bind(this);
    this.handleNoteChange = this.handleNoteChange.bind(this);
    this.handleAuthNoteChange = this.handleAuthNoteChange.bind(this);
    this.handleBatchChange = this.handleBatchChange.bind(this);
    this.handleAuthChange = this.handleAuthChange.bind(this);
    this.handleRefChange = this.handleRefChange.bind(this);
    this.openvisitPopup = this.openvisitPopup.bind(this);
    this.closevisitPopup = this.closevisitPopup.bind(this);
    this.addPlanRow = this.addPlanRow.bind(this);
    this.addAuthRow = this.addAuthRow.bind(this);
    this.handleInsurancePlansuggChange = this.handleInsurancePlansuggChange.bind(
      this
    );
    this.nextVisit = this.nextVisit.bind(this);
    this.previousVisit = this.previousVisit.bind(this);

    this.handleBatchCheck = this.handleBatchCheck.bind(this);
    this.handleInsuranceAuthsuggChange = this.handleInsuranceAuthsuggChange.bind(
      this
    );
    this.closefaxPopup = this.closefaxPopup.bind(this);
    this.openfaxPopup = this.openfaxPopup.bind(this);
  }

  async UNSAFE_componentWillMount() {
    await this.setState({
      patientPopupId: this.props.popupPatientId,
      loading: true,
    });

    try {
      //Get insurance plans from get profiles
      try {
        await axios
          .get(this.patientPlanUrl + "getprofiles", this.config)
          .then((response) => {
            this.setState({ insurancePlans: response.data.insurancePlans });
          })
          .then((error) => {});
      } catch {}

      var NewPatientmodel = "";
      if (this.state.editId > 0) {
        await axios
          .get(this.url + "findPatient/" + this.state.editId, this.config)
          .then((response) => {
            NewPatientmodel = response.data;

            if (NewPatientmodel.note == null) {
              NewPatientmodel.note = [];
            }
            if (response.data.patientPlans == null) {
              NewPatientmodel.patientPlans = [];
            }
          })
          .catch((error) => {
            console.log(error);
          });
        await NewPatientmodel.patientPlans.map(async (plan, index) => {
          var insurancePlan = await this.state.insurancePlans.filter(
            (indurancePlan) => indurancePlan.id == plan.insurancePlanID
          );
          NewPatientmodel.patientPlans[
            index
          ].insurancePlanObject = insurancePlan;

          if (insurancePlan.length > 0) {
            this.myPatientPlans.push({
              id: plan.id,
              value: insurancePlan[0].value,
              label: insurancePlan[0].value,
              insurancePlanID: insurancePlan[0].id,
              commonKey:
                NewPatientmodel.patientPlans[index].coverage.toString() +
                NewPatientmodel.patientPlans[index].insurancePlanID.toString() +
                NewPatientmodel.patientPlans[index].subscriberId.toString() +
                NewPatientmodel.patientPlans[index].isActive.toString(),
            });
          }

          try {
            axios
              .get(
                this.insurancePlanAddressURL +
                  "GetInsurancePlanAddressesByInsurancePlanID/" +
                  plan.insurancePlanID,
                this.config
              )
              .then((response) => {
                NewPatientmodel.patientPlans[index].insurancePlanAddresses =
                  response.data;
                this.setState({
                  patientModel: NewPatientmodel,
                });
              })
              .catch((error) => {
                console.log(error);
              });
          } catch {
            NewPatientmodel.patientPlans[index].insurancePlanAddresses = [];
          }
        });

        //Auth Patient Plans
        await NewPatientmodel.patientAuthorization.map(async (plan, index) => {
          //Set Patient Plans Object
          var insurancePlan = await this.state.insurancePlans.filter(
            (indurancePlan) => indurancePlan.id == plan.insurancePlanID
          );
          NewPatientmodel.patientAuthorization[
            index
          ].insurancePlanObject = insurancePlan;

          //Set Provider Object
          var provider = await this.props.userProviders.filter(
            (provider) => provider.id == plan.providerID
          );
          NewPatientmodel.patientAuthorization[index].providerObject = provider;

          //Set ICD Object
          var icd = await this.props.icdCodes.filter(
            (icd) => icd.id == plan.icdid
          );
          NewPatientmodel.patientAuthorization[index].icdObject = icd;

          //Set CPT Object
          var cpt = await this.props.cptCodes.filter(
            (cpt) => cpt.id == plan.cptid
          );
          NewPatientmodel.patientAuthorization[index].cptObject = cpt;
        });

        //Referral Patient
        await NewPatientmodel.patientReferrals.map(async (ref, index) => {
          //Set Patient Plans Object
          var insurancePlan = await this.state.insurancePlans.filter(
            (indurancePlan) => indurancePlan.id == ref.insurancePlanID
          );
          console.log("insu", insurancePlan);
          NewPatientmodel.patientReferrals[
            index
          ].insurancePlanObject = insurancePlan;

          //Set Provider Object
          var provider = await this.props.userProviders.filter(
            (provider) => provider.id == ref.providerID
          );
          NewPatientmodel.patientReferrals[index].providerObject = provider;

          //Set PCP Object
          var provider = await this.props.userProviders.filter(
            (provider) => provider.id == ref.pcpid
          );
          NewPatientmodel.patientReferrals[index].pcpObject = provider;
        });

        this.setState({
          patientModel: NewPatientmodel,
          imagePreviewUrl: NewPatientmodel.profilePic,
        });
      } else {
        await axios
          .get(this.url + "GetProfiles/" + this.state.editId, this.config)
          .then((response) => {
            this.setState({
              patientModel: {
                ...this.state.patientModel,
                accountNum: response.data.accountNumber,
              },
            });
          });
      }
    } catch {
      this.setState({ loading: false });
    }
    this.setState({ loading: false });
  }

  openPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  openLocationPopup = (id) => {
    this.setState({ showLPopup: true, id: id });
  };

  closeLocationPopup = () => {
    $("#locationModal").hide();
    this.setState({ showLPopup: false });
  };

  openProviderPopup = (id) => {
    this.setState({ showPPopup: true, id: id });
  };

  //close facility popup
  closeProviderPopup = () => {
    $("#providerModal").hide();
    this.setState({ showPPopup: false });
  };

  //open facility popup
  openRefProviderPopup = (id) => {
    this.setState({ showRPopup: true, id: id });
  };

  //close facility popup
  closeRefProviderPopup = () => {
    $("#refModal").hide();
    this.setState({ showRPopup: false });
  };

  async handleZip(event) {
    var zip = event.target.value;
    const index = event.target.id;
    const name = event.target.name;
    const value = event.target.value;

    if (name == "planZipCode") {
      let newList = [...this.state.patientModel.patientPlans];
      newList[index].zipCode = value;
      await this.setState({
        patientModel: {
          ...this.state.patientModel,
          patientPlans: newList,
        },
      });
    } else {
      await this.setState({
        patientModel: {
          ...this.state.patientModel,
          [event.target.name]: event.target.value.toUpperCase(),
        },
      });
    }

    if (zip.length >= 5 && zip.length <= 9) {
      await axios
        .get(this.zipURL + "GetCityStateInfo/" + zip, this.config)
        .then((response) => {
          if (name == "planZipCode") {
            let newList = [...this.state.patientModel.patientPlans];
            newList[index].zipCode = value;
            newList[index].city = response.data.city.toUpperCase();
            newList[index].state = response.data.state_id;
            this.setState({
              patientModel: {
                ...this.state.patientModel,
                patientPlans: newList,
              },
            });
          } else {
            this.setState({
              patientModel: {
                ...this.state.patientModel,
                city: response.data.city.toUpperCase(),
                state: response.data.state_id,
              },
            });
          }
        })
        .catch((error) => {
          this.setState({ loading: false });

          if (error.response) {
            if (error.response.data) {
              if (error.response.data == "InValid ZipCode") {
                Swal.fire(
                  "Something Wrong",
                  "Please Enter Valid ZipCode",
                  "error"
                );
              } else {
                console.log("Error : ", error);
              }
            } else {
              console.log("Error : ", error);
            }
          } else {
            console.log("Error : ", error);
          }
        });
    } else {
      console.log("Zip Code length should be 5");
    }
  }

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select" ||
      value.length == 0
    )
      return true;
    else return false;
  }

  replace(field, replaceWhat, replaceWith) {
    if (this.isNull(field)) return field;
    else return field.replace(replaceWhat, replaceWith);
  }

  async handleChange(event) {
    event.preventDefault();
    var eventName = event.target.name;
    var eventValue = event.target.value;
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase(),
      },
    });

    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    // practice change dropdown
    if (event.target.name == "practiceID") {
      var userLocation = await this.props.userInfo1.userLocations.filter(
        (location) => location.iD2 == this.props.userInfo1.practiceID
      );
      var userProvider = await this.props.userInfo1.userProviders.filter(
        (provider) => provider.iD2 == this.props.userInfo1.practiceID
      );
      var userRefProvider = await this.props.userInfo1.userRefProviders.filter(
        (refProvider) => refProvider.iD2 == this.props.userInfo1.practiceID
      );
      await this.setState({
        location: userLocation,
        provider: userProvider,
        refProvider: userRefProvider,
      });

      if (this.isNull(this.state.patientModel.locationId) == true) {
        await this.setState({
          patientModel: {
            ...this.state.patientModel,
            locationId: userLocation[0].id,
          },
        });
      }
      if (this.isNull(this.state.patientModel.providerID) == true) {
        await this.setState({
          patientModel: {
            ...this.state.patientModel,
            providerID: userProvider[0].id,
          },
        });
      }
      if (this.isNull(this.state.patientModel.refProviderID) == true) {
        await this.setState({
          patientModel: {
            ...this.state.patientModel,
            refProviderID: userRefProvider[0].id,
          },
        });
      }
    }
  }

  handleBatchChange(event) {
    const eventValue = event.target.value;
    const eventName = event.target.name;

    this.setState({
      patientModel: {
        ...this.state.patientModel,
        [eventName]: eventValue.trim(),
      },
      batchDocumentID: eventName == "batchDocumentID" ? eventValue : null,
    });
  }

  handleBatchCheck = (event) => {
    var eventValue = event.target.value;
    if (event.target.name == "pageNumber") {
      eventValue = this.state.patientModel.batchDocumentID;
    } else {
      eventValue = eventValue;
    }
    var myVal = this.validationModel;
    axios
      .get(this.batchURL + "FindBatchDocument/" + eventValue, this.config)
      .then((response) => {
        this.setState({ pageNumber: response.data.numberOfPages });
        myVal.batchDocumentIDValField = "";
        myVal.responsepagesValField = (
          <span
            className="validationMsg"
            style={{ color: "green", marginLeft: "-43%" }}
          >
            Number of Pages: {response.data.numberOfPages}
          </span>
        );

        return;
      })
      .catch((error) => {
        if (error.response) {
          if (error.response.status) {
            if (error.response.status == 404) {
              console.log("Not Found");
              var myVal = this.validationModel;

              myVal.batchDocumentIDValField = (
                <span className="validationMsg" style={{ marginLeft: "-50%" }}>
                  Invalid Batch # {this.state.patientModel.batchDocumentID}
                </span>
              );
              myVal.responsepagesValField = "";
              return;
            }
          }
        }
      });
    // }
  };

  //Save Patient
  async savePatient(e) {
    if (this.savePatientCount == 1) {
      return;
    }

    this.savePatientCount = 1;
    // e.preventDefault();

    if (this.state.patientModel.phoneNumber) {
      if (this.state.patientModel.phoneNumber.length > 10) {
        var lng = this.state.patientModel.phoneNumber
          ? this.state.patientModel.phoneNumber.length
          : "";
        var phoneNumber = this.state.patientModel.phoneNumber.slice(3, lng);
        this.state.patientModel.phoneNumber = phoneNumber.replace(
          /[-_ )(]/g,
          ""
        );
      }
    }

    if (this.state.patientModel.mobileNumber) {
      if (this.state.patientModel.mobileNumber.length > 10) {
        var lng = this.state.patientModel.mobileNumber
          ? this.state.patientModel.mobileNumber.length
          : "";
        var mobileNumber = this.state.patientModel.mobileNumber.slice(3, lng);
        this.state.patientModel.mobileNumber = mobileNumber.replace(
          /[-_ )(]/g,
          ""
        );
      }
    }

    this.setState({ loading: true });

    var myVal = { ...this.validationModel };
    myVal.validation = false;

    //Batch number Validatoin
    console.log("Page Number : ", this.state.patientModel.pageNumber);
    console.log("Page Number : ", this.state.pageNumber);
    if (
      this.isNull(this.state.patientModel.pageNumber) == false &&
      this.isNull(this.state.pageNumber) == false
    ) {
      var listOfNum, matchComme, matchDash;
      var pageNumber = this.state.patientModel.pageNumber;
      matchComme = pageNumber.indexOf(",");
      matchDash = pageNumber.indexOf("-");
      if (matchComme > 0) {
        listOfNum = pageNumber.split(",");
      }
      if (matchDash > 0) {
        listOfNum = pageNumber.split("-");
      } else {
        listOfNum = pageNumber;
      }
      console.log("Page Nmber List : ", listOfNum);
      console.log("Page Number : ", pageNumber);
      for (var i = 0; i < listOfNum.length; i++) {
        if (listOfNum[i] > this.state.pageNumber) {
          console.log("Page Nmber : ", listOfNum[i]);
          myVal.pageNumberValField = (
            <span className="validationMsg" style={{ marginLeft: "-58%" }}>
              Invalid Page # {listOfNum[i]}
            </span>
          );
          myVal.validation = true;
          // break;
        } else {
          myVal.pageNumberValField = "";
          if (myVal.validation === false) myVal.validation = false;
        }
      }
    }
    if (this.isNull(this.state.patientModel.lastName)) {
      myVal.lastNameValField = (
        <span className="validationMsg">Enter Last Name</span>
      );
      myVal.validation = true;
    } else {
      myVal.lastNameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.patientModel.firstName)) {
      myVal.firstNameValField = (
        <span className="validationMsg">Enter First Name</span>
      );
      myVal.validation = true;
    } else {
      myVal.firstNameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.patientModel.zipCode) === false &&
      this.state.patientModel.zipCode.length > 0
    ) {
      if (this.state.patientModel.zipCode.length < 5) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of alleast 5 digits
          </span>
        );
        myVal.validation = true;
      } else if (
        this.state.patientModel.zipCode.length > 5 &&
        this.state.patientModel.zipCode.length < 9
      ) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of either 5 or 9 digits
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.zipCodeValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.zipCodeValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.patientModel.phoneNumber) === false &&
      this.state.patientModel.phoneNumber.length < 10
    ) {
      myVal.phoneNumberValField = (
        <span className="validationMsg">Phone # length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.phoneNumberValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.patientModel.mobileNumber) === false &&
      this.state.patientModel.mobileNumber.length < 10
    ) {
      myVal.mobileNumberValField = (
        <span className="validationMsg">Phone # length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.mobileNumberValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.patientModel.ssn) === false &&
      this.state.patientModel.ssn.length < 9
    ) {
      myVal.ssnValField = (
        <span className="validationMsg">ssn # length should be 9</span>
      );
      myVal.validation = true;
    } else {
      myVal.ssnValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.patientModel.practiceID)) {
      myVal.practiceIDValField = (
        <span className="validationMsg">Select Practice</span>
      );
      myVal.validation = true;
    } else {
      myVal.practiceIDValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.patientModel.locationId)) {
      myVal.locationIdValField = (
        <span className="validationMsg">Select Location</span>
      );
      myVal.validation = true;
    } else {
      myVal.locationIdValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.patientModel.providerID)) {
      myVal.providerIDValField = (
        <span className="validationMsg">Select Provider</span>
      );
      myVal.validation = true;
    } else {
      myVal.providerIDValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //DOB Future Date Validation
    if (this.isNull(this.state.patientModel.dob) == false) {
      if (
        new Date(
          moment(this.state.patientModel.dob).format().slice(0, 10)
        ).getTime() > new Date(moment().format().slice(0, 10)).getTime()
      ) {
        myVal.dobValField = (
          <span className="validationMsg">Future date can't be selected </span>
        );
        myVal.validation = true;
      } else {
        myVal.dobValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.dobValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    myVal.emailValField = "";
    this.setState({
      validationModel: myVal,
    });

    if (myVal.validation === true) {
      Swal.fire("Please fill all patient fields prooerly", "", "error");
      this.setState({ loading: false });
      this.savePatientCount = 0;
      return;
    }

    //Patient Plans Validation
    var patientPlans = [];
    let patientPlanValidationCount = 0;
    try {
      patientPlans = this.state.patientModel.patientPlans
        ? this.state.patientModel.patientPlans
        : [];
      await patientPlans.map((plan, index) => {
        //Last Name Validation
        if (this.isNull(plan.lastName)) {
          plan.lastNameValField = (
            <span className="validationMsg">Enter Last Name</span>
          );
          patientPlanValidationCount += 1;
        } else {
          plan.lastNameValField = null;
        }
        //First Name Validation
        if (this.isNull(plan.firstName)) {
          plan.firstNameValField = (
            <span className="validationMsg">Enter First Name</span>
          );
          patientPlanValidationCount += 1;
        } else {
          plan.firstNameValField = null;
        }

        //DOB Future Date Validation
        if (this.isNull(plan.dob) == false) {
          if (
            new Date(moment(plan.dob).format().slice(0, 10)).getTime() >
            new Date(moment().format().slice(0, 10)).getTime()
          ) {
            plan.dobValField = (
              <span className="validationMsg">
                Future date can't be selected{" "}
              </span>
            );
            patientPlanValidationCount += 1;
          } else {
            plan.dobValField = null;
          }
        } else {
          plan.dobValField = null;
        }

        //Coverage Val Field
        if (this.isNull(plan.coverage)) {
          plan.coverageValField = (
            <span className="validationMsg">Select Coverage</span>
          );
          patientPlanValidationCount += 1;
        } else {
          plan.coverageValField = null;
        }

        //Relationship Val Field
        if (this.isNull(plan.relationShip)) {
          plan.relationshipValField = (
            <span className="validationMsg">Select Rlationship</span>
          );
          patientPlanValidationCount += 1;
        } else {
          plan.relationshipValField = null;
        }

        //Subscriber validation
        if (this.isNull(plan.subscriberId)) {
          plan.subscriberIDValField = (
            <span className="validationMsg">Enter SubscriberID</span>
          );
          patientPlanValidationCount += 1;
        } else {
          plan.subscriberIDValField = null;
        }

        //Insurance Plan Validation
        if (this.isNull(plan.insurancePlanID)) {
          plan.insurancePlanValField = (
            <span className="validationMsg">Enter Insurance Plan</span>
          );
          patientPlanValidationCount += 1;
        } else {
          plan.insurancePlanValField = null;
        }
      });
    } catch {}

    if (patientPlanValidationCount > 0) {
      this.setState({
        loading: false,
        patientModel: {
          ...this.state.patientModel,
          patientPlans: patientPlans,
        },
      });
      Swal.fire(
        "Something Wrong!",
        "Please Select All patient Plan Fields Properly",
        "error"
      );
      this.savePatientCount = 0;
      return;
    }

    //Patient Auth Validation
    // var patientAuthModel = [];
    // let patientAuthValidationCount = 0;
    // try {
    //   patientAuthModel = this.state.patientModel.patientAuthorization
    //     ? this.state.patientModel.patientAuthorization
    //     : [];
    //   await patientAuthModel.map((auth, index) => {
    //     console.log("Auth Plan : ", auth);
    //     // Validation
    //     if (this.isNull(auth.insurancePlanID)) {
    //       auth.planIDValField = (
    //         <span className="validationMsg">Enter Plan</span>
    //       );
    //       patientAuthValidationCount += 1;
    //     } else {
    //       auth.planIDValField = null;
    //     }

    //     if (this.isNull(auth.providerID)) {
    //       auth.providerIDValField = (
    //         <span className="validationMsg">Enter Provider</span>
    //       );
    //       patientAuthValidationCount += 1;
    //     } else {
    //       auth.providerIDValField = null;
    //     }

    //     if (this.isNull(auth.cptid)) {
    //       auth.cptIDValField = <span className="validationMsg">Enter CPT</span>;
    //       patientAuthValidationCount += 1;
    //     } else {
    //       auth.cptIDValField = null;
    //     }

    //     if (this.isNull(auth.authorizationNumber)) {
    //       auth.authorizationNumberValField = (
    //         <span className="validationMsg">Enter Authorization #</span>
    //       );
    //       patientAuthValidationCount += 1;
    //     } else {
    //       auth.authorizationNumberValField = null;
    //     }

    //     if (this.isNull(auth.startDate)) {
    //       auth.startdateNumberValField = (
    //         <span className="validationMsg">Enter Start Date</span>
    //       );
    //       patientAuthValidationCount += 1;
    //     } else {
    //       auth.startdateNumberValField = null;
    //     }

    //     if (this.isNull(auth.endDate)) {
    //       auth.enddateValField = (
    //         <span className="validationMsg">Enter End Date</span>
    //       );
    //       patientAuthValidationCount += 1;
    //     } else {
    //       auth.enddateValField = null;
    //     }

    //     if (
    //       this.isNull(auth.startDate) == false &&
    //       this.isNull(auth.endDate) == false
    //     ) {
    //       if (
    //         new Date(moment(auth.endDate).format().slice(0, 10)).getTime() <
    //         new Date(moment(auth.startDate).format().slice(0, 10)).getTime()
    //       ) {
    //         console.log("start date is greater than end date")
    //         auth.greaterValField = (
    //           <span className="validationMsg">
    //             Start Date must be greater than End Date
    //           </span>
    //         );
    //         patientAuthValidationCount += 1;
    //       }
    //     } else {
    //       auth.greaterValField = null;
    //     }

    //     if (this.isNull(auth.visitsAllowed)) {
    //       auth.visitsAllowedValField = (
    //         <span className="validationMsg">Enter Visit Allowed</span>
    //       );
    //       patientAuthValidationCount += 1;
    //     } else {
    //       auth.visitsAllowedValField = null;
    //     }
    //   });
    // } catch {}

    // if (patientAuthValidationCount > 0) {
    //   this.setState({
    //     loading: false,
    //     patientModel: {
    //       ...this.state.patientModel,
    //       patientAuthModel: patientAuthModel,
    //     },
    //   });
    //   Swal.fire(
    //     "Something Wrong!",
    //     "Please Select All patient Authorization Fields Properly",
    //     "error"
    //   );
    //   this.savePatientCount = 0;
    //   return;
    // }

    //Patient Referral Validation
    var patientRefModel = [];
    let patientRefValidationCount = 0;
    try {
      patientRefModel = this.state.patientModel.patientReferrals
        ? this.state.patientModel.patientReferrals
        : [];
      await patientRefModel.map((ref, index) => {
        console.log("ref Plan : ", ref);
        // Validation
        if (this.isNull(ref.providerID)) {
          ref.providerIDRefValField = (
            <span className="validationMsg">Enter Provider</span>
          );
          patientRefValidationCount += 1;
        } else {
          ref.providerIDRefValField = null;
        }

        if (this.isNull(ref.patientPlanID)) {
          ref.patientPlanIDRefValField = (
            <span className="validationMsg">Enter Plan</span>
          );
          patientRefValidationCount += 1;
        } else {
          ref.patientPlanIDRefValField = null;
        }
      });
    } catch {}

    if (patientRefValidationCount > 0) {
      this.setState({
        loading: false,
        patientModel: {
          ...this.state.patientModel,
          patientReferral: patientRefModel,
        },
      });
      Swal.fire(
        "Something Wrong!",
        "Please Select All Patient Referral Fields Properly",
        "error"
      );
      this.savePatientCount = 0;
      return;
    }

    //Notes Validation
    var note = [];
    var notesVal;
    if (this.state.patientModel.note == null) {
      note = [];
    } else {
      note = this.state.patientModel.note;
    }

    for (var i = 0; i < note.length; i++) {
      notesVal = { ...this.state.patientModel.note[i] };
      notesVal.validation = false;
      //Notes validation
      if (this.isNull(this.state.patientModel.note[i].note)) {
        notesVal.noteValField = (
          <span className="validationMsg">Enter Notes</span>
        );
        notesVal.validation = true;
      } else {
        notesVal.noteValField = "";
        if (notesVal.validation === false) notesVal.validation = false;
      }

      //Notes validation set state
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          note: [
            ...this.state.patientModel.note.slice(0, i),
            Object.assign({}, this.state.patientModel.note[i], notesVal),
            ...this.state.patientModel.note.slice(i + 1),
          ],
        },
      });
    }

    //Notes
    for (var i = 0; i < note.length; i++) {
      if (this.state.patientModel.note[i].validation == true) {
        this.setState({ loading: false });
        Swal.fire("Something Wrong", "Please Check All Note Fields", "error");
        this.savePatientCount = 0;
        return;
      }
    }

    let propsTosend = [];
    let patientModel = { ...this.state.patientModel };
    patientModel.profilePic = this.state.imagePreviewUrl;
    // e.preventDefault();
    axios
      .post(this.url + "savePatient", patientModel, this.config)
      .then((response) => {
        this.savePatientCount = 0;
        propsTosend = response.data;
        this.setState({
          // patientModel: response.data,
          editId: response.data.id,
          loading: false,
        });
        Swal.fire("Record Saved Successfully", "", "success").then((sres) => {
          this.UNSAFE_componentWillMount();
          if (this.props.SchedularAdvSearch) {
            this.props.rowSelect(propsTosend);
            this.props.gotoAppointment();
          }
          if (!this.props.SchedularAdvSearch) {
            if (
              this.state.patientPopupId > 0 ||
              this.state.patientPopupId == -1
            ) {
            } else {
              this.props.selectTabAction("NewPatient", response.data.id);
              this.props.history.push("/NewPatient/" + response.data.id);
            }
          }
        });
      })
      .catch((error) => {
        this.savePatientCount = 0;
        this.setState({ loading: false });

        try {
          if (error.response) {
            if (error.response.status) {
              if (error.response.status == 401) {
                Swal.fire("Unauthorized Access", "", "error");
                return;
              } else if (error.response.status == 404) {
                Swal.fire("Not Found", "Failed With Status Code 404", "error");
              } else if (error.response.status == 400) {
                Swal.fire("", error.response.data, "error");
              }
            }
          }
          if (error.response.data) {
            if (error.response.data.Email[0] == "Please enter Valid Email ID") {
              //Swal.fire("Something Wrong", error.response.data.Email[0], "error");
              myVal.emailValField = (
                <span className="validationMsg">
                  Please enter Valid Email ID
                </span>
              );
              myVal.validation = true;
            } else {
              myVal.emailValField = "";
              if (myVal.validation === false) myVal.validation = false;
            }
            this.setState({
              validationModel: myVal,
            });
          } else {
            Swal.fire("Something went Wrong", "", "error");
            return;
          }
        } catch {}
      });
  }

  cancelBtn = (e) => {
    this.props.selectTabAction("Patient");
    this.props.history.push("/Patient");
  };

  async handleCheck() {
    // var patientPlans    = this.state.patientModel.patientPlans    ;
    // patientPlans   [index].active = !this.state.patientModel.patientPlans    [index].active
    await this.setState({
      patientModel: {
        ...this.state.patientModel,
        isActive: !this.state.patientModel.isActive,
      },
    });
  }

  handlePatientPlanCheck = (index) => {
    var patientPlans = this.state.patientModel.patientPlans;
    patientPlans[index].isActive = !this.state.patientModel.patientPlans[index]
      .isActive;
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        patientPlans: patientPlans,
      },
    });
  };

  handlePatientPlanAuthReqCheck = (index) => {
    var patientPlans = this.state.patientModel.patientPlans;
    patientPlans[index].authRequired = !this.state.patientModel.patientPlans[
      index
    ].authRequired;
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        patientPlans: patientPlans,
      },
    });
    if (
      patientPlans[index].authRequired == true &&
      this.isNull(patientPlans[index].insurancePlanID) == false
    ) {
      this.addAuthRow();
    }
    if (
      patientPlans[index].authRequired == false &&
      this.isNull(patientPlans[index].insurancePlanID) == false
    ) {
      var length = this.state.patientModel.patientAuthorization.length
        ? this.state.patientModel.patientAuthorization.length
        : 0;
      if (length) {
        var ID = this.state.patientModel.patientAuthorization[length - 1].id
          ? this.state.patientModel.patientAuthorization[length - 1].id
          : 0;
        if (ID > 0) {
          axios
            .delete(this.url + "DeletePatientAuth/" + ID, this.config)
            .then((response) => {
              Swal.fire(
                "Record Deleted!",
                "Record has been deleted.",
                "success"
              );
              let patientAuthModel = [
                ...this.state.patientModel.patientAuthorization,
              ];
              patientAuthModel.splice(index, 1);
              this.setState({
                loading: false,
                patientModel: {
                  ...this.state.patientModel,
                  patientAuthorization: patientAuthModel,
                },
              });
            })
            .catch((error) => {
              this.setState({ loading: false });
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let patientAuthModel = [
            ...this.state.patientModel.patientAuthorization,
          ];
          patientAuthModel.splice(index, 1);
          this.setState({
            loading: false,
            patientModel: {
              ...this.state.patientModel,
              patientAuthorization: patientAuthModel,
            },
          });
        }
      }
    }
  };

  handleCheckbox() {
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        statement: !this.state.patientModel.statement,
      },
    });
  }

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  handleDateChange = (date) => {
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        dob: date.target.value,
      },
    });
  };

  //Add New Patient
  addNewPatient = () => {
    axios.get(this.url + "GetProfiles/" + 0, this.config).then((response) => {
      this.setState({
        editId: 0,
        patientModel: {
          ...this.state.patientModel,
          id: 0,
          accountNum: "",
          medicalRecordNumber: "",
          title: "",
          lastName: "",
          middleInitial: "",
          firstName: "",
          ssn: "",
          dob: "",
          gender: "",
          maritalStatus: "",
          race: "",
          ethinicity: "",
          address1: "",
          address2: "",
          city: "",
          state: "",
          zipCode: "",
          phoneNumber: "",
          mobileNumber: "",
          email: "",
          statementMessage: "",
          statement: false,
          // practiceID: null,
          // locationId: null,
          // providerID: null,
          // refProviderID: null,
          note: [],
          patientPlans: [],
          notes: "",
          isDeleted: false,
          isActive: true,
        },
      });
    });

    this.props.selectTabAction("NewPatient", 0);
    this.props.history.push("/NewPatient/" + 0);
  };

  deletePatient = (e) => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        axios
          .delete(this.url + "DeletePatient/" + this.state.editId, this.config)
          .then((response) => {
            Swal.fire("Record Deleted Successfully", "", "success");
            $("#btnCancel").click();
            this.props.selectTabAction("Patient");
          })
          .catch((error) => {
            Swal.fire(
              "Record Not Deleted!",
              "Record can not be deleted, as it is being referenced in other screens.",
              "error"
            );
          });
      }
    });
  };

  _handleSubmit(e) {
    e.preventDefault();
    // TODO: do something with -> this.state.file
  }

  _handleImageChange(e) {
    e.preventDefault();

    let reader = new FileReader();
    let file = e.target.files[0];

    reader.onloadend = () => {
      this.setState({
        file: file,
        imagePreviewUrl: reader.result,
      });
    };

    reader.readAsDataURL(file);
  }

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  openhistorypopup = (name, id) => {
    this.setState({ popupName: "NewHistoryPractice", id: id });
  };

  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ popupName: "" });
  };

  async addRowNotes(event) {
    const note = { ...this.notesModel };
    var len = this.state.patientModel.note
      ? this.state.patientModel.note.length
      : 0;
    if (len == 0) {
      await this.setState({
        patientModel: {
          ...this.state.patientModel,
          note: this.state.patientModel.note.concat(note),
        },
      });
      return;
    } else {
      len = len - 1;
      if (this.isNull(this.state.patientModel.note[len].note)) {
        Swal.fire("First Enter Previous Notes", "", "error");
        return;
      } else {
        await this.setState({
          patientModel: {
            ...this.state.patientModel,
            note: this.state.patientModel.note.concat(note),
          },
        });
      }
    }
    if (this.state.patientModel.note) {
    }
  }

  async addAuthRowNotes(event) {
    const authnote = { ...this.notesModel };
    var len = this.state.patientModel.authnote
      ? this.state.patientModel.authnote.length
      : 0;
    if (len == 0) {
      await this.setState({
        patientModel: {
          ...this.state.patientModel,
          //  authnote: this.state.patientModel.authnote.concat(note)
        },
      });
      return;
    } else {
      len = len - 1;
      if (this.isNull(this.state.patientModel.authnote[len].authnote)) {
        Swal.fire("First Enter Previous Notes", "", "error");
        return;
      } else {
        await this.setState({
          patientModel: {
            ...this.state.patientModel,
            //  authnote: this.state.patientModel.authnote.concat(authnote)
          },
        });
      }
    }
    if (this.state.patientModel.authnote) {
    }
  }

  // async addRowNotes() {
  //   const note = { ...this.notesModel };

  //   await this.setState({
  //     patientModel: {
  //       ...this.state.patientModel,
  //       note: this.state.patientModel.note.concat(note)
  //     }
  //   });
  // }

  handlePlanChange = (event) => {
    let newList = [...this.state.patientModel.patientPlans];
    const index = event.target.id;
    const name = event.target.name;
    const value = event.target.value;

    // handle First index Plan Coverage
    if (index == 0) {
      if (name == "coverage") {
        if (value != "P") {
          Swal.fire("Select First Coverage As Primary", "", "error");
          return;
        }
      }
    }

    if (name === "relationShip") {
      newList[index][name] =
        value == "Please Select" ? null : value.toUpperCase();
      if (value == 18) {
        newList[index].lastName = this.state.patientModel.lastName;
        newList[index].firstName = this.state.patientModel.firstName;
        newList[index].dob = this.state.patientModel.dob;
        newList[index].gender = this.state.patientModel.gender;
        newList[index].middleInitial = this.state.patientModel.middleInitial;
        newList[index].city = this.state.patientModel.city;
        newList[index].state = this.state.patientModel.state;
        newList[index].zipCode = this.state.patientModel.zipCode;
        newList[index].address1 = this.state.patientModel.address1;
      } else {
        newList[index].lastName = "";
        newList[index].firstName = "";
        newList[index].dob = "";
        newList[index].gender = "";
        newList[index].middleInitial = "";
        newList[index].city = "";
        newList[index].state = "";
        newList[index].zipCode = "";
        newList[index].address1 = "";
      }
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          patientPlans: newList,
        },
      });
    } else {
      newList[index][name] =
        value == "Please Select" ? null : value.toUpperCase();
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          patientPlans: newList,
        },
      });
    }

    //carret Position
    if (
      event.target.name == "dob" ||
      event.target.name == "startdate" ||
      event.target.name == "enddate"
    ) {
    } else {
      const caret = event.target.selectionStart;
      const element = event.target;
      window.requestAnimationFrame(() => {
        element.selectionStart = caret;
        element.selectionEnd = caret;
      });
    }
  };

  handleAuthChange = (event) => {
    let newList = [...this.state.patientModel.patientAuthorization];
    const index = event.target.id;
    const name = event.target.name;
    var value = event.target.value;

    if (name == "authorizationNumber") {
      var authorizationDate = new Date().toISOString().slice(0, 10);
      newList[index].authorizationDate = authorizationDate;
    } else if (name == "visitsAllowed") {
      newList[index].remaining =
        this.state.patientModel.patientAuthorization[index].visitsAllowed -
        this.state.patientModel.patientAuthorization[index].visitsUsed;
    } else if (
      name == "medicalNecessityRequired" ||
      name == "medicalRecordRequired"
    ) {
      if (value == "Y") {
        value = true;
      } else {
        value = false;
      }
      value = value;
    } else if (name == "status" || name == "responsibleParty") {
      value = value;
    } else {
      value = value.toUpperCase();
    }
    newList[index][name] = value;
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        patientAuthorization: newList,
      },
    });

    //carret Position
    if (
      event.target.name == "startDate" ||
      event.target.name == "endDate" ||
      event.target.name == "authorizationDate"
    ) {
    } else {
      const caret = event.target.selectionStart;
      const element = event.target;
      window.requestAnimationFrame(() => {
        element.selectionStart = caret;
        element.selectionEnd = caret;
      });
    }
  };

  handleRefChange = (event) => {
    console.log(event.target.value, event.target.name);
    let newList = [...this.state.patientModel.patientReferrals];
    const index = event.target.id;
    const name = event.target.name;
    var value = event.target.value;

    // handle First index Plan Coverage

    // if( name == "remaining"){
    //   value = newList[index]visitsAllowed - newList[index]visitsUsed;
    // }
    if (name == "status" || name == "rererralForService") {
      value = value;
    } else {
      value = value.toUpperCase();
    }
    newList[index][name] = value;
    this.setState({
      patientModel: {
        ...this.state.patientModel,
        patientReferrals: newList,
      },
    });

    //carret Position
    if (event.target.name == "startDate" || event.target.name == "endDate") {
    } else {
      const caret = event.target.selectionStart;
      const element = event.target;
      window.requestAnimationFrame(() => {
        element.selectionStart = caret;
        element.selectionEnd = caret;
      });
    }
  };

  // handleAuthDropDownChange = event => {
  //   console.log(event.target.value, event.target.name);
  //   let newList = [...this.state.patientModel.patientAuthorization];
  //   const index = event.target.id;
  //   const name = event.target.name;
  //   const value = event.target.value;

  //   newList[index][name] = value.toUpperCase();
  //   this.setState({
  //     patientModel: {
  //       ...this.state.patientModel,
  //       patientAuthorization: newList
  //     }
  //   });
  // };

  async handleNoteChange(event) {
    var value = event.target.value;
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    if (caret == 0 || caret <= 1) {
      value = value.trim();
    }
    let newNotesList = this.state.patientModel.note;
    const index = event.target.id;
    const name = event.target.name;
    newNotesList[index][name] = value.toUpperCase();

    this.setState({
      patientModel: {
        ...this.state.patientModel,
        note: newNotesList,
      },
    });
  }

  async handleAuthNoteChange(event) {
    var value = event.target.value;
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    if (caret == 0 || caret <= 1) {
      value = value.trim();
    }
    let newAuthNotesList = this.state.patientModel.authnote;
    const index = event.target.id;
    const name = event.target.name;
    newAuthNotesList[index][name] = value.toUpperCase();

    this.setState({
      patientModel: {
        ...this.state.patientModel,
        authnote: newAuthNotesList,
      },
    });
  }

  async deleteRowNotes(event, index, NoteRowId) {
    const NoteRowID = NoteRowId;
    const id = event.target.id;
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        //KHIZER CODE-------------------------DeleteNote
        if (NoteRowID > 0) {
          axios
            .delete(this.Notesurl + "DeleteNotes/" + NoteRowID, this.config)
            .then((response) => {
              Swal.fire("Record Deleted Successfully", "", "success");
              let note = [...this.state.patientModel.note];
              note.splice(id, 1);
              this.setState({
                patientModel: {
                  ...this.state.patientModel,
                  note: note,
                },
              });
            })
            .catch((error) => {
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let note = [...this.state.patientModel.note];
          note.splice(id, 1);
          this.setState({
            patientModel: {
              ...this.state.patientModel,
              note: note,
            },
          });
        }
      }
    });
  }

  //Patient Plans Functions
  addPlanRow() {
    const patientPlanModel = { ...this.patientPlanModel };

    var len = this.state.patientModel.patientPlans
      ? this.state.patientModel.patientPlans.length
      : 0;
    if (len == 0) {
      patientPlanModel.patientID = this.state.patientModel.id;
      var patientPlanModelList = [];
      if (this.isNull(this.state.patientModel.patientPlans)) {
        patientPlanModelList = patientPlanModelList.concat(patientPlanModel);
      } else {
        patientPlanModelList = this.state.patientModel.patientPlans.concat(
          patientPlanModel
        );
      }
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          patientPlans: patientPlanModelList,
        },
      });
      return;
    } else {
      len = len - 1;
      var patientPlans = this.state.patientModel.patientPlans;
      patientPlans[len].validation = false;
      //Last Name Validation
      if (this.isNull(patientPlans[len].lastName)) {
        patientPlans[len].lastNameValField = (
          <span className="validationMsg">Enter Last Name</span>
        );
        patientPlans[len].validation = true;
      } else {
        if (patientPlans[len].validation == false)
          patientPlans[len].validation = false;
      }
      //First Name Validation
      if (this.isNull(patientPlans[len].firstName)) {
        patientPlans[len].firstNameValField = (
          <span className="validationMsg">Enter First Name</span>
        );
        patientPlans[len].validation = true;
      } else {
        if (patientPlans[len].validation == false)
          patientPlans[len].validation = false;
      }

      //Coverage Val Field
      if (this.isNull(patientPlans[len].coverage)) {
        patientPlans[len].coverageValField = (
          <span className="validationMsg">Select Coverage</span>
        );
        patientPlans[len].validation = true;
      } else {
        if (patientPlans[len].validation == false)
          patientPlans[len].validation = false;
      }

      //Relationship Val Field
      if (this.isNull(patientPlans[len].relationShip)) {
        patientPlans[len].relationshipValField = (
          <span className="validationMsg">Select Rlationship</span>
        );
        patientPlans[len].validation = true;
      } else {
        if (patientPlans[len].validation == false)
          patientPlans[len].validation = false;
      }

      //Subscriber validation
      if (this.isNull(patientPlans[len].subscriberId)) {
        patientPlans[len].subscriberIDValField = (
          <span className="validationMsg">Enter SubscriberID</span>
        );
        patientPlans[len].validation = true;
      } else {
        if (patientPlans[len].validation == false)
          patientPlans[len].validation = false;
      }

      //Insurance Plan Validation
      // if (this.isNull(patientPlans[len].insurancePlanID)) {
      //   patientPlans[len] = (
      //     <span className="validationMsg">Enter Insurance Plan</span>
      //   );
      //   patientPlans[len].validation  = true;
      // } else {
      //   if( patientPlans[len].validation == false)  patientPlans[len].validation = false
      // }

      if (patientPlans[len].validation == true) {
        this.setState({
          patientModel: {
            ...this.state.patientModel,
            patientPlans: patientPlans,
          },
        });
        Swal.fire(
          "First  Fill All Required Fields of Curent Plan",
          "",
          "error"
        );
        return;
      }

      this.addMYPatientPlan(
        patientPlans[len],
        patientPlans[len].insurancePlanObject,
        patientPlans[len].insurancePlanID
      );

      patientPlans[len].commonKey =
        patientPlans[len].coverage.toString() +
        patientPlans[len].insurancePlanID.toString() +
        patientPlans[len].subscriberId.toString() +
        patientPlans[len].isActive.toString();

      patientPlanModel.patientID = this.state.patientModel.id;
      var patientPlanModelList = [];
      if (this.isNull(this.state.patientModel.patientPlans)) {
        patientPlanModelList = patientPlanModelList.concat(patientPlanModel);
      } else {
        patientPlanModelList = this.state.patientModel.patientPlans.concat(
          patientPlanModel
        );
      }
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          patientPlans: patientPlanModelList,
        },
      });
      return;
    }
  }

  async addAuthRow() {
    var len = this.state.patientModel.patientPlans.length - 1;
    var patientPlans = this.state.patientModel.patientPlans;
    patientPlans[len].commonKey =
      patientPlans[len].coverage.toString() +
      patientPlans[len].insurancePlanID.toString() +
      patientPlans[len].subscriberId.toString() +
      patientPlans[len].isActive.toString();

    var patientPlan = await this.myPatientPlans.filter(
      (patientPlan) => patientPlan.commonKey == patientPlans[len].commonKey
    );
    console.log("Patient Plan ;", patientPlan);
    if (patientPlan.length == 0) {
      this.addMYPatientPlan(
        patientPlans[len],
        patientPlans[len].insurancePlanObject,
        patientPlans[len].insurancePlanID
      );
    }

    var length = this.state.patientModel.patientAuthorization.length;
    console.log(length);
    if (length == 0) {
      const patientAuthModel = { ...this.patientAuthModel };
      patientAuthModel.patientID = this.state.patientModel.id;
      // set by default plan
      patientAuthModel.patientPlanID = patientPlans[0].insurancePlanObject.id;
      patientAuthModel.insurancePlanID = patientPlans[0].insurancePlanID;
      patientAuthModel.insurancePlanObject =
        patientPlans[0].insurancePlanObject;
      //Set Provider Object
      var provider = await this.props.userProviders.filter(
        (provider) => provider.id == this.state.patientModel.providerID
      );

      patientAuthModel.providerID = this.state.patientModel.providerID;
      patientAuthModel.providerObject = provider;
      var patientAuthModelList = [];
      if (this.isNull(this.state.patientModel.patientAuthorization)) {
        patientAuthModelList = patientAuthModelList.concat(patientAuthModel);
      } else {
        patientAuthModelList = this.state.patientModel.patientAuthorization.concat(
          patientAuthModel
        );
      }
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          patientAuthorization: patientAuthModelList,
          patientPlans: patientPlans,
        },
      });
    } else {
      len = length - 1;
      var patientAuth = this.state.patientModel.patientAuthorization;
      patientAuth[len].validation = false;
      //authorizationNumber
      // if (this.isNull(patientAuth[len].authorizationNumber)) {
      //   patientAuth[len].authorizationNumberValField = (
      //     <span className="validationMsg">Enter Auth #</span>
      //   );
      //   patientAuth[len].validation = true;
      // } else {
      //   if (patientAuth[len].validation == false)
      //     patientAuth[len].validation = false;
      // }

      //authorizationNumber
      // if (this.isNull(patientAuth[len].cptid)) {
      //   patientAuth[len].cptIDValField = (
      //     <span className="validationMsg">Enter CPT</span>
      //   );
      //   patientAuth[len].validation = true;
      // } else {
      //   if (patientAuth[len].validation == false)
      //     patientAuth[len].validation = false;
      // }

      // if (this.isNull(patientAuth[len].providerID)) {
      //   patientAuth[len].providerIDValField = (
      //     <span className="validationMsg">Enter Provider</span>
      //   );
      //   patientAuth[len].validation = true;
      // } else {
      //   if (patientAuth[len].validation == false)
      //     patientAuth[len].validation = false;
      // }

      // if (this.isNull(patientAuth[len].insurancePlanID)) {
      //   patientAuth[len].planIDValField = (
      //     <span className="validationMsg">Enter Insurnace Plan</span>
      //   );
      //   patientAuth[len].validation = true;
      // } else {
      //   if (patientAuth[len].validation == false)
      //     patientAuth.validation = false;
      // }

      // if (this.isNull(patientAuth[len].startDate)) {
      //   patientAuth[len].startdateNumberValField = (
      //     <span className="validationMsg">Enter Start Date</span>
      //   );
      //   patientAuth[len].validation = true;
      // } else {
      //   if (patientAuth[len].validation == false)
      //     patientAuth.validation = false;
      // }

      // if (this.isNull(patientAuth[len].endDate)) {
      //   patientAuth[len].enddateValField = (
      //     <span className="validationMsg">Enter End Date</span>
      //   );
      //   patientAuth[len].validation = true;
      // } else {
      //   if (patientAuth[len].validation == false)
      //     patientAuth.validation = false;
      // }

      // if (this.isNull(patientAuth[len].visitsAllowed)) {
      //   patientAuth[len].visitsAllowedValField = (
      //     <span className="validationMsg">Enter End Date</span>
      //   );
      //   patientAuth[len].validation = true;
      // } else {
      //   if (patientAuth[len].validation == false)
      //     patientAuth.validation = false;
      // }

      // if (patientAuth[len].validation == true) {
      //   this.setState({
      //     patientModel: {
      //       ...this.state.patientModel,
      //       patientAuthorization: patientAuth,
      //       patientPlans: patientPlans,
      //     },
      //   });
      //   Swal.fire(
      //     "First  Fill All Required Fields of Patient Authorization",
      //     "",
      //     "error"
      //   );
      //   return;
      // } else {
      const patientAuthModel = { ...this.patientAuthModel };
      patientAuthModel.patientID = this.state.patientModel.id;
      // set by default plan
      patientAuthModel.patientPlanID =
        patientPlans[0].insurancePlanObject[0].id;
      patientAuthModel.insurancePlanID = patientPlans[0].insurancePlanID;
      patientAuthModel.insurancePlanObject =
        patientPlans[0].insurancePlanObject;
      //Set Provider Object
      var provider = await this.props.userProviders.filter(
        (provider) => provider.id == this.state.patientModel.providerID
      );

      patientAuthModel.providerID = this.state.patientModel.providerID;
      patientAuthModel.providerObject = provider;
      var patientAuthModelList = [];
      if (this.isNull(this.state.patientModel.patientAuthorization)) {
        patientAuthModelList = patientAuthModelList.concat(patientAuthModel);
      } else {
        patientAuthModelList = this.state.patientModel.patientAuthorization.concat(
          patientAuthModel
        );
      }
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          patientAuthorization: patientAuthModelList,
          patientPlans: patientPlans,
        },
      });
    }
    // }
  }

  async addReferral(event) {
    var len = this.state.patientModel.patientPlans.length - 1;
    var patientPlans = this.state.patientModel.patientPlans;

    patientPlans[len].commonKey =
      patientPlans[len].coverage.toString() +
      patientPlans[len].insurancePlanID.toString() +
      patientPlans[len].subscriberId.toString() +
      patientPlans[len].isActive.toString();

    var patientPlan = await this.myPatientPlans.filter(
      (patientPlan) => patientPlan.commonKey == patientPlans[len].commonKey
    );

    if (patientPlan.length == 0) {
      this.addMYPatientPlan(
        patientPlans[len],
        patientPlans[len].insurancePlanObject,
        patientPlans[len].insurancePlanID
      );
    }

    var length = this.state.patientModel.patientReferrals.length;
    if (length == 0) {
      const patientReferrals = { ...this.patientReferral };
      patientReferrals.patientID = this.state.patientModel.id;
      // set by default plan
      patientReferrals.patientPlanID = patientPlans[0].insurancePlanObject.id
        ? patientPlans[0].insurancePlanObject.id
        : patientPlans[0].insurancePlanObject[0].id;
      patientReferrals.insurancePlanID = patientPlans[0].insurancePlanID;
      patientReferrals.insurancePlanObject =
        patientPlans[0].insurancePlanObject;
      //Set PCP && Provider Object
      var provider = await this.props.userProviders.filter(
        (provider) => provider.id == this.state.patientModel.providerID
      );
      console.log("Provider", provider);
      // NewPatientmodel.patientReferrals[index].pcpObject = provider;
      patientReferrals.pcpid = this.state.patientModel.providerID;
      patientReferrals.pcpObject = provider;
      patientReferrals.providerID = this.state.patientModel.providerID;
      patientReferrals.providerObject = provider;
      console.log(patientReferrals);

      var patientRefModelList = [];
      if (this.isNull(this.state.patientModel.patientReferrals)) {
        patientRefModelList = patientRefModelList.concat(patientReferrals);
      } else {
        patientRefModelList = this.state.patientModel.patientReferrals.concat(
          patientReferrals
        );
      }
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          patientReferrals: patientRefModelList,
          patientPlans: patientPlans,
        },
      });
    } else {
      len = length - 1;
      var patientReferral = this.state.patientModel.patientReferrals;
      patientReferral[len].validation = false;

      //patientPlanIDRefValField
      if (this.isNull(patientReferral[len].patientPlanID)) {
        patientReferral[len].patientPlanIDRefValField = (
          <span className="validationMsg">Enter Plan</span>
        );
        patientReferral[len].validation = true;
      } else {
        if (patientReferral[len].validation == false)
          patientReferral[len].validation = false;
      }
      //providerIDRefValField
      if (this.isNull(patientReferral[len].providerID)) {
        patientReferral[len].providerIDRefValField = (
          <span className="validationMsg">Enter Provider</span>
        );
        patientReferral[len].validation = true;
      } else {
        if (patientReferral[len].validation == false)
          patientReferral[len].validation = false;
      }

      if (patientReferral[len].validation == true) {
        this.setState({
          patientModel: {
            ...this.state.patientModel,
            patientReferrals: patientReferral,
            patientPlans: patientPlans,
          },
        });
        Swal.fire(
          "First  Fill All Required Fields of Patient Referral",
          "",
          "error"
        );
        return;
      } else {
        const patientReferralModel = { ...this.patientReferral };
        patientReferralModel.patientID = this.state.patientModel.id;
        // set by default plan
        patientReferralModel.patientPlanID = patientPlans[0].insurancePlanObject
          .id
          ? patientPlans[0].insurancePlanObject.id
          : patientPlans[0].insurancePlanObject[0].id;
        patientReferralModel.insurancePlanID = patientPlans[0].insurancePlanID;
        patientReferralModel.insurancePlanObject =
          patientPlans[0].insurancePlanObject;
        //Set PCP && Provider Object
        var provider = await this.props.userProviders.filter(
          (provider) => provider.id == this.state.patientModel.providerID
        );
        console.log("Provider", provider);
        // NewPatientmodel.patientReferrals[index].pcpObject = provider;
        patientReferralModel.pcpid = this.state.patientModel.providerID;
        patientReferralModel.pcpObject = provider;
        patientReferralModel.providerID = this.state.patientModel.providerID;
        patientReferralModel.providerObject = provider;
        console.log(patientReferralModel);
        var patientReferralModelList = [];
        if (this.isNull(this.state.patientModel.patientReferrals)) {
          patientReferralModelList = patientReferralModelList.concat(
            patientReferralModel
          );
        } else {
          patientReferralModelList = this.state.patientModel.patientReferrals.concat(
            patientReferralModel
          );
        }
        this.setState({
          patientModel: {
            ...this.state.patientModel,
            patientReferrals: patientReferralModelList,
            patientPlans: patientPlans,
          },
        });
      }
    }
  }
  //Remove Plan Row
  removePlanRow = (event, index, planID) => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        //KHIZER CODE-------------------------DeleteNote
        if (planID > 0) {
          axios
            .delete(
              this.patientPlanUrl + "DeletePatientPlan/" + planID,
              this.config
            )
            .then((response) => {
              Swal.fire(
                "Record Deleted!",
                "Record has been deleted.",
                "success"
              );
              let patientPlans = [...this.state.patientModel.patientPlans];
              patientPlans.splice(index, 1);
              this.setState({
                patientModel: {
                  ...this.state.patientModel,
                  patientPlans: patientPlans,
                },
              });
            })
            .catch((error) => {
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let patientPlans = [...this.state.patientModel.patientPlans];
          patientPlans.splice(index, 1);
          this.setState({
            patientModel: {
              ...this.state.patientModel,
              patientPlans: patientPlans,
            },
          });
        }
      }
    });
  };

  removeAuthRow = (event, index, ID) => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      this.setState({ loading: true });
      if (result.value) {
        //KHIZER CODE-------------------------DeleteNote
        if (ID > 0) {
          axios
            .delete(this.url + "DeletePatientAuth/" + ID, this.config)
            .then((response) => {
              Swal.fire(
                "Record Deleted!",
                "Record has been deleted.",
                "success"
              );
              let patientAuthModel = [
                ...this.state.patientModel.patientAuthorization,
              ];
              patientAuthModel.splice(index, 1);
              this.setState({
                loading: false,
                patientModel: {
                  ...this.state.patientModel,
                  patientAuthorization: patientAuthModel,
                },
              });
            })
            .catch((error) => {
              this.setState({ loading: false });
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let patientAuthModel = [
            ...this.state.patientModel.patientAuthorization,
          ];
          patientAuthModel.splice(index, 1);
          this.setState({
            loading: false,
            patientModel: {
              ...this.state.patientModel,
              patientAuthorization: patientAuthModel,
            },
          });
        }
      }
    });
  };

  removeRefRow = (event, index, ID) => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      this.setState({ loading: true });
      if (result.value) {
        //KHIZER CODE-------------------------DeleteNote
        if (ID > 0) {
          axios
            .delete(this.url + "DeletePatientReferral/" + ID, this.config)
            .then((response) => {
              this.setState({ loading: false });
              Swal.fire(
                "Record Deleted!",
                "Record has been deleted.",
                "success"
              );
              let patientReferral = [
                ...this.state.patientModel.patientReferrals,
              ];
              patientReferral.splice(index, 1);
              this.setState({
                patientModel: {
                  ...this.state.patientModel,
                  patientReferrals: patientReferral,
                },
              });
            })
            .catch((error) => {
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let patientReferral = [...this.state.patientModel.patientReferrals];
          patientReferral.splice(index, 1);
          this.setState({
            patientModel: {
              ...this.state.patientModel,
              patientReferrals: patientReferral,
            },
          });
        }
      }
    });
  };

  //toggle collapse
  toggleCollapse = (collapseID) => {
    const collapseIDL = this.state.collapseID != collapseID ? collapseID : 0;
    this.setState({ collapseID: collapseIDL });
  };

  //Handle Insurnace Plan Change
  handleInsurancePlanChange = (event) => {
    this.setState({ insurancePlanObject: event });
  };

  //Handle Patient Plan Change
  handlePatientPlanChange = (event) => {
    this.setState({
      patientPlans: {
        ...this.state.patientPlans,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase(),
      },
    });
  };

  addMYPatientPlan = async (patientPlan, event, insurancePlanID) => {
    // var newMyPatientPlans = await  this.myPatientPlans.filter(plan => plan.id != patientPlan.id);
    // console.log("New Patient Plans List : " , newMyPatientPlans);

    this.myPatientPlans.push({
      id: patientPlan.id,
      label: event.label,
      value: event.value,
      insurancePlanID: insurancePlanID,
      commonKey:
        patientPlan.coverage.toString() +
        patientPlan.insurancePlanID.toString() +
        patientPlan.subscriberId.toString() +
        patientPlan.isActive.toString(),
    });

    // this.myPatientPlans = newMyPatientPlans;
  };

  //Insurance Plan Change
  async handleInsurancePlansuggChange(event, index) {
    let newList = [...this.state.patientModel.patientPlans];

    if (event) {
      newList[index].insurancePlanID = event.id;
      newList[index].insurancePlanObject = event;

      try {
        await axios
          .get(
            this.insurancePlanAddressURL +
              "GetInsurancePlanAddressesByInsurancePlanID/" +
              event.id,
            this.config
          )
          .then((response) => {
            newList[index].insurancePlanAddresses = response.data;
          })
          .catch((error) => {
            console.log(error);
          });
      } catch {
        newList[index].insurancePlanAddresses = [];
      }

      this.setState({
        patientPlanModel: {
          ...this.state.patientPlanModel,
          insurancePlanID: event.id,
        },
      });
    } else {
      newList[index].insurancePlanID = null;
      newList[index].insurancePlanObject = [];
      newList[index].insurancePlanAddresses = [];

      this.setState({
        patientPlanModel: {
          ...this.state.patientPlanModel,
          patientPlans: newList,
        },
      });
    }
  }

  async handleInsuranceAuthsuggChange(event, index) {
    console.log("Plan : ", event);
    let newAuthList = [...this.state.patientModel.patientAuthorization];

    if (event) {
      newAuthList[index].patientPlanID = event.id;
      newAuthList[index].insurancePlanObject = event;
      newAuthList[index].commonKey = event.commonKey;
      newAuthList[index].insurancePlanID = event.insurancePlanID;
      // if (event.id == 0) {
      //   newAuthList[index].insurancePlanID = event.insurancePlanID;
      // }

      // await this.addMYPatientPlan(newAuthList[index], event, event.id);

      try {
        await axios
          .get(
            this.insurancePlanAddressURL +
              "GetInsurancePlanAddressesByInsurancePlanID/" +
              event.id,
            this.config
          )
          .then((response) => {
            newAuthList[index].insurancePlanAddresses = response.data;
          })
          .catch((error) => {
            console.log(error);
          });
      } catch {
        newAuthList[index].insurancePlanAddresses = [];
      }

      this.setState({
        patientAuthModel: {
          ...this.state.patientAuthModel,
          // insurancePlanID: event.id
          patientPlanID: event.id,
        },
      });
    } else {
      newAuthList[index].insurancePlanID = null;
      newAuthList[index].insurancePlanObject = [];
      newAuthList[index].insurancePlanAddresses = [];

      this.setState({
        patientAuthModel: {
          ...this.state.patientAuthModel,
          patientAuthorization: newAuthList,
        },
      });
    }
  }

  //Handle  ICD Change  Function
  async handleProviderChange(event, index) {
    //If ICD value selected
    let newList = [...this.state.patientModel.patientAuthorization];

    if (event) {
      newList[index].providerID = event.id;
      newList[index].providerObject = event;
    } else {
      newList[index].providerID = null;
      newList[index].providerObject = [];
    }
    this.setState({
      patientAuthModel: {
        ...this.state.patientAuthModel,
        patientAuthorization: newList,
      },
    });
  }

  async handleInsuranceRefsuggChange(event, index) {
    console.log("Plan : ", event);
    let newRefList = [...this.state.patientModel.patientReferrals];

    if (event) {
      newRefList[index].patientPlanID = event.id;
      newRefList[index].insurancePlanObject = event;
      newRefList[index].commonKey = event.commonKey;
      newRefList[index].insurancePlanID = event.insurancePlanID;
      try {
        await axios
          .get(
            this.insurancePlanAddressURL +
              "GetInsurancePlanAddressesByInsurancePlanID/" +
              event.id,
            this.config
          )
          .then((response) => {
            newRefList[index].insurancePlanAddresses = response.data;
          })
          .catch((error) => {
            console.log(error);
          });
      } catch {
        newRefList[index].insurancePlanAddresses = [];
      }

      this.setState({
        patientReferrals: {
          ...this.state.patientReferrals,
          // insurancePlanID: event.id
          patientPlanID: event.id,
        },
      });
    } else {
      newRefList[index].insurancePlanID = null;
      newRefList[index].insurancePlanObject = [];
      newRefList[index].insurancePlanAddresses = [];

      this.setState({
        patientReferrals: {
          ...this.state.patientReferrals,
          patientReferrals: newRefList,
        },
      });
    }
  }

  async handleRefProviderChange(event, index) {
    //If ICD value selected
    let newList = [...this.state.patientModel.patientReferrals];

    if (event) {
      newList[index].providerID = event.id;
      newList[index].providerObject = event;
    } else {
      newList[index].providerID = null;
      newList[index].providerObject = [];
    }
    this.setState({
      patientReferral: {
        ...this.state.patientReferral,
        patientReferrals: newList,
      },
    });
  }

  async handleRefPCPChange(event, index) {
    //If ICD value selected
    let newList = [...this.state.patientModel.patientReferrals];

    if (event) {
      newList[index].pcpid = event.id;
      newList[index].pcpObject = event;
    } else {
      newList[index].pcpid = null;
      newList[index].pcpObject = [];
    }
    this.setState({
      patientReferral: {
        ...this.state.patientReferral,
        patientReferrals: newList,
      },
    });
  }

  async handleicdChange(event, index) {
    let newList = [...this.state.patientModel.patientAuthorization];

    if (event) {
      newList[index].icdid = event.id;
      newList[index].icdObject = event;
    } else {
      newList[index].icdid = null;
      newList[index].icdObject = [];
    }
    this.setState({
      patientAuthModel: {
        ...this.state.patientAuthModel,
        patientAuthorization: newList,
      },
    });
  }

  async handlecptChange(event, index) {
    let newList = [...this.state.patientModel.patientAuthorization];

    if (event) {
      newList[index].cptid = event.id;
      newList[index].cptObject = event;
    } else {
      newList[index].cptid = null;
      newList[index].cptObject = [];
    }
    this.setState({
      patientAuthModel: {
        ...this.state.patientAuthModel,
        patientAuthorization: newList,
      },
    });
  }

  //Previous Visit
  async previousVisit() {
    if (this.currentIndex - 1 < 0) {
      Swal.fire("No More Patients", "", "warning");
      return;
    }
    this.currentIndex = this.currentIndex - 1;
    var patient = this.props.patientGridData[this.currentIndex];
    await this.setState({
      editId: patient.id,
      patientModel: {
        ...this.state.patientModel,
        id: 0,
      },
    });
    this.props.selectPatient({ ID: patient.id, accNum: patient.accountNum });
    this.props.selectTabAction("NewPatient", patient.id);
    this.UNSAFE_componentWillMount();
  }

  //NextVisit
  async nextVisit() {
    if (this.currentIndex + 1 >= this.props.patientGridData.length) {
      Swal.fire("No More Patients", "", "warning");
      return;
    }
    this.currentIndex = this.currentIndex + 1;
    var patient = this.props.patientGridData[this.currentIndex];
    await this.setState({
      editId: patient.id,
      patientModel: {
        ...this.state.patientModel,
        id: 0,
      },
    });
    this.props.selectPatient({ ID: patient.id, accNum: patient.accountNum });
    this.props.selectTabAction("NewPatient", patient.id);
    this.UNSAFE_componentWillMount();
  }

  //On Paste Function
  onPaste = (event) => {
    var x = event.target.value;
    x = x.trim();
    var regex = /^[0-9]+$/;
    if (x.length == 0) {
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          [event.target.name]: x,
        },
      });
      return;
    }

    if (!x.match(regex)) {
      Swal.fire("", "Should be Number", "error");
      return;
    } else {
      this.setState({
        patientModel: {
          ...this.state.patientModel,
          [event.target.name]: x,
        },
      });
    }

    return;
  };

  //Filter Options
  filterOption = (option, inputValue) => {
    try {
      var value = inputValue + "";
      if (value.length > 1) {
        const words = inputValue.split(" ");
        return words.reduce(
          (acc, cur) =>
            acc && option.label.toLowerCase().includes(cur.toLowerCase()),
          true
        );
      }
    } catch {
      console.log("Error");
    }
  };

  closevisitPopup = () => {
    $("#submittedVisitsModal").hide();
    this.setState({ showVPopup: false });
  };

  openvisitPopup = (id) => {
    this.setState({
      showVPopup: true,
      patientAuthID: id,
    });
  };

  closefaxPopup = () => {
    $("#faxModal").hide();
    this.setState({ showFPopup: false });
  };

  async openfaxPopup(index) {
    this.setState({ loading: true });
    var faxNumber = "";
    var referralDocumentFileName = "";
    await axios
      .get(
        this.proURL + "findprovider/" + this.state.patientModel.providerID,
        this.config
      )
      .then((response) => {
        faxNumber = response.data.faxNumber;
        referralDocumentFileName = response.data.referralDocumentFileName;
        this.setState({ loading: false });
      })
      .catch((error) => {
        console.log(error);
      });
    let modelList = [];
    modelList = {
      pcp: this.state.patientModel.patientReferrals[index].pcp,
      patientName:
        this.state.patientModel.firstName +
        " " +
        this.state.patientModel.lastName,
      patientDOB: this.state.patientModel.dob,
      serviceName: this.state.patientModel.patientReferrals[index]
        .rererralForService,
      providerID: this.state.patientModel.providerID,
      faxNumber: faxNumber,
      patientid: this.state.patientModel.id,
      pcpproviderid: this.state.patientModel.patientReferrals[index].pcpid,
      providerid: this.state.patientModel.patientReferrals[index].providerID,
      referralDocumentFileName: referralDocumentFileName,
    };
    this.setState({
      showFPopup: true,
      faxModel: modelList,
    });
  }

  async getbatchID(batID) {
    $("#myModal").hide();
    this.setState({
      popupName: "",
      id: 0,
      patientModel: {
        ...this.state.patientModel,
        batchDocumentID: batID[0],
      },
    });
  }

  render() {
    try {
      this.props.patientGridData.filter((patient, index) => {
        if (patient.id == this.state.editId) {
          this.currentIndex = index;
        }
      });
    } catch {}

    try {
      if (this.props.userInfo1.userPractices.length > 0) {
        if (this.state.practice.length == 0) {
          if (this.state.editId == 0) {
            let locID =
              this.props.userInfo1.userLocations.length > 1
                ? this.props.userInfo1.userLocations[1].id
                : null;
            let provID =
              this.props.userInfo1.userProviders.length > 1
                ? this.props.userInfo1.userProviders[1].id
                : null;
            let refProvID =
              this.props.userInfo1.userRefProviders.length > 1
                ? this.props.userInfo1.userRefProviders[0].id
                : null;

            this.setState({
              patientModel: {
                ...this.state.patientModel,
                practiceID: this.props.userInfo1.practiceID,
                locationId: locID,
                providerID: provID,
                refProviderID: refProvID,
              },
              practice: this.props.userInfo1.userPractices,
              location: this.props.userInfo1.userLocations,
              provider: this.props.userInfo1.userProviders,
              refProvider: this.props.userInfo1.userRefProviders,
            });
          } else {
            this.setState({
              patientModel: {
                ...this.state.patientModel,
                practiceID: this.props.userInfo1.practiceID,
              },
              practice: this.props.userInfo1.userPractices,
              location: this.props.userInfo1.userLocations,
              provider: this.props.userInfo1.userProviders,
              refProvider: this.props.userInfo1.userRefProviders,
            });
          }
        }
      }
    } catch {}

    let imagePreviewUrl = this.state.imagePreviewUrl;

    let $imagePreview = null;
    if (imagePreviewUrl) {
      $imagePreview = <img src={imagePreviewUrl} />;
    } else {
      $imagePreview = <img src={patientPic} />;
    }

    let active = this.state.patientModel.isActive;

    const usStates = [
      { value: "", display: "Select State" },
      { value: "AL", display: "AL - Alabama" },
      { value: "AK", display: "AK - Alaska" },
      { value: "AZ", display: "AZ - Arizona" },
      { value: "AR", display: "AR - Arkansas" },
      { value: "CA", display: "CA - California" },
      { value: "CO", display: "CO - Colorado" },
      { value: "CT", display: "CT - Connecticut" },
      { value: "DE", display: "DE - Delaware" },
      { value: "FL", display: "FL - Florida" },
      { value: "GA", display: "GA - Georgia" },
      { value: "HI", display: "HI - Hawaii" },
      { value: "ID", display: "ID - Idaho" },
      { value: "IL", display: "IL - Illinois" },
      { value: "IN", display: "IN - Indiana" },
      { value: "IA", display: "IA - Iowa" },
      { value: "KS", display: "KS - Kansas" },
      { value: "KY", display: "KY - Kentucky" },
      { value: "LA", display: "LA - Louisiana" },
      { value: "ME", display: "ME - Maine" },
      { value: "MD", display: "MD - Maryland" },
      { value: "MA", display: "MA - Massachusetts" },
      { value: "MI", display: "MI - Michigan" },
      { value: "MN", display: "MN - Minnesota" },
      { value: "MS", display: "MS - Mississippi" },
      { value: "MO", display: "MO - Missouri" },
      { value: "MT", display: "MT - Montana" },
      { value: "NE", display: "NE - Nebraska" },
      { value: "NV", display: "NV - Nevada" },
      { value: "NH", display: "NH - New Hampshire" },
      { value: "NJ", display: "NJ - New Jersey" },
      { value: "NM", display: "NM - New Mexico" },
      { value: "NY", display: "NY - New York" },
      { value: "NC", display: "NC - North Carolina" },
      { value: "ND", display: "ND - North Dakota" },
      { value: "OH", display: "OH - Ohio" },
      { value: "OK", display: "OK - Oklahoma" },
      { value: "OR", display: "OR - Oregon" },
      { value: "PA", display: "PA - Pennsylvania" },
      { value: "RI", display: "RI - Rhode Island" },
      { value: "SC", display: "SC - South Carolina" },
      { value: "SD", display: "SD - South Dakota" },
      { value: "TN", display: "TN - Tennessee" },
      { value: "TX", display: "TX - Texas" },
      { value: "UT", display: "UT - Utah" },
      { value: "VT", display: "VT - Vermont" },
      { value: "VA", display: "VA - Virginia" },
      { value: "WA", display: "WA - Washington" },
      { value: "WV", display: "WV - West Virginia" },
      { value: "WI", display: "WI - Wisconsin" },
      { value: "WY", display: "WY - Wyoming" },
    ];

    const titles = [
      { value: "", display: "Select Title" },
      { value: "MR.", display: "MR" },
      { value: "MRS.", display: "MRS" },
    ];

    const gender = [
      { value: "", display: "Select Gender" },
      { value: "M", display: "MALE" },
      { value: "F", display: "FEMALE" },
      { value: "U", display: "UNKNOWN" },
    ];

    const matitalStatus = [
      { value: "", display: "MARITAL STATUS" },
      { value: "SINGLE", display: "SINGLE" },
      { value: "MARRIED", display: "MARRIED" },
      { value: "DIVORCED", display: "DIVORCED" },
      { value: "WIDOW", display: "WIDOW" },
      { value: "OTHER", display: "OTHER" },
    ];

    const options = [
      { value: "History", label: "History", className: "dropdown" },
    ];

    const relationship = [
      { value: "", display: "Select Relationship" },
      { value: "18", display: "18 SELF" },
      { value: "01", display: "01 SPOUSE" },
      { value: "19", display: "19 CHiLD" },
      { value: "20", display: "20 EMPLOYEE" },
      { value: "21", display: "21 UNKNOWN" },
      { value: "39", display: "39 ORGAN DONAR" },
      { value: "53", display: "53 LIFE PARTNER" },
      { value: "G8", display: "G8 OTHER RELATIONSHIP" },
    ];

    //Coverage
    const coverage = [
      { value: "", display: "Select Coverage" },
      { value: "P", display: "PRIMARY" },
      { value: "S", display: "SECONDARY" },
      { value: "T", display: "TERTIARY" },
    ];

    const medicalRecordRequired = [
      { value: "", display: "Please Select" },
      { value: "Y", display: "YES" },
      { value: "N", display: "NO" },
    ];

    const medicalNecessityRequired = [
      { value: "", display: "Please Select" },
      { value: "Y", display: "YES" },
      { value: "N", display: "NO" },
    ];

    const headers = ["Plans", "Authorizations", "Referrals", "Notes"];

    const status = [
      // { value: "AUTH REQUIRED", display: "AUTH REQUIRED" },
      { value: "ACTIVE", display: "ACTIVE" },
      { value: "IN ACTIVE", display: "IN ACTIVE" },
    ];

    const pAuthstatus = [
      { value: "AUTH REQUIRED", display: "AUTH REQUIRED" },
      { value: "ACTIVE", display: "ACTIVE" },
      { value: "IN ACTIVE", display: "IN ACTIVE" },
      { value: "IN PROCESS", display: "IN PROCESS" },
      { value: "MD ORDERS REQUESTED", display: "MD ORDERS REQUESTED" },
    ];

    const responsibleParty = [
      { value: "BELLMEDEX", display: "BELLMEDEX" },
      { value: "CLIENT", display: "CLIENT" },
    ];

    const referralFor = [
      { value: "", display: "Please Select" },
      {
        value: "Most Recent Wellness Visit",
        display: "MOST RECENT WELLNESS VISIT",
      },
      {
        value: "Medical Clearance for Speech Therapy",
        display: "MEDICAL CLEARANCE FOR SPEECH THERAPY",
      },
      {
        value: "Medical Clearance for Hearing Aids",
        display: "MEDICAL CLEARANCE FOR HEARING AIDS",
      },
      {
        value: "Most Recent Audiological Evaluation",
        display: "MOST RECENT AUDIOLOGICAL EVALUATION",
      },
      {
        value: "Dizziness/Balance Testing",
        display: "DIZZINESS/BALANCE TESTING",
      },
      {
        value: "Most Recent Speech Language Evaluation",
        display: "MOST RECENT SPEECH LANGUAGE EVALUATION",
      },
      {
        value: "Auditory Brainstem Response Results",
        display: "AUDITORY BRAINSTEM RESPONSE RESULTS",
      },
    ];

    let newList = [];
    var patientPlanData = {};

    var patientPlan = [];
    if (this.isNull(this.state.patientModel.patientPlans)) {
      patientPlan = [];
    } else {
      patientPlan = this.state.patientModel.patientPlans;
    }
    patientPlan.map((row, index) => {
      var insurancePlanAddresses = row.insurancePlanAddresses
        ? row.insurancePlanAddresses
        : [];
      var dob = row.dob ? row.dob.slice(0, 10) : "";
      newList.push({
        id: "row.id",

        coverage: (
          <div style={{ width: "130px" }} className="textBoxValidate">
            <select
              name="coverage"
              id={index}
              value={this.state.patientModel.patientPlans[index].coverage}
              onChange={this.handlePlanChange}
            >
              {coverage.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.display}
                </option>
              ))}
            </select>
            {row.coverageValField}
          </div>
        ),

        insurancePlan: (
          <div style={{ width: "205px" }} className="textBoxValidate">
            <Select
              type="text"
              value={
                this.state.patientModel.patientPlans[index].insurancePlanObject
              }
              name="insurancePlanID"
              id="insurancePlanID"
              max="10"
              onChange={(event) =>
                this.handleInsurancePlansuggChange(event, index)
              }
              options={this.state.insurancePlans}
              // onKeyDown={(e)=>this.filterOption(e)}
              // filterOption={this.filterOption}
              menuShouldBlockScroll={true}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                // menuPortal: provided => ({ ...provided, zIndex: 2000 }),
                indicatorSeparator: () => {},
                // container : (defaultProps) =>({
                //   ...defaultProps,
                //   position:"absulute",
                //   width: "16%",
                //   zIndex: "999 !important"
                // }),
                menu: (styles) => ({
                  ...styles,
                  // width: '125px',
                  zIndex: "999 !important",
                }),
                clearIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  color: "#286881",
                }),
                indicatorsContainer: (defaultStyles) => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "2px",
                }),
                dropdownIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  display: "none",
                }),
                singleValue: (defaultStyles) => ({
                  ...defaultStyles,
                  paddingBottom: "9px",
                }),
              }}
            />

            {row.insurancePlanValField}
          </div>
        ),
        authRequired: (
          <div style={{ width: "60px" }}>
            <div className="lblChkBox">
              <input
                type="checkbox"
                id={"authRequired" + index}
                name="authRequired"
                checked={row.authRequired}
                onChange={() => this.handlePatientPlanAuthReqCheck(index)}
              />
              <label htmlFor={"authRequired" + index}>
                {/* <span>Active</span> */}
              </label>
            </div>
          </div>
        ),
        subscriberID: (
          <div style={{ width: "160px" }} className="textBoxValidate">
            <input
              type="text"
              name="subscriberId"
              id={index}
              maxLength="20"
              value={this.state.patientModel.patientPlans[index].subscriberId}
              onChange={this.handlePlanChange}
              // onKeyPress={this.handleNumericCheck}
            ></input>
            {row.subscriberIDValField}
          </div>
        ),
        relationShip: (
          <div style={{ width: "150px" }} className="textBoxValidate">
            <select
              name="relationShip"
              id={index}
              value={this.state.patientModel.patientPlans[index].relationShip}
              onChange={this.handlePlanChange}
            >
              {relationship.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.display}
                </option>
              ))}
            </select>
            {row.relationshipValField}
          </div>
        ),
        lastName: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <input
                type="text"
                name="lastName"
                id={index}
                maxLength="25"
                value={this.state.patientModel.patientPlans[index].lastName}
                onChange={this.handlePlanChange}
              ></input>
              {row.lastNameValField}
            </div>
          </div>
        ),
        firstName: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <input
                type="text"
                name="firstName"
                id={index}
                maxLength="25"
                value={this.state.patientModel.patientPlans[index].firstName}
                onChange={this.handlePlanChange}
              ></input>
              {row.firstNameValField}
            </div>
          </div>
        ),
        middleInitial: (
          <div style={{ width: "70px" }}>
            <input
              type="text"
              name="middleInitial"
              id={index}
              maxLength="3"
              value={this.state.patientModel.patientPlans[index].middleInitial}
              onChange={this.handlePlanChange}
            ></input>
          </div>
        ),
        gender: (
          <div style={{ width: "110px" }}>
            <select
              name="gender"
              id={index}
              value={this.state.patientModel.patientPlans[index].gender}
              onChange={this.handlePlanChange}
            >
              {gender.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.display}
                </option>
              ))}
            </select>
          </div>
        ),
        dob: (
          <div className="textBoxValidate" style={{ width: "130px" }}>
            <input
              type="date"
              min="1900-01-01"
              max="9999-12-31"
              name="dob"
              min="1900-01-01"
              max="9999-12-31"
              id={index}
              value={dob}
              onChange={this.handlePlanChange}
            ></input>
            {row.dobValField}
          </div>
        ),
        address1: (
          <div style={{ width: "200px" }}>
            <input
              type="text"
              name="address1"
              id={index}
              maxLength="55"
              value={this.state.patientModel.patientPlans[index].address1}
              onChange={this.handlePlanChange}
            ></input>
          </div>
        ),
        city: (
          <div style={{ width: "100px" }}>
            <input
              type="text"
              name="city"
              id={index}
              maxLength="20"
              value={this.state.patientModel.patientPlans[index].city}
              onChange={this.handlePlanChange}
            ></input>
          </div>
        ),
        state: (
          <div style={{ width: "120px" }}>
            <select
              name="state"
              id={index}
              value={this.state.patientModel.patientPlans[index].state}
              onChange={this.handlePlanChange}
            >
              {usStates.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.display}
                </option>
              ))}
            </select>
          </div>
        ),
        zipCode: (
          <div style={{ width: "100px" }}>
            <input
              className={
                this.state.validationModel.zipCodeValField
                  ? this.errorField
                  : ""
              }
              type="text"
              name="planZipCode"
              id={index}
              maxLength="9"
              value={this.state.patientModel.patientPlans[index].zipCode}
              onChange={this.handleZip}
              onKeyPress={(event) => this.handleNumericCheck(event)}
            ></input>
          </div>
        ),
        insurancePlanAddress: (
          <div style={{ width: "150px" }}>
            <select
              name="insurancePlanAddressID"
              id={index}
              value={
                this.state.patientModel.patientPlans[index]
                  .insurancePlanAddressID == null
                  ? "Please Select"
                  : this.state.patientModel.patientPlans[index]
                      .insurancePlanAddressID
              }
              onChange={this.handlePlanChange}
            >
              {insurancePlanAddresses.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.address1}
                </option>
              ))}
            </select>
          </div>
        ),
        isActive: (
          <div style={{ width: "60px" }}>
            {/*//<span>{this.state.planFollowupModel.note[index].addedBy}</span> */}
            <div className="lblChkBox">
              <input
                type="checkbox"
                id={"markInactive" + index}
                name="markInactive"
                checked={row.isActive}
                onChange={() => this.handlePatientPlanCheck(index)}
              />
              <label htmlFor={"markInactive" + index}>
                {/* <span>Active</span> */}
              </label>
            </div>
          </div>
        ),
        remove: (
          <div style={{ width: "50px", textAlign: "center" }}>
            <button
              className="removeBtn"
              name="deleteCPTBtn"
              id={index}
              onClick={(event) => this.removePlanRow(event, index, row.id)}
            ></button>
          </div>
        ),
      });
    });

    patientPlanData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          //width: 150
        },

        {
          label: "COVERAGE",
          field: "coverage",
          sort: "asc",
          //width: 150
        },
        {
          label: "PLAN NAME",
          field: "insurancePlan",
          sort: "asc",
          //width: 150
        },
        {
          label: "AUTH REQ.",
          field: "authRequired",
          sort: "asc",
          //width: 150
        },
        {
          label: "SUBSCRIBER ID",
          field: "subscriberID",
          sort: "asc",
          //width: 150
        },
        {
          label: "RELATIONSHIP",
          field: "relationShip",
          sort: "asc",
          //width: 150
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          //width: 150
        },
        {
          label: "FIRST NAME",
          field: "firstName",
          sort: "asc",
          //width: 150
        },
        {
          label: "MI",
          field: "middleInitial",
          sort: "asc",
          //width: 150
        },
        {
          label: "GENDER",
          field: "gender",
          sort: "asc",
          //width: 150
        },
        {
          label: "DOB",
          field: "dob",
          sort: "asc",
          //width: 150
        },
        {
          label: "ADDRESS",
          field: "address1",
          sort: "asc",
          //width: 150
        },
        {
          label: "CITY",
          field: "city",
          sort: "asc",
          //width: 150
        },
        {
          label: "STATE",
          field: "state",
          sort: "asc",
          //width: 150
        },
        {
          label: "ZIP",
          field: "zipCode",
          sort: "asc",
          //width: 150
        },
        {
          label: "PLAN ADDRESS",
          field: "insurancePlanAddress",
          sort: "asc",
          //width: 150
        },
        {
          label: "ACTIVE",
          field: "isActive",
          sort: "asc",
          //width: 150
        },
        {
          label: "",
          field: "remove",
          sort: "asc",
          //width: 150
        },
      ],
      rows: newList,
    };

    console.log("My Plans ; ", this.myPatientPlans);

    /******************AFZAAL
     * CHANGES FOR
     * AUTH GRID
     * **************/

    let newAuthList = [];
    var patientAuthData = {};

    var patientAuth = [];
    if (this.isNull(this.state.patientModel.patientAuthorization)) {
      patientAuth = [];
    } else {
      patientAuth = this.state.patientModel.patientAuthorization;
    }

    patientAuth.map((row, index) => {
      var startdate = row.startDate ? row.startDate.slice(0, 10) : "";
      var enddate = row.endDate ? row.endDate.slice(0, 10) : "";
      var addedDate = new Date().toISOString().slice(0, 10);
      row.addedDate = addedDate;
      addedDate = row.addedDate;

      var authorizationDate = row.authorizationDate
        ? row.authorizationDate.slice(0, 10)
        : "";

      newAuthList.push({
        id: "row.id",
        plan: (
          <div style={{ width: "205px" }} className="textBoxValidate">
            <Select
              type="text"
              value={
                this.state.patientModel.patientAuthorization[index]
                  .insurancePlanObject
              }
              name="insurancePlanID"
              id="insurancePlanID"
              max="10"
              onChange={(event) =>
                this.handleInsuranceAuthsuggChange(event, index)
              }
              options={this.myPatientPlans}
              filterOption={this.filterOption}
              menuShouldBlockScroll={true}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => {},

                menu: (styles) => ({
                  ...styles,
                  // width: '125px',
                  zIndex: "999 !important",
                }),
                clearIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  color: "#286881",
                }),

                indicatorsContainer: (defaultStyles) => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "2px",
                }),
                dropdownIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  display: "none",
                }),
                singleValue: (defaultStyles) => ({
                  ...defaultStyles,
                  paddingBottom: "9px",
                }),
              }}
            ></Select>

            {/* {row.planIDValField} */}
            {/* {row.insurancePlanValField} */}
          </div>
        ),
        providerID: (
          <div style={{ width: "205px" }} className="textBoxValidate">
            <Select
              value={
                this.state.patientModel.patientAuthorization[index]
                  .providerObject
              }
              onChange={(event) => this.handleProviderChange(event, index)}
              options={this.props.userProviders}
              placeholder=""
              filterOption={this.filterOption}
              menuShouldBlockScroll={true}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => {},

                menu: (styles) => ({
                  ...styles,
                  // width: '125px',
                  zIndex: "999 !important",
                }),
                clearIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  color: "#286881",
                }),

                indicatorsContainer: (defaultStyles) => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "2px",
                }),
                dropdownIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  display: "none",
                }),
                singleValue: (defaultStyles) => ({
                  ...defaultStyles,
                  paddingBottom: "9px",
                }),
              }}
            />
            {/* {row.providerIDValField} */}
            {/* <div style={{ marginTop: "30%" }}>
        {this.state.validationModel.icd1ValField}
      </div> */}
          </div>
        ),
        icdid: (
          <div style={{ width: "120px" }} className="textBoxValidate">
            <Select
              value={
                this.state.patientModel.patientAuthorization[index].icdObject
              }
              onChange={(event) => this.handleicdChange(event, index)}
              options={this.props.icdCodes}
              placeholder=""
              filterOption={this.filterOption}
              menuShouldBlockScroll={true}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => {},

                menu: (styles) => ({
                  ...styles,
                  // width: '125px',
                  zIndex: "999 !important",
                }),
                clearIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  color: "#286881",
                }),

                indicatorsContainer: (defaultStyles) => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "2px",
                }),
                dropdownIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  display: "none",
                }),
                singleValue: (defaultStyles) => ({
                  ...defaultStyles,
                  paddingBottom: "9px",
                }),
              }}
            />
            {/* <div style={{ marginTop: "30%" }}>
      {this.state.validationModel.icd1ValField}
    </div> */}
          </div>
        ),
        cptid: (
          <div style={{ width: "120px" }} className="textBoxValidate">
            <Select
              value={
                this.state.patientModel.patientAuthorization[index].cptObject
              }
              onChange={(event) => this.handlecptChange(event, index)}
              options={this.props.cptCodes}
              placeholder=""
              filterOption={this.filterOption}
              menuShouldBlockScroll={true}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => {},

                menu: (styles) => ({
                  ...styles,
                  // width: '125px',
                  zIndex: "999 !important",
                }),
                clearIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  color: "#286881",
                }),

                indicatorsContainer: (defaultStyles) => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "2px",
                }),
                dropdownIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  display: "none",
                }),
                singleValue: (defaultStyles) => ({
                  ...defaultStyles,
                  paddingBottom: "9px",
                }),
              }}
            />
            {/* {row.cptIDValField} */}
          </div>
        ),
        authorizationNumber: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <input
                type="text"
                name="authorizationNumber"
                id={index}
                maxLength="25"
                value={
                  this.state.patientModel.patientAuthorization[index]
                    .authorizationNumber
                }
                onChange={this.handleAuthChange}
              ></input>
            </div>
            {/* {row.authorizationNumberValField} */}
          </div>
        ),

        authorizationDate: (
          <div className="textBoxValidate" style={{ width: "150px" }}>
            <input
              type="date"
              min="1900-01-01"
              max="9999-12-31"
              name="authorizationDate"
              min="1900-01-01"
              max="9999-12-31"
              disabled={true}
              id={index}
              value={authorizationDate}
              onChange={this.handleAuthChange}
            ></input>
          </div>
        ),
        startdate: (
          <div className="textBoxValidate" style={{ width: "150px" }}>
            <input
              type="date"
              min="1900-01-01"
              max="9999-12-31"
              name="startDate"
              min="1900-01-01"
              max="9999-12-31"
              id={index}
              value={startdate}
              onChange={this.handleAuthChange}
            ></input>
            {/* {row.startdateNumberValField} */}
          </div>
        ),
        enddate: (
          <div className="textBoxValidate" style={{ width: "150px" }}>
            <input
              type="date"
              min="1900-01-01"
              max="9999-12-31"
              name="endDate"
              min="1900-01-01"
              max="9999-12-31"
              id={index}
              value={enddate}
              onChange={this.handleAuthChange}
            ></input>
            {/* {row.enddateValField}
            {row.greaterValField} */}
          </div>
        ),
        visitsAllowed: (
          <div className="container" style={{ width: "250px" }}>
            <div className="row">
              <div style={{ width: "70px", marginRight: "3%" }}>
                <div className="textBoxValidate">
                  <input
                    type="text"
                    name="visitsAllowed"
                    id={index}
                    maxLength="25"
                    value={
                      this.state.patientModel.patientAuthorization[index]
                        .visitsAllowed
                    }
                    onChange={this.handleAuthChange}
                  ></input>
                  {row.visitsAllowedValField}
                </div>
              </div>

              <div style={{ width: "70px", marginRight: "3%" }}>
                <div className="textBoxValidate">
                  <MDBBtn
                    className="gridBlueBtn"
                    onClick={() =>
                      this.openvisitPopup(
                        this.state.patientModel.patientAuthorization[index].id
                      )
                    }
                  >
                    {" "}
                    {
                      this.state.patientModel.patientAuthorization[index]
                        .visitsUsed
                    }
                  </MDBBtn>
                </div>
              </div>

              <div style={{ width: "70px" }}>
                <div className="textBoxValidate">
                  <input
                    type="text"
                    name="remaining"
                    id={index}
                    readOnly
                    maxLength="25"
                    value={
                      (this.state.patientModel.patientAuthorization[
                        index
                      ].remaining =
                        this.state.patientModel.patientAuthorization[index]
                          .visitsAllowed -
                        this.state.patientModel.patientAuthorization[index]
                          .visitsUsed)
                    }
                    onChange={this.handleAuthChange}
                  ></input>
                </div>
              </div>
            </div>
          </div>
        ),
        // visitsUsed: (
        // <div style={{ width: "70px" }}>
        //   <div className="textBoxValidate">

        //     <MDBBtn
        //       className="gridBlueBtn"
        //       onClick={() =>
        //         this.openvisitPopup(
        //           this.state.patientModel.patientAuthorization[index].id
        //         )
        //       }
        //     >
        //       {" "}
        //       {this.state.patientModel.patientAuthorization[index].visitsUsed}
        //     </MDBBtn>
        //   </div>
        // </div>
        // ),
        // remaining: (
        //   <div style={{ width: "70px" }}>
        //     <div className="textBoxValidate">
        //       <input
        //         type="text"
        //         name="remaining"
        //         id={index}
        //         readOnly
        //         maxLength="25"
        //         value={
        //           (this.state.patientModel.patientAuthorization[
        //             index
        //           ].remaining =
        //             this.state.patientModel.patientAuthorization[index]
        //               .visitsAllowed -
        //             this.state.patientModel.patientAuthorization[index]
        //               .visitsUsed)
        //         }
        //         onChange={this.handleAuthChange}
        //       ></input>
        //     </div>
        //   </div>
        // ),
        remindBeforeDays: (
          <div className="container" style={{ width: "210px" }}>
            <div className="row">
              <div style={{ width: "80px", marginRight: "3%" }}>
                <div className="textBoxValidate">
                  <input
                    type="text"
                    name="remindBeforeDays"
                    id={index}
                    maxLength="25"
                    value={
                      this.state.patientModel.patientAuthorization[index]
                        .remindBeforeDays
                    }
                    onChange={this.handleAuthChange}
                  ></input>
                  {/* {row.visitsAllowedValField} */}
                </div>
              </div>

              <div style={{ width: "80px" }}>
                <div className="textBoxValidate">
                  <input
                    type="text"
                    name="remindBeforeRemainingVisits"
                    id={index}
                    maxLength="25"
                    value={
                      this.state.patientModel.patientAuthorization[index]
                        .remindBeforeRemainingVisits
                    }
                    onChange={this.handleAuthChange}
                  ></input>
                  {/* {row.visitsAllowedValField} */}
                </div>
              </div>
            </div>
          </div>
        ),
        // remindBeforeRemainingVisits: (
        //   <div style={{ width: "200px" }}>
        //     <div className="textBoxValidate">
        //       <input
        //         type="text"
        //         name="remindBeforeRemainingVisits"
        //         id={index}
        //         maxLength="25"
        //         value={
        //           this.state.patientModel.patientAuthorization[index]
        //             .remindBeforeRemainingVisits
        //         }
        //         onChange={this.handleAuthChange}
        //       ></input>
        //       {/* {row.visitsAllowedValField} */}
        //     </div>
        //   </div>
        // ),
        authorizedAmount: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <input
                type="text"
                name="authorizedAmount"
                id={index}
                maxLength="25"
                value={
                  this.state.patientModel.patientAuthorization[index]
                    .authorizedAmount
                }
                onChange={this.handleAuthChange}
                onKeyPress={(event) => this.handleNumericCheck(event)}
              ></input>
            </div>
          </div>
        ),
        medicalRecordRequired: (
          <div className="container" style={{ width: "243px" }}>
            <div className="row">
              <div style={{ width: "116px", marginRight: "3%" }}>
                <div className="textBoxValidate">
                  <select
                    name="medicalRecordRequired"
                    id={index}
                    value={
                      this.state.patientModel.patientAuthorization[index]
                        .medicalRecordRequired == true
                        ? "Y"
                        : "N"
                    }
                    onChange={this.handleAuthChange}
                  >
                    {medicalRecordRequired.map((s) => (
                      <option key={s.value} value={s.value}>
                        {s.display}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div style={{ width: "118px" }}>
                <div className="textBoxValidate">
                  <select
                    name="medicalNecessityRequired"
                    id={index}
                    value={
                      this.state.patientModel.patientAuthorization[index]
                        .medicalNecessityRequired == true
                        ? "Y"
                        : "N"
                    }
                    onChange={this.handleAuthChange}
                  >
                    {medicalNecessityRequired.map((s) => (
                      <option key={s.value} value={s.value}>
                        {s.display}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>
        ),
        // medicalNecessityRequired: (
        //   <div style={{ width: "150px" }}>
        //     <div className="textBoxValidate">
        //       <select
        //         name="medicalNecessityRequired"
        //         id={index}
        //         value={
        //           this.state.patientModel.patientAuthorization[index]
        //             .medicalNecessityRequired == true
        //             ? "Y"
        //             : "N"
        //         }
        //         onChange={this.handleAuthChange}
        //       >
        //         {medicalNecessityRequired.map((s) => (
        //           <option key={s.value} value={s.value}>
        //             {s.display}
        //           </option>
        //         ))}
        //       </select>
        //     </div>
        //   </div>
        // ),

        status: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <select
                name="status"
                id={index}
                value={
                  this.state.patientModel.patientAuthorization[index].status
                }
                onChange={this.handleAuthChange}
              >
                {pAuthstatus.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.display}
                  </option>
                ))}
              </select>
            </div>
          </div>
        ),

        responsibleParty: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <select
                name="responsibleParty"
                id={index}
                value={
                  this.state.patientModel.patientAuthorization[index]
                    .responsibleParty
                }
                onChange={this.handleAuthChange}
              >
                {responsibleParty.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.display}
                  </option>
                ))}
              </select>
            </div>
          </div>
        ),
        remarks: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <textarea
                style={{
                  overflowY: "scroll",
                  height: "30px",
                  width: "150px",
                  borderRadius: "5px",
                }}
                type="text"
                name="remarks"
                id={index}
                cols="20"
                rows="10"
                value={
                  this.state.patientModel.patientAuthorization[index].remarks
                }
                onChange={this.handleAuthChange}
              ></textarea>
            </div>
          </div>
        ),
        addeddate: (
          <div className="textBoxValidate" style={{ width: "150px" }}>
            <input
              type="date"
              min="1900-01-01"
              max="9999-12-31"
              name="addedDate"
              min="1900-01-01"
              max="9999-12-31"
              id={index}
              disabled={true}
              value={addedDate}
              onChange={this.handleAuthChange}
            ></input>
            {/* {row.startdateNumberValField} */}
          </div>
        ),
        remove: (
          <div style={{ width: "50px", textAlign: "center" }}>
            <button
              className="removeBtn"
              id={index}
              onClick={(event) => this.removeAuthRow(event, index, row.id)}
            ></button>
          </div>
        ),
      });
    });
    patientAuthData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
        },
        {
          label: "PLAN",
          field: "plan",
          sort: "asc",
        },
        {
          label: "PROVIDER",
          field: "providerID",
          sort: "asc",
        },
        {
          label: "ICD",
          field: "icdid",
          sort: "asc",
        },
        {
          label: "CPT",
          field: "cptid",
          sort: "asc",
        },
        {
          label: "AUTH #",
          field: "authorizationNumber",
          sort: "asc",
        },

        {
          label: "AUTH DATE",
          field: "authorizationDate",
          sort: "asc",
        },
        {
          label: "START DATE",
          field: "startdate",
          sort: "asc",
        },
        {
          label: "END DATE",
          field: "enddate",
          sort: "asc",
        },
        {
          label: "VISIT ALLOWED/USED/REMAINING",
          field: "visitsallowed",
          sort: "asc",
        },
        // {
        //   label: "VISITS USED",
        //   field: "visitsUsed",
        //   sort: "asc",
        // },
        // {
        //   label: "REMAINING",
        //   field: "remaining",
        //   sort: "asc",
        // },
        {
          label: "REMIND BEFORE DAYS/VISITS",
          field: "remindBeforeDays",
          sort: "asc",
        },
        // {
        //   label: "REMIND BEFORE REMAINING VISITS",
        //   field: "remindBeforeRemainingVisits",
        //   sort: "asc",
        // },
        {
          label: "AUTH AMOUNT",
          field: "authorizedAmount",
          sort: "asc",
        },
        {
          label: "MEDICAL RECORD/NECESSITY",
          field: "medicalRecordRequired",
          sort: "asc",
        },
        // {
        //   label: "MEDICAL NECESSITY",
        //   field: "medicalNecessityRequired",
        //   sort: "asc",
        // },
        {
          label: "STATUS",
          field: "status",
          sort: "asc",
        },
        {
          label: "RESPONSIBLE PARTY",
          field: "responsibleParty",
          sort: "asc",
        },

        {
          label: "REMARKS",
          field: "remarks",
          sort: "asc",
        },
        {
          label: "ENTRY DATE",
          field: "addeddate",
          sort: "asc",
        },
        {
          label: "",
          field: "remove",
          sort: "asc",
          // width: 0
        },
      ],
      rows: newAuthList,
    };

    let plangrid = "";
    plangrid = (
      <div className="mainTable fullWidthTable">
        <div className="table-grid mt-15">
          <div className="row headingTable">
            <div className="mf-6">
              <h1>PATIENT PLAN</h1>
            </div>
            <div className="mf-6 headingRightTable">
              <button class="btn-blue" onClick={this.addPlanRow}>
                Add Plan{" "}
              </button>
            </div>
          </div>

          <div className="tableGridContainer text-nowrap">
            <div className="tableGridContainer">
              <MDBDataTable
                responsive={true}
                striped
                bordered
                searching={false}
                data={patientPlanData}
                displayEntries={false}
                sortable={true}
                scrollX={false}
                scrollY={false}
              />
            </div>
          </div>
        </div>
      </div>
    );

    /************Patient Authorization Grid*********** */
    let ptauthgrid = "";
    ptauthgrid = (
      <div className="mainTable fullWidthTable">
        <div className="table-grid mt-15">
          <div className="row headingTable">
            <div className="mf-6">
              <h1>PATIENT AUTHORIZATION PLAN</h1>
            </div>
            <div className="mf-6 headingRightTable">
              <button class="btn-blue" onClick={this.addAuthRow}>
                Add Patient Auth{" "}
              </button>
            </div>
          </div>

          <div className="tableGridContainer text-nowrap">
            <div className="tableGridContainer">
              <MDBDataTable
                responsive={true}
                striped
                bordered
                searching={false}
                data={patientAuthData}
                displayEntries={false}
                sortable={true}
                scrollX={false}
                scrollY={false}
              />
            </div>
          </div>
        </div>
      </div>
    );

    /************Patient Referrals Grid*********** */

    let newReferralList = [];
    var patientReferralData = {};

    var patientReferral = [];
    if (this.isNull(this.state.patientModel.patientReferrals)) {
      patientReferral = [];
    } else {
      patientReferral = this.state.patientModel.patientReferrals;
    }

    patientReferral.map((row, index) => {
      var startdate = row.startDate ? row.startDate.slice(0, 10) : "";
      var enddate = row.endDate ? row.endDate.slice(0, 10) : "";

      newReferralList.push({
        id: "row.id",
        pcp: (
          <div style={{ width: "205px" }} className="textBoxValidate">
            <Select
              value={this.state.patientModel.patientReferrals[index].pcpObject}
              onChange={(event) => this.handleRefPCPChange(event, index)}
              options={this.props.userProviders}
              placeholder=""
              filterOption={this.filterOption}
              menuShouldBlockScroll={true}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => {},

                menu: (styles) => ({
                  ...styles,
                  // width: '125px',
                  zIndex: "999 !important",
                }),
                clearIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  color: "#286881",
                }),

                indicatorsContainer: (defaultStyles) => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "2px",
                }),
                dropdownIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  display: "none",
                }),
                singleValue: (defaultStyles) => ({
                  ...defaultStyles,
                  paddingBottom: "9px",
                }),
              }}
            />
            {/* {row.providerIDValField} */}
          </div>
        ),

        providerID: (
          <div style={{ width: "205px" }} className="textBoxValidate">
            <Select
              value={
                this.state.patientModel.patientReferrals[index].providerObject
              }
              onChange={(event) => this.handleRefProviderChange(event, index)}
              options={this.props.userProviders}
              placeholder=""
              filterOption={this.filterOption}
              menuShouldBlockScroll={true}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => {},

                menu: (styles) => ({
                  ...styles,
                  // width: '125px',
                  zIndex: "999 !important",
                }),
                clearIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  color: "#286881",
                }),

                indicatorsContainer: (defaultStyles) => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "2px",
                }),
                dropdownIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  display: "none",
                }),
                singleValue: (defaultStyles) => ({
                  ...defaultStyles,
                  paddingBottom: "9px",
                }),
              }}
            />
            {row.providerIDRefValField}
          </div>
        ),

        referralFor: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <select
                name="rererralForService"
                id={index}
                value={
                  this.state.patientModel.patientReferrals[index]
                    .rererralForService
                }
                onChange={this.handleRefChange}
              >
                {referralFor.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.display}
                  </option>
                ))}
              </select>
            </div>
          </div>
        ),
        plan: (
          <div style={{ width: "205px" }} className="textBoxValidate">
            <Select
              type="text"
              value={
                this.state.patientModel.patientReferrals[index]
                  .insurancePlanObject
              }
              name="insurancePlanID"
              id="insurancePlanID"
              max="10"
              onChange={(event) =>
                this.handleInsuranceRefsuggChange(event, index)
              }
              options={this.myPatientPlans}
              filterOption={this.filterOption}
              menuShouldBlockScroll={true}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              menuPosition="fixed"
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => {},

                menu: (styles) => ({
                  ...styles,
                  // width: '125px',
                  zIndex: "999 !important",
                }),
                clearIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  color: "#286881",
                }),

                indicatorsContainer: (defaultStyles) => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "2px",
                }),
                dropdownIndicator: (defaultStyles) => ({
                  ...defaultStyles,
                  display: "none",
                }),
                singleValue: (defaultStyles) => ({
                  ...defaultStyles,
                  paddingBottom: "9px",
                }),
              }}
            ></Select>

            {row.patientPlanIDRefValField}
          </div>
        ),

        startdate: (
          <div className="textBoxValidate" style={{ width: "150px" }}>
            <input
              type="date"
              min="1900-01-01"
              max="9999-12-31"
              name="startDate"
              min="1900-01-01"
              max="9999-12-31"
              id={index}
              value={startdate}
              onChange={this.handleRefChange}
            ></input>
          </div>
        ),
        enddate: (
          <div className="textBoxValidate" style={{ width: "150px" }}>
            <input
              type="date"
              min="1900-01-01"
              max="9999-12-31"
              name="endDate"
              min="1900-01-01"
              max="9999-12-31"
              id={index}
              value={enddate}
              onChange={this.handleRefChange}
            ></input>
          </div>
        ),
        visitsAllowed: (
          <div style={{ width: "70px" }}>
            <div className="textBoxValidate">
              <input
                type="text"
                name="visitAllowed"
                id={index}
                maxLength="25"
                value={
                  this.state.patientModel.patientReferrals[index].visitAllowed
                }
                onChange={this.handleRefChange}
              ></input>
              {/* {row.visitsAllowedValField} */}
            </div>
          </div>
        ),
        visitsUsed: (
          <div style={{ width: "70px" }}>
            <div className="textBoxValidate">
              <input
                type="text"
                name="visitUsed"
                id={index}
                maxLength="25"
                value={
                  this.state.patientModel.patientReferrals[index].visitUsed
                }
                disabled={true}
                onChange={this.handleRefChange}
              ></input>
              {/* {row.visitsAllowedValField} */}
            </div>
          </div>
        ),
        status: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <select
                name="status"
                id={index}
                value={this.state.patientModel.patientReferrals[index].status}
                onChange={this.handleRefChange}
              >
                {status.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.display}
                  </option>
                ))}
              </select>
            </div>
          </div>
        ),
        referralID: (
          <div style={{ width: "70px" }}>
            <div className="textBoxValidate">
              <input
                type="text"
                name="referralNo"
                id={index}
                maxLength="25"
                value={
                  this.state.patientModel.patientReferrals[index].referralNo
                }
                onChange={this.handleRefChange}
              ></input>
              {/* {row.visitsAllowedValField} */}
            </div>
          </div>
        ),
        faxStatus: (
          <div style={{ width: "150px" }}>
            <div className="textBoxValidate">
              <input
                type="text"
                name="faxStatus"
                id={index}
                maxLength="25"
                disabled={true}
                value={
                  this.state.patientModel.patientReferrals[index].faxStatus
                }
                onChange={this.handleRefChange}
              ></input>
              {/* {row.visitsAllowedValField} */}
            </div>
          </div>
        ),
        faxSent: (
          <div style={{ width: "100px" }}>
            <div className="textBoxValidate">
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openfaxPopup(index)}
              >
                {"Send Fax"}
              </MDBBtn>
            </div>
          </div>
        ),
        remove: (
          <div style={{ width: "50px", textAlign: "center" }}>
            <button
              className="removeBtn"
              id={index}
              onClick={(event) => this.removeRefRow(event, index, row.id)}
            ></button>
          </div>
        ),
      });
    });
    patientReferralData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
        },
        {
          label: "PCP",
          field: "pcp",
          sort: "asc",
        },
        {
          label: "PROVIDER",
          field: "providerID",
          sort: "asc",
        },
        {
          label: "REFERRAL FOR",
          field: "referralFor",
          sort: "asc",
        },
        {
          label: "PLAN",
          field: "plan",
          sort: "asc",
        },
        {
          label: "START DATE",
          field: "startdate",
          sort: "asc",
        },
        {
          label: "END DATE",
          field: "enddate",
          sort: "asc",
        },
        {
          label: "VISIT ALLOWED",
          field: "visitsallowed",
          sort: "asc",
        },
        {
          label: "VISITS USED",
          field: "visitsUsed",
          sort: "asc",
        },
        {
          label: "STATUS",
          field: "status",
          sort: "asc",
        },
        {
          label: "REFERRAL #",
          field: "referralID",
          sort: "asc",
        },

        {
          label: "FAX STATUS",
          field: "faxStatus",
          sort: "asc",
        },
        {
          label: "",
          field: "faxSent",
          sort: "asc",
        },

        {
          label: "",
          field: "remove",
          sort: "asc",
          // width: 0
        },
      ],
      rows: newReferralList,
    };

    let ptreferralgrid = "";
    ptreferralgrid = (
      <div className="mainTable fullWidthTable">
        <div className="table-grid mt-15">
          <div className="row headingTable">
            <div className="mf-6">
              <h1>PATIENT REFERRALS</h1>
            </div>
            <div className="mf-6 headingRightTable">
              <button class="btn-blue" onClick={this.addReferral}>
                Add Patient Referrals{" "}
              </button>
            </div>
          </div>

          <div className="tableGridContainer text-nowrap">
            <div className="tableGridContainer">
              <MDBDataTable
                responsive={true}
                striped
                bordered
                searching={false}
                data={patientReferralData}
                displayEntries={false}
                sortable={true}
                scrollX={false}
                scrollY={false}
              />
            </div>
          </div>
        </div>
      </div>
    );
    /************ End Patient Referrals Grid*********** */

    var Imag;
    Imag = (
      <div>
        <img src={settingsIcon} style={{ marginTop: "10px" }} />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup("NewHistoryPractice", 0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );

    // let popup = "";

    let popup = "";
    if (this.state.popupName === "practice") {
      popup = (
        <NewPractice
          onClose={() => this.closePopup}
          practiceID={this.state.id}
        ></NewPractice>
      );
    } else if (this.state.popupName === "location") {
      popup = (
        <NewLocation
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewLocation>
      );
    } else if (this.state.popupName === "provider") {
      popup = (
        <NewProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (this.state.popupName === "refprovider") {
      popup = (
        <NewRefferingProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewRefferingProvider>
      );
    } else if (this.state.popupName === "NewHistoryPractice") {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
          // disabled={this.isDisabled(this.props.rights.update)}
          // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else if (this.state.popupName == "batch") {
      popup = (
        <BatchDocumentPopup
          onClose={() => this.closePopup}
          // getbatchID={(name) => this.getbatchID(name)}
          // popupName="batchNo"
          id={this.state.patientModel.batchDocumentID}
        ></BatchDocumentPopup>
      );
    } else if (this.state.popupName == "batchNo") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          getbatchID={(name) => this.getbatchID(name)}
          popupName="batchNo"
          batchPopupID={this.state.patientModel.batchDocumentID}
        ></GPopup>
      );
    } else if (this.state.showLPopup) {
      popup = (
        <NewLocation
          onClose={() => this.closeLocationPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewLocation>
      );
    } else if (this.state.showPPopup) {
      popup = (
        <NewProvider
          onClose={() => this.closeProviderPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        >
          >
        </NewProvider>
      );
    } else if (this.state.showRPopup) {
      popup = (
        <NewRefferingProvider
          onClose={() => this.closeRefProviderPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        >
          >
        </NewRefferingProvider>
      );
    } else if (this.state.showVPopup) {
      popup = (
        <VisitUsed
          onClose={() => this.closevisitPopup}
          patientAuthID={this.state.patientAuthID}
        ></VisitUsed>
      );
    } else if (this.state.showFPopup) {
      popup = (
        <SendFax
          onClose={() => this.closefaxPopup}
          faxModel={this.state.faxModel}
          userProviders={this.props.userProviders}
          referralFor={referralFor}
        ></SendFax>
      );
    } else popup = <React.Fragment></React.Fragment>;
    //Spinner
    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    /******************************************khizer code*************************************************************/
    let notesList = [];
    var noteTableData = {};
    let Note = [];

    if (this.state.patientModel.note)
      this.state.patientModel.note.map((row, index) => {
        var notesDate = this.isNull(row.notesDate)
          ? ""
          : row.notesDate.slice(0, 10);

        if (notesDate != "") {
          var YY = notesDate.slice(0, 4);
          var DD = notesDate.slice(5, 7);
          var MM = notesDate.slice(8, 10);
        }

        notesList.push({
          id: row.id,

          notesDate: (
            <div style={{ width: "86px" }}>
              <span>{notesDate != "" ? MM + "/" + DD + "/" + YY : ""}</span>
            </div>
          ),

          note: (
            <div style={{ width: "100%" }}>
              <textarea
                data-toggle="tooltip"
                title={this.state.patientModel.note[index].note}
                className="Note-textarea"
                style={{
                  width: "100%",
                  height: "100%",
                  padding: "10px",
                }}
                rows="1"
                cols="60"
                name="note"
                value={this.state.patientModel.note[index].note}
                id={index}
                onChange={this.handleNoteChange}
              ></textarea>
              {this.state.patientModel.note[index].noteValField}
            </div>

            // <div >
            //   <input
            //     // style={{
            //     //   width: " 350px",
            //     //   marginRight: "0px",
            //     //   padding: "7px 5px"
            //     // }}
            //     type="text"
            //     value={this.state.planFollowupModel.note[index].note}
            //     name="note"
            //     id={index}
            //     onChange={this.handleNoteChange}
            //   ></input>
            // </div>
          ),

          addedBy: (
            <div style={{ width: "150px" }}>
              <span>{this.state.patientModel.note[index].addedBy}</span>
            </div>
          ),

          remove: (
            <div style={{ width: "50px", textAlign: "center" }}>
              <button
                className="removeBtn"
                name="deleteCPTBtn"
                id={index}
                onClick={(event, index) =>
                  this.deleteRowNotes(event, index, row.id)
                }
              ></button>
            </div>
          ),
        });
      });

    noteTableData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          //  width: 100
        },
        {
          label: "DATE",
          field: "notesDate",
          sort: "asc",
          // width: 400
        },
        {
          label: "NOTES",
          field: "note",
          sort: "asc",
          // width: 200
        },
        {
          label: "ADDED BY",
          field: "addedBy",
          sort: "asc",
          // width: 50
        },

        {
          label: "",
          field: "remove",
          sort: "asc",
          // width: 0
        },
      ],
      rows: notesList,
    };
    /******************************************khizer code*************************************************************/

    return (
      <div>
        {spiner}
        {this.props.SchedularAdvSearch ? null : (
          <TopForm patientID={this.props.id} />
        )}
        <div className="col py-3">
          <div className="col-md-12">
            <div className="mainHeading row">
              <div className="col-md-4">
                <h1>
                  {this.state.editId > 0
                    ? this.state.patientModel.lastName +
                      " - " +
                      this.state.patientModel.firstName +
                      " - " +
                      this.state.patientModel.accountNum
                    : "NEW PATIENT"}
                </h1>
              </div>
              <div className="col-md-4">
                {!(this.props.popupPatientId > 0) && this.state.editId > 0 ? (
                  <React.Fragment>
                    <Input
                      type="button"
                      value="<="
                      className="btn-blue"
                      onClick={this.previousVisit}
                      style={{ marginLeft: "20px" }}
                    ></Input>
                    <Input
                      type="button"
                      value="=>"
                      className="btn-blue"
                      onClick={this.nextVisit}
                      style={{ marginLeft: "20px" }}
                    ></Input>
                  </React.Fragment>
                ) : null}
              </div>
              <div className="col-md-4 headingRight">
                <div className="lblChkBox">
                  <input
                    type="checkbox"
                    id="markInactive"
                    name="markInactive"
                    checked={this.state.patientModel.isActive}
                    onClick={this.handleCheck}
                  />
                  <label htmlFor="markInactive">
                    <span>Active</span>
                  </label>
                </div>
                <Input
                  type="button"
                  value="AddNew"
                  className="btn-blue"
                  onClick={this.addNewPatient}
                  disabled={this.isDisabled(this.props.rights.delete)}
                >
                  Add New +
                </Input>
                <Input
                  type="button"
                  value="Delete"
                  className="btn-blue"
                  onClick={this.deletePatient}
                  disabled={this.isDisabled(this.props.rights.delete)}
                >
                  Delete
                </Input>
                {this.state.editId > 0 ? dropdown : ""}
              </div>
            </div>
            <div className="mf-12 headingtwo mt-25">
              <p>Demographics</p>
            </div>
            <div className="mainTable fullWidthTable wSpace">
              <div className="row-form">
                <div className="mf-2 profileSection">
                  {/* <div className="row-form">
                    <div className="mf-12">
                      {$imagePreview}
                      <input
                        id="file-input"
                        type="file"
                        onChange={e => this._handleImageChange(e)}
                      />
                    </div>
                  </div> */}
                  <div className="row-form uploadFile">
                    <div className="image-upload">
                      <label htmlFor="file-input">{$imagePreview}</label>
                      <input
                        id="file-input"
                        type="file"
                        onChange={(e) => this._handleImageChange(e)}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12">
                      <label>
                        {/* <h2>Jordan Jackson</h2> */}
                        <h2></h2>
                      </label>
                      <label>
                        {/* <p className="smallText">Age 27 Years</p> */}
                        <p className="smallText"></p>
                      </label>
                    </div>
                  </div>
                </div>
                <div className="mf-10">
                  <div className="row-form">
                    <div className="mf-6">
                      <label name="Account#">
                        Account#<span className="redlbl"> *</span>
                      </label>
                      <Input
                        readOnly
                        className={
                          this.state.validationModel.accountNumValField
                            ? this.errorField
                            : ""
                        }
                        type="text"
                        name="accountNum"
                        id="accountNum"
                        max="20"
                        value={this.state.patientModel.accountNum}
                        onChange={() => this.handleChange}
                      />{" "}
                      {this.state.validationModel.accountNumValField}
                    </div>
                    <div className="mf-6">
                      <Label name="MRN"></Label>
                      <Input
                        type="text"
                        name="medicalRecordNumber"
                        id="medicalRecordNumber"
                        max="20"
                        value={this.state.patientModel.medicalRecordNumber}
                        onChange={() => this.handleChange}
                      ></Input>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Title</label>
                      <select
                        name="title"
                        id="title"
                        value={this.state.patientModel.title}
                        onChange={this.handleChange}
                      >
                        {titles.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="mf-6">
                      <label name="Last Name">
                        Last Name<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.lastNameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          name="lastName"
                          id="lastName"
                          max="35"
                          value={this.state.patientModel.lastName}
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.lastNameValField}
                      </div>
                      {/* {" "} */}
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <Label name="Middle Initial"></Label>
                      <Input
                        type="text"
                        name="middleInitial"
                        id="middleInitial"
                        max="3"
                        value={this.state.patientModel.middleInitial}
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label name="FirstName">
                        First Name<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.firstNameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          name="firstName"
                          id="firstName"
                          max="35"
                          value={this.state.patientModel.firstName}
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.firstNameValField}
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <Label name="SSN"></Label>
                      <div className="textBoxValidate">
                        <input
                          type="text"
                          name="ssn"
                          id="ssn"
                          maxLength="9"
                          value={this.state.patientModel.ssn}
                          // onChange={() => this.handleChange}
                          onKeyPress={(event) => this.handleNumericCheck(event)}
                          onInput={this.onPaste}
                        ></input>
                        {this.state.validationModel.ssnValField}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>DOB</label>
                      <div className="textBoxValidate">
                        <input
                          className="smallCalendarIcon"
                          min="1900-01-01"
                          max="9999-12-31"
                          type="date"
                          min="1900-01-01"
                          max="9999-12-31"
                          name="dob"
                          id="dob"
                          value={this.replace(
                            this.state.patientModel.dob,
                            "T00:00:00",
                            ""
                          )}
                          onChange={this.handleDateChange}
                        ></input>
                        {this.state.validationModel.dobValField}
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Gender</label>
                      <select
                        name="gender"
                        id="gender"
                        value={this.state.patientModel.gender}
                        onChange={this.handleChange}
                      >
                        {gender.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="mf-6">
                      <label>Marital Status</label>
                      <select
                        name="maritalStatus"
                        id="maritalStatus"
                        value={this.state.patientModel.maritalStatus}
                        onChange={this.handleChange}
                      >
                        {matitalStatus.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  {/* <div className="row-form">
                    <div className="mf-6">
                      <label>Race</label>
                      <select name="" id=""></select>
                    </div>
                    <div className="mf-6">
                      <label>Ethinicity</label>
                      <select name="" id=""></select>
                    </div>
                  </div> */}
                </div>
              </div>
            </div>
            <div className="mf-12 headingtwo mt-25">
              <p>Address Information</p>
            </div>
            <div className="mainTable fullWidthTable wSpace">
              <div className="row-form">
                <div className="mf-6">
                  <Label name="Address1"></Label>
                  <Input
                    type="text"
                    name="address1"
                    id="address1"
                    max="55"
                    value={this.state.patientModel.address1}
                    onChange={() => this.handleChange}
                  ></Input>
                </div>
                <div className="mf-6">
                  <Label name="Address2"></Label>
                  <Input
                    type="text"
                    name="address2"
                    id="address2"
                    max="55"
                    value={this.state.patientModel.address2}
                    onChange={() => this.handleChange}
                  ></Input>
                </div>
              </div>
              <div className="row-form">
                <div className="mf-6">
                  <label>City - State</label>
                  <div className="textBoxTwoField">
                    <Input
                      type="text"
                      name="city"
                      id="city"
                      max="20"
                      value={this.state.patientModel.city}
                      onChange={() => this.handleChange}
                    ></Input>
                    <select
                      name="state"
                      id="state"
                      value={this.state.patientModel.state}
                      onChange={this.handleChange}
                    >
                      {usStates.map((s) => (
                        <option key={s.value} value={s.value}>
                          {s.display}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="mf-6">
                  <label>Zip Code - Phone</label>

                  <div className="textBoxTwoField textBoxValidate">
                    <div className="twoColValidate">
                      <Input
                        className={
                          this.state.validationModel.zipCodeValField
                            ? this.errorField
                            : ""
                        }
                        type="text"
                        name="zipCode"
                        id="zipCode"
                        max="9"
                        value={this.state.patientModel.zipCode}
                        onChange={() => this.handleZip}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      />
                      {this.state.validationModel.zipCodeValField}
                    </div>

                    <div className="twoColValidate">
                      <NumberFormat
                        format="00 (###) ###-####"
                        mask="_"
                        className={
                          this.state.validationModel.phoneNumberValField
                            ? this.errorField
                            : ""
                        }
                        type="text"
                        name="phoneNumber"
                        id="phoneNumber"
                        max="10"
                        value={this.state.patientModel.phoneNumber}
                        onChange={this.handleChange}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      />
                      {/* <Input
                        className={
                          this.state.validationModel.phoneNumberValField
                            ? this.errorField
                            : ""
                        }
                        type="text"
                        name="phoneNumber"
                        id="phoneNumber"
                        max="10"
                        value={this.state.patientModel.phoneNumber}
                        onChange={() => this.handleChange}
                        onKeyPress={event => this.handleNumericCheck(event)}
                      /> */}
                      {this.state.validationModel.phoneNumberValField}
                    </div>
                  </div>

                  {/* <div className="textBoxTwoField">


                  </div> */}
                </div>
              </div>
              <div className="row-form">
                <div className="mf-6">
                  <Label name="Cell#"></Label>
                  <NumberFormat
                    format="00 (###) ###-####"
                    mask="_"
                    className={
                      this.state.validationModel.mobileNumberValField
                        ? this.errorField
                        : ""
                    }
                    type="text"
                    name="mobileNumber"
                    id="mobileNumber"
                    max="10"
                    value={this.state.patientModel.mobileNumber}
                    onChange={this.handleChange}
                    onKeyPress={(event) => this.handleNumericCheck(event)}
                  />
                  {/* <Input
                    className={
                      this.state.validationModel.mobileNumberValField
                        ? this.errorField
                        : ""
                    }
                    type="text"
                    name="mobileNumber"
                    id="mobileNumber"
                    max="10"
                    value={this.state.patientModel.mobileNumber}
                    onChange={() => this.handleChange}
                    onKeyPress={event => this.handleNumericCheck(event)}
                  /> */}
                  {this.state.validationModel.mobileNumberValField}
                </div>
                <div className="mf-6">
                  <Label name="Email"></Label>
                  <Input
                    type="text"
                    name="email"
                    id="email"
                    max="60"
                    value={this.state.patientModel.email}
                    onChange={() => this.handleChange}
                  ></Input>
                  <div className="textBoxValidate">
                    {this.state.validationModel.emailValField}
                  </div>
                  {/* </div> */}
                </div>
              </div>

              <div className="row-form">
                <div class="mf-6 text-right">
                  <span
                    style={{ lineHeight: "32px", position: "relative" }}
                    className={
                      this.state.patientModel.batchDocumentID
                        ? "txtUnderline"
                        : ""
                    }
                    onClick={() =>
                      this.openPopup(
                        "batch",
                        this.state.patientModel.batchDocumentID
                      )
                    }
                  >
                    Batch#
                  </span>

                  <span>/Page#</span>
                  <div className="textBoxTwoField textBoxValidate ml-2">
                    <div class="textBoxValidate twoColValidate">
                      <input
                        style={{ width: "86%" }}
                        type="text"
                        maxLength="20"
                        value={this.state.patientModel.batchDocumentID}
                        name="batchDocumentID"
                        id="batchDocumentID"
                        onBlur={this.handleBatchCheck}
                        onChange={this.handleBatchChange}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      ></input>
                      <img
                        style={{
                          marginTop: "-3%",
                          height: "96%",
                          marginRight: "-6%",
                          position: "relative",
                          width: "17%",
                        }}
                        src={plusSrc}
                        onClick={() =>
                          this.openPopup(
                            "batchNo",
                            this.state.patientModel.batchDocumentID
                          )
                        }
                      />
                      {this.state.validationModel.batchDocumentIDValField}
                      {this.state.validationModel.responsepagesValField}
                    </div>
                    <div class="textBoxValidate twoColValidate">
                      <input
                        maxLength="20"
                        type="text"
                        value={this.state.patientModel.pageNumber}
                        name="pageNumber"
                        id="pageNumber"
                        // onChange={this.handleChange}
                        onBlur={this.handleBatchCheck}
                        onChange={this.handleBatchChange}
                        // onKeyPress={(event) => this.handleNumericCheck(event)}
                      ></input>
                      {this.state.validationModel.pageNumberValField}
                    </div>
                  </div>
                </div>
                <div className="mf-6"></div>
              </div>
            </div>

            <div className="mf-12 headingtwo mt-25">
              <p>Statement Info</p>
            </div>
            <div className="mainTable fullWidthTable wSpace">
              <div className="row-form">
                <div className="mf-6 row">
                  <div className="lblChkBox">
                    <input
                      type="checkbox"
                      id="statement"
                      name="statement"
                      checked={this.state.patientModel.statement}
                      onChange={this.handleCheckbox}
                      //value={this.state.providerModel.billUnderProvider}
                    />
                    <label htmlFor="statement">
                      {/* <span>Statement</span> */}
                    </label>
                  </div>
                  <span>Statement</span>
                </div>

                <div className="mf-6">
                  <Label name="Statement Message"></Label>
                  <Input
                    type="text"
                    name="statementMessage"
                    id="statementMessage"
                    max="60"
                    value={this.state.patientModel.statementMessage}
                    onChange={() => this.handleChange}
                  ></Input>
                </div>
              </div>
            </div>

            <div className="mf-12 headingtwo mt-25">
              <p>Legal Entities</p>
            </div>

            <div className="mainTable fullWidthTable wSpace">
              <div className="row-form">
                <div className="mf-6">
                  <label
                    className={
                      this.state.patientModel.practiceID ? "txtUnderline" : ""
                    }
                    onClick={
                      this.state.patientModel.practiceID
                        ? () =>
                            this.openPopup(
                              "practice",
                              this.state.patientModel.practiceID
                            )
                        : undefined
                    }
                  >
                    Practice <span className="redlbl"> *</span>
                  </label>
                  <div className="selectBoxValidate addBoxCol">
                    <select
                      className={
                        this.state.validationModel.practiceIDValField
                          ? this.errorField
                          : ""
                      }
                      name="practiceID"
                      id="practiceID"
                      readOnly
                      disabled
                      value={this.state.patientModel.practiceID}
                      onChange={this.handleChange}
                    >
                      {this.state.practice.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.description}
                        </option>
                      ))}
                    </select>
                    {this.state.validationModel.practiceIDValField}
                  </div>
                </div>

                <div className="mf-6">
                  <label
                    className={
                      this.state.patientModel.locationId ? "txtUnderline" : ""
                    }
                    onClick={
                      this.state.patientModel.locationId
                        ? () =>
                            this.openPopup(
                              "location",
                              this.state.patientModel.locationId
                            )
                        : undefined
                    }
                  >
                    Location <span className="redlbl"> *</span>
                  </label>

                  <div className="selectBoxValidate addBoxCol">
                    <select
                      className={
                        this.state.validationModel.locationIdValField
                          ? this.errorField
                          : ""
                      }
                      name="locationId"
                      id="locationId"
                      value={this.state.patientModel.locationId}
                      onChange={this.handleChange}
                    >
                      {this.props.userLocations.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.description}
                        </option>
                      ))}
                    </select>
                    <img
                      src={plusSrc}
                      onClick={() => this.openLocationPopup(0)}
                      disabled={this.isDisabled(this.props.rights.add)}
                    />

                    {/* <button
                   className="btn"
                  onClick={() => this.openLocationPopup(0)} 
                  disabled={this.isDisabled(this.props.rights.add)}>
               +{""}
                </button> */}
                  </div>
                  <div className="textBoxValidate">
                    {this.state.validationModel.locationIdValField}
                  </div>
                </div>
              </div>
              <div className="row-form">
                <div className="mf-6">
                  <label
                    className={
                      this.state.patientModel.providerID ? "txtUnderline" : ""
                    }
                    onClick={
                      this.state.patientModel.providerID
                        ? () =>
                            this.openPopup(
                              "provider",
                              this.state.patientModel.providerID
                            )
                        : undefined
                    }
                  >
                    Provider <span className="redlbl"> *</span>
                  </label>

                  <div className=" selectBoxValidate addBoxCol">
                    <select
                      className={
                        this.state.validationModel.providerIDValField
                          ? this.errorField
                          : ""
                      }
                      name="providerID"
                      id="providerID"
                      value={this.state.patientModel.providerID}
                      onChange={this.handleChange}
                    >
                      {this.props.userProviders.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.description}
                        </option>
                      ))}
                    </select>
                    <img
                      src={plusSrc}
                      onClick={() => this.openProviderPopup(0)}
                      disabled={this.isDisabled(this.props.rights.add)}
                    />

                    {/* <button
                   className="btn"
                  onClick={() => this.openProviderPopup(0)} 
                  disabled={this.isDisabled(this.props.rights.add)}>
               +{""}
                </button> */}
                  </div>
                  <div className="textBoxValidate">
                    {this.state.validationModel.providerIDValField}
                  </div>
                </div>
                <div className="mf-6">
                  <label
                    className={
                      this.state.patientModel.refProviderID
                        ? "txtUnderline"
                        : ""
                    }
                    onClick={
                      this.state.patientModel.refProviderID
                        ? () =>
                            this.openPopup(
                              "refprovider",
                              this.state.patientModel.refProviderID
                            )
                        : undefined
                    }
                  >
                    Ref Provider
                  </label>

                  <div className=" selectBoxValidate addBoxCol">
                    <select
                      name="refProviderID"
                      id="refProviderID"
                      value={this.state.patientModel.refProviderID}
                      onChange={this.handleChange}
                    >
                      {this.props.userRefProviders.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.description}
                        </option>
                      ))}
                    </select>

                    <img
                      src={plusSrc}
                      onClick={() => this.openRefProviderPopup(0)}
                      disabled={this.isDisabled(this.props.rights.add)}
                    />

                    {/* <button
                   className="btn"
                  onClick={() => this.openRefProviderPopup(0)} 
                  disabled={this.isDisabled(this.props.rights.add)}>
               +{""}
                </button> */}
                  </div>
                </div>
              </div>
              {/* <div className="row-form">
                <div className="mf-12 field_full-8">
                  <label>Notes:</label>
                  <textarea
                    name="notes"
                    id="notes"
                    cols="30"
                    rows="10"
                    value={this.state.patientModel.notes}
                    onChange={this.handleChange}
                  ></textarea>
                </div>
              </div> */}
            </div>

            <div class="row-form">
              <div class="mf-12">
                <Tabs headers={headers} style={{ cursor: "default" }}>
                  <Tab>{plangrid}</Tab>

                  <Tab>{ptauthgrid}</Tab>
                  <Tab> {ptreferralgrid}</Tab>
                  <Tab>
                    <div class="mainTable fullWidthTable">
                      <div class="mf-12 table-grid mt-15">
                        <div class="row headingTable">
                          <div class="mf-6">{/* <h1>NOTES</h1> */}</div>
                          <div class="mf-6 headingRightTable">
                            <button class="btn-blue" onClick={this.addRowNotes}>
                              Add Note{" "}
                            </button>
                          </div>
                        </div>

                        <div>
                          <div className="tableGridContainer">
                            <MDBDataTable
                              striped
                              bordered
                              searching={false}
                              data={noteTableData}
                              displayEntries={false}
                              //sortable={true}
                              scrollX={false}
                              scrollY={false}
                              responsive
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tab>
                </Tabs>
              </div>
            </div>

            {/* ============================ Patient Plans =================================== */}

            <div className="modal-footer">
              <div className="mainTable">
                <div className="row-form row-btn">
                  <div className="mf-12">
                    {/* 
                  <NavLink to="/NewPatient" onClick={this.savePatient} className='btn-blue' >Save</NavLink> */}
                    {this.props.SchedularAdvSearch ? (
                      <div
                        style={{
                          textAlign: "center",
                          width: "100%",
                          margin: "10px",
                        }}
                      >
                        <input
                          type="button"
                          value="Save"
                          className="btn-blue"
                          onClick={this.savePatient}
                          disabled={this.isDisabled(
                            this.state.editId > 0
                              ? this.props.rights.update
                              : this.props.rights.add
                          )}
                        ></input>
                        <input
                          // className="SchedularAppointmentButtons text-white w-auto px-3 mr-2 Schedularcancel mt-2 mt-lg-0"
                          type="button"
                          value="Cancel"
                          className="btn-grey"
                          onClick={this.props.closeAdvSrch}
                        ></input>
                      </div>
                    ) : (
                      <div>
                        <Input
                          type="button"
                          value="Save"
                          className="btn-blue"
                          onClick={this.savePatient}
                          disabled={this.isDisabled(
                            this.state.editId > 0
                              ? this.props.rights.update
                              : this.props.rights.add
                          )}
                        />
                        <Input
                          type="button"
                          value="Cancel"
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.state.patientPopupId > 0 ||
                            this.state.patientPopupId == -1
                              ? this.props.onClose()
                              : this.cancelBtn
                          }
                        />
                      </div>
                    )}

                    {/* {this.state.patientPopupId > 0 ? 
                      (<button
                        id="btnCancel"
                        className="btn-grey"
                        data-dismiss="modal"
                        onClick={this.props.onClose()
                         
                        }
                        // onClick={this.closeNewCharge.bind(this)}
                      >
                        Cancel{" "}
                      </button>):
                              // <NavLink to="/Patient"  className='btn-grey' >Cancel</NavLink>
                              (
                                <button
                                id="btnCancel"
                                className="btn-grey"
                                data-dismiss="modal"
                                onClick={
                                  this.state.patientPopupId > 0
                                    ? this.props.onClose()
                                    : this.cancelBtn
                                }
                              >
                                Cancel
                              </button>
                              )

                      } */}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* </div> */}
          {/* // Patient Plan Grid */}
          {/* {this.state.editId > 0 ? plangrid : ""} */}
        </div>

        {popup}
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    patientGridData: state.PatientGridDataReducer
      ? state.PatientGridDataReducer
      : [],
    userProviders: state.loginInfo
      ? state.loginInfo.userProviders
        ? state.loginInfo.userProviders
        : []
      : [],
    userRefProviders: state.loginInfo
      ? state.loginInfo.userRefProviders
        ? state.loginInfo.userRefProviders
        : []
      : [],
    icdCodes: state.loginInfo
      ? state.loginInfo.icd
        ? state.loginInfo.icd
        : []
      : [],
    userLocations: state.loginInfo
      ? state.loginInfo.userLocations
        ? state.loginInfo.userLocations
        : []
      : [],
    cptCodes: state.loginInfo
      ? state.loginInfo.cpt
        ? state.loginInfo.cpt
        : []
      : [],
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.patientSearch,
          add: state.loginInfo.rights.patientCreate,
          update: state.loginInfo.rights.patientEdit,
          delete: state.loginInfo.rights.patientDelete,
          export: state.loginInfo.rights.patientExport,
          import: state.loginInfo.rights.patientImport,
        }
      : [],
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
      selectPatient: selectPatient,
    },
    dispatch
  );
}

export default withRouter(
  connect(mapStateToProps, matchDispatchToProps)(NewPatient)
);
