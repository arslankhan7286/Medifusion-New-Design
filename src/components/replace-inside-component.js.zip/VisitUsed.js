import React, { Component } from "react";
import { MDBDataTable, MDBBtn, MDBInput } from "mdbreact";
import axios from "axios";
import { isNullOrUndefined } from "util";
import $ from "jquery";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

import GPopup from "./GPopup";
import EditCharge from "./EditCharge";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class VisitUsed extends Component {
    constructor(props) {
        super(props);
        this.url = process.env.REACT_APP_URL + "/Patient/";

        //Authorization Token
        this.config = {
            headers: {
                Authorization: "Bearer  " + this.props.loginObject.token,
                Accept: "*/*"
            }
        };

        this.state = {
            patientAuthID: this.props.patientAuthID,
            data: [],
            popupName: "",
            chargePopup: false,
            id: 0

        };
        this.closeChargePopup = this.closeChargePopup.bind(this);
        this.openChargePopup = this.openChargePopup.bind(this);
    }

    ///////////////////////// Handling Null Value ////////////////////////////////
    val(value) {
        if (isNullOrUndefined(value)) return "";
        else return value;
    }

    ////////////////// componentDidMount ////////////////////////////
    async componentDidMount() {
        await this.setState({ loading: true });
        try {
            await axios
                .get(this.url + "GetAuthorizationUsedVisit/" + this.state.patientAuthID, this.config)
                .then(response => {
                    let newList = [];
                    response.data.map((row, i) => {
                        newList.push({
                            id: row.id,
                            insurancePlan: row.insurancePlan,
                            subscriberID: row.subscriberID,
                            authorizationNumber: row.authorizationNumber,
                            visitID: (
                                <MDBBtn
                                    className="gridBlueBtn"
                                    onClick={() => this.openPopUp("visit", row.visitID)}
                                >
                                    {row.visitID}
                                </MDBBtn>
                            ),
                            chargeID: (
                                <MDBBtn
                                    className="gridBlueBtn"
                                    onClick={() => this.openChargePopup("charge", row.chargeID)}
                                >
                                    {" "}
                                    {this.val(row.chargeID)}
                                </MDBBtn>
                            ),
                            dos: row.dos,
                            cpt: row.cpt,
                            billedAmount: row.billedAmount,
                            allowedAmount: row.allowedAmount,
                            paidAmount: row.paidAmount,
                            balance: row.balance
                        });
                    });
                    this.setState({
                        data: newList,
                    });
                    console.log("After updated data", this.state.data);
                })
                .catch(error => {
                    console.log(error);
                });
        } catch {
            this.setState({ loading: false });
        }
        this.setState({ loading: false });
    }

    openPopUp = (name, id) => {
        this.setState({ popupName: name, id: id });
    };

    closePopup = () => {
        $("#myModal").hide();
        this.setState({ popupName: "" });
    };

    openChargePopup = (name, id) => {
        this.setState({ popupName: name, chargePopup: true, id: id });
    }

    //Close Charge Popup
    closeChargePopup = () => {
        this.setState({ popupName: "", chargePopup: false });
    }



    render() {

        const data = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    // sort: 'asc',
                    width: 0
                },
                {
                    label: "INSURANCE PLAN",
                    field: "insurancePlan",
                    // sort: 'asc',
                    width: 150
                },
                {
                    label: "SUBSCRIBER ID",
                    field: "subscriberID",
                    // sort: 'asc',
                    width: 150
                },
                {
                    label: "AUTHORIZATION #",
                    field: "authorizationId",
                    sort: "desc",
                    width: 150
                },
                {
                    label: "VISIT #",
                    field: "visitID",
                    // sort: 'asc',
                    width: 150
                },
                {
                    label: "CHARGE #",
                    field: "chargeID",
                    // sort: 'asc',
                    width: 150
                },

                {
                    label: "DOS",
                    field: "dos",
                    // sort: 'asc',
                    width: 150
                },
                {
                    label: "CPT",
                    field: "cpt",
                    // sort: 'asc',
                    width: 150
                },
                {
                    label: "BILLED AMOUNT",
                    field: "billedAmount",
                    // sort: 'asc',
                    width: 150
                },
                {
                    label: "ALLOWED AMOUNT",
                    field: "allowedAmount",
                    // sort: 'asc',
                    width: 150
                },
                {
                    label: "PAID AMOUNT",
                    field: "paidAmount",
                    // sort: 'asc',
                    width: 150
                },
                {
                    label: "BALANCE",
                    field: "balance",
                    // sort: 'asc',
                    width: 150
                }
            ],
            rows: this.state.data
        };

        let popup = "";
        if (this.state.popupName === "visit") {
            popup = (
                <GPopup
                    onClose={() => this.closePopup}
                    id={this.state.id}
                    popupName={this.state.popupName}
                ></GPopup>
            );
        } else if (this.state.chargePopup) {
            popup = (
                <EditCharge
                    onClose={() => this.closeChargePopup}
                    chargeId={this.state.id}
                ></EditCharge>
            );
        } else {
            popup = <React.Fragment></React.Fragment>;
        }


        let spiner = "";
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            );
        }

        return (
            <React.Fragment>
                <div
                    id="submittedVisitsModal"
                    className="modal fade bs-example-modal-new show"
                    tabIndex="-1"
                    role="dialog"
                    aria-labelledby="myLargeModalLabel"
                    style={{ display: "block", paddingRight: "17px" }}
                >
                    <div className="modal-dialog modal-lg">
                        {spiner}
                        <div className="modal-content" style={{ overflow: "hidden" }}>
                            <button
                                onClick={this.props.onClose()}
                                className="close"
                                data-dismiss="modal"
                                aria-label="Close"
                            >
                                <span aria-hidden="true"></span>
                            </button>
                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">
                                                Visit Used
                                            </h1>
                                        </div>
                                        <div className="mf-6 popupHeadingRight"></div>
                                    </div>
                                </div>
                            </div>

                            <div
                                className="modal-body"
                                style={{ maxHeight: this.state.maxHeight }}
                            >
                                <div className="mf-12 table-grid mt-15">
                                    <div className="row headingTable">
                                        <div className="mf-6">
                                            <h1 className="modal-title">VISIT USED</h1>
                                        </div>
                                        <div className="mf-6 headingRightTable">
                                        </div>
                                    </div>
                                    <div className="tableGridContainer">
                                        <MDBDataTable
                                            responsive={true}
                                            striped
                                            bordered
                                            searching={false}
                                            data={data}
                                            displayEntries={false}
                                            sortable={true}
                                            scrollX={false}
                                            scrollY={false}
                                        />
                                    </div>
                                </div>

                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <button
                                                    id="btnCancel"
                                                    className="btn-blue"
                                                    data-dismiss="modal"
                                                    onClick={this.props.onClose()}
                                                >
                                                    OK
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {popup}
            </React.Fragment>
        );
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page", state);
    return {
        selectedTab:
            state.selectedTab !== null ? state.selectedTab.selectedTab : "",
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject: state.loginToken
            ? state.loginToken
            : { toekn: "", isLogin: false },
        userInfo: state.loginInfo
            ? state.loginInfo
            : { userPractices: [], name: "", practiceID: null }
    };
}
function matchDispatchToProps(dispatch) {
    return bindActionCreators(
        {
            selectTabPageAction: selectTabPageAction,
            loginAction: loginAction,
            selectTabAction: selectTabAction
        },
        dispatch
    );
}

export default connect(mapStateToProps, matchDispatchToProps)(VisitUsed);
