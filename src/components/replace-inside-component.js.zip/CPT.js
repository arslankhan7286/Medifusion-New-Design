import React, { Component } from "react";

import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Input from "./Input";
import $ from "jquery";
import Swal from "sweetalert2";
import axios from "axios";
import { MDBDataTable, MDBBtn } from "mdbreact";
import NewProvider from "./NewProvider";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import settingIcon from "../images/setting-icon.png";
import { rootCertificates } from "tls";
import NewCPT from "./NewCPT";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import GridHeading from "./GridHeading";

import Hotkeys from "react-hot-keys";

class CPT extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/cpt/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      cptCode: "",
      description: "",
      modifiers: "",
      ndcNumber: "",
      ndcDescription: ""
    };

    this.state = {
      searchModel: this.searchModel,
      data: [],
      showPopup: false,
      id: 0,
      loading: false
    };

    //binding functions to this class
    this.searchCPTCodes = this.searchCPTCodes.bind(this);
    this.clearFields = this.clearFields.bind(this);
    this.openCPTPopup = this.openCPTPopup.bind(this);
    this.closeCPTPopup = this.closeCPTPopup.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    console.log("test:onKeyDown", keyName, e, handle);

    if (keyName == "alt+n") {
      // alert("search key")
      this.openCPTPopup(0);
      console.log(e.which);
    } else if (keyName == "alt+s") {
      this.searchCPTCodes(e);
      console.log(e.which);
    } else if (keyName == "alt+c") {
      // alert("clear skey")
      this.clearFields(e);
      console.log(e.which);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    console.log("test:onKeyUp", e, handle);
    if (e) {
      console.log("event has been called", e);

      // this.onKeyDown(keyName, e , handle);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  searchCPTCodes = e => {
    this.setState({ loading: true });
    axios
      .post(this.url + "findcpts", this.state.searchModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            cptCode: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openCPTPopup(row.id)}
              >
                {row.cptCode}
              </MDBBtn>
            ),
            description: row.description,
            amount: row.amount,
            typeOfService: row.typeOfService,
            modifiers: row.modifiers,
            ndcNumber: row.ndcNumber
          });
        });

        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false });

        Swal.fire("Something Wrong", "Please Check Server Connection", "error");
        let errorsList = [];
        if (error.response !== null && error.response.data !== null) {
          errorsList = error.response.data;
          console.log(errorsList);
        } else console.log(error);
      });

    e.preventDefault();
  };

  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  //clear fields button
  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  //open facility popup
  openCPTPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  //close facility popup
  closeCPTPopup = () => {
    $("#myModal1").hide();
    this.setState({ showPopup: false });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  //Render Method
  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "CPT CODE",
          field: "cptCode",
          sort: "asc",
          width: 150
        },
        {
          label: "DESCRIPTION",
          field: "description",
          sort: "asc",
          width: 270
        },
        {
          label: "AMOUNT",
          field: "amount",
          sort: "asc",
          width: 200
        },
        {
          label: "TYPE OF SERVICE",
          field: "typeOfService",
          sort: "asc",
          width: 100
        },
        {
          label: "MODIFIERS",
          field: "modifiers",
          sort: "asc",
          width: 150
        },
        {
          label: "NDC NUMBER",
          field: "ndcNumber",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.data
    };

    let popup = "";

    if (this.state.showPopup) {
      popup = (
        <NewCPT
          onClose={() => this.closeCPTPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewCPT>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <GifLoader
          loading={true}
          imageSrc={Eclips}
          // imageStyle={imageStyle}
          overlayBackground="rgba(0,0,0,0.5)"
        />
      );
    }

    return (
      <React.Fragment>
        {spiner}

        <div
          className={
            this.state.showPopup == true ? "blurPopupBackground" : null
          }
        >
          <Hotkeys
            keyName="alt+n"
            onKeyDown={this.onKeyDown.bind(this)}
            onKeyUp={this.onKeyUp.bind(this)}
          >
            <SearchHeading
              heading="CPT SEARCH"
              handler={() => this.openCPTPopup(0)}
              disabled={this.isDisabled(this.props.rights.add)}
            >
              >
            </SearchHeading>
          </Hotkeys>

          <form onSubmit={event => this.searchCPTCodes(event)}>
            <div className="mainTable">
              <div className="row-form">
                <div className="mf-6">
                  <Label name="CPT Code"></Label>

                  <Input
                    type="text"
                    name="cptCode"
                    id="cptCode"
                    max="5"
                    value={this.state.searchModel.cptCode}
                    onChange={() => this.handleChange}
                  />
                </div>
                <div className="mf-6">
                  <Label name="Description"></Label>
                  <Input
                    max="100"
                    type="text"
                    name="description"
                    id="description"
                    value={this.state.searchModel.description}
                    onChange={() => this.handleChange}
                  />
                </div>
              </div>

              <div className="row-form">
                <div className="mf-6">
                  <Label name="NDC Number"></Label>
                  <Input
                    type="text"
                    name="ndcNumber"
                    id="ndcNumber"
                    max="11"
                    value={this.state.searchModel.ndcNumber}
                    onChange={() => this.handleChange}
                    onKeyPress={event => this.handleNumericCheck(event)}
                  />
                </div>
                <div className="mf-6">
                  <Label name="NDC Description"></Label>
                  <Input
                    type="text"
                    name="ndcDescription"
                    id="ndcDescription"
                    max="100"
                    value={this.state.searchModel.ndcDescription}
                    onChange={() => this.handleChange}
                  />
                </div>
              </div>

              <div className="row-form row-btn">
                <div className="mf-12">
                  <Hotkeys
                    keyName="alt+s"
                    onKeyDown={this.onKeyDown.bind(this)}
                    onKeyUp={this.onKeyUp.bind(this)}
                  >
                    <Input
                      type="submit"
                      name="name"
                      id="name"
                      className="btn-blue"
                      value="Search"
                      disabled={this.isDisabled(this.props.rights.search)}
                    />
                  </Hotkeys>

                  <Hotkeys
                    keyName="alt+s"
                    onKeyDown={this.onKeyDown.bind(this)}
                    onKeyUp={this.onKeyUp.bind(this)}
                  >
                    <Input
                      type="button"
                      name="clear"
                      id="clear"
                      className="btn-grey"
                      value="Clear"
                      onClick={event => this.clearFields(event)}
                    />
                  </Hotkeys>
                </div>
              </div>
            </div>
          </form>

          <div className="mf-12 table-grid mt-15">
            <GridHeading
              Heading="CPT SEARCH RESULT"
              disabled={this.isDisabled(this.props.rights.export)}
              dataObj={this.state.searchModel}
              url={this.url}
              methodName="Export"
              methodNamePdf="ExportPdf"
              length={this.state.data.length}
            ></GridHeading>

            <div className="tableGridContainer text-nowrap">
              <MDBDataTable
                responsive={true}
                striped
                bordered
                searching={false}
                data={data}
                displayEntries={false}
                sortable={true}
                scrollX={false}
                scrollY={false}
              />
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.cptSearch,
          add: state.loginInfo.rights.cptCreate,
          update: state.loginInfo.rights.cptEdit,
          delete: state.loginInfo.rights.cptDelete,
          export: state.loginInfo.rights.cptExport,
          import: state.loginInfo.rights.cptImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(CPT);
