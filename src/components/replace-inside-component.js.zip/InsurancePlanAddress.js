import React, { Component } from "react";
import SearchHeading from "./SearchHeading";
import NewInsurancePlanAddress from "./NewInsurancePlanAddress";
import NewInsurancePlan from "./NewInsurancePlan";
import Label from "./Label";
import Input from "./Input";
import $ from "jquery";
import axios from "axios";
import { MDBDataTable } from "mdbreact";
import { MDBBtn } from "mdbreact";
import Swal from "sweetalert2";
import settingIcon from "../images/setting-icon.png";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import GridHeading from "./GridHeading";

class InsurancePlanAddress extends Component {
  constructor(props) {
    super(props);
    this.url = process.env.REACT_APP_URL + "/InsurancePlanAddress/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      insurancePlan: "",
      address: "",
      phoneNumber: ""
    };

    this.state = {
      searchModel: this.searchModel,
      data: [],
      showPopup: false,
      showInsurancePlanPopup: false,
      id: 0
    };

    //binding functions to this class
    this.searchInsurancePlanAddress = this.searchInsurancePlanAddress.bind(
      this
    );
    this.clearFields = this.clearFields.bind(this);
    this.openInsurancePlanAddressPopup = this.openInsurancePlanAddressPopup.bind(
      this
    );
    this.closeInsurancePlanAddressrPopup = this.closeInsurancePlanAddressrPopup.bind(
      this
    );
  }

  //search insurance plan address
  searchInsurancePlanAddress = e => {
    this.setState({ loading: true });

    axios
      .post(
        this.url + "FindInsurancePlanAddress",
        this.state.searchModel,
        this.config
      )
      .then(response => {
        console.log(
          "Insurance Plan Address Grid Search Response : ",
          response.data
        );
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            address: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openInsurancePlanAddressPopup(row.id)}
              >
                {row.address}
              </MDBBtn>
            ),
            insurancePlan: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openInsurancePlanPopup(row.insurancePlanID)}
              >
                {row.insurancePlan}
              </MDBBtn>
            ),
            phoneNumber: row.phoneNumber,
            faxNumber: row.faxNumber
          });
        });
        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false });

        Swal.fire("Something Wrong", "Please Check Server Connection", "error");
        try {
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
            console.log(errorsList);
          } else console.log(error);
        } catch {}
      });
    e.preventDefault();
  };

  //handle Change
  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };
  //clear fields button
  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  //open facility popup
  openInsurancePlanAddressPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  //close facility popup
  closeInsurancePlanAddressrPopup = () => {
    $("#myModal1").hide();
    this.setState({ showPopup: false });
  };

  //open facility popup
  openInsurancePlanPopup = id => {
    this.setState({ showInsurancePlanPopup: true, id: id });
  };

  //close facility popup
  closeInsurancePlanPopup = () => {
    $("#myModal1").hide();
    this.setState({ showInsurancePlanPopup: false });
  };

  //handle numeric change
  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  render() {
    try {
      console.log("Righs In IPA : ", this.props.rights.search);
    } catch {}
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDRESS",
          field: "address",
          sort: "asc",
          width: 150
        },
        {
          label: "INSURANCE PLAN",
          field: "insurancePlan",
          sort: "asc",
          width: 150
        },
        {
          label: "PHONE#",
          field: "phoneNumber",
          sort: "asc",
          width: 150
        },
        {
          label: "FAX#",
          field: "faxNumber",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.data
    };

    //popup
    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewInsurancePlanAddress
          onClose={() => this.closeInsurancePlanAddressrPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        />
      );
    } else if (this.state.showInsurancePlanPopup) {
      popup = (
        <NewInsurancePlan
          onClose={() => this.closeInsurancePlanPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.insPlan)}
        />
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <SearchHeading
          heading="INSURANCE PLAN ADDRESS SEARCH"
          handler={() => this.openInsurancePlanAddressPopup(0)}
          disabled={this.isDisabled(this.props.rights.add)}
        >
          >
        </SearchHeading>
        <form onSubmit={event => this.searchInsurancePlanAddress(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-4">
                <Label name="Insurance Plan"></Label>
                <Input
                  type="text"
                  name="insurancePlan"
                  id="insurancePlan"
                  max="20"
                  value={this.state.searchModel.insurancePlan}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-4">
                <Label name="Address"></Label>
                <Input
                  max="15"
                  type="text"
                  name="address"
                  id="address"
                  value={this.state.searchModel.address}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-4">
                <Label name="Phone#"></Label>
                <Input
                  type="text"
                  name="phoneNumber"
                  id="phoneNumber"
                  max="20"
                  value={this.state.searchModel.phoneNumber}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />

                <Input
                  type="button"
                  name="clear"
                  id="clear"
                  className="btn-grey"
                  value="Clear"
                  onClick={event => this.clearFields(event)}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="INSURANCE PLAN ADDRESS SEARCH RESULT"
            disabled={this.isDisabled(this.props.rights.export)}
            dataObj={this.state.searchModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from IPS Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.insurancePlanAddressSearch,
          add: state.loginInfo.rights.insurancePlanAddressCreate,
          update: state.loginInfo.rights.insurancePlanAddressEdit,
          delete: state.loginInfo.rights.insurancePlanAddressDelete,
          export: state.loginInfo.rights.insurancePlanAddressExport,
          import: state.loginInfo.rights.insurancePlanAddressImport,
          insPlan: state.loginInfo.rights.insurancePlanEdit
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(InsurancePlanAddress);
