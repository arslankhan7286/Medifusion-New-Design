import React, { Component } from "react";
import axios from "axios";
import { MDBDataTable, MDBBtn, MDBInput } from "mdbreact";
import GridHeading from "./GridHeading";
import Label from "./Label";
import Input from "./Input";
import { saveAs } from "file-saver";
import $ from "jquery";
import Swal from "sweetalert2";
import moment from "moment";
import { withRouter } from "react-router-dom";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import { isNullOrUndefined } from "util";
import SubmittedVisits from "./SubmittedVisits";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

export class SubmissionLog extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/SubmissionLog/";
    this.elecUrl = process.env.REACT_APP_URL + "/ElectronicSubmission/";
    this.paperUrl = process.env.REACT_APP_URL + "/PaperSubmission/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.electModel = {
      receiver: "",
      submitDate: null,
      submitType: "",
      isaControllNumber: "",
      submitBatchNumber: "",
      formType: ""
    };

    //Validation Model
    this.validationModel = {
      submitDatevalField: ""
    };

    this.state = {
      electModel: this.electModel,
      validationModel: this.validationModel,
      data: [],
      id: 0,
      revData: [],
      loading: false,
      showPopup: false,
      date: "",
      visitCount: ""
    };
    this.searchSubmissionLog = this.searchSubmissionLog.bind(this);
    this.clearFields = this.clearFields.bind(this);
    this.downloadSubmissionLogs = this.downloadSubmissionLogs.bind(this);
    this.openPopup = this.openPopup.bind(this);
  }

  handleChange = event => {
    if (event.target.name == "submitDate") {
    } else {
      //Carret Position
      const caret = event.target.selectionStart;
      const element = event.target;
      window.requestAnimationFrame(() => {
        element.selectionStart = caret;
        element.selectionEnd = caret;
      });
    }
    this.setState({
      electModel: {
        ...this.state.electModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  clearFields = event => {
    var myVal = this.validationModel;
    myVal.submitDatevalField = "";
    this.setState({
      electModel: this.electModel,
      validationModel: myVal
    });
  };

  async componentWillMount() {
    try {
      await axios
        .get(this.url + "GetSubmissionLogs", this.config)
        .then(response => {
          this.setState({
            revData: response.data.receivers
          });
        })
        .catch(error => {});

      if (this.props.location.query.submitDate) {
        await this.setState({
          electModel: {
            ...this.setState.electModel,
            submitDate: this.props.location.query.submitDate
          }
        });

        this.searchSubmissionLogData();
      }
    } catch {}
  }

  downloadSubmissionLogs(id, submitType) {
    let myUrl = "";
    let contentType = "";
    let outputfile = "";

    if (submitType === "EDI") {
      myUrl = this.elecUrl + "DownloadEDIFile/";
      contentType = "application/txt";
      outputfile = "837.txt";
    } else if (submitType === "Paper") {
      myUrl = this.paperUrl + "DownloadHCFAFile/";
      contentType = "application/pdf";
      outputfile = "hcfa.pdf";
    }

    this.setState({ loading: true });

    try {
      axios
        .get(myUrl + id, {
          headers: {
            "Content-Type": "*",
            Authorization: "Bearer " + this.props.loginObject.token
          },
          responseType: "blob"
        })
        .then(function(res) {
          var blob = new Blob([res.data], {
            type: contentType
          });

          saveAs(blob, outputfile);
          this.setState({ loading: false });
        })
        .catch(error => {
          this.setState({ loading: false });

          if (error.response) {
            if (error.response.status) {
              //Swal.fire("Unauthorized Access" , "" , "error");
              Swal.fire({
                type: "info",
                text: "File Not Found on server"
              });
              return;
            }
          } else if (error.request) {
            return;
          } else {
            return;
          }
        });
    } catch {}
  }

  val(value) {
    if (isNullOrUndefined(value)) return " ";
    else return value;
  }

  searchSubmissionLog = e => {
    e.preventDefault();
    this.searchSubmissionLogData();
  };

  isNull = value => {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select" ||
      value === "Please Coverage" ||
      value === "Please Relationship"
    )
      return true;
    else return false;
  };
  searchSubmissionLogData = () => {
    var myVal = this.validationModel;
    myVal.validation = false;

    //DOS From Future Date Validation
    if (this.isNull(this.state.electModel.submitDate) == false) {
      if (
        new Date(
          moment(this.state.electModel.submitDate)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.submitDatevalField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.submitDatevalField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.submitDatevalField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    if (myVal.validation == true) {
      this.setState({ validationModel: myVal });
      Swal.fire(
        "Something Wrong",
        "Please Select All Fields Properly",
        "error"
      );
      return;
    }

    this.setState({ loading: true });
    axios
      .post(this.url + "FindSubmissionLog", this.state.electModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.submitBatchNumber,
            submitBatchNumber: this.val(row.submitBatchNumber),
            receiver: this.val(row.receiver),
            formType: this.val(row.formType),
            submitDate: this.val(row.submitDate),
            visitCount: this.val(
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.openPopup(
                    row.submitBatchNumber,
                    row.submitDate,
                    row.visitCount
                  )
                }
              >
                {" "}
                {row.visitCount}
              </MDBBtn>
            ),
            visitAmount: this.val(row.visitAmount),
            status: this.val(row.status),
            isaControllNumber: this.val(row.isaControllNumber),
            submitType: this.val(row.submitType),
            notes: this.val(row.notes),
            download: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.downloadSubmissionLogs(
                    row.submitBatchNumber,
                    row.submitType
                  )
                }
              >
                {" "}
                {"Download"}
              </MDBBtn>
            )
          });
        });
        this.setState({
          data: newList,
          loading: false
        });
      })
      .catch(error => {
        this.setState({ loading: false });
      });
  };
  closePopup = () => {
    $("#submittedVisitsModal").hide();
    this.setState({ showPopup: false });
  };

  openPopup = (id, date, visitCount) => {
    this.setState({
      showPopup: true,
      id: id,
      date: date,
      visitCount: visitCount
    });
  };

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  onPaste = event => {};
  render() {
    const subType = [
      { value: "", display: "All" },
      { value: "E", display: "EDI" },
      { value: "P", display: "Paper" }
    ];

    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          // sort: 'asc',
          width: 0
        },
        {
          label: "SUBMIT BATCH #",
          field: "submitBatchNumber",
          // sort: 'asc',
          width: 150
        },
        {
          label: "RECEIVER",
          field: "receiver",
          // sort: 'asc',
          width: 150
        },

        {
          label: "HCFA TEMPLATE",
          field: "formType",
          // sort: 'asc',
          width: 150
        },
        {
          label: "SUBMIT DATE",
          field: "submitDate",
          sort: "desc",
          width: 150
        },
        {
          label: "VISIT COUNT",
          field: "visitCount",
          // sort: 'asc',
          width: 150
        },
        {
        label: "VISIT AMOUNT",
        field: "visitAmount",
        // sort: 'asc',
        width: 150
       },
        {
          label: "STATUS",
          field: "status",
          // sort: 'asc',
          width: 150
        },
        {
          label: "CONTROL #",
          field: "isaControllNumber",
          // sort: 'asc',
          width: 150
        },
        {
          label: "SUBMIT TYPE",
          field: "submitType",
          // sort: 'asc',
          width: 150
        },
        {
          label: "NOTES",
          field: "notes",
          // sort: 'asc',
          width: 150
        },
        {
          label: "DOWNLOAD",
          field: "download",
          // sort: 'asc',
          width: 150
        }
      ],
      rows: this.state.data
    };
    const formType = [
      { value: "", display: "Select Title" },
      { value: "HCFA 1500", display: "HCFA 1500" },
      { value: "PLAN 1500", display: "Plan 1500" }
    ];

    var admissionDate = this.state.electModel.submitDate
      ? this.state.electModel.submitDate.slice(0, 10)
      : null;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }
    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <SubmittedVisits
          onClose={() => this.closePopup}
          batchID={this.state.id}
          date={this.state.date}
          visitCount={this.state.visitCount}
        ></SubmittedVisits>
      );
    } else popup = <React.Fragment></React.Fragment>;

    return (
      <React.Fragment>
        {spiner}
        <div className="mainHeading row">
          <div className="col-md-6">
            <h1>SUBMISSION LOGS SEARCH</h1>
          </div>
          <div className="col-md-6 headingRight"></div>
        </div>

        <form onSubmit={event => this.searchSubmissionLog(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Receiver"></Label>
                <input
                  type="text"
                  name="receiver"
                  id="receiver"
                  value={this.state.electModel.receiver}
                  onChange={this.handleChange}
                  onPasteCapture={this.onPaste}
                />
              </div>
              <div className="mf-6">
                {/* <Label name='Form Type'></Label>
                                <Input type='text' name='formType' id='formType' value={this.state.electModel.formType} onChange={() => this.handleChange} /> */}

                <label>HCFA Template</label>
                <select
                  name="formType"
                  id="formType"
                  value={this.state.electModel.formType}
                  onChange={this.handleChange}
                >
                  {formType.map(s => (
                    <option key={s.value} value={s.value}>
                      {s.display}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                {/* <Label name='Submit Date'></Label>
                                <Input type='text' name='submitDate' id='submitDate' value={this.state.electModel.submitDate} onChange={() => this.handleChange} /> */}
                <label>Submit Date</label>
                <div class="textBoxValidate">
                  <input
                    style={{
                      width: "215px",
                      marginLeft: "0px"
                    }}
                    className="myInput"
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="submitDate"
                    id="submitDate"
                    value={admissionDate}
                    onChange={this.handleChange}
                  ></input>
                  {this.state.validationModel.submitDatevalField
                    ? this.state.validationModel.submitDatevalField
                    : ""}
                </div>
              </div>
              <div className="mf-6">
                <Label name="Submit Type"></Label>
                <select
                  name="submitType"
                  id="submitType"
                  value={this.state.electModel.submitType}
                  onChange={this.handleChange}
                >
                  {subType.map(s => (
                    <option key={s.value} value={s.value}>
                      {s.display}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="row-form">
              <div className="mf-6">
                <Label name="Control Number"></Label>
                <Input
                  type="text"
                  name="isaControllNumber"
                  id="isaControllNumber"
                  value={this.state.electModel.isaControllNumber}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Submit Batch #"></Label>
                <Input
                  type="text"
                  name="submitBatchNumber"
                  id="submitBatchNumber"
                  value={this.state.electModel.submitBatchNumber}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-grey"
                  value="Clear"
                  onClick={() => this.clearFields()}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="SUBMISSION LOG SEARCH RESULT"
            dataObj={this.state.electModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>
          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? { search: state.loginInfo.rights.submissionLogSearch }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default withRouter(
  connect(mapStateToProps, matchDispatchToProps)(SubmissionLog)
);
