import React, { Component } from "react";
import $ from "jquery";
import axios from "axios";
import Input from "./Input";
import Swal from "sweetalert2";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import Dropdown from "react-dropdown";
import settingsIcon from "../images/setting-icon.png";
import NewHistoryPractice from "./NewHistoryPractice";
//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class NewAdjustmentCode extends Component {
  constructor(props) {
    super(props);
    this.errorField = "errorField";
    this.url = process.env.REACT_APP_URL + "/AdjustmentCode/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.saveAdjustmentCodeCount = 0;

    // alert(this.props.id);
    this.validationModel = {
      adjustmentCodeValField: "",
      descriptionValField: ""
    };
    this.adjustmentModel = {
      code: "",
      description: "",
      groupID: null,
      reasonID: null,
      actionID: null,
      isValid: true
    };

    this.state = {
      adjustmentModel: this.adjustmentModel,
      validationModel: this.validationModel,
      editId: this.props.id,
      practiceID: this.props.userInfo.practiceID,
      maxHeight: "361",
      typeAdjustment: false,
      action: [],
      reason: [],
      group: [],
      loading: false,
      showPopup: false
    };
    this.handleChange = this.handleChange.bind(this);
  }
  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  async componentDidMount() {
    await this.setState({ loading: true });
    await axios
      .get(this.url + "GetProfiles", this.config)
      .then(response => {
        console.log("Get Profiles Response to actions: ", response);
        this.setState({
          action: response.data.action,
          reason: response.data.reason,
          group: response.data.group
        });
        console.log("ACTION: ", this.state.action);
      })

      .catch(error => {
        this.setState({ loading: false });
        if (error.response) {
          if (error.response.status) {
            //Swal.fire("Unauthorized Access" , "" , "error");
            console.log(error.response.status);
            return;
          }
        } else if (error.request) {
          console.log(error.request);
          return;
        } else {
          console.log("Error", error.message);
          console.log(JSON.stringify(error));
          //Swal.fire("Something went Wrong" , "" , "error");
          return;
        }

        console.log(error);
      });

    await axios
      .get(this.url + "GetProfiles/" + this.state.editId, this.config)
      .then(response => {
        console.log("Response : ", response.data);
        this.setState({ adjustmentModel: response.data });
      })
      .catch(error => {
        this.setState({ loading: false });
      });

    console.log("ID of Practice : ", this.props.userInfo.practiceID);
    await this.setModalMaxHeight($(".modal"));
    // if ($('.modal.in').length != 0) {
    //     this.setModalMaxHeight($('.modal.in'));
    // }

    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function () {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    if (this.state.editId > 0) {
      await axios
        .get(this.url + "FindAdjustmentCode/" + this.state.editId, this.config)
        .then(response => {
          console.log("Response : ", response.data);
          this.setState({ adjustmentModel: response.data });
        })
        .catch(error => {
          this.setState({ loading: false });
        });

      await axios
        .get(this.url + "FindAdjustmentCode/" + this.state.editId, this.config)

        .catch(error => {
          this.setState({ loading: false });
          try {
            let errorsList = [];
            if (error.response !== null && error.response.data !== null) {
              errorsList = error.response.data;
              console.log(errorsList);
            }
          } catch {
            console.log(error);
          }
        });
    }
    this.setState({ loading: false });
  }

  handleChange = event => {
    event.preventDefault();
    console.log(event);
    this.setState({
      adjustmentModel: {
        ...this.state.adjustmentModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  handleCheck = () => {
    this.setState({
      adjustmentModel: {
        ...this.state.adjustmentModel,
        isActive: !this.state.adjustmentModel.isActive
      }
    });
  };
  handleIsValid = () => {
    this.setState({
      adjustmentModel: {
        ...this.state.adjustmentModel,
        isValid: !this.state.adjustmentModel.isValid
      }
    });
  };

  SaveAdjusmentCode = e => {
    console.log("Before Update", this.saveAdjustmentCodeCount)
    if (this.saveAdjustmentCodeCount == 1) {
      return
    }
    this.saveAdjustmentCodeCount = 1;
    // console.log(this.state.remarkCodeModel);
    console.log(this.state.adjustmentModel);
    e.preventDefault();

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.adjustmentModel.code) === true) {
      myVal.adjustmentCodeValField = (
        <span className="validationMsg">Adjusment Code Is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.adjustmentCodeValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.adjustmentModel.description) === true) {
      myVal.descriptionValField = (
        <span className="validationMsg">Description Is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.descriptionValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.saveAdjustmentCodeCount = 0;
      return;
    }

    axios
      .post(
        this.url + "SaveAdjustmentCode",
        this.state.adjustmentModel,
        this.config
      )
      .then(response => {
        this.saveAdjustmentCodeCount = 0;

        this.setState({
          adjustmentModel: response.data,
          editId: response.data.id
        });
        Swal.fire("Record Saved Successfully", "", "success");
        console.log(response.data);
      })

      .catch(error => {
        this.saveAdjustmentCodeCount = 0;

        try {
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
            console.log(errorsList);
          }
        } catch {
          console.log(error);
        }
      });
  };

  delete = e => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        axios
          .delete(
            this.url + "DeleteAdjustmentCode/" + this.state.editId,
            this.config
          )
          .then(response => {
            console.log("Delete Response :", response);
            Swal.fire("Record Deleted Successfully", "", "success");
          })
          .catch(error => {
            console.log(error);
            Swal.fire(
              "Record Not Deleted!",
              "Record can not be delete, as it is being reference in other screens.",
              "error"
            );
          });
        $("#btnCancel").click();
      }
    });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  openhistorypopup = id => {
    this.setState({ showPopup: true, id: id });
  };
  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  render() {
    const type = [
      { value: "", display: "Select Type" },
      { value: "W", display: "Write Off" },
      { value: "D", display: "Denial" }
    ];
    const isActive = this.state.adjustmentModel.isActive;
    const isValid = this.state.adjustmentModel.isValid;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    const options = [
      { value: "History", label: "History", className: "dropdown" }
    ];

    var Imag;
    Imag = (
      <div>
        <img
          src={settingsIcon}
        />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup(0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
        // disabled={this.isDisabled(this.props.rights.update)}
        // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    return (
      <React.Fragment>
        <div
          id="myModal1"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          aria-hidden="true"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={
                  this.props.onClose
                    ? this.props.onClose()
                    : () => this.props.onClose()
                }
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {" "}
                        {this.state.editId > 0
                          ? this.state.adjustmentModel.code
                          : "NEW ADJUSTMENT CODES"}
                      </h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      {/* <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkBox"
                          id="isActive"
                          name="isActive"
                          checked={!isActive}
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div> */}
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                        disabled={this.isDisabled(this.props.rights.delete)}
                      >
                        Delete
                      </Input>
                      {this.state.editId > 0 ? dropdown : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable">
                  {/* <div className="mf-12 headingOne mt-25">
                    <p>ICD Information</p>
                  </div> */}
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        Adjustment Codes<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.adjustmentCodeValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.adjustmentModel.code}
                          name="code"
                          id="code"
                          max="3"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.adjustmentCodeValField}
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>
                        Type<span className="redlbl"> *</span>
                      </label>

                      <select
                        name="type"
                        id="type"
                        value={this.state.adjustmentModel.type}
                        onChange={this.handleChange}
                      >
                        {type.map(w => (
                          <option key={w.id} value={w.value}>
                            {w.display}
                          </option>
                        ))}
                      </select>
                      {/* {this.state.validationModel.descriptionValField} */}
                    </div>

                    <div className="mf-12 field_full-8 mt-15">
                      <label>Description:</label>
                      <textarea
                        value={this.state.adjustmentModel.description}
                        name="description"
                        id="description"
                        cols="30"
                        rows="10"
                        onChange={this.handleChange}
                      ></textarea>
                    </div>
                    <div className="textBoxValidate">
                      {this.state.validationModel.descriptionValField}
                    </div>
                    <div className="mf-6 mt-15">
                      <label>
                        Action
                        <span className="redlbl"> </span>
                      </label>

                      <select
                        name="actionID"
                        id="actionID"
                        value={this.state.adjustmentModel.actionID}
                        onChange={this.handleChange}
                      >
                        {this.state.action.map(a => (
                          <option key={a.id} value={a.id}>
                            {a.description}
                          </option>
                        ))}
                      </select>
                      {/* {this.state.adjustmentModel.reasonID} */}
                    </div>
                    <div className="mf-6 mt-15">
                      <label>
                        Reason<span className="redlbl"> </span>
                      </label>

                      <select
                        name="reasonID"
                        id="reasonID"
                        value={this.state.adjustmentModel.reasonID}
                        onChange={this.handleChange}
                      >
                        {this.state.reason.map(r => (
                          <option key={r.id} value={r.id}>
                            {r.description}
                          </option>
                        ))}
                      </select>
                      {/* {this.state.adjustmentModel.group} */}
                    </div>
                    <div className="mf-6 mt-15">
                      <label>
                        Group
                        <span className="redlbl"> </span>
                      </label>

                      <select
                        name="groupID"
                        id="groupID"
                        value={this.state.adjustmentModel.groupID}
                        onChange={this.handleChange}
                      >
                        {this.state.group.map(g => (
                          <option key={g.id} value={g.id}>
                            {g.description}
                          </option>
                        ))}
                      </select>
                      {/* {this.state.validationModel.group} */}
                    </div>

                    <div className="mf-6 mt-15">
                      {/* <div
                        className="lblChkBox"
                        onClick={this.handleIsValid}
                        style={{
                          marginLeft: "50px",
                          marginTop: "10px"
                        }}
                      >
                        <input
                          type="checkBox"
                          id="isValid"
                          name="isValid"
                          checked={!isValid}
                        />
                        <label> Is Valid</label>
                      </div> */}
                    </div>
                  </div>
                </div>

                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <input
                          type="button"
                          value="Save"
                          className="btn-blue"
                          onClick={this.SaveAdjusmentCode}
                          disabled={this.isDisabled(
                            this.state.editId > 0
                              ? this.props.rights.update
                              : this.props.rights.add
                          )}
                        ></input>
                         <input
                         type="button"
                         value="Cancel"
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                        </input>

                        {/* <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                          Cancel
                        </button> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.adjustmentCodesSearch,
        add: state.loginInfo.rights.adjustmentCodesCreate,
        update: state.loginInfo.rights.adjustmentCodesEdit,
        delete: state.loginInfo.rights.adjustmentCodesDelete,
        export: state.loginInfo.rights.adjustmentCodesExport,
        import: state.loginInfo.rights.adjustmentCodesImport
      }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(NewAdjustmentCode);
