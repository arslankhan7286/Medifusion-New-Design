import React, { Component } from "react";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import GPopup from "./GPopup";

import NewPatientSheet from "../components/NewPatientSheet";
import { MDBDataTable, MDBBtn } from "mdbreact";
import GridHeading from "./GridHeading";
import Swal from "sweetalert2";

import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Input from "./Input";
import axios from "axios";
import $ from "jquery";

import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

import Hotkeys from "react-hot-keys";
class PatientSheet extends Component {
  constructor(props) {
    super(props);

    this.AddPatientSheet = process.env.REACT_APP_URL + "/DataMigration/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      firstName: "",
      lastName: "",
      externalPatientID: "",
      accountNumber: "",
      status: "",
      fileName: ""
    };

    this.state = {
      searchModel: this.searchModel,
      popupName: "",
      showPopup: false,
      data: [],
      loading: false,
      table: [],
      Columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "FILENAME",
          field: "fileName",
          sort: "asc",
          width: 100
        },
        {
          label: "EXTERNAL PATIENT ID",
          field: "externalPatientID",
          sort: "asc",
          width: 150
        },
        {
          label: "ACCOUNT #",
          field: "accountNumber",
          sort: "asc",
          width: 100
        },
        {
          label: "STATUS",
          field: "status",
          sort: "asc",
          width: 100
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          width: 150
        },
        {
          label: "FIRST NAME",
          field: "firstName",
          sort: "asc",
          width: 270
        },
        {
          label: "DOB",
          field: "dob",
          sort: "asc",
          width: 200
        },
        {
          label: "PRIMARY SUBSCRIBER ID",
          field: "primaryPatientPlanID",
          sort: "asc",
          width: 100
        },
        {
          label: "PRIMARY PAYER",
          field: "primaryPayer",
          sort: "asc",
          width: 100
        },
        {
          label: "SECONDDARY SUBSCRIBER ID",
          field: "secondaryPatientPlanID",
          sort: "asc",
          width: 100
        },
        {
          label: "SECONDDARY PAYER",
          field: "secondaryPayer",
          sort: "asc",
          width: 100
        },
        {
          label: "PROVIDER",
          field: "providerName",
          sort: "asc",
          width: 100
        },
        {
          label: "LOCATION",
          field: "locationName",
          sort: "asc",
          width: 150
        }
      ]
    };

    this.openPopUp = this.openPopUp.bind(this);
    this.openNewPatientSheetPopUp = this.openNewPatientSheetPopUp.bind(this);
    this.closeNewPatientSheetPopUp = this.closeNewPatientSheetPopUp.bind(this);
    this.closePopup = this.closePopup.bind(this);
    this.searchPatientSheet = this.searchPatientSheet.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.isNull = this.isNull.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    console.log("test:onKeyDown", keyName, e, handle);

    if (keyName == "alt+n") {
      // alert("search key")
      this.openNewPatientSheetPopUp(0);
      console.log(e.which);
    } else if (keyName == "alt+s") {
      this.searchPatientSheet(e);
      console.log(e.which);
    } else if (keyName == "alt+c") {
      // alert("clear skey")
      this.clearFields(e);
      console.log(e.which);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    console.log("test:onKeyUp", e, handle);
    if (e) {
      console.log("event has been called", e);

      // this.onKeyDown(keyName, e , handle);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  isNull = value => {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select" ||
      value === -1
    )
      return true;
    else return false;
  };

  componentWillMount() {
    this.setState({
      table: {
        columns: this.state.Columns,
        rows: this.state.data
      }
    });
  }

  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  ///////////////------------OPEN/CLOSE POP UPs

  openNewPatientSheetPopUp(id) {
    this.setState({ showPopup: true, id: id });
    console.log(id);
  }

  closeNewPatientSheetPopUp = () => {
    $("#myModal").hide();
    this.setState({ showPopup: false });
  };

  openPopUp = (name, id, planID) => {
    this.setState({ popupName: name, id: id, planID: planID });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  ///////////////------------CHANGE HANDLERS

  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase()
      }
    });
    console.log(this.state.searchModel);
  };

  ///////////////------------SEARCH PATIENT DATA

  async searchPatientSheet(e) {
    e.preventDefault();
    this.setState({ loading: true });
    console.log("Search model", this.state.searchModel);
    await axios
      .post(
        this.AddPatientSheet + "FindExternalPatients",
        this.state.searchModel,
        this.config
      )
      .then(response => {
        let newList = [];
        let STATUS = "";
        let PPID = "";
        let SPID = "";
        let AccountNum = "";

        response.data.map((row, i) => {
          ///////////////------------STATUS HANDLING

          if (row.status == "A") {
            STATUS = row.status + "DDED";
          } else if (row.status == "E") {
            STATUS = row.status + "XTERNAL";
          } else if (row.status == "D") {
            STATUS = row.status + "UPLICATE";
          }

          ///////////////------------PRIMARY PATIENT ID EXCEPTION

          if (!this.isNull(row.primaryPatientPlanID)) {
            if (!this.isNull(row.primarySubscriberID)) {
              PPID = (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() =>
                    this.openPopUp(
                      "patientplan",
                      row.patientID,
                      row.primaryPatientPlanID
                    )
                  }
                >
                  {row.primarySubscriberID}
                </MDBBtn>
              );
            } else if (this.isNull(row.primarySubscriberID)) {
              PPID = (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() =>
                    this.openPopUp(
                      "patientplan",
                      row.patientID,
                      row.primaryPatientPlanID
                    )
                  }
                >
                  ---
                </MDBBtn>
              );
            }
          } else if (!this.isNull(row.primarySubscriberID)) {
            PPID = row.primarySubscriberID;
          } else {
            PPID = null;
          }

          ///////////////------------SECONDARY PATIENT ID EXCEPTION

          if (!this.isNull(row.secondaryPatientPlanID)) {
            if (!this.isNull(row.secondarySubscriberID)) {
              SPID = (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() =>
                    this.openPopUp(
                      "patientplan",
                      row.patientID,
                      row.secondaryPatientPlanID
                    )
                  }
                >
                  {row.secondarySubscriberID}
                </MDBBtn>
              );
            } else if (this.isNull(row.secondarySubscriberID)) {
              SPID = (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() =>
                    this.openPopUp(
                      "patientplan",
                      row.patientID,
                      row.secondaryPatientPlanID
                    )
                  }
                >
                  ---
                </MDBBtn>
              );
            }
          } else if (!this.isNull(row.secondarySubscriberID)) {
            SPID = row.secondarySubscriberID;
          } else {
            SPID = null;
          }

          ///////////////------------ACCOUNT NUMBER EXCEPTION

          if (!this.isNull(row.accountNumber)) {
            AccountNum = (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPopUp("patient", row.patientID, 0)}
              >
                {row.accountNumber}
              </MDBBtn>
            );
          } else {
            AccountNum = null;
          }

          newList.push({
            id: row.id,
            fileName: row.fileName,
            externalPatientID: row.externalPatientID,
            accountNumber: AccountNum,
            status: STATUS,
            lastName: row.lastName,
            firstName: row.firstName,
            dob: row.dob,
            primaryPatientPlanID: PPID,
            primaryPayer: row.primaryPayer,
            secondaryPatientPlanID: SPID,
            secondaryPayer: row.secondaryPayer,
            providerName: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.openPopUp("providerName", row.providerID, 0)
                }
              >
                {row.providerName}
              </MDBBtn>
            ),
            locationName: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.openPopUp("locationName", row.locationID, 0)
                }
              >
                {row.locationName}
              </MDBBtn>
            )
          });
        });

        console.log("NewList", newList);

        this.setState({
          data: newList,
          loading: false,
          table: {
            columns: this.state.Columns,
            rows: newList
          }
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });
  }

  processPatients(id) {
    this.setState({ loading: true });
    axios
      .post(this.AddPatientSheet + "ProcessRemainingPatientPlan", {}, this.config)
      .then(response => {
        this.setState({
          loading: false
        });
        Swal.fire("Processed Successfully", "", "success").then(sres => { });
      })
      .catch(error => {
        this.setState({ loading: false });

        try {
          if (error.response) {
            if (error.response.status) {
              if (error.response.status == 401) {
                Swal.fire("Unauthorized Access", "", "error");
                return;
              } else if (error.response.status == 404) {
                Swal.fire("Not Found", "Failed With Status Code 404", "error");
                return;
              } else if (error.response.status == 400) {
                Swal.fire("Not Found", error.response.data, "error");
                return;
              }
            }
          } else {
            Swal.fire("Something went Wrong", "", "error");
            return;
          }
        } catch { }
      });
  }

  render() {
    ///////////////------------DROP-DOWN OPTIONS

    const StatusOptions = [
      { value: null, display: "Please Select" },
      { value: "A", display: "Added" },
      { value: "E", display: "External" },
      { value: "D", display: "Duplicate" }
    ];

    ///////////////------------POP UP SELECTION

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewPatientSheet
          onClose={() => this.closeNewPatientSheetPopUp}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewPatientSheet>
      );
    } else if (this.state.popupName === "locationName") {
      popup = (
        <NewLocation
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewLocation>
      );
    } else if (this.state.popupName === "providerName") {
      popup = (
        <NewProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (this.state.popupName === "patient") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else if (this.state.popupName === "patientplan") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          id={this.state.id}
          popupName={this.state.popupName}
          planID={this.state.planID}
        ></GPopup>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    ///////////////------------LOADING SPINER

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}

        <Hotkeys
          keyName="alt+n"
          onKeyDown={this.onKeyDown.bind(this)}
          onKeyUp={this.onKeyUp.bind(this)}
        >
          <SearchHeading
            heading="PATIENT SHEET SEARCH"
            handler={() => this.openNewPatientSheetPopUp(0)}
            handler1={() => this.processPatients(0)}
            disabled={this.isDisabled(this.props.rights.add)}
          ></SearchHeading>
        </Hotkeys>

        <form onSubmit={this.searchPatientSheet}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="File Name"></Label>
                <Input
                  type="text"
                  name="fileName"
                  id="fileName"
                  max="30"
                  value={this.state.searchModel.fileName}
                  onChange={() => this.handleChange}
                />
              </div>

              <div className="mf-6">
                <Label name="External Patient ID"></Label>
                <Input
                  type="text"
                  name="externalPatientID"
                  id="externalPatientID"
                  max="16"
                  value={this.state.searchModel.externalPatientID}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Account #"></Label>
                <Input
                  type="text"
                  name="accountNumber"
                  id="accountNumber"
                  max="9"
                  value={this.state.searchModel.accountNumber}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Status"></Label>
                <select
                  name="status"
                  id="status"
                  value={this.state.searchModel.status}
                  onChange={this.handleChange}
                >
                  {StatusOptions.map(s => (
                    <option key={s.value} value={s.value}>
                      {s.display}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Last Name"></Label>
                <Input
                  max="20"
                  type="text"
                  name="lastName"
                  id="lastName"
                  value={this.state.searchModel.lastName}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="First Name"></Label>
                <Input
                  type="text"
                  name="firstName"
                  id="firstName"
                  max="20"
                  value={this.state.searchModel.firstName}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Hotkeys
                  keyName="alt+s"
                  onKeyDown={this.onKeyDown.bind(this)}
                  onKeyUp={this.onKeyUp.bind(this)}
                >
                  <Input
                    type="submit"
                    name="name"
                    id="name"
                    className="btn-blue"
                    value="Search"
                    disabled={this.isDisabled(this.props.rights.search)}
                  />
                </Hotkeys>

                <Hotkeys
                  keyName="alt+c"
                  onKeyDown={this.onKeyDown.bind(this)}
                  onKeyUp={this.onKeyUp.bind(this)}
                >
                  <Input
                    type="button"
                    name="name"
                    id="name"
                    className="btn-grey"
                    value="Clear"
                    onClick={() => this.clearFields()}
                  />
                </Hotkeys>
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="PATIENT SHEET SEARCH RESULT"
            disabled={this.isDisabled(this.props.rights.export)}
            dataObj={this.state.searchModel}
            url={this.AddPatientSheet}
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={this.state.table}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>

        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.clientSearch,
        add: state.loginInfo.rights.clientCreate,
        update: state.loginInfo.rights.clientEdit,
        delete: state.loginInfo.rights.clientDelete,
        export: state.loginInfo.rights.clientExport,
        import: state.loginInfo.rights.clientImport
      }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(PatientSheet);
