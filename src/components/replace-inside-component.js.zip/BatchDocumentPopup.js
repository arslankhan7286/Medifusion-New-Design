import React, { Component } from "react";
import GifLoader from "react-gif-loader";
import Eclips from "../images/loading_spinner.gif";
import $ from "jquery";
import Input from "./Input";
import { isNull, isNullOrUndefined } from "util";
import { saveAs } from "file-saver";
import axios from "axios";
import { MDBDataTable, MDBBtn } from "mdbreact";
import GridHeading from "./GridHeading";
import Swal from "sweetalert2";
import Dropdown from "react-dropdown";
import settingsIcon from "../images/setting-icon.png";
import NewHistoryPractice from "./NewHistoryPractice";

import { Tabs, Tab } from "react-tab-view";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

import plusSrc from "../images/plus-icon.png";
import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewDocumentType from "./NewDocumentType";
import NewProvider from "./NewProvider";

import moment from "moment";

export class BatchDocumentPopup extends Component {
  constructor(props) {
    super(props);
    this.url = process.env.REACT_APP_URL + "/BatchDocument/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*",
      },
    };

    this.saveBatchCount = 0;

    this.searchModel = {
      batchNum: "",
      responsibleParty: "B",
      documentTypeID: null,
      practiceID: null,
      locationID: null,
      providerID: null,
      noOfDemographics: "",
      noOfDemographicsEntered: null,
      status: "N",

      startDate: null,
      endDate: null,

      addedBy: "",
      updatedBy: "",
      updatedDate: null,
      documentInfo: this.documentInfo,

      note: [],

      chargeRowData: [], // ptAuth
      batchDocumentCharges: [], // ptPlans

      paymentRowData: [],
      batchDocumentPayment: [],

      fileSize: 0,
      numberOfPages: 0,
    };
    this.documentInfo = {
      content: "",
      name: "",
      size: "",
      type: "",
      clientID: 0,
    };
    this.errorField = "errorField";

    this.batchdocumentCharges = {
      // batchDocumentNoID: 0,
      dos: "",
      noOfVisits: "",
      copay: "",
      otherPatientAmount: "",
    };
    this.batchdocumentPayment = {
      // batchDocumentNoID: 0,
      checkNo: "",
      checkDate: "",
      checkAmount: "",
      applied: "",
      unApplied: "",
      remarks: "",
    };

    this.validationModel = {
      fileUploadVal: "",
      responsiblePartyValField: "",
      documentTypeIDValField: "",
      dateValField: "",
      paymentDateFDValField: "",
      amountValField: "",
      checkValField: "",
      dosdateValField: "",
      dosDateFDValField: "",
      noOfVisitsValField: "",
      copayValField: "",
      patValField: "",
      noteValField: "",
    };

    this.notesModel = {
      id: 0,
      notesDate: null,
      note: null,
      noteValField: "",
      validation: false,
    };

    this.state = {
      editId: this.props.id,

      // logSubmitId: this.props.data.submissionLogID,
      id: 0,

      STATUS: "",
      validationModel: this.validationModel,
      searchModel: this.searchModel,
      batchdocumentCharges: this.batchdocumentCharges,
      batchdocumentPayment: this.batchdocumentPayment,
      popupName: "",
      showLPopup: false,
      showDPopup: false,
      showPPopup: false,
      practice: [],
      location: [],
      provider: [],
      filePath: "",
      floading: false,

      batchDocumentCharges: [],
      batchDocumentPayment: [],
      note: [],

      maxHeight: "361",
      facData: [],
      cateData: [],
      billData: [],
      practicesData: [],
      locData: [],
      proData: [],
      isActive: true,
      loading: false,
    };

    this.closeNewDocument = this.closeNewDocument.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.downloadDocument = this.downloadDocument.bind(this);
    this.addChargeRow = this.addChargeRow.bind(this);
    this.addPaymentRow = this.addPaymentRow.bind(this);
    this.handleChargeChange = this.handleChargeChange.bind(this);
    this.handlePaymentChange = this.handlePaymentChange.bind(this);
    this.openPopup = this.openPopup.bind(this);
    this.closePopup = this.closePopup.bind(this);
    this.openProviderPopup = this.openProviderPopup.bind(this);
    this.closeProviderPopup = this.closeProviderPopup.bind(this);
    this.openLocationPopup = this.openLocationPopup.bind(this);
    this.closeLocationPopup = this.closeLocationPopup.bind(this);
    this.openDocumentPopup = this.openDocumentPopup.bind(this);

    this.closeDocumentPopup = this.closeDocumentPopup.bind(this);

    this.handleNumericCheck = this.handleNumericCheck.bind(this);

    this.handleNoteChange = this.handleNoteChange.bind(this);

    this.addRowNotes = this.addRowNotes.bind(this);

    this.downloadFile = this.downloadFile.bind(this);
  }

  async componentWillMount() {
    await this.setState({ loading: true });
    await this.setModalMaxHeight($(".modal"));
    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function () {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    try {
      if (this.state.editId > 0) {
        await axios
          .get(this.url + "FindBatchDocument/" + this.state.editId, this.config)
          .then((response) => {
            if (response.data.status == "" || response.data.status == "") {
              this.state.STATUS = "STATUS";
            } else if (
              response.data.status == "N" ||
              response.data.status == "NOT STARTED"
            ) {
              this.state.STATUS = "NOT STARTED";
            } else if (
              response.data.status == "C" ||
              response.data.status == "CLOSED"
            ) {
              this.state.STATUS = "CLOSED";
            } else if (
              response.data.status == "I" ||
              response.data.status == "IN PROCESS"
            ) {
              this.state.STATUS = "IN PROCESS";
            }

            console.log("find response", response);

            this.setState({
              searchModel: response.data,
            });
            console.log(
              " searchModel startDate data is  ",
              this.state.searchModel.startDate
            );
          })
          .catch((error) => {
            console.log(error);
          });
      }

      await axios
        .get(this.url + "GetProfiles", this.config)
        .then((response) => {
          this.setState({
            cateData: response.data.category,

            searchModel: {
              ...this.state.searchModel,
              // status:"N"
            },
          });

          console.log("category data ", response.data);
        })
        .catch((error) => {
          console.log(error);
        });
    } catch {
      this.setState({ loading: false });
    }
    this.setState({ loading: false });
  }

  async addRowNotes(event) {
    const note = { ...this.notesModel };
    var len = this.state.searchModel.note
      ? this.state.searchModel.note.length
      : 0;
    if (len == 0) {
      await this.setState({
        searchModel: {
          ...this.state.searchModel,
          note: this.state.searchModel.note.concat(note),
        },
      });
      return;
    } else {
      len = len - 1;
      if (this.isNull(this.state.searchModel.note[len].note)) {
        Swal.fire("First Enter Previous Notes", "", "error");
        return;
      } else {
        await this.setState({
          searchModel: {
            ...this.state.searchModel,
            note: this.state.searchModel.note.concat(note),
          },
        });
      }
    }
    if (this.state.searchModel.note) {
    }
  }

  downloadFile() {
    console.log(this.state.editId);
    this.setState({ loading: true });

    try {
      axios
        .get(this.url + "DownloadBatchDocument/" + this.state.editId, {
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer  " + this.props.loginObject.token,
            Accept: "*/*",
          },
          responseType: "blob",
        })
        .then(function (res) {
          console.log(res);
          var blob = new Blob([res.data], {
            type: "application/pdf",
          });

          saveAs(blob, "File.pdf");
          this.setState({ loading: false });
        })
        .catch((error) => {
          this.setState({ loading: false });

          if (error.response) {
            if (error.response.status) {
              //Swal.fire("Unauthorized Access" , "" , "error");
              Swal.fire({
                type: "info",
                text: "File Not Found on server",
              });
              return;
            }
          } else if (error.request) {
            return;
          } else {
            return;
          }
        });
    } catch {}
  }

  async handleChange(event) {
    // event.preventDefault();

    var eventName = event.target.name;
    var eventValue = event.target.value;

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase(),
      },
    });

    if (eventName == "practiceID") {
      var userLocation = await this.props.userInfo1.userLocations.filter(
        (location) => location.iD2 == this.props.userInfo1.practiceID
      );
      var userProvider = await this.props.userInfo1.userProviders.filter(
        (provider) => provider.iD2 == this.props.userInfo1.practiceID
      );
      console.log(userLocation);
      console.log("---");
      console.log(userProvider);

      await this.setState({
        location: userLocation,
        provider: userProvider,
      });

      if (this.isNull(this.state.searchModel.locationID) == true) {
        await this.setState({
          searchModel: {
            ...this.state.searchModel,
            locationID: userLocation[0].id,
          },
        });
      }
      if (this.isNull(this.state.searchModel.providerID) == true) {
        await this.setState({
          searchModel: {
            ...this.state.searchModel,
            providerID: userProvider[0].id,
          },
        });
      }
    }
  }

  closeNewDocument() {
    console.log("clicked");
    this.props.selectTabAction("Documents");
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }
  openProviderPopup = (id) => {
    this.setState({ showPPopup: true, id: id });
  };

  //close facility popup
  closeProviderPopup = () => {
    $("#providerModal").hide();
    this.setState({ showPPopup: false });
  };

  openLocationPopup = (id) => {
    this.setState({ showLPopup: true, id: id });
  };

  closeLocationPopup = () => {
    $("#locationModal").hide();
    this.setState({ showLPopup: false });
  };

  openDocumentPopup = (id) => {
    this.setState({ showDPopup: true, id: id });
  };

  closeDocumentPopup = () => {
    $("#myModal1").hide();
    this.setState({ showDPopup: false });
    this.componentWillMount();
  };

  downloadDocument = (id) => {
    let contentType = "";
    let outputfile = "";

    this.fileURl = this.url + "DownloadBatchDocument/" + id;

    //console.log(this.fileURl)
    alert(this.fileURl);

    axios
      .get(this.fileURl, {
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer  " + this.props.loginObject.token,
          Accept: "*/*",
        },
        responseType: "blob",
      })
      .then(function (res) {
        var blob = new Blob([res.data], {
          type: contentType,
        });

        saveAs(blob, outputfile);
      })
      .catch((error) => {
        if (error.response.status === 404) {
          console.log(error.response.status);
          Swal.fire({
            type: "info",
            text: "File Not Found on server",
          });
        }
      });
  };

  ProcessFileLoad(e) {
    e.preventDefault();

    console.log("file process method");

    try {
      let reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      let file = e.target.files[0];

      console.log("File : ", file);

      reader.onloadend = (e) => {
        try {
          this.setState({
            searchModel: {
              ...this.state.searchModel,
              documentInfo: {
                ...this.state.searchModel.documentInfo,
                content: reader.result,
                name: file.name,
                size: file.size,
                type: file.type,
              },
            },
          });
        } catch {}

        console.log("Content", this.state.searchModel.documentInfo.content);

        var Filetype = this.state.searchModel.documentInfo.name.substr(
          this.state.searchModel.documentInfo.name.indexOf(".")
        );
        console.log("file type", Filetype);
        if (Filetype == ".pdf") {
          this.setState({
            filePath: file.name,
          });
        } else {
          Swal.fire("Error", "Invalid File", "error");
        }
      };
    } catch {}
  }

  openPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  delete = (e) => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        this.setState({ loading: true });

        axios
          .delete(
            //https://localhost:44306/api/BatchDocument/DeleteBatchDocument/15
            this.url + "DeleteBatchDocument/" + this.state.editId,
            this.config
          )
          .then((response) => {
            this.setState({ loading: false });

            console.log("Delete Response :", response);
            Swal.fire("Record Deleted Successfully", "", "success");
            $("#btnCancel").click();
          })
          .catch((error) => {
            this.setState({ loading: false });

            console.log(error);
            Swal.fire(
              "Record Not Deleted!",
              "Record can not be delete, as it is being reference in other screens.",
              "error"
            );
          });
      }
    });
  };
  saveBatchDocumentSearch = (e) => {
    // e.preventDefault();

    if (!(this.state.editId > 0)) {
      if (
        this.state.filePath === "" ||
        this.state.filePath === null ||
        this.state.filePath === undefined
      ) {
        Swal.fire({
          type: "error",
          text: "Please Attach File",
        });
        return;
      }
    }

    this.setState({ loading: true });
    this.saveBatchDocuments();
    // e.preventDefault();
  };

  saveBatchDocuments = async (e) => {
    if (this.saveBatchCount == 1) {
      return;
    }

    this.saveBatchCount = 1;

    this.setState({ loading: true });

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.searchModel.responsibleParty)) {
      myVal.responsiblePartyValField = (
        <span className="validationMsg">Select Responsible Party</span>
      );
      myVal.validation = true;
    } else {
      myVal.responsiblePartyValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.searchModel.documentTypeID) === true) {
      myVal.documentTypeIDValField = (
        <span className="validationMsg">Select Document Type</span>
      );
      myVal.validation = true;
    } else {
      myVal.documentTypeIDValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //Payment Validation

    var batchDocumentPayment = [];
    let paymentValCount = 0;

    if (this.state.searchModel.batchDocumentPayment == null) {
      batchDocumentPayment = [];
    } else {
      batchDocumentPayment = this.state.searchModel.batchDocumentPayment;
    }

    batchDocumentPayment = await batchDocumentPayment.map(
      async (batchDocument, i) => {
        paymentValCount = 0;

        if (this.isNull(batchDocument.checkDate)) {
          paymentValCount = 1;
          batchDocument.dateValField = (
            <span className="validationMsg">Enter Check Date</span>
          );
        } else {
          batchDocument.dateValField = "";
        }

        if (
          this.isNull(batchDocument.checkDate) == false &&
          new Date(
            moment(batchDocument.checkDate).format().slice(0, 10)
          ).getTime() > new Date(moment().format().slice(0, 10)).getTime()
        ) {
          paymentValCount = 1;
          batchDocument.paymentDateFDValField = (
            <span className="validationMsg">Future date can't be selected</span>
          );
        } else {
          batchDocument.paymentDateFDValField = "";
        }

        if (this.isNull(batchDocument.checkAmount)) {
          paymentValCount = 1;
          batchDocument.amountValField = (
            <span className="validationMsg">Enter Amount</span>
          );
        } else {
          batchDocument.amountValField = "";
        }

        if (this.isNull(batchDocument.checkNo)) {
          paymentValCount = 1;
          batchDocument.checkValField = (
            <span className="validationMsg">Enter Check Number</span>
          );
        } else {
          batchDocument.checkValField = "";
        }
      }
    );
    if (paymentValCount > 0) {
      Swal.fire(
        "SOMETHING WRONG",
        "Please Select Payment Fields Properly",
        "error"
      );
      this.setState({ loading: false });

      this.saveBatchCount = 0;

      return;
    }

    var note = [];
    let noteValCount = 0;

    if (this.state.searchModel.note == null) {
      note = [];
    } else {
      note = this.state.searchModel.note;
    }

    note = await note.map(async (batchDocument, i) => {
      noteValCount = 0;

      if (this.isNull(batchDocument.note)) {
        noteValCount = 1;
        batchDocument.noteValField = (
          <span className="validationMsg">Enter Note</span>
        );
      } else {
        batchDocument.noteValField = "";
      }
    });

    if (noteValCount > 0) {
      Swal.fire(
        "SOMETHING WRONG",
        "Please Select Note Fields Properly",
        "error"
      );
      this.setState({ loading: false });

      this.saveBatchCount = 0;

      return;
    }

    var batchDocumentCharges = [];
    let chargeValCount = 0;

    if (this.state.searchModel.batchDocumentCharges == null) {
      batchDocumentCharges = [];
    } else {
      batchDocumentCharges = this.state.searchModel.batchDocumentCharges;
    }

    batchDocumentCharges = await batchDocumentCharges.map(
      async (batchDocument, i) => {
        chargeValCount = 0;

        if (this.isNull(batchDocument.dos)) {
          chargeValCount = 1;
          batchDocument.dosdateValField = (
            <span className="validationMsg">Enter DOS Date</span>
          );
        } else {
          batchDocument.dosdateValField = "";
        }

        //Payment Date future date  validation
        if (
          this.isNull(batchDocument.dos) == false &&
          new Date(moment(batchDocument.dos).format().slice(0, 10)).getTime() >
            new Date(moment().format().slice(0, 10)).getTime()
        ) {
          chargeValCount = 1;
          batchDocument.dosDateFDValField = (
            <span className="validationMsg">Future date can't be selected</span>
          );
        } else {
          batchDocument.dosDateFDValField = "";
        }

        if (this.isNull(batchDocument.noOfVisits)) {
          chargeValCount = 1;
          batchDocument.noOfVisitsValField = (
            <span className="validationMsg">Enter Visits</span>
          );
        } else {
          batchDocument.noOfVisitsValField = "";
        }

        if (this.isNull(batchDocument.copay)) {
          chargeValCount = 1;
          batchDocument.copayValField = (
            <span className="validationMsg">Enter Copay</span>
          );
        } else {
          batchDocument.copayValField = "";
        }

        if (this.isNull(batchDocument.otherPatientAmount)) {
          chargeValCount = 1;
          batchDocument.patValField = (
            <span className="validationMsg">Enter Other Patient Amount</span>
          );
        } else {
        }
      }
    );

    if (chargeValCount > 0) {
      Swal.fire(
        "SOMETHING WRONG",
        "Please Select Charge Fields Properly",
        "error"
      );
      this.setState({ loading: false });

      this.saveBatchCount = 0;

      return;
    }

    if (this.state.editId > 0) {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          documentInfo: null,
        },
      });
    }

    this.setState({
      validationModel: myVal,
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });

      Swal.fire("SOMETHING WRONG", "Please Select Fields Properly", "error");
      this.setState({ loading: false });

      this.saveBatchCount = 0;

      return;
    }

    if (
      myVal.validation === true
      // && paymentmyVal === true  && chargemyVal === true
    ) {
      this.setState({ loading: false });
      Swal.fire("SOMETHING WRONG", "Please Fill Fields Properly", "error");
    } else {
      axios
        .post(
          this.url + "SaveBatchDocument",
          this.state.searchModel,
          this.config
        )
        .then((response) => {
          console.log("record", this.state.searchModel);

          this.saveBatchCount = 0;

          this.setState({ searchModel: response.data, loading: false });
          Swal.fire("Record Saved Successfully", "", "success");
          // console.log("response of API", response);
        })
        .catch((error) => {
          this.saveBatchCount = 0;

          this.setState({ loading: false });
          console.log("error");
          if (error.response) {
            if (error.response.status) {
              if (error.response.status == 400) {
                console.log(error);
                console.log(error.response);
                Swal.fire(
                  "400 Bad Request",
                  "Please Enter Valid Data",
                  "error"
                );
              } else {
                Swal.fire("Bad Request", "Please Enter Valid Data", "error");
              }
            }
          }
        });

      // e.preventDefault();
    }
  };
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  openhistorypopup = (id) => {
    this.setState({ showPopup: true, id: id });
  };
  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  async handleNoteChange(event) {
    var value = event.target.value;
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    if (caret == 0 || caret <= 1) {
      value = value.trim();
    }
    let newNotesList = this.state.searchModel.note;
    const index = event.target.id;
    const name = event.target.name;
    newNotesList[index][name] = value.toUpperCase();

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        note: newNotesList,
      },
    });
  }
  async deleteRowNotes(event, index, NoteRowId) {
    console.log("deleting the row");
    const NoteRowID = NoteRowId;
    const id = event.target.id;
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        if (NoteRowID > 0) {
          axios
            .delete(this.url + "DeleteNotes/" + NoteRowID, this.config)
            .then((response) => {
              Swal.fire("Record Deleted Successfully", "", "success");
              let note = [...this.state.searchModel.note];
              note.splice(id, 1);
              this.setState({
                searchModel: {
                  ...this.state.searchModel,
                  note: note,
                },
              });
            })
            .catch((error) => {
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let note = [...this.state.searchModel.note];
          note.splice(id, 1);
          this.setState({
            searchModel: {
              ...this.state.searchModel,
              note: note,
            },
          });
        }
      }
    });
  }

  onPaste = (event) => {
    var x = event.target.value;
    x = x.trim();
    var regex = /^[0-9]+$/;
    if (x.length == 0) {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          [event.target.name]: x,
        },
      });
      return;
    }

    if (!x.match(regex)) {
      Swal.fire("", "Should be Number", "error");
      return;
    } else {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          [event.target.name]: x,
        },
      });
    }

    return;
  };

  addPaymentRow() {
    console.log("add Payment row ");
    const batchdocumentPayment = { ...this.batchdocumentPayment };

    var paymentRowModelList = [];

    if (this.isNull(this.state.searchModel.batchDocumentPayment)) {
      paymentRowModelList = paymentRowModelList.concat(batchdocumentPayment);
    } else {
      paymentRowModelList = this.state.searchModel.batchDocumentPayment.concat(
        batchdocumentPayment
      );
    }

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        batchDocumentPayment: paymentRowModelList,
      },
    });
  }

  addChargeRow() {
    console.log("add charge row ");
    const batchdocumentCharges = { ...this.batchdocumentCharges };
    var chargeRowModelList = [];

    if (this.isNull(this.state.searchModel.batchDocumentCharges)) {
      chargeRowModelList = chargeRowModelList.concat(batchdocumentCharges);
    } else {
      chargeRowModelList = this.state.searchModel.batchDocumentCharges.concat(
        batchdocumentCharges
      );
    }

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        batchDocumentCharges: chargeRowModelList,
      },
    });
  }

  handleChargeChange = (event) => {
    let newList = [...this.state.searchModel.batchDocumentCharges];
    const index = event.target.id;
    const name = event.target.name;
    const value = event.target.value;

    newList[index][name] =
      value == "Please Select" ? null : value.toUpperCase();

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        batchDocumentCharges: newList,
      },
    });
  };

  handleBatchPaymentAmountChange = (e) => {
    let batchDocumentPayment = [...this.state.searchModel.batchDocumentPayment];
    const index = e.target.id;
    const name = e.target.name;
    const amount = e.target.value;
    var regexp = /^\d*(\.\d{0,2})?$/;

    if (amount.length < 15) {
      if (regexp.test(amount)) {
        batchDocumentPayment[index][name] = amount;
        this.setState({
          searchModel: {
            ...this.state.searchModel,
            batchDocumentPayment: batchDocumentPayment,
          },
        });
      } else if (amount == "") {
        batchDocumentPayment[index][name] = "";
        this.setState({
          searchModel: {
            ...this.state.searchModel,
            batchDocumentPayment: batchDocumentPayment,
          },
        });
      }
    }
  };

  handleBatchChargeAmountChange = (e) => {
    let batchDocumentCharges = [...this.state.searchModel.batchDocumentCharges];
    const index = e.target.id;
    const name = e.target.name;
    const amount = e.target.value;
    var regexp = /^\d*(\.\d{0,2})?$/;

    if (amount.length < 15) {
      if (regexp.test(amount)) {
        batchDocumentCharges[index][name] = amount;
        this.setState({
          searchModel: {
            ...this.state.searchModel,
            batchDocumentCharges: batchDocumentCharges,
          },
        });
      } else if (amount == "") {
        batchDocumentCharges[index][name] = "";
        this.setState({
          searchModel: {
            ...this.state.searchModel,
            batchDocumentCharges: batchDocumentCharges,
          },
        });
      }
    }
  };

  handlePaymentChange = (event) => {
    let newPList = [...this.state.searchModel.batchDocumentPayment];
    const index = event.target.id;
    const name = event.target.name;
    const value = event.target.value;

    newPList[index][name] =
      value == "Please Select" ? null : value.toUpperCase();

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        batchDocumentPayment: newPList,
      },
    });
  };

  removePaymentRow = (event, index, paymentID) => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        //KHIZER CODE-------------------------DeleteNote
        if (paymentID > 0) {
          axios
            .delete(
              this.url + "DeleteBatchDocumentPayment/" + paymentID,
              this.config
            )
            .then((response) => {
              Swal.fire(
                "Record Deleted!",
                "Record has been deleted.",
                "success"
              );
              let batchDocumentPayment = [
                ...this.state.searchModel.batchDocumentPayment,
              ];
              batchDocumentPayment.splice(index, 1);
              this.setState({
                searchModel: {
                  ...this.state.searchModel,
                  batchDocumentPayment: batchDocumentPayment,
                },
              });
            })
            .catch((error) => {
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let batchDocumentPayment = [
            ...this.state.searchModel.batchDocumentPayment,
          ];
          batchDocumentPayment.splice(index, 1);
          this.setState({
            searchModel: {
              ...this.state.searchModel,
              batchDocumentPayment: batchDocumentPayment,
            },
          });
        }
      }
    });
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select" ||
      value.length == 0
    )
      return true;
    else return false;
  }

  removeChargeRow = (event, index, chaID) => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        if (chaID > 0) {
          axios
            .delete(
              this.url + "DeleteBatchDocumentCharge/" + chaID,
              this.config
            )
            .then((response) => {
              Swal.fire(
                "Record Deleted!",
                "Record has been deleted.",
                "success"
              );
              let batchDocumentCharges = [
                ...this.state.searchModel.batchDocumentCharges,
              ];
              batchDocumentCharges.splice(index, 1);
              this.setState({
                searchModel: {
                  ...this.state.searchModel,
                  batchDocumentCharges: batchDocumentCharges,
                },
              });
            })
            .catch((error) => {
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let batchDocumentCharges = [
            ...this.state.searchModel.batchDocumentCharges,
          ];
          batchDocumentCharges.splice(index, 1);
          this.setState({
            searchModel: {
              ...this.state.searchModel,
              batchDocumentCharges: batchDocumentCharges,
            },
          });
        }
      }
    });
  };

  render() {
    const headers = ["Demographics Info", "Charges", "Payment", "Notes"];

    let popup = "";

    if (this.state.popupName === "practice") {
      popup = (
        <NewPractice
          onClose={() => this.closePopup}
          practiceID={this.state.id}
        ></NewPractice>
      );
    } else if (this.state.popupName === "location") {
      popup = (
        <NewLocation
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewLocation>
      );
    } else if (this.state.popupName === "provider") {
      popup = (
        <NewProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (this.state.showLPopup) {
      popup = (
        <NewLocation
          onClose={() => this.closeLocationPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewLocation>
      );
    } else if (this.state.showDPopup) {
      popup = (
        <NewDocumentType
          onClose={() => this.closeDocumentPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewDocumentType>
      );
    } else if (this.state.showPPopup) {
      popup = (
        <NewProvider
          onClose={() => this.closeProviderPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        >
          >
        </NewProvider>
      );
    } else if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
          // disabled={this.isDisabled(this.props.rights.update)}
          // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else popup = <React.Fragment></React.Fragment>;

    try {
      if (this.props.userInfo1.userPractices.length > 0) {
        if (this.state.practice.length == 0) {
          if (this.state.editId == 0) {
            let locID =
              this.props.userInfo1.userLocations.length > 1
                ? this.props.userInfo1.userLocations[1].id
                : null;
            let provID =
              this.props.userInfo1.userProviders.length > 1
                ? this.props.userInfo1.userProviders[1].id
                : null;

            console.log(locID);
            console.log("second");
            console.log(provID);

            this.setState({
              searchModel: {
                ...this.state.searchModel,
                practiceID: this.props.userInfo1.practiceID,
                locationID: locID,
                providerID: provID,
              },
              practice: this.props.userInfo1.userPractices,
              location: this.props.userInfo1.userLocations,
              provider: this.props.userInfo1.userProviders,
            });
          } else {
            this.setState({
              searchModel: {
                ...this.state.searchModel,
                practiceID: this.props.userInfo1.practiceID,
              },
              practice: this.props.userInfo1.userPractices,
              location: this.props.userInfo1.userLocations,
              provider: this.props.userInfo1.userProviders,
            });
          }
        }
      }
    } catch {}

    let chargeRowModelList = [];

    if (this.isNull(this.state.searchModel.batchDocumentCharges) == false) {
      //BAtch Payment Map method
      this.state.searchModel.batchDocumentCharges.map((row, index) => {
        var dos = row.dos ? row.dos.slice(0, 10) : "";

        chargeRowModelList.push({
          id: "row.id",
          dos: (
            <div className="textBoxValidate" style={{ width: "150px" }}>
              <input
                ref={(input) => {
                  this.chargeInput = input;
                }}
                type="date"
                min="1900-01-01"
                max="9999-12-31"
                name="dos"
                id={index}
                value={dos}
                onChange={this.handleChargeChange}
              ></input>
              {row.dosdateValField}
              {row.dosDateFDValField}
            </div>
          ),
          noOfVisits: (
            <div style={{ width: "160px" }} className="textBoxValidate">
              <input
                ref={(input) => {
                  this.chargeInput = input;
                }}
                type="text"
                name="noOfVisits"
                id={index}
                maxLength="20"
                value={
                  this.state.searchModel.batchDocumentCharges[index].noOfVisits
                }
                onChange={this.handleChargeChange}
                onKeyPress={this.handleNumericCheck}
              ></input>

              {row.noOfVisitsValField}
            </div>
          ),
          copay: (
            <div style={{ width: "160px" }} className="textBoxValidate">
              <input
                type="text"
                name="copay"
                id={index}
                maxLength="20"
                value={this.state.searchModel.batchDocumentCharges[index].copay}
                onChange={this.handleBatchChargeAmountChange}
                // onKeyPress={this.handleNumericCheck}
              ></input>
              {row.copayValField}
            </div>
          ),

          otherPatientAmount: (
            <div style={{ width: "160px" }} className="textBoxValidate">
              <input
                type="text"
                name="otherPatientAmount"
                id={index}
                maxLength="20"
                value={
                  this.state.searchModel.batchDocumentCharges[index]
                    .otherPatientAmount
                }
                onChange={this.handleBatchChargeAmountChange}
                // onKeyPress={this.handleNumericCheck}
              ></input>
              {row.patValField}
            </div>
          ),
          remove: (
            <div style={{ width: "50px", textAlign: "center" }}>
              <button
                className="removeBtn"
                name="deleteCPTBtn"
                id={index}
                onClick={(event) => this.removeChargeRow(event, index, row.id)}
              ></button>
            </div>
          ),
        });
      });
    } else {
      chargeRowModelList = [];
    }

    const chargeData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150,
        },
        {
          label: "DOS",
          field: "dos",
          sort: "asc",
          width: 150,
        },
        {
          label: "# OF VISITS",
          field: "noOfVisits",
          sort: "asc",
          width: 150,
        },
        {
          label: "COPAY",
          field: "copay",
          sort: "asc",
          width: 150,
        },
        {
          label: "OTHER PATIENT AMOUNT",
          field: "otherPatientAmount",
          sort: "asc",
          width: 150,
        },

        {
          label: "",
          field: "remove",
          sort: "asc",
          // width: 0
        },
      ],
      rows: chargeRowModelList,
    };

    var paymentRowModelList = [];

    if (this.isNull(this.state.searchModel.batchDocumentPayment) == false) {
      //BAtch Payment Map method
      this.state.searchModel.batchDocumentPayment.map((row, index) => {
        var checkDate = row.checkDate ? row.checkDate.slice(0, 10) : "";

        paymentRowModelList.push({
          id: "row.id",

          checkNo: (
            <div style={{ width: "160px" }} className="textBoxValidate">
              <input
                ref={(input) => {
                  this.chargeInput = input;
                }}
                type="text"
                name="checkNo"
                id={index}
                maxLength="20"
                value={
                  this.state.searchModel.batchDocumentPayment[index].checkNo
                }
                onChange={this.handlePaymentChange}
              ></input>
              {this.state.searchModel.batchDocumentPayment[index].checkValField}
            </div>
          ),
          checkDate: (
            <div className="textBoxValidate" style={{ width: "150px" }}>
              <input
                type="date"
                min="1900-01-01"
                max="9999-12-31"
                name="checkDate"
                id={index}
                value={checkDate}
                onChange={this.handlePaymentChange}
              ></input>

              {this.state.searchModel.batchDocumentPayment[index].dateValField}
              {
                this.state.searchModel.batchDocumentPayment[index]
                  .paymentDateFDValField
              }
            </div>
          ),

          checkAmount: (
            <div style={{ width: "160px" }} className="textBoxValidate">
              <input
                type="text"
                name="checkAmount"
                id={index}
                maxLength="20"
                value={
                  this.state.searchModel.batchDocumentPayment[index].checkAmount
                }
                onChange={this.handleBatchPaymentAmountChange}
              ></input>
              {
                this.state.searchModel.batchDocumentPayment[index]
                  .amountValField
              }
            </div>
          ),

          applied: (
            <div style={{ width: "160px" }} className="textBoxValidate">
              <input
                type="text"
                name="applied"
                readOnly
                disabled
                id={index}
                maxLength="20"
                value={
                  this.state.searchModel.batchDocumentPayment[index].applied
                }
                onChange={this.handlePaymentChange}
                onKeyPress={this.handleNumericCheck}
              ></input>
              {/* {row.subscriberIDValField} */}
            </div>
          ),

          unApplied: (
            <div style={{ width: "160px" }} className="textBoxValidate">
              <input
                type="text"
                name="unApplied"
                id={index}
                readOnly
                disabled
                maxLength="20"
                value={
                  this.state.searchModel.batchDocumentPayment[index].unApplied
                }
                onChange={this.handlePaymentChange}
                onKeyPress={this.handleNumericCheck}
              ></input>
              {/* {row.subscriberIDValField} */}
            </div>
          ),

          remarks: (
            <div style={{ width: "160px" }} className="textBoxValidate">
              <input
                type="text"
                name="remarks"
                id={index}
                maxLength="20"
                value={
                  this.state.searchModel.batchDocumentPayment[index].remarks
                }
                onChange={this.handlePaymentChange}
                // onKeyPress={this.handleNumericCheck}
              ></input>
              {/* {row.subscriberIDValField} */}
            </div>
          ),
          remove: (
            <div style={{ width: "50px", textAlign: "center" }}>
              <button
                className="removeBtn"
                name="deleteCPTBtn"
                id={index}
                onClick={(event) => this.removePaymentRow(event, index, row.id)}
              ></button>
            </div>
          ),
        });
      });
    } else {
      paymentRowModelList = [];
    }

    const paymentData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150,
        },
        {
          label: "CHECK #",
          field: "checkNo",
          sort: "asc",
          width: 150,
        },
        {
          label: "CHECK DATE",
          field: "checkDate",
          sort: "asc",
          width: 150,
        },
        {
          label: "AMOUNT",
          field: "checkAmount",
          sort: "asc",
          width: 150,
        },
        {
          label: "APPLIED",
          field: "applied",
          sort: "asc",
          width: 150,
        },
        {
          label: "UNAPPLIED",
          field: "unApplied",
          sort: "asc",
          width: 150,
        },
        {
          label: "REMARKS",
          field: "remarks",
          sort: "asc",
          width: 150,
        },
        {
          label: "",
          field: "remove",
          sort: "asc",
          // width: 0
        },
      ],
      rows: paymentRowModelList,
    };

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    const options = [
      { value: "History", label: "History", className: "dropdown" },
    ];

    var Imag;
    Imag = (
      <div>
        <img
          src={settingsIcon}
          style={{ marginTop: "0em", marginRight: "-2em" }}
        />
      </div>
    );

    var dropdown;

    if (this.state.editId > 0) {
      dropdown = (
        <Dropdown
          className="TodayselectContainer"
          options={options}
          onChange={() => this.openhistorypopup(0)}
          //  value={options}
          // placeholder={"Select an option"}

          placeholder={Imag}
        />
      );
    }

    var inputShow;
    if (this.state.searchModel.id > 0) {
      inputShow = (
        <React.Fragment>
          <span
            style={{ lineHeight: "32px", position: "relative" }}
            className={this.state.numberOfPages ? "txtUnderline" : ""}
            // onClick={
            //   this.state.numberOfPages
            //     ? () =>
            //         this.openPopup(
            //           "batchNo",
            //           this.state.searchModel.numberOfPages
            //         )
            //     : undefined
            // }
          >
            # of Pages
          </span>

          <span>/Size</span>

          <div className="selectBoxValidate addBoxCol"></div>

          <div className="textBoxTwoField textBoxValidate ml-2">
            <div className="textBoxValidate twoColValidate">
              <input
                type="text"
                maxLength="20"
                readOnly
                value={this.state.searchModel.numberOfPages}
                name="numberOfPages"
                id="numberOfPages"
                // onChange={this.handleBatchChange}
              ></input>
              {/* {this.state.validationModel.batchDocumentIDValField} */}
            </div>
            <div className="textBoxValidate twoColValidate">
              <input
                className="w-75"
                maxLength="20"
                type="text"
                readOnly
                value={this.state.searchModel.fileSize}
                name="fileSize"
                id="fileSize"
                //  onChange={this.handleChange}
                //   onKeyPress={(event) => this.handleNumericCheck(event)}
              ></input>
              <span
                style={{
                  float: "left",
                  margin: "10px",
                }}
              >
                KB
              </span>
            </div>
          </div>
        </React.Fragment>
      );
    }

    let chargegrid = "";
    chargegrid = (
      <div className="mainTable fullWidthTable">
        <div className="table-grid mt-15">
          <div className="row headingTable">
            <div className="mf-6">
              <h1>CHARGES</h1>
            </div>
            <div className="mf-6 headingRightTable">
              <button className="btn-blue" onClick={this.addChargeRow}>
                Add charge{" "}
              </button>
            </div>
          </div>

          <div className="tableGridContainer text-nowrap">
            <div className="tableGridContainer">
              <MDBDataTable
                responsive={true}
                striped
                bordered
                searching={false}
                data={chargeData}
                displayEntries={false}
                sortable={true}
                scrollX={false}
                scrollY={false}
              />
            </div>
          </div>
        </div>
      </div>
    );
    let paymentgrid = "";
    paymentgrid = (
      <div className="mainTable fullWidthTable">
        <div className="table-grid mt-15">
          <div className="row headingTable">
            <div className="mf-6">
              <h1>PAYMENT</h1>
            </div>
            <div className="mf-6 headingRightTable">
              <button className="btn-blue" onClick={this.addPaymentRow}>
                Add Payment{" "}
              </button>
            </div>
          </div>

          <div className="tableGridContainer text-nowrap">
            <div className="tableGridContainer">
              <MDBDataTable
                responsive={true}
                striped
                bordered
                searching={false}
                data={paymentData}
                displayEntries={false}
                sortable={true}
                scrollX={false}
                scrollY={false}
              />
            </div>
          </div>
        </div>
      </div>
    );

    const resPID = [
      { value: "", display: "Please Select" },
      { value: "B", display: "BELLMEDEX" },
      { value: "C", display: "CLIENT" },
    ];

    const statusID = [
      { value: "", display: "Please Select" },
      { value: "N", display: "NOT STARTED" },
      { value: "C", display: "CLOSED" },
      { value: "I", display: "IN PROCESS" },
    ];

    let notesList = [];
    var noteTableData = {};
    let Note = [];

    if (this.state.searchModel.note)
      this.state.searchModel.note.map((row, index) => {
        var notesDate = this.isNull(row.notesDate)
          ? ""
          : row.notesDate.slice(0, 10);

        if (notesDate != "") {
          var YY = notesDate.slice(0, 4);
          var DD = notesDate.slice(5, 7);
          var MM = notesDate.slice(8, 10);
        }

        notesList.push({
          id: row.id,

          notesDate: (
            <div style={{ width: "86px" }}>
              <span>{notesDate != "" ? MM + "/" + DD + "/" + YY : ""}</span>
            </div>
          ),

          note: (
            <div style={{ width: "100%" }}>
              <textarea
                data-toggle="tooltip"
                title={this.state.searchModel.note[index].note}
                className="Note-textarea"
                style={{
                  width: "100%",
                  height: "100%",
                  padding: "10px",
                }}
                rows="1"
                cols="60"
                name="note"
                value={this.state.searchModel.note[index].note}
                id={index}
                onChange={this.handleNoteChange}
              ></textarea>
              {this.state.searchModel.note[index].noteValField}
            </div>
          ),

          addedBy: (
            <div style={{ width: "150px" }}>
              <span>{this.state.searchModel.note[index].addedBy}</span>
            </div>
          ),

          remove: (
            <div style={{ width: "50px", textAlign: "center" }}>
              <button
                className="removeBtn"
                name="deleteCPTBtn"
                id={index}
                onClick={(event, index) =>
                  this.deleteRowNotes(event, index, row.id)
                }
              ></button>
            </div>
          ),
        });
      });
    noteTableData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          //  width: 100
        },
        {
          label: "DATE",
          field: "notesDate",
          sort: "asc",
          // width: 400
        },
        {
          label: "NOTES",
          field: "note",
          sort: "asc",
          // width: 200
        },
        {
          label: "ADDED BY",
          field: "addedBy",
          sort: "asc",
          // width: 50
        },

        {
          label: "",
          field: "remove",
          sort: "asc",
          // width: 0
        },
      ],
      rows: notesList,
    };

    var providerFromDate = this.state.searchModel.startDate
      ? this.state.searchModel.startDate.slice(0, 10)
      : "";
    var providerToDate = this.state.searchModel.endDate
      ? this.state.searchModel.endDate.slice(0, 10)
      : "";

    return (
      <React.Fragment>
        <div
          id="myModal"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}

            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={this.props.onClose()}
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>

              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-4 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? "BATCH #  " + this.state.editId
                          : //  +
                            // "-" +
                            // this.state.STATUS
                            "NEW BATCH DOCUMENT"}
                      </h1>
                    </div>

                    <div className="mf-8 popupHeadingRight">
                      {this.state.editId > 0 ? (
                        <React.Fragment>
                          <button
                            data-toggle="modal"
                            paddingRight="20%"
                            data-target=".bs-example-modal-new"
                            className="btn-blue-icon"
                            onClick={() => this.downloadFile()}
                          >
                            Download File
                          </button>
                        </React.Fragment>
                      ) : (
                        <React.Fragment>
                          <div
                            className="textBoxValidate"
                            style={{
                              display: "inline-block",
                            }}
                          >
                            <label
                              for="file-upload"
                              // id="file-upload-style"
                              className={
                                this.state.validationModel.fileUploadVal +
                                " btn-blue"
                                  ? this.errorField + " btn-blue"
                                  : ""
                              }
                              // className="custom-file-upload btn-blue"
                            >
                              Attach Document
                              <input
                                id="file-upload"
                                type="file"
                                onChange={(e) => this.ProcessFileLoad(e)}
                              />
                            </label>
                            <label id="validPath">{this.state.filePath}</label>
                            {this.state.validationModel.fileUploadVal}
                          </div>
                        </React.Fragment>
                      )}

                      <Input
                        type="button"
                        paddingRight="20%"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                        disabled={this.isDisabled(this.props.rights.delete)}
                      >
                        Delete
                      </Input>
                      {dropdown}
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable fullWidthTable wSpace">
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Batch #</label>
                      <div>
                        <Input
                          type="text"
                          disabled="disabled"
                          value={this.state.searchModel.id}
                          name="id"
                          id="id"
                          onChange={() => this.handleChange}
                        />
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>
                        Reponsible Party <span className="redlbl"> *</span>
                        {/* <span className="redlbl"> *</span> */}
                      </label>
                      <select
                        className={
                          this.state.validationModel.responsiblePartyValField
                            ? this.errorField
                            : ""
                        }
                        name="responsibleParty"
                        id="responsibleParty"
                        value={this.state.searchModel.responsibleParty}
                        onChange={this.handleChange}
                      >
                        {resPID.map((s) => (
                          <option key={s.value} value={s.value}>
                            {" "}
                            {s.display}{" "}
                          </option>
                        ))}
                      </select>
                      <div className="textBoxValidate">
                        {" "}
                        {this.state.validationModel.responsiblePartyValField}
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        Doc Type <span className="redlbl"> *</span>
                      </label>

                      <div className="selectBoxValidate addBoxCol">
                        <select
                          className={
                            this.state.validationModel.documentTypeIDValField
                              ? this.errorField
                              : ""
                          }
                          name="documentTypeID"
                          id="documentTypeID"
                          value={this.state.searchModel.documentTypeID}
                          onChange={this.handleChange}
                        >
                          {this.state.cateData.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.description}
                            </option>
                          ))}
                        </select>

                        <img
                          src={plusSrc}
                          onClick={() => this.openDocumentPopup(0)}
                          disabled={this.isDisabled(this.props.rights.add)}
                        />
                      </div>

                      <div className="textBoxValidate">
                        {" "}
                        {this.state.validationModel.documentTypeIDValField}
                      </div>
                    </div>

                    <div className="mf-6">
                      <label
                        className={
                          this.state.searchModel.practiceID
                            ? "txtUnderline"
                            : ""
                        }
                        onClick={
                          this.state.searchModel.practiceID
                            ? () =>
                                this.openPopup(
                                  "practice",
                                  this.state.searchModel.practiceID
                                )
                            : undefined
                        }
                      >
                        Practice
                      </label>
                      <div className="selectBoxValidate">
                        <select
                          className={
                            this.state.validationModel.practiceIDValField
                              ? this.errorField
                              : ""
                          }
                          name="practiceID"
                          id="practiceID"
                          readOnly
                          disabled
                          value={this.state.searchModel.practiceID}
                          onChange={this.handleChange}
                        >
                          {this.state.practice.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.description}
                            </option>
                          ))}
                        </select>
                        {this.state.validationModel.practiceIDValField}
                      </div>
                    </div>
                  </div>

                  {/* mf-6 Second last Row */}

                  <div className="row-form">
                    <div className="mf-6">
                      <label
                        className={
                          this.state.searchModel.locationID
                            ? "txtUnderline"
                            : ""
                        }
                        onClick={
                          this.state.searchModel.locationID
                            ? () =>
                                this.openPopup(
                                  "location",
                                  this.state.searchModel.locationID
                                )
                            : undefined
                        }
                      >
                        Location
                      </label>

                      <div className="selectBoxValidate addBoxCol">
                        <select
                          className={
                            this.state.validationModel.locationIdValField
                              ? this.errorField
                              : ""
                          }
                          name="locationID"
                          id="locationID"
                          value={this.state.searchModel.locationID}
                          onChange={this.handleChange}
                        >
                          {this.props.userLocations.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.description}
                            </option>
                          ))}
                        </select>

                        <img
                          src={plusSrc}
                          onClick={() => this.openLocationPopup(0)}
                          disabled={this.isDisabled(this.props.rights.add)}
                        />
                      </div>

                      <div className="textBoxValidate">
                        {this.state.validationModel.locationIdValField}
                      </div>
                    </div>

                    <div className="mf-6">
                      <label
                        className={
                          this.state.searchModel.providerID
                            ? "txtUnderline"
                            : ""
                        }
                        onClick={
                          this.state.searchModel.providerID
                            ? () =>
                                this.openPopup(
                                  "provider",
                                  this.state.searchModel.providerID
                                )
                            : undefined
                        }
                      >
                        Provider
                      </label>

                      <div className="selectBoxValidate addBoxCol">
                        <select
                          className={
                            this.state.validationModel.providerIDValField
                              ? this.errorField
                              : ""
                          }
                          name="providerID"
                          id="providerID"
                          value={this.state.searchModel.providerID}
                          onChange={this.handleChange}
                        >
                          {this.props.userProviders.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.description}
                            </option>
                          ))}
                        </select>
                        <img
                          src={plusSrc}
                          onClick={() => this.openProviderPopup(0)}
                          disabled={this.isDisabled(this.props.rights.add)}
                        />
                      </div>

                      <div className="textBoxValidate">
                        {this.state.validationModel.providerIDValField}
                      </div>
                    </div>
                  </div>

                  {/* mf-6 last Row */}

                  <div className="row-form">
                    <div className="mf-6">
                      {this.props.id > 0 ? (
                        <React.Fragment>
                          <label>Status</label>
                          <select
                            name="status"
                            id="status"
                            value={this.state.searchModel.status}
                            onChange={this.handleChange}
                          >
                            {statusID.map((s) => (
                              <option key={s.value} value={s.value}>
                                {" "}
                                {s.display}{" "}
                              </option>
                            ))}
                          </select>
                        </React.Fragment>
                      ) : (
                        <React.Fragment>
                          <label>Status</label>
                          <select
                            name="status"
                            id="status"
                            disabled
                            readOnly
                            value={this.state.searchModel.status}
                            onChange={this.handleChange}
                          >
                            {statusID.map((s) => (
                              <option key={s.value} value={s.value}>
                                {" "}
                                {s.display}{" "}
                              </option>
                            ))}
                          </select>
                        </React.Fragment>
                      )}
                    </div>

                    <div class="mf-6 text-right">{inputShow}</div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>Start Date</label>
                      <div className="textBoxValidate">
                        <input
                          style={{
                            width: "215px",
                            marginLeft: "0px",
                          }}
                          readOnly
                          disabled
                          className="myInput"
                          type="date"
                          name="startDate"
                          id="startDate"
                          value={providerFromDate}
                          readOnly
                        ></input>
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>End Date</label>
                      <div className="textBoxValidate">
                        <input
                          style={{
                            width: "215px",
                            marginLeft: "0px",
                          }}
                          className="myInput"
                          type="date"
                          disabled
                          name="endDate"
                          id="endDate"
                          value={providerToDate}
                          readOnly
                        ></input>
                      </div>
                    </div>
                  </div>

                  <Tabs
                    headers={headers}
                    // style={{ cursor: "default" }}
                  >
                    <Tab>
                      <div style={{ marginTop: "20px" }}>
                        <div
                          className="mainTable fullWidthTable wSpace"
                          style={{ maxWidth: "100%" }}
                        >
                          <div className="row-form">
                            <div className="mf-6">
                              <label>Demographic # </label>

                              <Input
                                type="text"
                                value={this.state.searchModel.noOfDemographics}
                                name="noOfDemographics"
                                id="noOfDemographics"
                                onChange={() => this.handleChange}
                                onKeyPress={(event) =>
                                  this.handleNumericCheck(event)
                                }
                                onInput={this.onPaste}
                              ></Input>
                            </div>
                            <div class="mf-6">
                              <label>Demographic Entered # </label>
                              <Input
                                type="text"
                                disabled="disabled"
                                value={
                                  this.state.searchModel.noOfDemographicsEntered
                                }
                                name="noOfDemographicsEntered"
                                id="noOfDemographicsEntered"
                                onChange={() => this.handleChange}
                                onKeyPress={(event) =>
                                  this.handleNumericCheck(event)
                                }
                              ></Input>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Tab>

                    <Tab>{chargegrid}</Tab>
                    <Tab>{paymentgrid}</Tab>
                    <Tab>
                      <div class="mainTable fullWidthTable">
                        <div class="mf-12 table-grid mt-15">
                          <div class="row headingTable">
                            <div class="mf-6">{/* <h1>NOTES</h1> */}</div>
                            <div class="mf-6 headingRightTable">
                              <button
                                class="btn-blue"
                                onClick={this.addRowNotes}
                              >
                                Add Note{" "}
                              </button>
                            </div>
                          </div>

                          <div>
                            <div className="tableGridContainer">
                              <MDBDataTable
                                striped
                                bordered
                                searching={false}
                                data={noteTableData}
                                displayEntries={false}
                                //sortable={true}
                                scrollX={false}
                                scrollY={false}
                                responsive
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </Tab>
                  </Tabs>
                </div>

                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <input
                          type="button"
                          value="Save"
                          className="btn-blue"
                          onClick={this.saveBatchDocumentSearch}
                          disabled={this.isDisabled(
                            this.state.editId > 0
                              ? this.props.rights.update
                              : this.props.rights.add
                          )}
                        ></input>
                        <input
                          type="button"
                          value="Cancel"
                          className="btn-grey"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        ></input>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    userLocations: state.loginInfo
      ? state.loginInfo.userLocations
        ? state.loginInfo.userLocations
        : []
      : [],

    userProviders: state.loginInfo
      ? state.loginInfo.userProviders
        ? state.loginInfo.userProviders
        : []
      : [],

    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    //id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },

    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },

    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.batchdocumentSearch,
          add: state.loginInfo.rights.batchdocumentCreate,
          update: state.loginInfo.rights.batchdocumentUpdate,
          delete: state.loginInfo.rights.batchdocumentDelete,
          export: state.loginInfo.rights.batchdocumentExport,
          import: state.loginInfo.rights.batchdocumentImport,
        }
      : [],
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
    },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(BatchDocumentPopup);
