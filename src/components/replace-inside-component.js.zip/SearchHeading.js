import React, { Component } from "react";

import searchIcon from "../images/search-icon.png";
import refreshIcon from "../images/refresh-icon.png";
import newBtnIcon from "../images/new-page-icon.png";
import settingsIcon from "../images/setting-icon.png";

export class SearchHeading extends Component {
  render() {
    return (
      <div className="mainHeading row">
        <div className="col-md-8">
          <h1>{this.props.heading}</h1>
        </div>
        <div className="col-md-4 headingRight">
          {this.props.heading == "CHARGES SHEET SEARCH" ? (
            <button
              style={{ marginRight: "2%" }}
              data-toggle="modal"
              data-target=".bs-example-modal-new"
              className={
                this.props.disabled == "disabled"
                  ? "btn-blue-disabled"
                  : "btn-blue-icon"
              }
              disabled={this.props.disabled}
              onClick={() => this.props.handler1()}
            >
              {this.props.btnCaption
                ? this.props.btnCaption
                : "Process Payments"}
            </button>
          ) : (
            ""
          )}

          {this.props.heading == "PATIENT SHEET SEARCH" ? (
            <button
              style={{ marginRight: "2%" }}
              data-toggle="modal"
              data-target=".bs-example-modal-new"
              className={
                this.props.disabled == "disabled"
                  ? "btn-blue-disabled"
                  : "btn-blue-icon"
              }
              disabled={this.props.disabled}
              onClick={() => this.props.handler1()}
            >
              {this.props.btnCaption ? this.props.btnCaption : "Process"}
            </button>
          ) : (
            ""
          )}
          {/* /************************************************/}
          {this.props.schedular ? (
            <button
              onClick={this.props.openSchedular}
              style={{ marginLeft: "10px" }}
              className="btn-blue"
            >
              Scheduler
            </button>
          ) : this.props.display != false || this.props.display == null ? (
            <button
              data-toggle="modal"
              data-target=".bs-example-modal-new"
              className={
                this.props.disabled == "disabled"
                  ? "btn-blue-disabled"
                  : "btn-blue-icon"
              }
              disabled={this.props.disabled}
              onClick={() => this.props.handler()}
            >
              {this.props.btnCaption ? this.props.btnCaption : "Add New +"}
            </button>
          ) : (
            ""
          )}

          {/* /************************************************/}
        </div>
      </div>
    );
  }
}

export default SearchHeading;
