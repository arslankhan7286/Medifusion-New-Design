import React, { Component, Fragment } from "react";
import $ from "jquery";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import axios from "axios";
import Input from "./Input";
import leftNavMenusReducer from "../reducers/leftNavMenusReducer";
import Swal from "sweetalert2";
import { Tabs, Tab } from "react-tab-view";
import {
  MDBDataTable,
  MDBBtn,
  MDBTableHead,
  MDBTableBody,
  MDBTable,
  MDBCollapse
} from "mdbreact";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import ResetPassword from "./ResetPassword";

import Hotkeys from "react-hot-keys";

export class NewUser extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/account/";
    this.assignPracticesUrl = process.env.REACT_APP_URL + "/userPractices/";
    this.errorField = "errorField";
    this.userRightsUrl = process.env.REACT_APP_URL + "/Rights/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };
    this.savePatientCount = 0;

    this.userModel = {
      id: 0,
      firstName: "",
      lastName: "",
      clientID: null,
      userRole: "",
      email: "",
      password: "",
      cnfrmPass: "",
      practiceID: null,
      teamID: null,
      designationID: null,
      reportingTo: null,
      isActive: false
    };

    this.userPracticesModel = {
      clientID: null,
      practiceID: null,
      currentUserID: null,
      email: "",
      status: false,
      clientName: "",
      practiceName: ""
    };

    this.validationModel = {
      firstNameValField: "",
      lastNameValField: "",
      clientValField: "",
      roleValField: "",
      emailValField: "",
      passwordValField: "",
      cnfrmPassValField: "",
      practiceValField: "",
      userClientValField: "",
      userPracticeValField: "",
      reportingToValField: "",
      validation: false,
      cnfrmValField: ""
    };

    this.userRights = {
      //Scheduler Rights
      schedulerCreate: false,
      schedulerEdit: false,
      schedulerDelete: false,
      schedulerSearch: false,
      schedulerImport: false,
      schedulerExport: false,
      // Patient Rights
      patientCreate: false,
      patientEdit: false,
      patientDelete: false,
      patientSearch: false,
      patientImport: false,
      patientExport: false,
      //Charges Rights
      chargesCreate: false,
      chargesEdit: false,
      chargesDelete: false,
      chargesSearch: false,
      chargesImport: false,
      chargesExport: false,
      resubmitCharges: false,
      //Documents Rights
      documentsCreate: false,
      documentsEdit: false,
      documentsDelete: false,
      documentsSearch: false,
      documentsImport: false,
      documentsExport: false,
      //Submissions Rights
      submissionsCreate: false,
      submissionsEdit: false,
      submissionsDelete: false,
      submissionsSearch: false,
      submissionsImport: false,
      submissionsExport: false,
      //Payments Rights
      paymentsCreate: false,
      paymentsEdit: false,
      paymentsDelete: false,
      paymentsSearch: false,
      paymentsImport: false,
      paymentsExport: false,
      //Followup Rights
      followupCreate: false,
      followupEdit: false,
      followupDelete: false,
      followupSearch: false,
      followupImport: false,
      followupExport: false,
      //Reports Rights
      reportsCreate: false,
      reportsEdit: false,
      reportsDelete: false,
      reportsSearch: false,
      reportsImport: false,
      reportsExport: false,
      //Client Rights
      clientCreate: false,
      clientEdit: false,
      clientDelete: false,
      clientSearch: false,
      clientImport: false,
      clientExport: false,
      userCreate: false,
      userEdit: false,
      userDelete: false,
      userSearch: false,
      userImport: false,
      userExport: false,
      //Practice
      practiceCreate: false,
      practiceEdit: false,
      practiceDelete: false,
      practiceSearch: false,
      practiceImport: false,
      practiceExport: false,
      //Location
      locationCreate: false,
      locationEdit: false,
      locationDelete: false,
      locationSearch: false,
      locationImport: false,
      locationExport: false,
      //Provider
      providerCreate: false,
      providerEdit: false,
      providerDelete: false,
      providerSearch: false,
      providerImport: false,
      providerExport: false,
      //Referring Provider
      referringProviderCreate: false,
      referringProviderEdit: false,
      referringProviderDelete: false,
      referringProviderSearch: false,
      referringProviderImport: false,
      referringProviderExport: false,
      //Insurance
      insuranceCreate: false,
      insuranceEdit: false,
      insuranceDelete: false,
      insuranceSearch: false,
      insuranceImport: false,
      insuranceExport: false,
      //Insurance Plan
      insurancePlanCreate: false,
      insurancePlanEdit: false,
      insurancePlanDelete: false,
      insurancePlanSearch: false,
      insurancePlanImport: false,
      insurancePlanExport: false,
      //Insurance Plan Address
      insurancePlanAddressCreate: false,
      insurancePlanAddressEdit: false,
      insurancePlanAddressDelete: false,
      insurancePlanAddressSearch: false,
      insurancePlanAddressImport: false,
      insurancePlanAddressExport: false,
      //EDI Submit
      eDISubmitCreate: false,
      eDISubmitEdit: false,
      eDISubmitDelete: false,
      eDISubmitSearch: false,
      eDISubmitImport: false,
      eDISubmitExport: false,
      //EDI EligiBility
      eDIEligiBilityCreate: false,
      eDIEligiBilityEdit: false,
      eDIEligiBilityDelete: false,
      eDIEligiBilitySearch: false,
      eDIEligiBilityImport: false,
      eDIEligiBilityExport: false,
      //EDI Status
      eDIStatusCreate: false,
      eDIStatusEdit: false,
      eDIStatusDelete: false,
      eDIStatusSearch: false,
      eDIStatusImport: false,
      eDIStatusExport: false,
      //ICD
      iCDCreate: false,
      iCDEdit: false,
      iCDDelete: false,
      iCDSearch: false,
      iCDImport: false,
      iCDExport: false,
      //CPT
      cPTCreate: false,
      cPTEdit: false,
      cPTDelete: false,
      cPTSearch: false,
      cPTImport: false,
      cPTExport: false,
      //Modifiers
      modifiersCreate: false,
      modifiersEdit: false,
      modifiersDelete: false,
      modifiersSearch: false,
      modifiersImport: false,
      modifiersExport: false,
      //POS
      pOSCreate: false,
      pOSEdit: false,
      pOSDelete: false,
      pOSSearch: false,
      pOSImport: false,
      pOSExport: false,
      //Claim Status Category Codes
      claimStatusCategoryCodesCreate: false,
      claimStatusCategoryCodesEdit: false,
      claimStatusCategoryCodesDelete: false,
      claimStatusCategoryCodesSearch: false,
      claimStatusCategoryCodesImport: false,
      claimStatusCategoryCodesExport: false,
      //Claim Status Codes
      claimStatusCodesCreate: false,
      claimStatusCodesEdit: false,
      claimStatusCodesDelete: false,
      claimStatusCodesSearch: false,
      claimStatusCodesImport: false,
      claimStatusCodesExport: false,
      //Adjustment Codes
      adjustmentCodesCreate: false,
      adjustmentCodesEdit: false,
      adjustmentCodesDelete: false,
      adjustmentCodesSearch: false,
      adjustmentCodesImport: false,
      adjustmentCodesExport: false,
      //Remark Codes
      remarkCodesCreate: false,
      remarkCodesEdit: false,
      remarkCodesDelete: false,
      remarkCodesSearch: false,
      remarkCodesImport: false,
      remarkCodesExport: false,
      //Team Search
      teamCreate: false,
      teamDelete: false,
      teamExport: false,
      teamImport: false,
      teamSearch: false,
      teamupdate: false,
      //Submitter Search
      submitterCreate: false,
      submitterDelete: false,
      submitterExport: false,
      submitterImport: false,
      submitterSearch: false,
      submitterUpdate: false,
      //Receiver
      receiverCreate: false,
      receiverDelete: false,
      receiverExport: false,
      receiverImport: false,
      receiverSearch: false,
      receiverupdate: false,
      //followup
      planFollowupSearch: false,
      planFollowupCreate: false,
      planFollowupDelete: false,
      planFollowupUpdate: false,
      planFollowupImport: false,
      planFollowupExport: false,
      patientFollowupSearch: false,
      patientFollowupCreate: false,
      patientFollowupDelete: false,
      patientFollowupUpdate: false,
      patientFollowupImport: false,
      patientFollowupExport: false,
      //group and reason
      groupSearch: false,
      groupCreate: false,
      groupUpdate: false,
      groupDelete: false,
      groupExport: false,
      groupImport: false,
      reasonSearch: false,
      reasonCreate: false,
      reasonUpdate: false,
      reasonDelete: false,
      reasonExport: false,
      reasonImport: false,
      //chck post
      addPaymentVisit: false,
      deleteCheck: false,
      manualPosting: false,
      postcheck: false,
      //payments
      patientPlanCreate: false,
      patientPlanUpdate: false,
      patientPlanDelete: false,
      patientPlanSearch: false,
      patientPlanExport: false,
      patientPlanImport: false,
      performEligibility: false,
      patientPaymentCreate: false,
      patientPaymentUpdate: false,
      patientPaymentDelete: false,
      patientPaymentSearch: false,
      patientPaymentExport: false,
      patientPaymentImport: false,
      batchdocumentCreate: false,
      batchdocumentUpdate: false,
      batchdocumentDelete: false,
      batchdocumentSearch: false,
      batchdocumentExport: false,
      batchdocumentImport: false,
      electronicsSubmissionSearch: false,
      electronicsSubmissionSubmit: false,
      electronicsSubmissionResubmit: false,
      addPaymentVisit: false,
      deleteCheck: false,
      manualPosting: false,
      postcheck: false,
      postExport: false,
      postImport: false,
      manualPostingAdd: false,
      manualPostingUpdate: false,
      postCheckSearch: false,
      deletePaymentVisit: false
    };

    this.state = {
      editId: this.props.userID,
      userModel: this.userModel,
      validationModel: this.validationModel,
      userPracticesModel: this.userPracticesModel,
      userRights: this.userRights,
      userPracticesArr: [],
      userPracticesArrRes: [],
      maxHeight: "361",
      loading: false,
      cnfrmPass: "",
      userRole: [],
      clientID: [],
      clientPractices: [],
      designations: [],
      teams: [],
      data: [],
      email: this.props.email,
      id: 0,
      test: false,
      reportingToArr: [],
      reportingToDropdown: false,
      loading: false,
      isChecked: false,
      collapseMenu: 0,
      newList: [],
      showPopup: false
    };

    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.saveUser = this.saveUser.bind(this);
    this.delete = this.delete.bind(this);
    this.handleClientChange = this.handleClientChange.bind(this);
    this.addPracticeRow = this.addPracticeRow.bind(this);
    this.deletePracticeRow = this.deletePracticeRow.bind(this);
    this.handlePracticeChange = this.handlePracticeChange.bind(this);
    this.handleUserPracticeClientChange = this.handleUserPracticeClientChange.bind(
      this
    );
    this.isNull = this.isNull.bind(this);
    this.savePractices = this.savePractices.bind(this);
    this.handleCheckedChange = this.handleCheckedChange.bind(this);
    this.saveUserRights = this.saveUserRights.bind(this);
    this.showHide = this.showHide.bind(this);
    this.handleDefultCheckbox = this.handleDefultCheckbox.bind(this);
  }

  //User

  // Search = alt + s
  // clear = alt + c
  //Add NEW = alt + n

  // New User Nav tab

  // save = alt + s

  onKeyDown(keyName, e, handle) {
    if (keyName == "alt+s") {
      // alert("save key")
      this.saveUser(e);
      this.saveUserRights(e);
      this.savePractices(e);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    if (e) {
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  componentWillMount() {
    this.setState({ id: this.props.email ? 1 : 0 });
  }

  async componentDidMount() {
    this.setModalMaxHeight($(".modal"));
    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function() {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);
    await this.setState({ loading: true });
    try {
      // Account Get Profiles
      await axios
        .get(this.url + "getProfiles", this.config)
        .then(response => {
          if (this.state.email) {
            this.setState({
              clientID: response.data.clients,
              userRole: response.data.list,
              designations: response.data.designations,
              teams: response.data.teams,
              loading: false
            });
          } else {
            var filteredUserRles = response.data.list.filter(
              role => role != this.props.userInfo.userRole
            );
            this.setState({
              clientID: response.data.clients,
              userRole: filteredUserRles,
              designations: response.data.designations,
              teams: response.data.teams,
              loading: false
            });
          }
        })
        .catch(error => {
          this.setState({ loading: false });
          if (error.response) {
            if (error.response.status) {
              Swal.fire("Unauthorized Access", "", "error");
              return;
            }
          } else if (error.request) {
            return;
          } else {
            Swal.fire("Something went Wrong", "", "error");
            return;
          }
        });

      if (this.state.email) {
        await this.setState({ loading: true });
        await axios
          .get(this.url + "findUser/" + this.state.email, this.config)
          .then(findUserResponse => {
            // Account Get Practices
            axios
              .get(
                this.url +
                  "GetClientPractices/" +
                  findUserResponse.data.clientID,
                this.config
              )
              .then(clientPracticesResponse => {
                //Reporting To DropDown
                if (
                  findUserResponse.data.userRole == "Biller" ||
                  findUserResponse.data.userRole == "TeamLead"
                ) {
                  var obj = {
                    role: findUserResponse.data.userRole,
                    designationID: findUserResponse.data.designationID,
                    teamID: findUserResponse.data.teamID
                  };
                  // Get ReportingTo Dropdown
                  axios
                    .post(this.url + "getRoleManager", obj, this.config)
                    .then(reportingTResponse => {
                      this.setState({
                        clientPractices: clientPracticesResponse.data,
                        userModel: {
                          ...this.state.userModel,
                          firstName: findUserResponse.data.firstName,
                          lastName: findUserResponse.data.lastName,
                          userRole: findUserResponse.data.userRole,
                          clientID: findUserResponse.data.clientID,
                          designationID: findUserResponse.data.designationID,
                          teamID: findUserResponse.data.teamID,
                          email: findUserResponse.data.email,
                          practiceID: findUserResponse.data.practiceID,
                          reportingTo: findUserResponse.data.reportingTo,
                          password: "123",
                          cnfrmPass: "123"
                        },
                        userPracticesArr:
                          findUserResponse.data.assignedUserPractices,
                        reportingToArr: reportingTResponse.data,
                        reportingToDropdown: true,
                        loading: false
                      });
                    })
                    .catch(error => {
                      this.setState({
                        reportingToDropdown: false,
                        loading: false
                      });
                      if (error.response) {
                        if (error.response.status) {
                          Swal.fire("Unauthorized Access", "", "error");
                          return;
                        }
                      } else if (error.request) {
                        return;
                      } else {
                        Swal.fire("Something went Wrong", "", "error");
                        return;
                      }
                    });
                } else {
                  this.setState({
                    clientPractices: clientPracticesResponse.data,
                    userModel: {
                      ...this.state.userModel,
                      firstName: findUserResponse.data.firstName,
                      lastName: findUserResponse.data.lastName,
                      userRole: findUserResponse.data.userRole,
                      clientID: findUserResponse.data.clientID,
                      designationID: findUserResponse.data.designationID,
                      teamID: findUserResponse.data.teamID,
                      email: findUserResponse.data.email,
                      practiceID: findUserResponse.data.practiceID,
                      reportingTo: findUserResponse.data.reportingTo,
                      password: "123",
                      cnfrmPass: "123"
                    },
                    userPracticesArr:
                      findUserResponse.data.assignedUserPractices,
                    // reportingToArr : reportingTResponse.data,
                    reportingToDropdown: false,
                    loading: false
                  });
                  // this.setState({
                  //   reportingToDropdown: false
                  // });
                }
              })
              .catch(error => {
                this.setState({ loading: false });
                if (error.response) {
                  if (error.response.status) {
                    Swal.fire("Unauthorized Access", "", "error");
                    return;
                  }
                } else if (error.request) {
                  return;
                } else {
                  Swal.fire("Something went Wrong", "", "error");
                  return;
                }
              });
          })
          .catch(error => {
            this.setState({ loading: false });
            if (error.response) {
              if (error.response.status) {
                Swal.fire("Unauthorized Access", "", "error");
                return;
              }
            } else if (error.request) {
              return;
            } else {
              Swal.fire("Something went Wrong", "", "error");
              return;
            }
          });

        //////////////////////////User Rights/////////////////////////////////

        axios
          .get(
            this.userRightsUrl + "GetRights/" + this.state.email,
            this.config
          )
          .then(response => {
            this.setState({
              userRights: response.data,
              loading: false
            });
          })
          .catch(error => {
            this.setState({ loading: false });
            if (error.response) {
              if (error.response.status) {
                //Swal.fire("Unauthorized Access", "", "error");
                return;
              }
            } else if (error.request) {
              return;
            } else {
              Swal.fire("Something went Wrong", "", "error");
              return;
            }
          });
      }
    } catch {}
  }

  async handleChange(event) {
    event.preventDefault();
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });
    var eventName = event.target.name;
    var eventVal = "";
    if (
      eventName == "firstName" ||
      eventName == "lastName" ||
      eventName == "email"
    ) {
      eventVal = event.target.value.toUpperCase();
    } else {
      eventVal = event.target.value;
    }

    await this.setState({
      userModel: {
        ...this.state.userModel,
        [eventName]: eventVal == "Please Select" ? null : eventVal
      }
    });

    //User Role Condition

    if (eventName == "userRole") {
      if (eventVal == "Biller" || eventVal == "TeamLead") {
        await this.setState({
          reportingToDropdown: true
        });
        await this.getReportingToDropdown();
      } else {
        await this.setState({
          reportingToDropdown: false
        });
      }
    } else if (
      eventName == "userRole" ||
      eventName == "teamID" ||
      eventName == "clientID"
    ) {
      await this.getReportingToDropdown();
    }
  }

  getReportingToDropdown = () => {
    var obj = {
      role:
        this.state.userModel.userRole == ""
          ? null
          : this.state.userModel.userRole,
      designationID: this.state.userModel.designationID,
      teamID: this.state.userModel.teamID
    };
    // Get ReportingTo Dropdown
    axios
      .post(this.url + "getRoleManager", obj, this.config)
      .then(response => {
        this.setState({
          reportingToArr: response.data
        });
      })
      .catch(error => {
        if (error.response) {
          if (error.response.status) {
            // Swal.fire("Unauthorized Access", "", "error");
            return;
          }
        } else if (error.request) {
          return;
        } else {
          // Swal.fire("Something went Wrong", "", "error");
          return;
        }
      });
  };
  // Handle client Change
  handleClientChange(event) {
    event.preventDefault();

    this.setState({
      userModel: {
        ...this.state.userModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase()
      }
    });

    // Account Get Practices
    axios
      .get(this.url + "GetClientPractices/" + event.target.value, this.config)
      .then(response => {
        this.setState({ clientPractices: response.data });
      })
      .catch(error => {
        if (error.response) {
          if (error.response.status) {
            Swal.fire("Unauthorized Access", "", "error");
            return;
          }
        } else if (error.request) {
          return;
        } else {
          Swal.fire("Something went Wrong", "", "error");
          return;
        }
      });
  }

  // Handle Practice Change
  handlePracticeChange(event) {
    this.setState({
      userPracticesModel: {
        ...this.state.userPracticesModel,
        [event.target.name]:
          event.target.value == "Please Select" ? null : event.target.value
      }
    });
  }

  //Handle user Pratices Client Change
  handleUserPracticeClientChange(event) {
    this.setState({
      userPracticesModel: {
        ...this.state.userPracticesModel,
        [event.target.name]:
          event.target.value == "Please Select" ? null : event.target.value
      }
    });

    var clientID = 0;
    if (this.isNull(event.target.value)) {
      clientID = 0;
    } else {
      clientID = event.target.value;
    }

    // Account Get Profiles
    axios
      .get(this.url + "GetClientPractices/" + clientID, this.config)
      .then(response => {
        this.setState({ clientPractices: response.data });
      })
      .catch(error => {
        if (error.response) {
          if (error.response.status) {
            Swal.fire("Unauthorized Access", "", "error");
            return;
          }
        } else if (error.request) {
          return;
        } else {
          Swal.fire("Something went Wrong", "", "error");
          return;
        }
      });
  }

  //////////////////////////////// handle user rights check box ///////////////////
  handleCheckedChange(e) {
    this.setState({
      userRights: {
        ...this.state.userRights,
        [e.target.name]: !this.state.userRights[e.target.name]
      }
    });
  }
  ////////////////////////////////////////////////////// save user rights ////////////////////
  saveUserRights(e) {
    if (this.savePatientCount == 1) {
      return;
    }
    this.savePatientCount = 1;
    this.handleCheckedChange(e);
    const obj = {
      email: this.state.userModel.email,
      Rights: this.state.userRights
    };
    axios
      .post(this.userRightsUrl + "SaveRights/", obj, this.config)
      .then(response => {
        this.savePatientCount = 0;
        this.setState({ userRights: response.data.rights });
        Swal.fire("Rights Added Successfully", "", "success");
      })
      .catch(error => {
        this.savePatientCount = 0;
      });
  }

  handleDefultCheckbox() {
    let isChecked = !this.state.isChecked;
    this.setState({ isChecked: isChecked });
    axios
      .get(
        this.userRightsUrl + "GetDefault/" + this.state.userModel.userRole,
        this.config
      )
      .then(response => {
        this.setState({
          userRights: response.data
        });
      })
      .catch(error => {
        if (error.response) {
          if (error.response.status) {
            //Swal.fire("Unauthorized Access", "", "error");
            return;
          }
        } else if (error.request) {
          return;
        } else {
          Swal.fire("Something went Wrong", "", "error");
          return;
        }
      });
  }

  handleCheck = () => {
    this.setState({
      userModel: {
        ...this.state.userModel,
        isActive: !this.state.userModel.isActive
      }
    });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value == "Please Select"
    )
      return true;
    else return false;
  }

  //Save User
  saveUser = e => {
    if (this.savePatientCount == 1) {
      return;
    }
    this.savePatientCount = 1;
    this.setState({ loading: true });
    if (this.state.userModelState == "Updated Successfully") {
      this.savePatientCount = 0;
      return;
    } else if (this.state.userModelState == "User Created Successfully") {
      this.savePatientCount = 0;
      return;
    }

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.userModel.lastName)) {
      myVal.lastNameValField = (
        <span className="validationMsg">Last Name is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.lastNameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.userModel.firstName)) {
      myVal.firstNameValField = (
        <span className="validationMsg"> First Name is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.firstNameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.userModel.userRole)) {
      myVal.roleValField = (
        <span className="validationMsg"> User Role is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.roleValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.userModel.userRole) == false) {
      if (
        this.state.userModel.userRole == "Biller" ||
        this.state.userModel.userRole == "TeamLead"
      ) {
        if (this.isNull(this.state.userModel.reportingTo)) {
          myVal.reportingToValField = (
            <span className="validationMsg"> ReportingTo is Required</span>
          );
          myVal.validation = true;
        } else {
          myVal.reportingToValField = "";
          if (myVal.validation === false) myVal.validation = false;
        }
      }
    } else {
      myVal.reportingToValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.userModel.clientID)) {
      myVal.clientValField = (
        <span className="validationMsg"> Client is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.clientValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.userModel.email)) {
      myVal.emailValField = (
        <span className="validationMsg"> Email is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.emailValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.userModel.practiceID)) {
      myVal.practiceValField = (
        <span className="validationMsg"> Practice is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.practiceValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.userModel.password)) {
      myVal.passwordValField = (
        <span className="validationMsg" style={{ marginTop: "-15px" }}>
          {" "}
          Password is Required
        </span>
      );
      myVal.validation = true;
    } else {
      myVal.passwordValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.userModel.cnfrmPass)) {
      myVal.cnfrmPassValField = (
        <span className="validationMsg">Confirm Password is Required</span>
      );
      myVal.validation = true;
    } else {
      myVal.cnfrmPassValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.state.userModel.password !== this.state.userModel.cnfrmPass) {
      //myVal.passwordValField = <span className="validationMsg">Password Did"t Match</span>
      myVal.cnfrmPassValField = (
        <span className="validationMsg">Password Did"t Match</span>
      );
      myVal.validation = true;
    } else {
      //myVal.passwordValField = '';
      myVal.cnfrmPassValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      Swal.fire("Please Select All Fields Properly", "", "error");
      this.savePatientCount = 0;
      return;
    }

    axios
      .post(this.url + "CreateAccount", this.state.userModel, this.config)
      .then(response => {
        this.savePatientCount = 0;
        this.setState({
          userModelState: response.data,
          editId: response.data.id,
          loading: false
        });
        Swal.fire("Account Saved Successfully", "", "success");
      })
      .catch(error => {
        this.savePatientCount = 0;
        this.setState({ loading: false });

        if (error.response) {
          if (error.response.status) {
            if (error.response.status == 404) {
              Swal.fire("Error", "404 Not Found ", "error");
            }
          }
        } else if (error.request) {
          return;
        } else {
          Swal.fire("Something  Wrong", "", "error");
          return;
        }
      });

    // this.setState({ loading: false });
    // e.preventDefault();
  };

  //Delete User
  delete = e => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        // this.setState({loading:true})
        // axios
        //     .delete(this.url + "deleteClient/" + this.state.editId)
        //     .then(response => {
        //         this.setState({loading:false})
        //         Swal.fire("Record Deleted Successfully", "", "success");
        //     })
        //     .catch(error => {
        //         this.setState({loading:false})
        // if (error.response) {
        //     if(error.response.status){
        //         Swal.fire("Unauthorized Access" , "" , "error");
        //         return
        //     }
        //   } else if (error.request) {
        //     return
        //   } else {
        //  Swal.fire("Record Not Deleted!", "Record can not be delete, as it is being referenced in other screens.", "error");
        //     return
        //   }
        //
        //     });
        // $("#btnCancel").click();
      }
    });
  };

  //Add Practice Row
  async addPracticeRow() {
    try {
      //User Practice And Client Validation Model
      var myVal = this.validationModel;
      myVal.validation = false;

      if (this.isNull(this.state.userPracticesModel.clientID)) {
        myVal.userClientValField = (
          <span className="validationMsg">Select Client</span>
        );
        myVal.validation = true;
      } else {
        myVal.userClientValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }

      if (this.isNull(this.state.userPracticesModel.practiceID)) {
        myVal.userPracticeValField = (
          <span className="validationMsg"> Select Primary Practice</span>
        );
        myVal.validation = true;
      } else {
        myVal.userPracticeValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }

      this.setState({
        validationModel: myVal
      });

      if (myVal.validation === true) {
        this.setState({ loading: false });
        Swal.fire("Please Select All Fields Properly", "", "error");
        return;
      }

      //Check weather this practice already added to array
      var practiceCheck = await this.state.userPracticesArr.filter(
        practice =>
          practice.practiceID == this.state.userPracticesModel.practiceID &&
          practice.clientID == this.state.userPracticesModel.clientID
      );
      if (practiceCheck.length > 0) {
        this.setState({ loading: false });
        Swal.fire("Same Record Alredy Exists", "", "error");
        return;
      }

      //Filter Client and Practice Array to get Client Name and Practice Name
      var client = await this.state.clientID.filter(
        client => client.id == this.state.userPracticesModel.clientID
      );
      var practice = await this.state.clientPractices.filter(
        practice => practice.id == this.state.userPracticesModel.practiceID
      );
      var obj = {
        clientID: this.state.userPracticesModel.clientID,
        practiceID: this.state.userPracticesModel.practiceID,
        currentUserID: null,
        email: this.props.email,
        status: true,
        clientName: client.length > 0 ? client[0].description : "",
        practiceName: practice.length > 0 ? practice[0].description : ""
      };

      await this.setState({
        userPracticesArr: this.state.userPracticesArr.concat(obj)
      });
    } catch {}
  }

  //Delete Practice Row
  async deletePracticeRow(clientID, practiceID) {
    try {
      if (practiceID == this.state.userModel.practiceID) {
        Swal.fire("Primary Practice Can't Be Deleted", "", "error");

        return;
      }
      var practice;
      await this.state.userPracticesArr.map((practice, index) => {
        if (
          practice.practiceID == practiceID &&
          practice.clientID == clientID
        ) {
          practice = [...this.state.userPracticesArr];
          practice[index].status = false;
          this.setState({
            userPracticesArr: practice
          });
        }
      });
    } catch {}
  }

  //Save Practices
  savePractices() {
    this.setState({ loading: true });
    axios
      .post(
        this.assignPracticesUrl + "assignPractices",
        this.state.userPracticesArr,
        this.config
      )
      .then(response => {
        Swal.fire("Saved Successfully", "", "success");
        this.setState({ loading: false });
        // this.setState({ client: response.data.clients , role : response.data.roles });
      })
      .catch(error => {
        this.setState({ loading: false });
        if (error.response) {
          if (error.response.status) {
            //Swal.fire("Unauthorized Access" , "" , "error");
            return;
          }
        } else if (error.request) {
          return;
        } else {
          //Swal.fire("Something went Wrong" , "" , "error");
          return;
        }
      });
  }

  /// collapse
  showHide(id) {
    this.setState({
      collapseMenu: this.state.collapseMenu == id ? -1 : id
    });
  }
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  openPasswordPopup = id => {
    this.setState({ showPopup: true, id: id });
  };
  closePasswordPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  render() {
    const isActive = this.state.userModel.isActive;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }
    const headers = ["User Info", "Practices", "Rights"];

    var rowData = [];
    this.state.userPracticesArr.map(practice => {
      if (practice.status == true) {
        var obj = {
          id: practice.status,
          clientName: practice.clientName,
          practiceName: practice.practiceName,
          delete: (
            <div style={{ width: "100px" }}>
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.deletePracticeRow(practice.clientID, practice.practiceID)
                }
              >
                Delete
              </MDBBtn>
            </div>
          )
        };
        rowData.push(obj);
      }
    });
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "CLIENT",
          field: "clientName",
          sort: "asc",
          width: 150
        },
        {
          label: "PRACTICE",
          field: "practiceName",
          sort: "asc",
          width: 270
        },

        {
          label: "DELETE",
          field: "delete",
          sort: "asc",
          width: 100
        }
      ],
      rows: rowData
    };

    //////////////////////////////////////////// Change Password //////////////////////////////////

    var resetPasswordButton;
    resetPasswordButton = (
      <Input
        type="button"
        value="Reset Password"
        className="btn-blue"
        onClick={() => this.openPasswordPopup(0)}
      >
        Reset Password
      </Input>
    );

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <ResetPassword
          onClose={() => this.closePasswordPopup}
          email={this.state.email}
        ></ResetPassword>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    return (
      <React.Fragment>
        {popup}
        <div
          id="myModal"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          userRole="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}
            {/* 
                        <button onClick={this.props.onClose} className="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true"></span>
                        </button> */}

            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                style={{ marginLeft: "1140px" }}
                onClick={
                  this.props.onClose
                    ? this.props.onClose()
                    : () => this.props.onClose()
                }
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.userModel.name +
                            " - " +
                            this.state.userModel.organizationName +
                            " "
                          : "NEW USER"}
                      </h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkbox"
                          checked={!isActive}
                          id="isActive"
                          name="isActive"
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      {this.state.email != "" ? resetPasswordButton : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable fullWidthTable">
                  <div className="row-form">
                    <div className="mf-12">
                      <Tabs headers={headers} style={{ cursor: "default" }}>
                        <Tab>
                          <div style={{ marginTop: "50px" }}>
                            <div className="mainTable">
                              <div className="row-form">
                                <div className="mf-6">
                                  <label>
                                    Last Name
                                    <span className="redlbl"> *</span>
                                  </label>

                                  <div className="textBoxValidate">
                                    <Input
                                      className={
                                        this.state.validationModel
                                          .lastNameValField
                                          ? this.errorField
                                          : ""
                                      }
                                      type="text"
                                      value={this.state.userModel.lastName}
                                      name="lastName"
                                      id="lastName"
                                      max="20"
                                      onChange={() => this.handleChange}
                                    />
                                    {
                                      this.state.validationModel
                                        .lastNameValField
                                    }
                                  </div>
                                </div>

                                <div className="mf-6">
                                  <label>
                                    First Name{" "}
                                    <span className="redlbl"> *</span>
                                  </label>

                                  <div className="textBoxValidate">
                                    <Input
                                      className={
                                        this.state.validationModel
                                          .firstNameValField
                                          ? this.errorField
                                          : ""
                                      }
                                      type="text"
                                      value={this.state.userModel.firstName}
                                      name="firstName"
                                      id="firstName"
                                      max="20"
                                      onChange={() => this.handleChange}
                                    />
                                    {
                                      this.state.validationModel
                                        .firstNameValField
                                    }
                                  </div>
                                </div>
                              </div>

                              <div className="row-form">
                                <div className="mf-6">
                                  <label>
                                    Client<span className="redlbl"> *</span>
                                  </label>
                                  <div>
                                    <select
                                      style={{
                                        borderColor: this.state.validationModel
                                          .clientValField
                                          ? "red"
                                          : ""
                                      }}
                                      name="clientID"
                                      id="clientID"
                                      value={this.state.userModel.clientID}
                                      onChange={this.handleClientChange}
                                    >
                                      {this.state.clientID.map(s => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                    <div className="textBoxValidate">
                                      {
                                        this.state.validationModel
                                          .clientValField
                                      }
                                    </div>
                                  </div>
                                </div>

                                <div className="mf-6">
                                  <label>
                                    Primary Practice{" "}
                                    <span className="redlbl"> *</span>
                                  </label>
                                  <div>
                                    <select
                                      style={{
                                        borderColor: this.state.validationModel
                                          .practiceValField
                                          ? "red"
                                          : ""
                                      }}
                                      name="practiceID"
                                      id="practiceID"
                                      value={this.state.userModel.practiceID}
                                      onChange={this.handleChange}
                                    >
                                      {this.state.clientPractices.map(s => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                    <div className="textBoxValidate">
                                      {" "}
                                      {
                                        this.state.validationModel
                                          .practiceValField
                                      }
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="row-form">
                                <div className="mf-6">
                                  <label>Team </label>
                                  <div>
                                    <select
                                      name="teamID"
                                      id="teamID"
                                      value={this.state.userModel.teamID}
                                      onChange={this.handleChange}
                                    >
                                      {this.state.teams.map(s => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>
                                <div className="mf-6">
                                  <label>
                                    Role <span className="redlbl"> *</span>
                                  </label>
                                  <div>
                                    <select
                                      style={{
                                        borderColor: this.state.validationModel
                                          .roleValField
                                          ? "red"
                                          : ""
                                      }}
                                      disabled={
                                        this.state.email &&
                                        this.state.userModel.userRole ==
                                          this.props.userInfo.userRole
                                          ? true
                                          : false
                                      }
                                      name="userRole"
                                      id="userRole"
                                      value={this.state.userModel.userRole}
                                      onChange={this.handleChange}
                                    >
                                      {this.state.userRole.map(s => (
                                        <option key={s} value={s}>
                                          {s}
                                        </option>
                                      ))}
                                    </select>
                                    <div className="textBoxValidate">
                                      {" "}
                                      {this.state.validationModel.roleValField}
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="row-form">
                                <div className="mf-6">
                                  <label>Designation</label>
                                  <div>
                                    <select
                                      name="designationID"
                                      id="designationID"
                                      value={this.state.userModel.designationID}
                                      onChange={this.handleChange}
                                    >
                                      {this.state.designations.map(s => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>

                                {this.state.reportingToDropdown == true ? (
                                  <div className="mf-6">
                                    <label>Reporting To</label>
                                    <div>
                                      <select
                                        // style={{borderColor : this.state.validationModel.roleValField ? "red" : ""}}
                                        name="reportingTo"
                                        id="reportingTo"
                                        value={this.state.userModel.reportingTo}
                                        onChange={this.handleChange}
                                      >
                                        {this.state.reportingToArr.map(
                                          (s, i) => (
                                            <option key={i} value={s.email}>
                                              {s.name}
                                            </option>
                                          )
                                        )}
                                      </select>
                                      <div className="textBoxValidate">
                                        {" "}
                                        {
                                          this.state.validationModel
                                            .reportingToValField
                                        }
                                      </div>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="mf-6"></div>
                                )}
                              </div>

                              <div className="row-form">
                                <div className="mf-6">
                                  <label>
                                    {" "}
                                    Email <span className="redlbl"> *</span>
                                  </label>
                                  <div className="textBoxValidate">
                                    <Input
                                      disabled={
                                        this.state.id > 0 ? "disable" : ""
                                      }
                                      className={
                                        this.state.validationModel.emailValField
                                          ? this.errorField
                                          : ""
                                      }
                                      type="text"
                                      value={this.state.userModel.email}
                                      name="email"
                                      id="email"
                                      max="60"
                                      onChange={() => this.handleChange}
                                    />

                                    {this.state.validationModel.emailValField}
                                  </div>
                                </div>
                                <div className="mf-6"></div>
                              </div>

                              <div className="row-form">
                                <div className="mf-6">
                                  <label>
                                    Password <span className="redlbl"> *</span>
                                  </label>
                                  <div className="textBoxValidate">
                                    <input
                                      disabled={
                                        this.state.id > 0 ? "disable" : ""
                                      }
                                      className={
                                        this.state.validationModel
                                          .passwordValField
                                          ? this.errorField
                                          : ""
                                      }
                                      type="password"
                                      value={this.state.userModel.password}
                                      name="password"
                                      id="password"
                                      max="15"
                                      onChange={this.handleChange}
                                    />
                                    {/* <p>Password should contains atleast 1 Capital and 1 Small letter , 1 Number and 1 Symbol and atleast 5 characters long</p> */}
                                    <p>
                                      Enter combination of at least 5
                                      letters,numbers and symbols
                                    </p>

                                    {
                                      this.state.validationModel
                                        .passwordValField
                                    }
                                  </div>
                                </div>

                                <div className="mf-6">
                                  <label>
                                    Confirm Password{" "}
                                    <span className="redlbl"> *</span>
                                  </label>
                                  <div className="textBoxValidate">
                                    <input
                                      disabled={
                                        this.state.id > 0 ? "disable" : ""
                                      }
                                      className={
                                        this.state.validationModel
                                          .cnfrmPassValField
                                          ? this.errorField
                                          : ""
                                      }
                                      type="password"
                                      value={this.state.userModel.cnfrmPass}
                                      name="cnfrmPass"
                                      id="cnfrmPass"
                                      max="15"
                                      onChange={this.handleChange}
                                    />
                                    {
                                      this.state.validationModel
                                        .cnfrmPassValField
                                    }
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="modal-footer">
                              <div className="mainTable">
                                <div className="row-form row-btn">
                                  <div className="mf-12">
                                    <input
                                      type="button"
                                      value="Save"
                                      className="btn-blue"
                                      onClick={this.saveUser}
                                      disabled={this.isDisabled(
                                        this.state.editId > 0
                                          ? this.props.rights.update
                                          : this.props.rights.add
                                      )}
                                    ></input>

                                    <input
                                      type="button"
                                      value="Cancel"
                                      className="btn-grey"
                                      onClick={
                                        this.props.onClose
                                          ? this.props.onClose()
                                          : () => this.props.onClose()
                                      }
                                    ></input>

                                    {/* <button
                                      id="btnCancel"
                                      className="btn-grey"
                                      data-dismiss="modal"
                                      onClick={
                                        this.props.onClose
                                          ? this.props.onClose()
                                          : () => this.props.onClose()
                                      }
                                    >
                                      Cancel
                                    </button> */}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </Tab>
                        <Tab>
                          <div style={{ marginTop: "5px" }}>
                            <div className="mainTable">
                              <div className="row-form">
                                <div className="mf-4">
                                  <label>
                                    Client<span className="redlbl"> *</span>
                                  </label>
                                  <div>
                                    <select
                                      style={{
                                        borderColor: this.state.validationModel
                                          .userClientValField
                                          ? "red"
                                          : ""
                                      }}
                                      name="clientID"
                                      id="clientID"
                                      value={
                                        this.state.userPracticesModel.clientID
                                      }
                                      onChange={
                                        this.handleUserPracticeClientChange
                                      }
                                    >
                                      {this.state.clientID.map(s => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                    <div className="textBoxValidate">
                                      {
                                        this.state.validationModel
                                          .userClientValField
                                      }
                                    </div>
                                  </div>
                                </div>
                                <div className="mf-5">
                                  <label>
                                    Practice<span className="redlbl"> *</span>
                                  </label>
                                  <div>
                                    <select
                                      style={{
                                        borderColor: this.state.validationModel
                                          .userPracticeValField
                                          ? "red"
                                          : ""
                                      }}
                                      name="practiceID"
                                      id="practiceID"
                                      value={
                                        this.state.userPracticesModel.practiceID
                                      }
                                      onChange={this.handlePracticeChange}
                                    >
                                      {this.state.clientPractices.map(s => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                    <div className="textBoxValidate">
                                      {" "}
                                      {
                                        this.state.validationModel
                                          .userPracticeValField
                                      }
                                    </div>
                                  </div>
                                </div>
                                <div className="mf-1">
                                  <div>
                                    <button
                                      className="btn-blue"
                                      style={{
                                        marginLeft: "20px",
                                        marginTop: "0px",
                                        width: "120px"
                                      }}
                                      onClick={this.addPracticeRow}
                                    >
                                      Add +{" "}
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="mf-12 table-grid mt-15">
                              {/* <GridHeading Heading='USER SEARCH RESULT'></GridHeading> */}

                              <div className="tableGridContainer">
                                <MDBDataTable
                                  responsive={true}
                                  striped
                                  bordered
                                  searching={false}
                                  data={data}
                                  displayEntries={false}
                                  sortable={true}
                                  scrollX={false}
                                  scrollY={false}
                                />
                              </div>
                            </div>

                            <div className="row-form">
                              <div className="mf-4"></div>
                              <div className="mf-4">
                                <div style={{ marginTop: "50px" }}>
                                  <input
                                    type="button"
                                    value="Save"
                                    className="btn-blue"
                                    onClick={this.savePractices}
                                    disabled={this.isDisabled(
                                      this.state.editId > 0
                                        ? this.props.rights.update
                                        : this.props.rights.add
                                    )}
                                  ></input>
                                  <input
                                    type="button"
                                    value="Cancel"
                                    className="btn-grey"
                                    onClick={
                                      this.props.onClose
                                        ? this.props.onClose()
                                        : () => this.props.onClose()
                                    }
                                  ></input>

                                  {/* <button
                                    id="btnCancel"
                                    className="btn-grey"
                                    data-dismiss="modal"
                                    onClick={
                                      this.props.onClose
                                        ? this.props.onClose()
                                        : () => this.props.onClose()
                                    }
                                  >
                                    Cancel
                                  </button> */}
                                </div>
                              </div>
                              <div className="mf-4"></div>
                            </div>
                          </div>
                        </Tab>
                        <Tab>
                          {/* Define User Rights */}
                          <div className="mainHeading row">
                            <div className="col-md-8">
                              <h1>USER RIGHTS</h1>
                            </div>
                            <div className="col-md-4 headingRight">
                              <div className="textBoxValidate">
                                <div className="lblChkBox">
                                  <input
                                    type="checkbox"
                                    id="loadDefualtRights"
                                    name="loadDefualtRights"
                                    checked={this.state.isChecked}
                                    onClick={this.handleDefultCheckbox}
                                  />
                                  <label
                                    className="wAuto"
                                    for="loadDefualtRights"
                                  >
                                    <span>Load Default Rights</span>
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="mf-12 batchContainer bdr-clr-ligthblue ">
                            <div className="mf-12 bg-lightblue">
                              <h2 onClick={event => this.showHide(0)}>Setup</h2>
                            </div>
                            <MDBCollapse
                              id={0}
                              isOpen={this.state.collapseMenu}
                            >
                              <div
                                className="row-form bg-white"
                                style={{ margin: "0" }}
                              >
                                <div className="mf-12 bdr-right-none pb-10">
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="practiceSearch"
                                            name="practiceSearch"
                                            checked={
                                              this.state.userRights
                                                .practiceSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="practiceSearch"
                                          >
                                            <span>Search Practices</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="practiceCreate"
                                            name="practiceCreate"
                                            checked={
                                              this.state.userRights
                                                .practiceCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="practiceCreate"
                                          >
                                            <span>Add Practices</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="practiceEdit"
                                            name="practiceEdit"
                                            checked={
                                              this.state.userRights.practiceEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="practiceEdit"
                                          >
                                            <span>Update Practices</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="practiceExport"
                                            name="practiceExport"
                                            checked={
                                              this.state.userRights
                                                .practiceExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="practiceExport"
                                          >
                                            <span>Export Practices</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="locationSearch"
                                            name="locationSearch"
                                            checked={
                                              this.state.userRights
                                                .locationSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="locationSearch"
                                          >
                                            <span>Search Locations</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="locationCreate"
                                            name="locationCreate"
                                            checked={
                                              this.state.userRights
                                                .locationCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="locationCreate"
                                          >
                                            <span>Add Locations</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="locationEdit"
                                            name="locationEdit"
                                            checked={
                                              this.state.userRights.locationEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="locationEdit"
                                          >
                                            <span>Update Locations</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="locationExport"
                                            name="locationExport"
                                            checked={
                                              this.state.userRights
                                                .locationExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="locationExport"
                                          >
                                            <span>Export Locations</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="providerSearch"
                                            name="providerSearch"
                                            checked={
                                              this.state.userRights
                                                .providerSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="providerSearch"
                                          >
                                            <span>Search Provider</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="providerCreate"
                                            name="providerCreate"
                                            checked={
                                              this.state.userRights
                                                .providerCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="providerCreate"
                                          >
                                            <span>Add Provider</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="providerEdit"
                                            name="providerEdit"
                                            checked={
                                              this.state.userRights.providerEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="providerEdit"
                                          >
                                            <span>Update Provider</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="providerExport"
                                            name="providerExport"
                                            checked={
                                              this.state.userRights
                                                .providerExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="providerExport"
                                          >
                                            <span>Export Provider</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="referringProviderSearch"
                                            name="referringProviderSearch"
                                            checked={
                                              this.state.userRights
                                                .referringProviderSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="referringProviderSearch"
                                          >
                                            <span>Search Ref. Pro.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="referringProviderCreate"
                                            name="referringProviderCreate"
                                            checked={
                                              this.state.userRights
                                                .referringProviderCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="referringProviderCreate"
                                          >
                                            <span>Add Ref. Pro.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="referringProviderEdit"
                                            name="referringProviderEdit"
                                            checked={
                                              this.state.userRights
                                                .referringProviderEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="referringProviderEdit"
                                          >
                                            <span>Update Ref. Pro.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="referringProviderExport"
                                            name="referringProviderExport"
                                            checked={
                                              this.state.userRights
                                                .referringProviderExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="referringProviderExport"
                                          >
                                            <span>Export Ref. Pro.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insuranceSearch"
                                            name="insuranceSearch"
                                            checked={
                                              this.state.userRights
                                                .insuranceSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insuranceSearch"
                                          >
                                            <span>Search Insurance </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insuranceCreate"
                                            name="insuranceCreate"
                                            checked={
                                              this.state.userRights
                                                .insuranceCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insuranceCreate"
                                          >
                                            <span>Add Insurance</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insuranceEdit"
                                            name="insuranceEdit"
                                            checked={
                                              this.state.userRights
                                                .insuranceEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insuranceEdit"
                                          >
                                            <span>Update Insurance</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insuranceExport"
                                            name="insuranceExport"
                                            checked={
                                              this.state.userRights
                                                .insuranceExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insuranceExport"
                                          >
                                            <span>Export Insurance</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insurancePlanSearch"
                                            name="insurancePlanSearch"
                                            checked={
                                              this.state.userRights
                                                .insurancePlanSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insurancePlanSearch"
                                          >
                                            <span>Search Ins. Plan. </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insurancePlanCreate"
                                            name="insurancePlanCreate"
                                            checked={
                                              this.state.userRights
                                                .insurancePlanCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insurancePlanCreate"
                                          >
                                            <span>Add Ins. Plan.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insurancePlanEdit"
                                            name="insurancePlanEdit"
                                            checked={
                                              this.state.userRights
                                                .insurancePlanEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insurancePlanEdit"
                                          >
                                            <span>Update Ins. Plan.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insurancePlanExport"
                                            name="insurancePlanExport"
                                            checked={
                                              this.state.userRights
                                                .insurancePlanExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insurancePlanExport"
                                          >
                                            <span>Export Ins. Plan.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insurancePlanAddressSearch"
                                            name="insurancePlanAddressSearch"
                                            checked={
                                              this.state.userRights
                                                .insurancePlanAddressSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insurancePlanAddressSearch"
                                          >
                                            <span>Search Plan. Add. </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insurancePlanAddressCreate"
                                            name="insurancePlanAddressCreate"
                                            checked={
                                              this.state.userRights
                                                .insurancePlanAddressCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insurancePlanAddressCreate"
                                          >
                                            <span>Add Plan. Add.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insurancePlanAddressEdit"
                                            name="insurancePlanAddressEdit"
                                            checked={
                                              this.state.userRights
                                                .insurancePlanAddressEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insurancePlanAddressEdit"
                                          >
                                            <span>Update Plan. Add.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="insurancePlanAddressExport"
                                            name="insurancePlanAddressExport"
                                            checked={
                                              this.state.userRights
                                                .insurancePlanAddressExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="insurancePlanAddressExport"
                                          >
                                            <span>Export Plan. Add.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediSubmitSearch"
                                            name="ediSubmitSearch"
                                            checked={
                                              this.state.userRights
                                                .ediSubmitSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediSubmitSearch"
                                          >
                                            <span>Search Sub. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediSubmitCreate"
                                            name="ediSubmitCreate"
                                            checked={
                                              this.state.userRights
                                                .ediSubmitCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediSubmitCreate"
                                          >
                                            <span>Add Sub. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediSubmitEdit"
                                            name="ediSubmitEdit"
                                            checked={
                                              this.state.userRights
                                                .ediSubmitEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediSubmitEdit"
                                          >
                                            <span>Update Sub. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediSubmitExport"
                                            name="ediSubmitExport"
                                            checked={
                                              this.state.userRights
                                                .ediSubmitExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediSubmitExport"
                                          >
                                            <span>Export Sub. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediEligiBilitySearch"
                                            name="ediEligiBilitySearch"
                                            checked={
                                              this.state.userRights
                                                .ediEligiBilitySearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediEligiBilitySearch"
                                          >
                                            <span>Search Elig. Pay. </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediEligiBilityCreate"
                                            name="ediEligiBilityCreate"
                                            checked={
                                              this.state.userRights
                                                .ediEligiBilityCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediEligiBilityCreate"
                                          >
                                            <span>Add Elig. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediEligiBilityEdit"
                                            name="ediEligiBilityEdit"
                                            checked={
                                              this.state.userRights
                                                .ediEligiBilityEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediEligiBilityEdit"
                                          >
                                            <span>Update Elig. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediEligiBilityExport"
                                            name="ediEligiBilityExport"
                                            checked={
                                              this.state.userRights
                                                .ediEligiBilityExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediEligiBilityExport"
                                          >
                                            <span>Export Elig. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediStatusSearch"
                                            name="ediStatusSearch"
                                            checked={
                                              this.state.userRights
                                                .ediStatusSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediStatusSearch"
                                          >
                                            <span>Search Status Pay. </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediStatusCreate"
                                            name="ediStatusCreate"
                                            checked={
                                              this.state.userRights
                                                .ediStatusCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediStatusCreate"
                                          >
                                            <span>Add Status Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediStatusEdit"
                                            name="ediStatusEdit"
                                            checked={
                                              this.state.userRights
                                                .ediStatusEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediStatusEdit"
                                          >
                                            <span>Update Status Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="ediStatusExport"
                                            name="ediStatusExport"
                                            checked={
                                              this.state.userRights
                                                .ediStatusExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="ediStatusExport"
                                          >
                                            <span>Export Status Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="icdSearch"
                                            name="icdSearch"
                                            checked={
                                              this.state.userRights.icdSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="icdSearch"
                                          >
                                            <span>Search ICD </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="icdCreate"
                                            name="icdCreate"
                                            checked={
                                              this.state.userRights.icdCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="icdCreate"
                                          >
                                            <span>Add ICD </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="icdEdit"
                                            name="icdEdit"
                                            checked={
                                              this.state.userRights.icdEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="icdEdit"
                                          >
                                            <span>Update ICD</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="icdExport"
                                            name="icdExport"
                                            checked={
                                              this.state.userRights.icdExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="icdExport"
                                          >
                                            <span>Export ICD</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="cptSearch"
                                            name="cptSearch"
                                            checked={
                                              this.state.userRights.cptSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="cptSearch"
                                          >
                                            <span>Search CPT </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="cptCreate"
                                            name="cptCreate"
                                            checked={
                                              this.state.userRights.cptCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="cptCreate"
                                          >
                                            <span>Add CPT </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="cptEdit"
                                            name="cptEdit"
                                            checked={
                                              this.state.userRights.cptEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="cptEdit"
                                          >
                                            <span>Update CPT</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="cptExport"
                                            name="cptExport"
                                            checked={
                                              this.state.userRights.cptExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="cptExport"
                                          >
                                            <span>Export CPT</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="modifiersSearch"
                                            name="modifiersSearch"
                                            checked={
                                              this.state.userRights
                                                .modifiersSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="modifiersSearch"
                                          >
                                            <span>Search Modifiers </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="modifiersCreate"
                                            name="modifiersCreate"
                                            checked={
                                              this.state.userRights
                                                .modifiersCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="modifiersCreate"
                                          >
                                            <span>Add Modifiers </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="modifiersEdit"
                                            name="modifiersEdit"
                                            checked={
                                              this.state.userRights
                                                .modifiersEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="modifiersEdit"
                                          >
                                            <span>Update Modifiers</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="modifiersExport"
                                            name="modifiersExport"
                                            checked={
                                              this.state.userRights
                                                .modifiersExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="modifiersExport"
                                          >
                                            <span>Export Modifiers</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="posSearch"
                                            name="posSearch"
                                            checked={
                                              this.state.userRights.posSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="posSearch"
                                          >
                                            <span>Search POS </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="posCreate"
                                            name="posCreate"
                                            checked={
                                              this.state.userRights.posCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="posCreate"
                                          >
                                            <span>Add POS </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="posEdit"
                                            name="posEdit"
                                            checked={
                                              this.state.userRights.posEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="posEdit"
                                          >
                                            <span>Update POS</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="posExport"
                                            name="posExport"
                                            checked={
                                              this.state.userRights.posExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="posExport"
                                          >
                                            <span>Export POS</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="claimStatusCategoryCodesSearch"
                                            name="claimStatusCategoryCodesSearch"
                                            checked={
                                              this.state.userRights
                                                .claimStatusCategoryCodesSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="claimStatusCategoryCodesSearch"
                                          >
                                            <span>Search CS Cat. Code </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="claimStatusCategoryCodesCreate"
                                            name="claimStatusCategoryCodesCreate"
                                            checked={
                                              this.state.userRights
                                                .claimStatusCategoryCodesCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="claimStatusCategoryCodesCreate"
                                          >
                                            <span>Add CS Cat. Code </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="claimStatusCategoryCodesEdit"
                                            name="claimStatusCategoryCodesEdit"
                                            checked={
                                              this.state.userRights
                                                .claimStatusCategoryCodesEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="claimStatusCategoryCodesEdit"
                                          >
                                            <span>Update CS Cat. Code</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="claimStatusCategoryCodesExport"
                                            name="claimStatusCategoryCodesExport"
                                            checked={
                                              this.state.userRights
                                                .claimStatusCategoryCodesExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="claimStatusCategoryCodesExport"
                                          >
                                            <span>Export CS Cat. Code</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="claimStatusCodesSearch"
                                            name="claimStatusCodesSearch"
                                            checked={
                                              this.state.userRights
                                                .claimStatusCodesSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="claimStatusCodesSearch"
                                          >
                                            <span>Search CS Code </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="claimStatusCodesCreate"
                                            name="claimStatusCodesCreate"
                                            checked={
                                              this.state.userRights
                                                .claimStatusCodesCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="claimStatusCodesCreate"
                                          >
                                            <span>Add CS Code </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="claimStatusCodesEdit"
                                            name="claimStatusCodesEdit"
                                            checked={
                                              this.state.userRights
                                                .claimStatusCodesEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="claimStatusCodesEdit"
                                          >
                                            <span>Update CS Code</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="claimStatusCodesExport"
                                            name="claimStatusCodesExport"
                                            checked={
                                              this.state.userRights
                                                .claimStatusCodesExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="claimStatusCodesExport"
                                          >
                                            <span>Export CS Code</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="adjustmentCodesSearch"
                                            name="adjustmentCodesSearch"
                                            checked={
                                              this.state.userRights
                                                .adjustmentCodesSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="adjustmentCodesSearch"
                                          >
                                            <span>Search Adj. Codes </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="adjustmentCodesCreate"
                                            name="adjustmentCodesCreate"
                                            checked={
                                              this.state.userRights
                                                .adjustmentCodesCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="adjustmentCodesCreate"
                                          >
                                            <span>Add Adj. Codes </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="adjustmentCodesEdit"
                                            name="adjustmentCodesEdit"
                                            checked={
                                              this.state.userRights
                                                .adjustmentCodesEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="adjustmentCodesEdit"
                                          >
                                            <span>Update Adj. Codes</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="adjustmentCodesExport"
                                            name="adjustmentCodesExport"
                                            checked={
                                              this.state.userRights
                                                .adjustmentCodesExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="adjustmentCodesExport"
                                          >
                                            <span>Export Adj. Codes</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="remarkCodesSearch"
                                            name="remarkCodesSearch"
                                            checked={
                                              this.state.userRights
                                                .remarkCodesSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="remarkCodesSearch"
                                          >
                                            <span>Search Remark Codes </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="remarkCodesCreate"
                                            name="remarkCodesCreate"
                                            checked={
                                              this.state.userRights
                                                .remarkCodesCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="remarkCodesCreate"
                                          >
                                            <span>Add Remark Codes </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="remarkCodesEdit"
                                            name="remarkCodesEdit"
                                            checked={
                                              this.state.userRights
                                                .remarkCodesEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="remarkCodesEdit"
                                          >
                                            <span>Update Remark Codes</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="remarkCodesExport"
                                            name="remarkCodesExport"
                                            checked={
                                              this.state.userRights
                                                .remarkCodesExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="remarkCodesExport"
                                          >
                                            <span>Export Remark Codes</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="userSearch"
                                            name="userSearch"
                                            checked={
                                              this.state.userRights.userSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="userSearch"
                                          >
                                            <span>Search User </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="userCreate"
                                            name="userCreate"
                                            checked={
                                              this.state.userRights.userCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="userCreate"
                                          >
                                            <span>Add User </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="userEdit"
                                            name="userEdit"
                                            checked={
                                              this.state.userRights.userEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="userEdit"
                                          >
                                            <span>Update User</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="userExport"
                                            name="userExport"
                                            checked={
                                              this.state.userRights.userExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="userExport"
                                          >
                                            <span>Export User</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="clientSearch"
                                            name="clientSearch"
                                            checked={
                                              this.state.userRights.clientSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="clientSearch"
                                          >
                                            <span>Search Client </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="clientCreate"
                                            name="clientCreate"
                                            checked={
                                              this.state.userRights.clientCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="clientCreate"
                                          >
                                            <span>Add Client </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="clientEdit"
                                            name="clientEdit"
                                            checked={
                                              this.state.userRights.clientEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="clientEdit"
                                          >
                                            <span>Update Client</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="clientExport"
                                            name="clientExport"
                                            checked={
                                              this.state.userRights.clientExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="clientExport"
                                          >
                                            <span>Export Client</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="teamSearch"
                                            name="teamSearch"
                                            checked={
                                              this.state.userRights.teamSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="teamSearch"
                                          >
                                            <span>Search Team </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="teamCreate"
                                            name="teamCreate"
                                            checked={
                                              this.state.userRights.teamCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="teamCreate"
                                          >
                                            <span>Add Team </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="teamupdate"
                                            name="teamupdate"
                                            checked={
                                              this.state.userRights.teamupdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="teamupdate"
                                          >
                                            <span>Update Team</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="teamExport"
                                            name="teamExport"
                                            checked={
                                              this.state.userRights.teamExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="teamExport"
                                          >
                                            <span>Export Team</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="receiverSearch"
                                            name="receiverSearch"
                                            checked={
                                              this.state.userRights
                                                .receiverSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="receiverSearch"
                                          >
                                            <span>Search Receiver </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="receiverCreate"
                                            name="receiverCreate"
                                            checked={
                                              this.state.userRights
                                                .receiverCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="receiverCreate"
                                          >
                                            <span>Add Receiver </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="receiverupdate"
                                            name="receiverupdate"
                                            checked={
                                              this.state.userRights
                                                .receiverupdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="receiverupdate"
                                          >
                                            <span>Update Receiver</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="receiverExport"
                                            name="receiverExport"
                                            checked={
                                              this.state.userRights
                                                .receiverExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="receiverExport"
                                          >
                                            <span>Export Receiver</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="submitterSearch"
                                            name="submitterSearch"
                                            checked={
                                              this.state.userRights
                                                .submitterSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="submitterSearch"
                                          >
                                            <span>Search Submitter </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="submitterCreate"
                                            name="submitterCreate"
                                            checked={
                                              this.state.userRights
                                                .submitterCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="submitterCreate"
                                          >
                                            <span>Add Submitter </span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="submitterUpdate"
                                            name="submitterUpdate"
                                            checked={
                                              this.state.userRights
                                                .submitterUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="submitterUpdate"
                                          >
                                            <span>Update Submitter</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="submitterExport"
                                            name="submitterExport"
                                            checked={
                                              this.state.userRights
                                                .submitterExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="submitterExport"
                                          >
                                            <span>Export Submitter</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </MDBCollapse>
                          </div>
                          <div className="mf-12 batchContainer bdr-clr-ligthblue mt-25">
                            <div className="mf-12 bg-lightblue">
                              <h2 onClick={event => this.showHide(1)}>
                                Patient
                              </h2>
                            </div>
                            <MDBCollapse
                              id={1}
                              isOpen={this.state.collapseMenu}
                            >
                              <div
                                className="row-form bg-white"
                                style={{ margin: "0" }}
                              >
                                <div className="mf-12 bdr-right-none pb-10">
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientSearch"
                                            name="patientSearch"
                                            checked={
                                              this.state.userRights
                                                .patientSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientSearch"
                                          >
                                            <span>Search Patients</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientCreate"
                                            name="patientCreate"
                                            checked={
                                              this.state.userRights
                                                .patientCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientCreate"
                                          >
                                            <span>Add Patient</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientEdit"
                                            name="patientEdit"
                                            checked={
                                              this.state.userRights.patientEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientEdit"
                                          >
                                            <span>Update Patient</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientExport"
                                            name="patientExport"
                                            checked={
                                              this.state.userRights
                                                .patientExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientExport"
                                          >
                                            <span>Export Patient</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientPlanSearch"
                                            name="patientPlanSearch"
                                            checked={
                                              this.state.userRights
                                                .patientPlanSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientPlanSearch"
                                          >
                                            <span>Search Pat. Plan</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientPlanCreate"
                                            name="patientPlanCreate"
                                            checked={
                                              this.state.userRights
                                                .patientPlanCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientPlanCreate"
                                          >
                                            <span>Add Pat. Plan</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientPlanUpdate"
                                            name="patientPlanUpdate"
                                            checked={
                                              this.state.userRights
                                                .patientPlanUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientPlanUpdate"
                                          >
                                            <span>Update Pat. Plan</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientPlanExport"
                                            name="patientPlanExport"
                                            checked={
                                              this.state.userRights
                                                .patientPlanExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientPlanExport"
                                          >
                                            <span>Export Pat. Plan</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientPaymentSearch"
                                            name="patientPaymentSearch"
                                            checked={
                                              this.state.userRights
                                                .patientPaymentSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientPaymentSearch"
                                          >
                                            <span>Search Pat. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientPaymentCreate"
                                            name="patientPaymentCreate"
                                            checked={
                                              this.state.userRights
                                                .patientPaymentCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientPaymentCreate"
                                          >
                                            <span>Add Pat. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientPaymentUpdate"
                                            name="patientPaymentUpdate"
                                            checked={
                                              this.state.userRights
                                                .patientPaymentUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientPaymentUpdate"
                                          >
                                            <span>Update Pat. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientPaymentExport"
                                            name="patientPaymentExport"
                                            checked={
                                              this.state.userRights
                                                .patientPaymentExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientPaymentExport"
                                          >
                                            <span>Export Pat. Pay.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="batchdocumentSearch"
                                            name="batchdocumentSearch"
                                            checked={
                                              this.state.userRights
                                                .batchdocumentSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="batchdocumentSearch"
                                          >
                                            <span>Search Batch Doc</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="batchdocumentCreate"
                                            name="batchdocumentCreate"
                                            checked={
                                              this.state.userRights
                                                .batchdocumentCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="batchdocumentCreate"
                                          >
                                            <span>Add Batch Doc</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="batchdocumentUpdate"
                                            name="batchdocumentUpdate"
                                            checked={
                                              this.state.userRights
                                                .batchdocumentUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="batchdocumentUpdate"
                                          >
                                            <span>Update Batch Doc</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="batchdocumentExport"
                                            name="batchdocumentExport"
                                            checked={
                                              this.state.userRights
                                                .batchdocumentExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="batchdocumentExport"
                                          >
                                            <span>Export Batch Doc</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="postcheck"
                                            name="postcheck"
                                            checked={
                                              this.state.userRights.postcheck
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="postcheck"
                                          >
                                            <span>Post Check</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="postCheckSearch"
                                            name="postCheckSearch"
                                            checked={
                                              this.state.userRights
                                                .postCheckSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="postCheckSearch"
                                          >
                                            <span>Search Post Check</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="manualPostingAdd"
                                            name="manualPostingAdd"
                                            checked={
                                              this.state.userRights
                                                .manualPostingAdd
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="manualPostingAdd"
                                          >
                                            <span>Add Manual Posting</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="manualPostingUpdate"
                                            name="manualPostingUpdate"
                                            checked={
                                              this.state.userRights
                                                .manualPostingUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="manualPostingUpdate"
                                          >
                                            <span>Update Manual Posting</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="addPaymentVisit"
                                            name="addPaymentVisit"
                                            checked={
                                              this.state.userRights
                                                .addPaymentVisit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="addPaymentVisit"
                                          >
                                            <span>Add Payment Visit</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                  </div>
                                </div>
                              </div>
                            </MDBCollapse>
                          </div>
                          <div className="mf-12 batchContainer bdr-clr-ligthblue mt-25">
                            <div className="mf-12 bg-lightblue">
                              <h2 onClick={event => this.showHide(2)}>
                                Charges
                              </h2>
                            </div>
                            <MDBCollapse
                              id={2}
                              isOpen={this.state.collapseMenu}
                            >
                              <div
                                className="row-form bg-white"
                                style={{ margin: "0" }}
                              >
                                <div className="mf-12 bdr-right-none pb-10">
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="chargesSearch"
                                            name="chargesSearch"
                                            checked={
                                              this.state.userRights
                                                .chargesSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="chargesSearch"
                                          >
                                            <span>Search Charges</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="chargesCreate"
                                            name="chargesCreate"
                                            checked={
                                              this.state.userRights
                                                .chargesCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="chargesCreate"
                                          >
                                            <span>Add Charges</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="chargesEdit"
                                            name="chargesEdit"
                                            checked={
                                              this.state.userRights.chargesEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="chargesEdit"
                                          >
                                            <span>Update Charges</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="chargesExport"
                                            name="chargesExport"
                                            checked={
                                              this.state.userRights
                                                .chargesExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="chargesExport"
                                          >
                                            <span>Export Charges</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="resubmitCharges"
                                            name="resubmitCharges"
                                            checked={
                                              this.state.userRights
                                                .resubmitCharges
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="resubmitCharges"
                                          >
                                            <span>Re-Submit Charges</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20"></div>

                                    <div className="mf-3 pl-20">&nbsp;</div>
                                    <div className="mf-3 pl-20">&nbsp;</div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="viewHcfa"
                                            name=""
                                          />
                                          <label
                                            className="wAuto"
                                            for="viewHcfa"
                                          >
                                            <span>View HCFA</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="viewLedgers"
                                            name=""
                                          />
                                          <label
                                            className="wAuto"
                                            for="viewLedgers"
                                          >
                                            <span>View Ledgers</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">&nbsp;</div>
                                    <div className="mf-3 pl-20">&nbsp;</div>
                                  </div>
                                </div>
                              </div>
                            </MDBCollapse>
                          </div>
                          <div className="mf-12 batchContainer bdr-clr-ligthblue mt-25">
                            <div className="mf-12 bg-lightblue">
                              <h2 onClick={event => this.showHide(3)}>
                                Followup
                              </h2>
                            </div>
                            <MDBCollapse
                              id={3}
                              isOpen={this.state.collapseMenu}
                            >
                              <div
                                className="row-form bg-white"
                                style={{ margin: "0" }}
                              >
                                <div className="mf-12 bdr-right-none pb-10">
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="planFollowupSearch"
                                            name="planFollowupSearch"
                                            checked={
                                              this.state.userRights
                                                .planFollowupSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="planFollowupSearch"
                                          >
                                            <span>Search PlanFollowup</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="planFollowupUpdate"
                                            name="planFollowupUpdate"
                                            checked={
                                              this.state.userRights
                                                .planFollowupUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="planFollowupUpdate"
                                          >
                                            <span>Update PlanFollowup</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientFollowupSearch"
                                            name="patientFollowupSearch"
                                            checked={
                                              this.state.userRights
                                                .patientFollowupSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientFollowupSearch"
                                          >
                                            <span>Search PatientFollowup</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="patientFollowupUpdate"
                                            name="patientFollowupUpdate"
                                            checked={
                                              this.state.userRights
                                                .patientFollowupUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="patientFollowupUpdate"
                                          >
                                            <span>Update PatientFollowup</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                  </div>

                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="groupSearch"
                                            name="groupSearch"
                                            checked={
                                              this.state.userRights.groupSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="groupSearch"
                                          >
                                            <span>Search Group</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="groupCreate"
                                            name="groupCreate"
                                            checked={
                                              this.state.userRights.groupCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="groupCreate"
                                          >
                                            <span>Add Group</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="groupUpdate"
                                            name="groupUpdate"
                                            checked={
                                              this.state.userRights.groupUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="groupUpdate"
                                          >
                                            <span>Update Group</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="groupExport"
                                            name="groupExport"
                                            checked={
                                              this.state.userRights.groupExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="groupExport"
                                          >
                                            <span>Export Group</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="reasonSearch"
                                            name="reasonSearch"
                                            checked={
                                              this.state.userRights.reasonSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="reasonSearch"
                                          >
                                            <span>Search Reason</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="reasonCreate"
                                            name="reasonCreate"
                                            checked={
                                              this.state.userRights.reasonCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="reasonCreate"
                                          >
                                            <span>Add Reason</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="reasonUpdate"
                                            name="reasonUpdate"
                                            checked={
                                              this.state.userRights.reasonUpdate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="reasonUpdate"
                                          >
                                            <span>Update Reason</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="reasonExport"
                                            name="reasonExport"
                                            checked={
                                              this.state.userRights.reasonExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="reasonExport"
                                          >
                                            <span>Export Reason</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </MDBCollapse>
                          </div>
                          <div className="mf-12 batchContainer bdr-clr-ligthblue mt-25">
                            <div className="mf-12 bg-lightblue">
                              <h2 onClick={event => this.showHide(4)}>
                                Submissions
                              </h2>
                            </div>
                            <MDBCollapse
                              id={4}
                              isOpen={this.state.collapseMenu}
                            >
                              <div
                                className="row-form bg-white"
                                style={{ margin: "0" }}
                              >
                                <div className="mf-12 bdr-right-none pb-10">
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="electronicsSubmissionSearch"
                                            name="electronicsSubmissionSearch"
                                            checked={
                                              this.state.userRights
                                                .electronicsSubmissionSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="electronicsSubmissionSearch"
                                          >
                                            <span>Search Elec. Sub.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="electronicsSubmissionSubmit"
                                            name="electronicsSubmissionSubmit"
                                            checked={
                                              this.state.userRights
                                                .electronicsSubmissionSubmit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="electronicsSubmissionSubmit"
                                          >
                                            <span>Submit Elec. Sub.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="paperSubmissionSearch"
                                            name="paperSubmissionSearch"
                                            checked={
                                              this.state.userRights
                                                .paperSubmissionSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="paperSubmissionSearch"
                                          >
                                            <span>Search Paper Sub.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="paperSubmissionSubmit"
                                            name="paperSubmissionSubmit"
                                            checked={
                                              this.state.userRights
                                                .paperSubmissionSubmit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="paperSubmissionSubmit"
                                          >
                                            <span>Submit Paper Sub.</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                  </div>
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="submissionLogSearch"
                                            name="submissionLogSearch"
                                            checked={
                                              this.state.userRights
                                                .submissionLogSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="submissionLogSearch"
                                          >
                                            <span>Search SubmissionsLog</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                    <div className="mf-3 pl-20"></div>
                                  </div>
                                </div>
                              </div>
                            </MDBCollapse>
                          </div>
                          <div className="mf-12 batchContainer bdr-clr-ligthblue mt-25">
                            <div className="mf-12 bg-lightblue">
                              <h2 onClick={event => this.showHide(5)}>
                                Reports
                              </h2>
                            </div>
                            <MDBCollapse
                              id={5}
                              isOpen={this.state.collapseMenu}
                            >
                              <div
                                className="row-form bg-white"
                                style={{ margin: "0" }}
                              >
                                <div className="mf-12 bdr-right-none pb-10">
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="reportsSearch"
                                            name="reportsSearch"
                                            checked={
                                              this.state.userRights
                                                .reportsSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="reportsSearch"
                                          >
                                            <span>Search Reports</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="reportsCreate"
                                            name="reportsCreate"
                                            checked={
                                              this.state.userRights
                                                .reportsCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="reportsCreate"
                                          >
                                            <span>Add Reports</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="reportsEdit"
                                            name="reportsEdit"
                                            checked={
                                              this.state.userRights.reportsEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="reportsEdit"
                                          >
                                            <span>Update Reports</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="reportsExport"
                                            name="reportsExport"
                                            checked={
                                              this.state.userRights
                                                .reportsExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="reportsExport"
                                          >
                                            <span>Export Reports</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </MDBCollapse>
                          </div>
                          <div className="mf-12 batchContainer bdr-clr-ligthblue mt-25">
                            <div className="mf-12 bg-lightblue">
                              <h2 onClick={event => this.showHide(6)}>
                                Scheduler
                              </h2>
                            </div>
                            <MDBCollapse
                              id={6}
                              isOpen={this.state.collapseMenu}
                            >
                              <div
                                className="row-form bg-white"
                                style={{ margin: "0" }}
                              >
                                <div className="mf-12 bdr-right-none pb-10">
                                  <div className="row-form">
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="schedulerSearch"
                                            name="schedulerSearch"
                                            checked={
                                              this.state.userRights
                                                .schedulerSearch
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="schedulerSearch"
                                          >
                                            <span>Search Scheduler</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="schedulerCreate"
                                            name="schedulerCreate"
                                            checked={
                                              this.state.userRights
                                                .schedulerCreate
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="schedulerCreate"
                                          >
                                            <span>Add Scheduler</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="schedulerEdit"
                                            name="schedulerEdit"
                                            checked={
                                              this.state.userRights
                                                .schedulerEdit
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="schedulerEdit"
                                          >
                                            <span>Update Scheduler</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="mf-3 pl-20">
                                      <div className="textBoxValidate">
                                        <div className="lblChkBox">
                                          <input
                                            type="checkbox"
                                            id="schedulerExport"
                                            name="schedulerExport"
                                            checked={
                                              this.state.userRights
                                                .schedulerExport
                                            }
                                            onClick={this.handleCheckedChange}
                                          />
                                          <label
                                            className="wAuto"
                                            for="schedulerExport"
                                          >
                                            <span>Export Scheduler</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </MDBCollapse>
                          </div>

                          {/* <!-- Modal Footer --> */}
                          <div className="modal-footer">
                            <div className="mainTable">
                              <div className="row-form row-btn">
                                <div className="mf-12">
                                  <Hotkeys
                                    keyName="alt+s"
                                    onKeyDown={this.onKeyDown.bind(this)}
                                    onKeyUp={this.onKeyUp.bind(this)}
                                  >
                                    <input
                                      type="button"
                                      value="Save"
                                      className="btn-blue"
                                      onClick={this.saveUserRights}
                                      disabled={this.isDisabled(
                                        this.state.editId > 0
                                          ? this.props.rights.update
                                          : this.props.rights.add
                                      )}
                                    ></input>
                                  </Hotkeys>

                                  <input
                                    type="button"
                                    value="Cancel"
                                    className="btn-grey"
                                    onClick={
                                      this.props.onClose
                                        ? this.props.onClose()
                                        : () => this.props.onClose()
                                    }
                                  ></input>

                                  {/* <button
                                    id="btnCancel"
                                    className="btn-grey"
                                    data-dismiss="modal"
                                    onClick={
                                      this.props.onClose
                                        ? this.props.onClose()
                                        : () => this.props.onClose()
                                    }
                                  >
                                    Cancel
                                  </button> */}
                                </div>
                              </div>
                            </div>
                          </div>
                        </Tab>
                      </Tabs>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.userSearch,
          add: state.loginInfo.rights.userCreate,
          update: state.loginInfo.rights.userEdit,
          delete: state.loginInfo.rights.userDelete,
          export: state.loginInfo.rights.userExport,
          import: state.loginInfo.rights.userImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewUser);
