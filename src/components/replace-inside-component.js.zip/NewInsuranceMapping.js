import React, { Component } from "react";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

import Label from "./Label";
import Button from "./Input";
import Input from "./Input";
import SearchInput2 from "./SearchInput2";
import Swal from "sweetalert2";
import axios from "axios";
import $ from "jquery";
import Select, { components } from "react-select";
import plusSrc from "../images/plus-icon.png";
import NewInsurancePlan from "./NewInsurancePlan";
import NewInsurancePlanAddress from "./NewInsurancePlanAddress";
//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class NewInsuranceMapping extends Component {
  constructor(props) {
    super(props);

    this.insurancePlanAddressURL =
      process.env.REACT_APP_URL + "/InsurancePlanAddress/";
    this.url = process.env.REACT_APP_URL + "/PatientPlan/";
    this.insurancePlanUrl = process.env.REACT_APP_URL + "/insurancePlan/";
    this.ExInsuranceMapping = process.env.REACT_APP_URL + "/ExInsuranceMapping/"; // Method : SaveExInsuranceMapping

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.loadInsuranceCount = 0;

    this.errorField = "errorField";

    this.validationModel = {
      externalInsuranceNameVal: "",
      insurancePlanIDVal: "",
      validation: false
    };

    //--------Model to be sent
    this.saveModel = {
      id: 0,
      externalInsuranceName: "",
      insurancePlanID: null,
      addedBy: "",
      updatedBy: "",
      planName: ""
    };

    this.insurancePlanAddressModel = {
      insurancePlanId: null,
      insurancePlan: null,
      address1: "",
      address2: "",
      city: "",
      state: "",
      zipCode: "",
      phoneNumber: "",
      faxNumber: null,
      isDeleted: false,
      notes: null
    };

    this.state = {
      id: 0,
      validationModel: this.validationModel,
      saveModel: this.saveModel,
      loading: false,
      maxHeight: "500",
      insurancePlans: [],
      insurancePlanAddresses: [],
      planID: null,
      popupName: "",
      relationShipID: null,
      subscriberID: null,
      insurancePlanID: {},
      insurancePlanAddressModel: this.insurancePlanAddressModel,
      showinsPopup: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.saveInsuranceMapping = this.saveInsuranceMapping.bind(this);
    this.isNull = this.isNull.bind(this);
    this.openInsurancePlanPopup = this.openInsurancePlanPopup.bind(this);
    this.openPopup = this.openPopup.bind(this);
    this.closePopup = this.closePopup.bind(this);
  }

  openPopup = (name, id) => {
    if (name == "insuranceplan") {
      axios
        .get(this.insurancePlanUrl + "findInsurancePlan/" + id, this.config)
        .then(response => {
          this.setState({
            id: id,
            popupName: "insuranceplan"
          });
        })
        .catch(error => {
          console.log(error);
        });
    } else this.setState({ popupName: name, id: id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  async componentDidMount() {
    this.setModalMaxHeight($(".modal"));

    try {
      //get insurance plans from get profiles
      await axios
        .get(this.url + "getprofiles", this.config)
        .then(response => {

          this.setState({ insurancePlans: response.data.insurancePlans });
        })
        .then(error => {
          console.log(error);
        });
    } catch { }
  }

  openInsurancePlanPopup = id => {
    this.setState({ showinsPopup: true, id: id });
  };

  closeInsurancePlanPopup = () => {
    $("#myModal").hide();
    this.setState({ showinsPopup: false });

    try {
      //get insurance plans from get profiles
      axios
        .get(this.url + "getprofiles", this.config)
        .then(response => {

          this.setState({ insurancePlans: response.data.insurancePlans });
        })
        .then(error => {
          console.log(error);
        });
    } catch { }
  };

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  isNull = value => {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  };

  async getInsurancePlanAddress(insurancePlanID, insurancePlanAddressID) {
    await axios
      .get(
        this.insurancePlanAddressURL +
        "GetInsurancePlanAddressesByInsurancePlanID/" +
        insurancePlanID,
        this.config
      )
      .then(response => {

        if (response.data.length > 1) {
          var insurancePlanAddress = response.data.filter(
            option => option.id == insurancePlanAddressID
          );
          this.setState({
            insurancePlanAddresses: response.data,
            insurancePlanAddressModel:
              insurancePlanAddress.length > 0
                ? insurancePlanAddress[0]
                : this.insurancePlanAddressModel
          });

          // SELECTING PLAN's ADDRESS
          //if (this.state.patientPlanModel.insurancePlanAddressID) {
          // this.setState({
          //   ...this.state,
          //   insurancePlanAddressModel: response.data.filter(option => option.id == this.state.patientPlanModel.insurancePlanAddressID)
          // })
          // } else {
          //   this.setState({
          //     ...this.state,
          //     insurancePlanAddressModel: null
          //   })
          // }
        } else if (response.data.length == 1) {
          this.setState({
            insurancePlanAddresses: response.data,
            insurancePlanAddressModel: {
              ...this.state.insurancePlanAddressModel,
              insurancePlanId: null,
              insurancePlan: null,
              address1: "",
              address2: "",
              city: "",
              state: "",
              zipCode: "",
              phoneNumber: "",
              faxNumber: null,
              isDeleted: false,
              notes: null
            }
          });
        } else
          this.setState({
            insurancePlanAddresses: [],
            insurancePlanAddressModel: {
              ...this.state.insurancePlanAddressModel,
              insurancePlanId: null,
              insurancePlan: null,
              address1: "",
              address2: "",
              city: "",
              state: "",
              zipCode: "",
              phoneNumber: "",
              faxNumber: null,
              isDeleted: false,
              notes: null
            }
          });
      })
      .catch(error => {
        console.log(error);
      });
  }

  handleChange = event => {
    //console.log(event.target);
    this.setState({
      saveModel: {
        ...this.state.saveModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  handleInsurancePlansuggChange(event) {

    if (event) {
      this.setState({
        insurancePlanID: event,
        saveModel: {
          ...this.state.saveModel,
          insurancePlanID: event.id,
          planName: event.value
        }
      });
      this.getInsurancePlanAddress(event.id);
    } else {
      // this.setState({
      //   insurancePlanID: null,
      //   saveModel: {
      //     ...this.state.saveModel,
      //     insurancePlanID: null
      //   }
      // });

      this.setState({
        insurancePlanID: null,
        insurancePlanAddresses: [],
        insurancePlanAddressModel: {
          ...this.state.insurancePlanAddressModel,
          insurancePlanId: null,
          insurancePlan: null,
          address1: "",
          address2: "",
          city: "",
          state: "",
          zipCode: "",
          phoneNumber: "",
          faxNumber: null,
          isDeleted: false,
          notes: null
        }
      });
      // this.getInsurancePlanAddress(event.id);
    }
  }

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  saveInsuranceMapping() {
    //---------------------------- VALIDATIONS

    if (this.loadInsuranceCount == 1) {
      return;
    }
    this.loadInsuranceCount = 1;

    this.setState({ loading: true });

    var myVal = this.validationModel;
    myVal.validation = false;

    //---------------------------- EXTERNAL INSURANCE NAME VALIDATION

    if (this.isNull(this.state.saveModel.externalInsuranceName)) {
      myVal.externalInsuranceNameVal = (
        <span className="validationMsg">Enter External Insurance Name</span>
      );
      myVal.validation = true;
    } else {
      myVal.externalInsuranceNameVal = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //---------------------------- INSURANCE PLAN ID VALIDATION

    if (this.isNull(this.state.saveModel.insurancePlanID)) {
      myVal.insurancePlanIDVal = (
        <span className="validationMsg">Enter Medifusion Insurance Name</span>
      );
      myVal.validation = true;
    } else {
      myVal.insurancePlanIDVal = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (myVal.validation === true) {
      this.setState({ loading: false });
      Swal.fire("Please Fill All Fields Properly", "", "error");
      this.loadInsuranceCount = 0;
      return;
    }

    axios
      .post(
        this.ExInsuranceMapping + "SaveExInsuranceMapping",
        this.state.saveModel,
        this.config
      )
      .then(response => {
        this.loadInsuranceCount = 0;
        this.setState({ loading: false });
        Swal.fire("File Loaded Successfully", "", "success");
      })
      .catch(error => {
        this.loadInsuranceCount = 0;

        if (error.response) {
          if (error.response.status) {
            if (error.response.status == 400) {
              this.setState({ loading: false });
              Swal.fire("Error", error.message, "error");
              return;
            } else {
              this.setState({ loading: false });
              Swal.fire("Insurance Mapping Failded!", "", "error");
              return;
            }
          }
        } else {
          this.setState({ loading: false });
          Swal.fire("Insurance Mapping Failded!", "", "error");
          return;
        }
      });

    this.setState({
      validationModel: myVal
    });
  }

  render() {
    let popup = "";
    if (this.state.popupName === "insuranceplan") {
      popup = (
        <NewInsurancePlan
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewInsurancePlan>
      );
    } else if (this.state.showinsPopup) {
      popup = (
        <NewInsurancePlanAddress
          onClose={() => this.closeInsurancePlanPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewInsurancePlanAddress>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        <div
          id="insuranceMapping"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {/* <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button> */}
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={this.props.onClose()}
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.clientModel.name +
                          " - " +
                          this.state.clientModel.organizationName +
                          " "
                          : "NEW INSURANCE MAPPING"}
                      </h1>
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <form>
                  <div className="mainTable fullWidthTable wSpace">
                    <div className="row-form">
                      <div className="mf-8">
                        <Label name="External Insurance Name"></Label>
                        <div className="textBoxValidate">
                          <Input
                            type="text"
                            name="externalInsuranceName"
                            id="externalInsuranceName"
                            max="100"
                            value={this.state.saveModel.externalInsuranceName}
                            onChange={() => this.handleChange}
                          ></Input>
                          {this.state.validationModel.externalInsuranceNameVal}
                        </div>
                      </div>
                      <div className="mf-4">

                      </div>
                    </div>
                    <div className="row-form">
                      <div className="mf-8">
                        <label
                          className={
                            this.state.saveModel.insurancePlanID
                              ? "txtUnderline"
                              : ""
                          }
                          onClick={
                            this.state.saveModel.insurancePlanID
                              ? () =>
                                this.openPopup(
                                  "insuranceplan",
                                  this.state.saveModel.insurancePlanID
                                )
                              : undefined
                          }
                        >
                          Medifusion Insurance Name
                        </label>
                        <div
                          className="selectBoxValidate addBoxCol"
                        //style={{ marginLeft: "34%" }}
                        >
                          <Select
                            className={
                              this.state.validationModel.taxonomyCodeValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.insurancePlanID}
                            name="insurancePlanID"
                            id="insurancePlanID"
                            max="10"
                            onChange={event =>
                              this.handleInsurancePlansuggChange(event)
                            }
                            options={this.state.insurancePlans}
                            // onKeyDown={(e)=>this.filterOption(e)}
                            // filterOption={this.filterOption}
                            placeholder=""
                            isClearable={true}
                            isSearchable={true}
                            // menuPosition="static"
                            openMenuOnClick={false}
                            escapeClearsValue={true}
                            styles={{
                              indicatorSeparator: () => { },
                              clearIndicator: defaultStyles => ({
                                ...defaultStyles,
                                color: "#286881"
                              }),
                              container: defaultProps => ({
                                ...defaultProps,
                                position: "absolute",
                                width: "37%"
                              }),
                              // menu: styles => ({ ...styles,
                              //   width: '125px'
                              //  }),
                              indicatorsContainer: defaultStyles => ({
                                ...defaultStyles,
                                padding: "0px",
                                marginBottom: "0",
                                marginTop: "0px",
                                height: "36px",
                                borderBottomRightRadius: "10px",
                                borderTopRightRadius: "10px"
                                // borderRadius:"0 6px 6px 0"
                              }),
                              indicatorContainer: defaultStyles => ({
                                ...defaultStyles,
                                padding: "9px",
                                marginBottom: "0",
                                marginTop: "1px",
                                // borderBottomRightRadius: "5px",
                                // borderTopRightRadius: "5px",
                                borderRadius: "0 4px 4px 0"
                              }),
                              dropdownIndicator: () => ({
                                display: "none"
                              }),
                              // dropdownIndicator: defaultStyles => ({
                              //   ...defaultStyles,
                              //   backgroundColor: "#d8ecf3",
                              //   color: "#286881",
                              //   borderRadius: "3px"
                              // }),
                              input: defaultStyles => ({
                                ...defaultStyles,
                                margin: "0px",
                                padding: "0px"
                                // display:'none'
                              }),
                              singleValue: defaultStyles => ({
                                ...defaultStyles,
                                fontSize: "16px",
                                transition: "opacity 300ms"
                                // display:'none'
                              }),
                              control: defaultStyles => ({
                                ...defaultStyles,
                                minHeight: "33px",
                                height: "33px",
                                height: "33px",
                                paddingLeft: "10px",
                                //borderColor:"transparent",
                                borderColor: "#C6C6C6",
                                boxShadow: "none",
                                borderColor: "#C6C6C6",
                                "&:hover": {
                                  borderColor: "#C6C6C6"
                                }
                                // display:'none'
                              })
                            }}
                          />
                          <img
                            src={plusSrc}
                            onClick={() => this.openInsurancePlanPopup(0)}
                            disabled={this.isDisabled(this.props.rights.add)}
                          />
                        </div>
                        <div className="textBoxValidate">
                          {this.state.validationModel.insurancePlanIDVal}
                        </div>
                      </div>
                      <div className="mf-4"></div>
                    </div>
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <div className="mainTable">
                  <div className="row-form row-btn">
                    <div className="mf-12">
                      <Input
                        type="button"
                        value="Save"
                        className="btn-blue"
                        onClick={this.saveInsuranceMapping}
                        disabled={this.isDisabled(
                          this.state.editId > 0
                            ? this.props.rights.update
                            : this.props.rights.add
                        )}
                      />
                      <Input
                        type="button"
                        value="Cancel"
                        id="btnCancel"
                        className="btn-grey"
                        data-dismiss="modal"
                        onClick={
                          this.props.onClose
                            ? this.props.onClose()
                            : () => this.props.onClose()
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    userProviders: state.loginInfo
      ? state.loginInfo.userProviders
        ? state.loginInfo.userProviders
        : []
      : [],
    userRefProviders: state.loginInfo
      ? state.loginInfo.userRefProviders
        ? state.loginInfo.userRefProviders
        : []
      : [],
    userLocations: state.loginInfo
      ? state.loginInfo.userLocations
        ? state.loginInfo.userLocations
        : []
      : [],
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.patientSearch,
        add: state.loginInfo.rights.patientCreate,
        update: state.loginInfo.rights.patientEdit,
        delete: state.loginInfo.rights.patientDelete,
        export: state.loginInfo.rights.patientExport,
        import: state.loginInfo.rights.patientImport
      }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(NewInsuranceMapping);
