import React, { Component } from "react";
import facilityIcon from "../images/facility-icon.png";
import facilityHIcon from "../images/facility-icon-hover.png";
import locationIcon from "../images/location-icon.png";
import locationHIcon from "../images/location-icon-hover.png";

import LeftMenuItem from "./LeftMenuItem";

import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";

export class ReportsLeftMenu extends Component {
  constructor(props) {
    super(props);

    // this.state = {
    //   leftNavigationMenus: setupLeftMenu
    // };
  }

  render() {
    let setupLeftMenu = [
      {
        Category: "Account Report",
        Icon: "",
        hIcon: "",
        expanded: true,
        SubCategories: [
          {
            SubCategory: "Unit Report",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () => this.props.selectTabPageAction("UNIT REPORT"),
            to: "/Unit Report",
            selected: this.props.selectedTabPage == "UNIT REPORT" ? true : false
          },
          {
            SubCategory: "Aging Summary Report",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () =>
              this.props.selectTabPageAction("AGING SUMMARY REPORT"),
            to: "/Aging Report",
            selected:
              this.props.selectedTabPage == "AGING SUMMARY REPORT"
                ? true
                : false
          },
          {
            SubCategory: "Aging Detail Report",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () =>
              this.props.selectTabPageAction("AGING DETAIL REPORT"),
            to: "/Aging Detail Report",
            selected:
              this.props.selectedTabPage == "AGING DETAIL REPORT" ? true : false
          },
          {
            SubCategory: "Collection Report",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () => this.props.selectTabPageAction("COLLECTION REPORT"),
            to: "/Collection Report",
            selected:
              this.props.selectedTabPage == "COLLECTION REPORT" ? true : false
          }
        ]
      },
      {
        Category: "Patient Report",
        Icon: "",
        hIcon: "",
        expanded: true,
        SubCategories: [
          {
            SubCategory: "Patient Visit Report",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () =>
              this.props.selectTabPageAction("PATIENT VISIT REPORT"),
            to: "/Patient Visit Report",
            selected:
              this.props.selectedTabPage == "PATIENT VISIT REPORT"
                ? true
                : false
          },
          {
            SubCategory: "Appointment Status",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () => this.props.selectTabPageAction("APPOINTMENT STATUS"),
            to: "/Patient Appointment Status",
            selected:
              this.props.selectedTabPage == "APPOINTMENT STATUS" ? true : false
          },
          {
            SubCategory: "Pending Claims",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () => this.props.selectTabPageAction("PENDING CLAIMS"),
            to: "/Patient Pending Claims",
            selected:
              this.props.selectedTabPage == "PENDING CLAIMS" ? true : false
          },
          {
            SubCategory: "Referral Physician",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () => this.props.selectTabPageAction("REFERRAL PHYSICIAN"),
            to: "/Patient By Referal Physician",
            selected:
              this.props.selectedTabPage == "REFERRAL PHYSICIAN" ? true : false
          },
          {
            SubCategory: "Copay Collection",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () => this.props.selectTabPageAction("COPAY COLLECTION"),
            to: "/Copay Collection",
            selected:
              this.props.selectedTabPage == "COPAY COLLECTION" ? true : false
          },
          {
            SubCategory: "Patient Authorization",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
            handler: () => this.props.selectTabPageAction("PATIENT AUTHORIZATION"),
            to: "/Patient auth Report",
            selected:
              this.props.selectedTabPage == "PATIENT AUTHORIZATION" ? true : false
          },

        ]
      }
    ];

    let leftMenuElements = [];
    setupLeftMenu.map((catogry, i) => {
      leftMenuElements.push(<LeftMenuItem data={catogry}></LeftMenuItem>);
    });

    return leftMenuElements;
  }
}

function mapStateToProps(state) {
  console.log(state.leftNavigationMenus);
  return {
    leftNavigationMenus: state.leftNavigationMenus,
    selectedTab: state.selectedTab,
    selectedTabPage: state.selectedTabPage
  };
}

function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    { selectTabPageAction: selectTabPageAction },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(ReportsLeftMenu);
