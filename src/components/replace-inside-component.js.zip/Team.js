import React, { Component } from "react";

import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Button from "./Input";
import Input from "./Input";
import Swal from "sweetalert2";
import axios from "axios";
import {
  MDBDataTable,
  MDBBtn,
  MDBTableHead,
  MDBTableBody,
  MDBTable
} from "mdbreact";
import GridHeading from "./GridHeading";
import NewPractice from "./NewPractice";
import NewTeam from "./NewTeam";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import $ from "jquery";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

import Hotkeys from "react-hot-keys";

class Team extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/teams/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      name: ""
    };

    this.state = {
      searchModel: this.searchModel,
      id: 0,
      data: [],
      showPopup: false,
      loading: false
    };

    this.searchTeam = this.searchTeam.bind(this);
    this.closeTeamPopup = this.closeTeamPopup.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.openTeamPopup = this.openTeamPopup.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    if (keyName == "alt+n") {
      // alert("search key")
      this.openTeamPopup(0);
    } else if (keyName == "alt+s") {
      this.searchTeam(e);
    } else if (keyName == "alt+c") {
      // alert("clear skey")
      this.clearFields(e);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    if (e) {
      // this.onKeyDown(keyName, e , handle);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  //Search Team
  searchTeam = e => {
    this.setState({ loading: true });

    try {
      axios
        .post(this.url + "findTeams", this.state.searchModel, this.config)
        .then(response => {
          let newList = [];
          response.data.map((row, i) => {
            newList.push({
              id: row.userId,
              name: (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() => this.openTeamPopup(row.id)}
                >
                  {row.name}
                </MDBBtn>
              ),
              details: row.details
            });
          });

          this.setState({ data: newList, loading: false });
        })
        .catch(error => {
          this.setState({ loading: false });
          if (error.response) {
            if (error.response.status) {
              Swal.fire("Unauthorized Access", "", "error");
              return;
            }
          } else if (error.request) {
            return;
          } else {
            Swal.fire("Something went Wrong", "", "error");
            return;
          }
        });
    } catch {}

    e.preventDefault();
  };

  handleChange = event => {
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  openTeamPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  closeTeamPopup = () => {
    $("#myModal").hide();
    this.setState({ showPopup: false });
  };

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "DETAILS",
          field: "details",
          sort: "asc",
          width: 270
        }
      ],
      rows: this.state.data
    };

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewTeam
          onClose={() => this.closeTeamPopup}
          teamID={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewTeam>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <div
          className={
            this.state.showPopup == true ? "blurPopupBackground" : null
          }
        >
          <Hotkeys
            keyName="alt+n"
            onKeyDown={this.onKeyDown.bind(this)}
            onKeyUp={this.onKeyUp.bind(this)}
          >
            <SearchHeading
              heading="TEAM SEARCH"
              handler={() => this.openTeamPopup(0)}
              disabled={this.isDisabled(this.props.rights.add)}
            ></SearchHeading>
          </Hotkeys>

          <form onSubmit={this.searchTeam}>
            <div className="mainTable">
              <div className="row-form">
                <div className="mf-1"></div>
                <div className="mf-6">
                  <Label name="Name"></Label>
                  <Input
                    max="20"
                    type="text"
                    name="name"
                    id="name"
                    value={this.state.searchModel.name}
                    onChange={() => this.handleChange}
                  />
                </div>
                <div className="mf-4"></div>
              </div>

              <div className="row-form row-btn">
                <div className="mf-12">
                  <Hotkeys
                    keyName="alt+s"
                    onKeyDown={this.onKeyDown.bind(this)}
                    onKeyUp={this.onKeyUp.bind(this)}
                  >
                    <Input
                      type="submit"
                      name="name"
                      id="name"
                      className="btn-blue"
                      value="Search"
                      disabled={this.isDisabled(this.props.rights.search)}
                    />
                  </Hotkeys>

                  <Hotkeys
                    keyName="alt+c"
                    onKeyDown={this.onKeyDown.bind(this)}
                    onKeyUp={this.onKeyUp.bind(this)}
                  >
                    <Input
                      type="button"
                      name="name"
                      id="name"
                      className="btn-grey"
                      value="Clear"
                      onClick={() => this.clearFields()}
                    />
                  </Hotkeys>
                </div>
              </div>
            </div>
          </form>

          <div className="mf-12 table-grid mt-15">
            <GridHeading
              Heading="TEAM SEARCH RESULT"
              disabled={this.isDisabled(this.props.rights.export)}
              dataObj={this.state.searchModel}
              url={this.url}
              methodName="Export"
              methodNamePdf="ExportPdf"
              length={this.state.data.length}
            ></GridHeading>

            <div className="tableGridContainer text-nowrap">
              <MDBDataTable
                responsive={true}
                striped
                bordered
                searching={false}
                data={data}
                displayEntries={false}
                sortable={true}
                scrollX={false}
                scrollY={false}
              />
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.teamSearch,
          add: state.loginInfo.rights.teamCreate,
          update: state.loginInfo.rights.teamupdate,
          delete: state.loginInfo.rights.teamDelete,
          export: state.loginInfo.rights.teamExport,
          import: state.loginInfo.rights.teamImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(Team);
