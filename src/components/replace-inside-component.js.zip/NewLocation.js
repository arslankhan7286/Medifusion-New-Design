import React, { Component, Fragment } from "react";
import $ from "jquery";
import taxonomyIcon from "../images/code-search-icon.png";
import axios from "axios";
import Input from "./Input";

import Swal from "sweetalert2";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import Dropdown from "react-dropdown";
import settingsIcon from "../images/setting-icon.png";
import plusSrc from "../images/plus-icon.png";
import NewHistoryPractice from "./NewHistoryPractice";
import NumberFormat from "react-number-format";

import NewPOS from "./NewPOS";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { userInfo } from "../actions/userInfo";
import { locationAction } from "../actions/LocationAction";

import Hotkeys from "react-hot-keys";
export class NewLocation extends Component {
  constructor(props) {
    super(props);

    this.commonUrl = process.env.REACT_APP_URL + "/Common/";
    this.url = process.env.REACT_APP_URL + "/Location/";
    this.zipURL = process.env.REACT_APP_URL + "/Common/";
    this.accountUrl = process.env.REACT_APP_URL + "/account/";
    this.errorField = "errorField";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.saveLocationCount = 0;

    this.locationModel = {
      id: 0,
      name: "",
      organizationName: "",
      practiceID: "",
      npi: "",
      posid: "",
      address1: "",
      address2: "",
      city: "",
      state: "",
      zipCode: "",
      cliaNumber: "",
      fax: "",
      website: "",
      email: "",
      phoneNumber: "",
      phoneNumExt: "",
      notes: "",
      isActive: true,
      isDeleted: false
    };

    this.validationModel = {
      nameValField: "",
      organizationNameValField: "",
      practiceIDValField: "",
      npiValField: "",
      posidValField: "",
      address1ValField: "",
      address2ValField: "",
      cityValField: "",
      stateValField: "",
      zipCodeValField: "",
      cliaNumberValField: "",
      faxValField: "",
      websiteValField: "",
      emailValField: "",
      phoneNumberValField: "",
      notesValField: "",
      isActiveValField: true
    };

    this.state = {
      editId: this.props.id,
      locationModel: this.locationModel,
      validationModel: this.validationModel,
      maxHeight: "361",
      practicesData: [],
      posData: [],
      showPopup: false,

      showPOSPopup: false
    };

    //this.dropdownData = {}

    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.handleChange = this.handleChange.bind(this);

    this.saveLocation = this.saveLocation.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
    this.delete = this.delete.bind(this);
    this.handleZip = this.handleZip.bind(this);
    this.openPOSPopup = this.openPOSPopup.bind(this);
    this.closePOSPopup = this.closePOSPopup.bind(this);
    this.onPaste = this.onPaste.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    if (keyName == "alt+s") {
      // alert("save key")
      this.saveLocation();
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    if (e) {
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  async componentWillMount() {
    this.setState({ loading: true });
    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function () {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    await this.setModalMaxHeight($(".modal"));

    await axios
      .get(this.url + "GetProfiles", this.config)
      .then(response => {
        this.setState({
          // practicesData: response.data.practice,
          posData: response.data.posCodes
        });
      })
      .catch(error => {
        this.setState({ loading: false });
      });

    if (this.state.editId > 0) {
      await axios
        .get(this.url + "FindLocation/" + this.state.editId, this.config)
        .then(response => {
          this.setState({ locationModel: response.data });
        })
        .catch(error => {
          this.setState({ loading: false });
        });
    }

    this.setState({ loading: false });
  }

  openPOSPopup = id => {
    this.setState({ showPOSPopup: true, id: id });
  };

  //close facility popup
  closePOSPopup = () => {
    $("#myModal1").hide();
    this.setState({ showPOSPopup: false });

    try {
      axios
        .get(this.url + "GetProfiles", this.config)
        .then(response => {
          this.setState({
            posData: response.data.posCodes
          });
        })
        .catch(error => {
          this.setState({ loading: false });
        });
    } catch { }
  };

  handleCheck() {
    this.setState({
      locationModel: {
        ...this.state.locationModel,
        isActive: !this.state.locationModel.isActive
      }
    });
  }

  handleZip(event) {
    var zip = event.target.value;

    this.setState({
      locationModel: {
        ...this.state.locationModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });

    if (zip.length == 5 || zip.length == 9) {
      axios
        .get(this.zipURL + "GetCityStateInfo/" + zip, this.config)
        .then(response => {
          this.setState({
            locationModel: {
              ...this.state.locationModel,
              city: response.data.city.toUpperCase(),
              state: response.data.state_id
            }
          });
        })
        .catch(error => {
          this.setState({ loading: false });

          if (error.response.data == "InValid ZipCode") {
            Swal.fire("Something Wrong", "InValid ZipCode", "error");
          } else {
            Swal.fire(
              "Something Wrong",
              "Please Check Server Connection",
              "error"
            );
          }
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
          }
        });
    } else {
      // Swal.fire("Enter Valid Zip Code", "", "error");
    }
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  handleChange = event => {
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    var myValue;
    event.preventDefault();
    var myName = event.target.name ? event.target.name : "";
    if (myName == "cliaNumber") {
      myValue = event.target.value ? event.target.value : "";
      event.target.value = myValue.trim();
    }
    event.preventDefault();
    this.setState({
      locationModel: {
        ...this.state.locationModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  saveLocation = e => {
    if (this.saveLocationCount == 1) {
      return;
    }
    this.saveLocationCount = 1;
    // e.preventDefault();
    this.setState({ loading: true });

    if (this.isNull(this.state.locationModel.phoneNumber) === false) {
      if (this.state.locationModel.phoneNumber.length > 10) {
        var officePhoneNum = this.state.locationModel.phoneNumber.slice(3, 17);
        this.state.locationModel.phoneNumber = officePhoneNum.replace(/[-_ )(]/g, "");
      }
    }

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.locationModel.name)) {
      myVal.nameValField = <span className="validationMsg">Enter Name</span>;
      myVal.validation = true;
    } else {
      myVal.nameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.locationModel.organizationName)) {
      myVal.organizationNameValField = (
        <span className="validationMsg">Enter Organization Name</span>
      );
      myVal.validation = true;
    } else {
      myVal.organizationNameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.locationModel.npi)) {
      myVal.npiValField = <span className="validationMsg">Enter NPI</span>;
      myVal.validation = true;
    } else if (this.state.locationModel.npi.length < 10) {
      myVal.npiValField = (
        <span className="validationMsg">NPI length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.npiValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    // if (this.isNull(this.state.locationModel.npi)) {
    //   myVal.npiValField = <span className="validationMsg">Enter NPI</span>;
    //   myVal.validation = true;
    // } else if (this.state.locationModel.npi.length > 10) {
    //   myVal.npiValField = (
    //     <span className="validationMsg">NPI length should be 10</span>
    //   );
    //   myVal.validation = true;
    // } else {
    //   myVal.npiValField = "";
    //   if (myVal.validation === false) myVal.validation = false;
    // }

    if (this.isNull(this.state.locationModel.practiceID)) {
      myVal.practiceIDValField = (
        <span className="validationMsg">Select Facility</span>
      );
      myVal.validation = true;
    } else {
      myVal.practiceIDValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.locationModel.posid)) {
      myVal.posidValField = <span className="validationMsg">Select POS</span>;
      myVal.validation = true;
    } else {
      myVal.posidValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.locationModel.zipCode) === false &&
      this.state.locationModel.zipCode.length > 0
    ) {
      if (this.state.locationModel.zipCode.length < 5) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of alleast 5 digits
          </span>
        );
        myVal.validation = true;
      } else if (
        this.state.locationModel.zipCode.length > 5 &&
        this.state.locationModel.zipCode.length < 9
      ) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of either 5 or 9 digits
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.zipCodeValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.zipCodeValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.state.locationModel.cliaNumber.length > 0 &&
      this.state.locationModel.cliaNumber.length < 10
    ) {
      myVal.cliaNumberValField = (
        <span className="validationMsg">cliaNumber length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.cliaNumberValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.locationModel.phoneNumber) === false &&
      this.state.locationModel.phoneNumber.length < 10
    ) {
      myVal.phoneNumberValField = (
        <span className="validationMsg">Phone # length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.phoneNumberValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.locationModel.fax) === false &&
      this.state.locationModel.fax.length < 10
    ) {
      myVal.faxValField = (
        <span className="validationMsg">Fax # length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.faxValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }
    myVal.emailValField = "";
    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      this.saveLocationCount = 0;

      return;
    }

    axios
      .post(this.url + "SaveLocation", this.state.locationModel, this.config)
      .then(response => {
        this.saveLocationCount = 0;
        Swal.fire("Record Saved Successfully", "", "success");
        this.setState({ loading: false, locationModel: response.data });

        try {
          axios
            .get(this.commonUrl + "GetLocations", this.config)
            .then(response => {
              this.saveLocationCount = 0;

              this.props.locationAction(
                this.props,
                response.data,
                "LOCATION_ACTION"
              );
            })
            .catch(error => {
              this.saveLocationCount = 0;
            });
        } catch {
          this.saveLocationCount = 0;
        }
      })
      .catch(error => {
        this.saveLocationCount = 0;

        this.setState({ loading: false });
        try {
          if (error.response) {
            if (error.response.status) {
              if (error.response.status == 401) {
                Swal.fire("Unauthorized Access", "", "error");
                return;
              } else if (error.response.status == 404) {
                Swal.fire("Not Found", "Failed With Status Code 404", "error");
                return;
              } else if (error.response.status == 400) {
                if (error.response.data.Email) {
                  if (error.response.data.Email[0] == "Please enter Valid Email ID") {
                    myVal.emailValField = (
                      <span className="validationMsg">Please enter Valid Email ID</span>
                    );
                    myVal.validation = true;
                  } else {
                    myVal.emailValField = "";
                    if (myVal.validation === false) myVal.validation = false;
                  }
                  this.setState({
                    validationModel: myVal
                  });

                  Swal.fire("Something Wrong", "Please Enter Valid Email", "error");
                  return;
                }
                Swal.fire("Something Wrong", error.response.data, "error");
                return;
              } else {
                Swal.fire("Something Wrong", "Please Try Again", "error");
                return;
              }
            }
          } else {
            Swal.fire("Something Wrong", "Please Try Again", "error");
            return;
          }


        } catch { }
      });

    // e.preventDefault();
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  onPaste(event) {
    var x = event.target.value;
    x = x.trim();
    var regex = /^[0-9]+$/;
    if (x.length == 0) {
      this.setState({
        locationModel: {
          ...this.state.locationModel,
          [event.target.name]: x
        }
      });
      return;
    }

    if (!x.match(regex)) {
      Swal.fire("Error", "Should be Number", "error");
      return;
    } else {
      this.setState({
        locationModel: {
          ...this.state.locationModel,
          [event.target.name]: x
        }
      });
    }
    return;
  }

  delete = e => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.setState({ loading: true });
        axios
          .delete(this.url + "DeleteLocation/" + this.state.editId, this.config)
          .then(response => {
            this.setState({
              loading: false,
              locationModel: this.locationModel
            });
            Swal.fire("Record Deleted Successfully", "", "success");

            try {
              axios
                .get(this.commonUrl + "GetLocations", this.config)
                .then(response => {
                  this.props.locationAction(
                    this.props,
                    response.data,
                    "LOCATION_ACTION"
                  );
                })
                .catch(error => { });
            } catch { }
          })
          .catch(error => {
            this.setState({ loading: false });
            if (this.state.editId > 0) {
              Swal.fire(
                "Record Not Deleted!",
                "Record can not be delete, as it is being reference in other screens.",
                "error"
              );
            } else {
              Swal.fire(
                "Record Not Deleted!",
                "Don't have record to delete",
                "error"
              );
            }
          });

        // $("#btnCancel").click();
      }
    });
  };

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  openhistorypopup = id => {
    this.setState({ showPopup: true, id: id });
  };
  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  render() {
    if (this.props.userInfo1.userPractices.length > 0) {
      if (this.state.practicesData.length == 0) {
        if (this.state.editId == 0) {
          this.setState({
            locationModel: {
              ...this.state.locationModel,
              practiceID: this.props.userInfo1.practiceID
            },
            practicesData: this.props.userInfo1.userPractices
          });
        } else {
          this.setState({
            locationModel: {
              ...this.state.locationModel,
              practiceID: this.props.userInfo1.practiceID
            },
            practicesData: this.props.userInfo1.userPractices
          });
        }
      }
    }

    const isActive = this.state.locationModel.isActive;
    const usStates = [
      { value: "", display: "Select State" },
      { value: "AL", display: "AL - Alabama" },
      { value: "AK", display: "AK - Alaska" },
      { value: "AZ", display: "AZ - Arizona" },
      { value: "AR", display: "AR - Arkansas" },
      { value: "CA", display: "CA - California" },
      { value: "CO", display: "CO - Colorado" },
      { value: "CT", display: "CT - Connecticut" },
      { value: "DE", display: "DE - Delaware" },
      { value: "FL", display: "FL - Florida" },
      { value: "GA", display: "GA - Georgia" },
      { value: "HI", display: "HI - Hawaii" },
      { value: "ID", display: "ID - Idaho" },
      { value: "IL", display: "IL - Illinois" },
      { value: "IN", display: "IN - Indiana" },
      { value: "IA", display: "IA - Iowa" },
      { value: "KS", display: "KS - Kansas" },
      { value: "KY", display: "KY - Kentucky" },
      { value: "LA", display: "LA - Louisiana" },
      { value: "ME", display: "ME - Maine" },
      { value: "MD", display: "MD - Maryland" },
      { value: "MA", display: "MA - Massachusetts" },
      { value: "MI", display: "MI - Michigan" },
      { value: "MN", display: "MN - Minnesota" },
      { value: "MS", display: "MS - Mississippi" },
      { value: "MO", display: "MO - Missouri" },
      { value: "MT", display: "MT - Montana" },
      { value: "NE", display: "NE - Nebraska" },
      { value: "NV", display: "NV - Nevada" },
      { value: "NH", display: "NH - New Hampshire" },
      { value: "NJ", display: "NJ - New Jersey" },
      { value: "NM", display: "NM - New Mexico" },
      { value: "NY", display: "NY - New York" },
      { value: "NC", display: "NC - North Carolina" },
      { value: "ND", display: "ND - North Dakota" },
      { value: "OH", display: "OH - Ohio" },
      { value: "OK", display: "OK - Oklahoma" },
      { value: "OR", display: "OR - Oregon" },
      { value: "PA", display: "PA - Pennsylvania" },
      { value: "RI", display: "RI - Rhode Island" },
      { value: "SC", display: "SC - South Carolina" },
      { value: "SD", display: "SD - South Dakota" },
      { value: "TN", display: "TN - Tennessee" },
      { value: "TX", display: "TX - Texas" },
      { value: "UT", display: "UT - Utah" },
      { value: "VT", display: "VT - Vermont" },
      { value: "VA", display: "VA - Virginia" },
      { value: "WA", display: "WA - Washington" },
      { value: "WV", display: "WV - West Virginia" },
      { value: "WI", display: "WI - Wisconsin" },
      { value: "WY", display: "WY - Wyoming" }
    ];

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    const options = [
      { value: "History", label: "History", className: "dropdown" }
    ];

    var Imag;
    Imag = (
      <div>
        <img src={settingsIcon} />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup(0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
        // disabled={this.isDisabled(this.props.rights.update)}
        // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else if (this.state.showPOSPopup) {
      popup = (
        <NewPOS
          onClose={() => this.closePOSPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewPOS>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    return (
      <React.Fragment>
        <div
          id="locationModal"
          class="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div class="modal-dialog modal-lg">
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={this.props.onClose()}
                type="button"
                class="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.locationModel.name.toUpperCase() +
                          " - " +
                          this.state.locationModel.id
                          : "NEW LOCATION"}
                      </h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkBox"
                          id="isActive"
                          name="isActive"
                          checked={!isActive}
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                        disabled={this.isDisabled(this.props.rights.delete)}
                      >
                        Delete
                      </Input>
                      {this.state.editId > 0 ? dropdown : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div
                class="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div class="mainTable">
                  <div class="row-form">
                    <div class="mf-6">
                      <label>
                        Name<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.nameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.locationModel.name}
                          max="60"
                          name="name"
                          id="name"
                          onChange={() => this.handleChange}
                        ></Input>
                        {this.state.validationModel.nameValField}
                      </div>
                    </div>

                    <div class="mf-6">
                      <label>
                        Organization Name<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.organizationNameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.locationModel.organizationName}
                          max="60"
                          name="organizationName"
                          id="organizationName"
                          onChange={() => this.handleChange}
                        ></Input>
                        {this.state.validationModel.organizationNameValField}
                      </div>
                    </div>
                  </div>
                  <div class="row-form">
                    <div class="mf-6">
                      <label>
                        Practice<span className="redlbl"> *</span>
                      </label>

                      <div className="selectBoxValidate">
                        <select
                          className={
                            this.state.validationModel.practiceIDValField
                              ? this.errorField
                              : ""
                          }
                          name="practiceID"
                          id="practiceID"
                          disabled
                          value={this.state.locationModel.practiceID}
                          onChange={this.handleChange}
                        >
                          {this.state.practicesData.map(s => (
                            <option key={s.id} value={s.id}>
                              {s.description}
                            </option>
                          ))}
                        </select>
                        {this.state.validationModel.practiceIDValField}
                      </div>
                    </div>
                    <div class="mf-6">&nbsp;</div>
                  </div>
                  <div class="mf-12 headingOne mt-25">
                    <p>Legal Information</p>
                  </div>
                  <div class="row-form">
                    <div class="mf-6">
                      <label>
                        NPI<span className="redlbl"> *</span>
                      </label>

                      <div className="textBoxValidate">
                        <input
                          className={
                            this.state.validationModel.npiValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.locationModel.npi}
                          name="npi"
                          id="npi"
                          maxLength="10"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                          onInput={this.onPaste}
                        ></input>
                        {this.state.validationModel.npiValField}
                      </div>
                    </div>

                    <div class="mf-6">
                      <label>
                        POS<span className="redlbl"> *</span>
                      </label>
                      <div className="selectBoxValidate addBoxCol">
                        <select
                          className={
                            this.state.validationModel.posidValField
                              ? this.errorField
                              : ""
                          }
                          name="posid"
                          id="posid"
                          value={this.state.locationModel.posid}
                          onChange={this.handleChange}
                        >
                          {this.state.posData.map(s => (
                            <option key={s.id} value={s.id}>
                              {s.description}
                            </option>
                          ))}
                        </select>
                        <img
                          src={plusSrc}
                          onClick={() => this.openPOSPopup(0)}
                          disabled={this.isDisabled(this.props.rights.add)}
                        />

                        {this.state.validationModel.posidValField}
                      </div>
                    </div>
                  </div>
                  <div class="row-form">
                    <div className="mf-6 mf-icon">
                      <label>CLIA</label>

                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.cliaNumberValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.locationModel.cliaNumber}
                          name="cliaNumber"
                          id="cliaNumber"
                          max="10"
                          onChange={() => this.handleChange}
                        />

                        {this.state.validationModel.cliaNumberValField}
                      </div>
                    </div>
                    <div class="mf-6">&nbsp;</div>
                  </div>
                  <div class="mf-12 headingOne mt-25">
                    <p>Address Information</p>
                  </div>
                  <div class="row-form">
                    <div class="mf-6">
                      <label>Address 1</label>
                      <Input
                        type="text"
                        value={this.state.locationModel.address1}
                        max="50"
                        name="address1"
                        id="address1"
                        max="55"
                        onChange={() => this.handleChange}
                      ></Input>
                    </div>
                    <div class="mf-6">
                      <label>Address 2</label>
                      <Input
                        type="text"
                        value={this.state.locationModel.address2}
                        max="50"
                        name="address2"
                        id="address2"
                        max="55"
                        onChange={() => this.handleChange}
                      ></Input>
                    </div>
                  </div>
                  <div class="row-form">
                    <div class="mf-6">
                      <label>City - State</label>
                      <div class="textBoxTwoField">
                        <Input
                          type="text"
                          value={this.state.locationModel.city}
                          max="20"
                          name="city"
                          id="city"
                          onChange={() => this.handleChange}
                        />

                        <select
                          name="state"
                          id="state"
                          value={this.state.locationModel.state}
                          onChange={this.handleChange}
                        >
                          {usStates.map(s => (
                            <option key={s.value} value={s.value}>
                              {s.display}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div class="mf-6">
                      <label>Zip Code - Fax</label>

                      <div class="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.zipCodeValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            max="9"
                            name="zipCode"
                            id="zipCode"
                            value={this.state.locationModel.zipCode}
                            onChange={() => this.handleZip}
                            onKeyPress={event => this.handleNumericCheck(event)}
                          ></Input>
                          {this.state.validationModel.zipCodeValField}
                        </div>

                        {/* <div className="twoColValidate">
                                                    <Input className={this.state.validationModel.phoneNumberValField ? this.errorField : ""}
                                                        type="text" value={this.state.locationModel.phoneNumber} max='10' name="phoneNumber" id="phoneNumber" onChange={() => this.handleChange} onKeyPress={event => this.handleNumericCheck(event)}></Input>
                                                    {this.state.validationModel.phoneNumberValField}
                                                </div> */}
                        <div className="twoColValidate">
                          <input
                            type="text"
                            value={this.state.locationModel.fax}
                            className={
                              this.state.validationModel.faxValField
                                ? this.errorField
                                : ""
                            }
                            maxLength="10"
                            name="fax"
                            id="fax"
                            onChange={() => this.handleChange}
                            onKeyPress={event => this.handleNumericCheck(event)}
                            onInput={this.onPaste}
                          ></input>
                          {this.state.validationModel.faxValField}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row-form">
                    {/* <div class="mf-6">
                      <label>Phone</label>
                      
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.phoneNumberValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.locationModel.phoneNumber}
                          max="10"
                          name="phoneNumber"
                          id="phoneNumber"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        ></Input>
                        {this.state.validationModel.phoneNumberValField}
                      </div>
                    </div> */}
                    <div className="mf-6">
                      <label>Phone - Extension</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <NumberFormat
                            format="00 (###) ###-####"
                            mask="_"
                            className={
                              this.state.validationModel.phoneNumberValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.locationModel.phoneNumber}
                            max="10"
                            name="phoneNumber"
                            id="phoneNumber"
                            onChange={this.handleChange}
                          // onKeyPress={event => this.handleNumericCheck(event)}
                          />

                          {this.state.validationModel.phoneNumberValField}
                        </div>
                        <div className="twoColValidate">
                          <input
                            className={
                              this.state.validationModel.faxNumberValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.locationModel.phoneNumExt}
                            maxLength="4"
                            name="phoneNumExt"
                            id="phoneNumExt"
                            onChange={() => this.handleChange}
                            onKeyPress={event => this.handleNumericCheck(event)}
                            onInput={this.onPaste}
                          />
                          {/* {this.state.validationModel.faxNumberValField} */}
                        </div>
                      </div>
                    </div>
                    <div class="mf-6">
                      <label>Website</label>
                      <Input
                        type="text"
                        value={this.state.locationModel.website}
                        name="website"
                        id="website"
                        max="50"
                        onChange={() => this.handleChange}
                      ></Input>
                    </div>
                  </div>
                  <div class="row-form">
                    <div class="mf-6">
                      <label>Email</label>
                      <Input
                        type="text"
                        value={this.state.locationModel.email}
                        name="email"
                        id="email"
                        max="60"
                        onChange={() => this.handleChange}
                      ></Input>
                      <div className="textBoxValidate">
                        {this.state.validationModel.emailValField}
                      </div>
                    </div>
                    <div class="mf-6">&nbsp;</div>
                  </div>
                  <div class="row-form">
                    <div class="mf-12 field_full-8">
                      <label>Notes:</label>
                      <textarea
                        value={this.state.locationModel.notes}
                        name="notes"
                        id="notes"
                        cols="30"
                        rows="10"
                        onChange={this.handleChange}
                      ></textarea>
                    </div>
                  </div>
                </div>

                <div class="modal-footer">
                  <div class="mainTable">
                    <div class="row-form row-btn">
                      <div class="mf-12">
                        <Hotkeys
                          keyName="alt+s"
                          onKeyDown={this.onKeyDown.bind(this)}
                          onKeyUp={this.onKeyUp.bind(this)}
                        >
                          <input
                            type="button"
                            value="Save"
                            className="btn-blue"
                            onClick={this.saveLocation}
                            disabled={this.isDisabled(
                              this.state.editId > 0
                                ? this.props.rights.update
                                : this.props.rights.add
                            )}
                          ></input>
                        </Hotkeys>

                        <input
                          type="button"
                          value="Cancel"
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        ></input>
                      </div>

                      {/* <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                          Cancel
                        </button>
                      </div> */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.locationSearch,
        add: state.loginInfo.rights.locationCreate,
        update: state.loginInfo.rights.locationEdit,
        delete: state.loginInfo.rights.locationDelete,
        export: state.loginInfo.rights.locationExport,
        import: state.loginInfo.rights.locationImport
      }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
      userInfo: userInfo,
      locationAction: locationAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewLocation);
