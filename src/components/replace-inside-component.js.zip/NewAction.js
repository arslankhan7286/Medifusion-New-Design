import React, { Component } from "react";

import Input from "./Input";
import $ from "jquery";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

import Swal from "sweetalert2";
import axios from "axios";
import Dropdown from "react-dropdown";
import settingsIcon from "../images/setting-icon.png";
import NewHistoryPractice from "./NewHistoryPractice";
//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

export class NewAction extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/Action/";

    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.savePatientCount = 0;

    this.actionModel = {
      name: "",
      description: "",
      userID: ""
    };
    this.validationModel = {
      valname: "",
      valdescription: "",
      valuserID: ""
    };

    this.state = {
      actionModel: this.actionModel,
      editId: this.props.id,
      validationModel: this.validationModel,
      data: [],

      usersData: [],
      id: 0,
      isActive: true,
      showPopup: false
    };
    this.handleChange = this.handleChange.bind(this);
    this.saveAction = this.saveAction.bind(this);
  }

  async componentWillMount() {
    await this.setState({ loading: true });
    try {
      await this.setModalMaxHeight($(".modal"));

      var zIndex = 1040 + 10 * $(".modal:visible").length;
      $(this).css("z-Index", zIndex);
      setTimeout(function() {
        $(".modal-backdrop")
          .not(".modal-stack")
          .css("z-Index", zIndex - 1)
          .addClass("modal-stack");
      }, 0);

      await axios
        .get(this.url + "GetProfiles", this.config)
        .then(response => {
          this.setState({
            usersData: response.data.users
          });
        })
        .catch(error => {});

      if (this.state.editId > 0) {
        await axios
          .get(this.url + "FindAction/" + this.state.editId, this.config)
          .then(response => {
            this.setState({ actionModel: response.data });
          })
          .catch(error => {});
      }
    } catch {
      this.setState({ loading: false });
    }
    this.setState({ loading: false });
  }

  saveAction = e => {
    if (this.savePatientCount == 1) {
      return;
    }
    this.savePatientCount = 1;

    this.setState({ loading: true });

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.actionModel.name)) {
      myVal.valname = <span className="validationMsg">Enter Name</span>;
      myVal.validation = true;
    } else {
      myVal.valname = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.actionModel.description)) {
      myVal.valdescription = (
        <span className="validationMsg">Enter Description</span>
      );
      myVal.validation = true;
    } else {
      myVal.valdescription = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.actionModel.userID)) {
      myVal.valuserID = <span className="validationMsg">Enter userID</span>;
      myVal.validation = true;
    } else {
      myVal.valuserID = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      this.savePatientCount = 0;

      return;
    }

    e.preventDefault();
    axios
      .post(this.url + "SaveAction", this.state.actionModel, this.config)
      .then(response => {
        this.savePatientCount = 0;

        this.setState({ data: response.data, loading: false });

        Swal.fire("Record Saved Successfully", "", "success");
      })
      .catch(error => {
        this.savePatientCount = 0;

        this.setState({ loading: false });
        let errorList = [];
        if (error.response !== null && error !== null) {
          errorList = error.response;
        }
      });
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  handleChange = event => {
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    if (event.target.name === "userID") {
      this.setState({
        actionModel: {
          ...this.state.actionModel,
          [event.target.name]: event.target.value
        }
      });
    } else {
      this.setState({
        actionModel: {
          ...this.state.actionModel,
          [event.target.name]: event.target.value.toUpperCase()
        }
      });
    }
  };

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  openhistorypopup = id => {
    this.setState({ showPopup: true, id: id });
  };
  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  render() {
    //Spinner
    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    const options = [
      { value: "History", label: "History", className: "dropdown" }
    ];

    var Imag;
    Imag = (
      <div>
        <img src={settingsIcon} />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup(0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
          // disabled={this.isDisabled(this.props.rights.update)}
          // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }
    return (
      <React.Fragment>
        <div
          id="actionModal"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}

            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={this.props.onClose()}
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>

              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.actionModel.name
                          : "NEW ACTION"}
                      </h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkbox"
                          checked={!this.state.actionModel.isActive}
                          id="isActive"
                          name="isActive"
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                      >
                        Delete
                      </Input>
                      {this.state.editId > 0 ? dropdown : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable">
                  {/* <div className="mf-12 headingOne mt-25">
                                    <p>EDI Status Payer Information</p>
                                </div> */}
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        Name<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.valname
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.actionModel.name}
                          name="name"
                          id="name"
                          max="11"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.valname}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>
                        Description<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.valdescription
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.actionModel.description}
                          name="description"
                          id="description"
                          max="100"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.valdescription}
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        User ID<span className="redlbl"> *</span>
                      </label>

                      <div className="selectBoxValidate">
                        <select
                          className={
                            this.state.validationModel.valuserID
                              ? this.errorField
                              : ""
                          }
                          name="userID"
                          id="userID"
                          value={this.state.actionModel.userID}
                          onChange={this.handleChange}
                        >
                          {this.state.usersData.map(s => (
                            <option key={s.id} value={s.description3}>
                              {s.description2}
                            </option>
                          ))}
                        </select>
                        {this.state.validationModel.valuserID}
                      </div>
                    </div>

                    <div className="mf-6">&nbsp;</div>
                  </div>
                </div>

                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <button className="btn-blue" onClick={this.saveAction}>
                          Save{" "}
                        </button>
                        <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={this.props.onClose()}
                        >
                          Cancel{" "}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewAction);
