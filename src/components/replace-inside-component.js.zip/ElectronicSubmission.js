import React, { Component } from "react";
import Label from "./Label";
import Input from "./Input";
import axios from "axios";
import { MDBDataTable, MDBBtn, MDBInput } from "mdbreact";
import GridHeading from "./GridHeading";
import ElectronicSubmissionModel from "./ElectronicSubmissionModel";
import $ from "jquery";
import Swal from "sweetalert2";
import { isNullOrUndefined } from "util";
import GPopup from "./GPopup";
import moment from "moment";

import { withRouter } from "react-router-dom";

import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";

import GifLoader from "react-gif-loader";
import Eclips from "../images/loading_spinner.gif";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import NewInsurancePlan from "./NewInsurancePlan";

export class ElectronicSubmission extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/ElectronicSubmission/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.electModel = {
      receiverID: "",
      accountNum: "",
      visitID: null,
      practice: "",
      provider: "",
      planName: "",
      payerID: "",
      location: "",
      status: "",
      entryDateFrom: "",
      entryDateTo: ""
    };

    this.submitModel = {
      receiverID: 0,
      clientID: 1,
      SubmissionLogID: 0,
      visits: []
    };

    this.display = "Record displaying Submit Successfully";

    this.validationModel = {
      EntryDateToGreaterValField: null,
      selectEntryFromValField: null,
      entryDateFromValField: "",
      entryDateToValField: "",
      validation: false
    };

    this.state = {
      electModel: this.electModel,
      submitModel: this.submitModel,
      validationModel: this.validationModel,
      data: [],
      initialData: [],
      revData: [],
      ischeck: {},
      id: 0,
      checked: [],
      output: {},
      popupName: "",
      showPopup: false,
      showPracticePopup: false,
      showLocationPopup: false,
      showProviderPopup: false,
      patientPopup: false,
      visitPopup: false,
      loading: false
    };

    this.selectedVisits = [];
    this.searchElectronicSub = this.searchElectronicSub.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.clearFields = this.clearFields.bind(this);
    this.submitCheckedVisits = this.submitCheckedVisits.bind(this);
    this.toggleCheck = this.toggleCheck.bind(this);
    this.isChecked = this.isChecked.bind(this);
    this.selectALL = this.selectALL.bind(this);
    this.openPatientPopup = this.openPatientPopup.bind(this);
    this.opensubmitPlanPopup = this.opensubmitPlanPopup.bind(this);
    this.closePatientPopup = this.closePatientPopup.bind(this);
    this.closesubmitPlanPopup = this.closesubmitPlanPopup.bind(this);
    this.openVisitPopup = this.openVisitPopup.bind(this);
    this.closeVisitPopUp = this.closeVisitPopUp.bind(this);
  }

  openPracticePopup = id => {
    this.setState({ showPracticePopup: true, id: id });
  };

  closePracticePopup = () => {
    $("#myModal").hide();
    this.setState({ showPracticePopup: false });
  };

  openLocationPopup = id => {
    this.setState({ showLocationPopup: true, id: id });
  };

  closeLocationPopup = () => {
    $("#myModal").hide();
    this.setState({ showLocationPopup: false });
  };

  openPatientPopup(name, id) {
    this.setState({ popupName: name, patientPopup: true, id: id });
  }

  closePatientPopup(name, id) {
    this.setState({ popupName: "", patientPopup: false });
  }

  //Open Visit Popup
  openVisitPopup(name, id) {
    this.setState({ popupName: name, visitPopup: true, id: id });
  }

  //Close Visit Popup
  closeVisitPopUp() {
    this.setState({ popupName: "", visitPopup: false });
  }

  openProviderPopup = id => {
    this.setState({ showProviderPopup: true, id: id });
  };

  closeProviderPopup = () => {
    $("#myModal").hide();
    this.setState({ showProviderPopup: false });
  };

  // Open Patient Plan By Subscriber ID Popup
  openPatientPlanPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  openPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  };

  isChecked = id => {
    //return this.state.submitModel.visits.filter(name => name === id)[0] ? true : false
    var checked = this.selectedVisits.filter(name => name == id)[0]
      ? true
      : false;
    return checked;
  };

  /////////// Null handle //////////////
  val(value) {
    if (isNullOrUndefined(value)) return " ";
    else return value;
  }

  async searchElectronicSubmission() {

    this.setState({ loading: true });


    var myVal = this.validationModel;
    myVal.validation = false;

    //Entry Date From Future Date Validation
    if (this.isNull(this.state.electModel.entryDateFrom) == false) {
      if (
        new Date(
          moment(this.state.electModel.entryDateFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.entryDateFromValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.entryDateFromValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.entryDateFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Entry Date To Future Date Validation
    if (this.isNull(this.state.electModel.entryDateTo) == false) {
      if (
        new Date(
          moment(this.state.electModel.entryDateTo)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.entryDateToValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.entryDateToValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.entryDateToValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Entry Date To must be greater than Entry Date From Validation
    if (
      this.isNull(this.state.electModel.entryDateFrom) == false &&
      this.isNull(this.state.electModel.entryDateTo) == false
    ) {
      if (
        new Date(
          moment(this.state.electModel.entryDateFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment(this.state.electModel.entryDateTo)
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.EntryDateToGreaterValField = (
          <span className="validationMsg">
            Entry Date To must be greater than Entry Date From
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.EntryDateToGreaterValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.EntryDateToGreaterValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }
    //if Entry Date To is selected Then Make sure than Entry date Form is also selected Validation
    if (
      this.isNull(this.state.electModel.entryDateFrom) == true &&
      this.isNull(this.state.electModel.entryDateTo) == false
    ) {
      console.log("Select DOS From");
      myVal.selectEntryFromValField = (
        <span className="validationMsg">Select Entry Date From</span>
      );
      myVal.validation = true;
      if (myVal.validation == false) myVal.validation = false;
    } else {
      myVal.selectEntryFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }


    if (myVal.validation == true) {
      this.setState({ validationModel: myVal, loading: false });
      Swal.fire(
        "Something Wrong",
        "Please Select All Fields Properly",
        "error"
      );
      return;
    }
    await axios
      .post(this.url + "FindVisits", this.state.electModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          //console.log(row)
          newList.push({
            id: this.val(row.id),
            ischeck: (
              <input
                style={{ width: "20px", height: "20px" }}
                type="checkbox"
                id={row.visitID}
                name={row.visitID}
                onChange={this.toggleCheck}
                checked={this.isChecked(row.visitID)}
              />
              // <div class="lblChkBox">
              //   <input
              //     type="checkbox"
              //     id={row.visitID}
              //     name={row.visitID}
              //     onChange={this.toggleCheck}
              //     checked={this.isChecked(row.visitID)}
              //   />
              //   <label for={this.val(row.visitID)}>
              //     <span></span>
              //   </label>
              // </div>
            ),
            visitID: (
              <MDBBtn
                className={row.coverage === "S" ? "gridBtn" : "gridBlueBtn"}
                onClick={() => this.openVisitPopup("visit", row.visitID)}
              >
                {" "}
                {this.val(row.visitID)}
              </MDBBtn>
            ),
            dos: row.dos,
            accountNum: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPatientPopup("patient", row.patientID)}
              >
                {" "}
                {this.val(row.accountNum)}
              </MDBBtn>
            ),
            patient: row.patient,
            subscriberID: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.openPatientPlanPopup("patientplan", row.patientID)
                }
              >
                {" "}
                {this.val(row.subscriberID)}
              </MDBBtn>
            ),
            insurancePlanName: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.openPopup("insuranceplan", row.insurancePlanID)
                }
              >
                {" "}
                {this.val(row.planName)}
              </MDBBtn>
            ),
            visitEntryDate: row.visitEntryDate,
            practice: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPracticePopup(row.practiceID)}
              >
                {" "}
                {this.val(row.practice)}
              </MDBBtn>
            ),
            location: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openLocationPopup(row.locationID)}
              >
                {" "}
                {this.val(row.location)}
              </MDBBtn>
            ),
            provider: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openProviderPopup(row.providerID)}
              >
                {" "}
                {this.val(row.provider)}
              </MDBBtn>
            ),
            totalAmount: isNullOrUndefined(row.totalAmount)
              ? ""
              : "$" + row.totalAmount,
            validationMessage: this.val(row.validationMessage)
          });
        });

        //setTimeout(function () {
        this.setState({
          data: newList,
          initialData: response.data,
          loading: false
        });
        //}.bind(this), 3000);
      })
      .catch(error => {
        //setTimeout(function () {
        this.setState({ loading: false });
        //}.bind(this), 3000);
        if (error.response.status == 400) {
          Swal.fire("Error", error.response.data, "error");
        }
      });
  }

  searchElectronicSub = e => {
    e.preventDefault();

    if (
      this.state.electModel.receiverID === "" ||
      this.state.electModel.receiverID === null ||
      this.state.electModel.receiverID === undefined
    ) {
      Swal.fire({
        type: "error",
        text: "Please Select the Receiver"
      });
      return;
    }

    this.setState({ loading: true });
    this.searchElectronicSubmission();
    e.preventDefault();
  };

  selectALL = e => {
    let newValue = !this.state.selectedAll;
    this.setState({ ...this.state, selectedAll: newValue });

    let newList = [];
    this.selectedVisits = [];
    this.state.initialData.map((row, i) => {
      if (newValue === true) this.selectedVisits.push(Number(row.visitID));

      newList.push({
        id: row.id,
        //ischeck: <MDBInput type="checkbox" id={row.visitID} onChange={this.toggleCheck} checked={this.isChecked(row.visitID)} />,
        ischeck: (
          <input
            style={{ width: "20px", height: "20px" }}
            type="checkbox"
            id={row.visitID}
            name={row.visitID}
            onChange={this.toggleCheck}
            checked={this.isChecked(row.visitID)}
          />
          // <div class="lblChkBox">
          //   <input
          //     type="checkbox"
          //     id={row.visitID}
          //     name={row.visitID}
          //     onChange={this.toggleCheck}
          //     checked={this.isChecked(row.visitID)}
          //   />
          //   <label for={row.visitID}>
          //     <span></span>
          //   </label>
          // </div>
        ),
        visitID: (
          <MDBBtn
            className={row.coverage === "S" ? "gridBtn" : "gridBlueBtn"}
            // onClick={() => this.openVisitPopup("visit", row.visitID)}
            //   className="gridBlueBtn"
            onClick={() => this.openVisitPopup("visit", row.visitID)}
          >
            {" "}
            {this.val(row.visitID)}
          </MDBBtn>
        ),
        dos: row.dos,
        accountNum: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPatientPopup("patient", row.patientID)}
          >
            {" "}
            {this.val(row.accountNum)}
          </MDBBtn>
        ),
        patient: row.patient,
        subscriberID: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() =>
              this.openPatientPlanPopup("patientplan", row.patientID)
            }
          >
            {" "}
            {this.val(row.subscriberID)}
          </MDBBtn>
        ),
        insurancePlanName: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPopup("insuranceplan", row.insurancePlanID)}
          >
            {" "}
            {this.val(row.planName)}
          </MDBBtn>
        ),
        visitEntryDate: row.visitEntryDate,
        practice: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPracticePopup(row.practiceID)}
          >
            {" "}
            {this.val(row.practice)}
          </MDBBtn>
        ),
        location: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openLocationPopup(row.locationID)}
          >
            {" "}
            {this.val(row.location)}
          </MDBBtn>
        ),
        provider: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openProviderPopup(row.providerID)}
          >
            {" "}
            {this.val(row.provider)}
          </MDBBtn>
        ),
        totalAmount: isNullOrUndefined(row.totalAmount)
          ? ""
          : "$" + row.totalAmount,
        validationMessage: this.val(row.validationMessage)
      });
    });

    this.setState({
      data: newList,
      submitModel: { ...this.state.submitModel, visits: this.selectedVisits }
    });
  };

  toggleCheck = e => {
    let checkedArr = this.selectedVisits;
    let newList = [];

    checkedArr.filter(name => name === Number(e.target.id))[0]
      ? (checkedArr = checkedArr.filter(name => name !== Number(e.target.id)))
      : checkedArr.push(Number(e.target.id));

    this.selectedVisits = checkedArr;

    this.state.initialData.map((row, i) => {
      newList.push({
        id: row.id,
        // ischeck: <MDBInput type="checkbox" id={row.visitID} containerClass='mr-5' onChange={this.toggleCheck}
        //     checked={this.isChecked(row.visitID)} />,
        ischeck: (
          <input
            style={{ width: "20px", height: "20px" }}
            type="checkbox"
            id={row.visitID}
            name={row.visitID}
            onChange={this.toggleCheck}
            checked={this.isChecked(row.visitID)}
          />
          // <div class="lblChkBox">
          //   <input
          //     type="checkbox"
          //     id={row.visitID}
          //     name={row.visitID}
          //     onChange={this.toggleCheck}
          //     checked={this.isChecked(row.visitID)}
          //   />
          //   <label for={row.visitID}>
          //     <span></span>
          //   </label>
          // </div>
        ),
        visitID: (
          <MDBBtn
            className={row.coverage === "S" ? "gridBtn" : "gridBlueBtn"}
            // onClick={() => this.openVisitPopup("visit", row.visitID)}
            //   className="gridBlueBtn"
            onClick={() => this.openVisitPopup("visit", row.visitID)}
          >
            {" "}
            {this.val(row.visitID)}
          </MDBBtn>
        ),
        dos: row.dos,
        accountNum: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPatientPopup("patient", row.patientID)}
          >
            {" "}
            {this.val(row.accountNum)}
          </MDBBtn>
        ),
        patient: row.patient,
        subscriberID: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() =>
              this.openPatientPlanPopup("patientplan", row.patientID)
            }
          >
            {" "}
            {this.val(row.subscriberID)}
          </MDBBtn>
        ),
        insurancePlanName: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPopup("insuranceplan", row.insurancePlanID)}
          >
            {" "}
            {this.val(row.planName)}
          </MDBBtn>
        ),
        visitEntryDate: row.visitEntryDate,
        practice: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPracticePopup(row.practiceID)}
          >
            {" "}
            {this.val(row.practice)}
          </MDBBtn>
        ),
        location: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openLocationPopup(row.locationID)}
          >
            {" "}
            {this.val(row.location)}
          </MDBBtn>
        ),
        provider: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openProviderPopup(row.providerID)}
          >
            {" "}
            {this.val(row.provider)}
          </MDBBtn>
        ),
        totalAmount: isNullOrUndefined(row.totalAmount)
          ? ""
          : "$" + row.totalAmount,
        validationMessage: this.val(row.validationMessage)
      });
    });

    //this.setState({ data: newList });
    this.setState({
      data: newList,
      submitModel: { ...this.state.submitModel, visits: this.selectedVisits }
    });
  };

  opensubmitPlanPopup = id => {
    this.setState({ showPopup: true, id: id });
  };
  closesubmitPlanPopup = () => {
    $("#myModal").hide();
    this.setState({ showPopup: false });
    $("#searchID").click();
    this.searchElectronicSubmission();
  };

  submitCheckedVisits = e => {
    if (this.selectedVisits === null || this.selectedVisits.length === 0) {
      Swal.fire({
        type: "info",
        text: "Please Select the Visit(s)"
      });
      return;
    } else {
      this.setState({ loading: true });
      axios
        .post(this.url + "SubmitVisits", this.state.submitModel, this.config)
        .then(response => {
          if (isNullOrUndefined(response.data.errorMessage) === false) {
            this.setState({ loading: false });
            Swal.fire({
              type: "error",
              text: response.data.errorMessage
            });
          } else if (response.data.isisFileSubmitted === true) {
            this.setState({ loading: false });
            Swal.fire({
              type: "success",
              text: "File Submitted Successfully"
            }).then(sres => {
              this.searchElectronicSubmission();
            });
          } else {
            this.selectedVisits = [];
            this.setState({
              output: response.data,
              showPopup: true,
              loading: false
            });
          }
        })
        .catch(error => {
          this.setState({ loading: false });
          Swal.fire({
            type: "error",
            text: "Something Wrong.Please Try Again"
          });
        });
    }
  };

  async componentWillMount() {
    try {
      if (this.props.location.query.receiverID) {
        await this.setState({
          electModel: {
            ...this.setState.electModel,
            receiverID: this.props.location.query.receiverID
            // accountNUm:this.props.match.params.id ?this.props.match.params.id:null
          }
        });

        this.searchElectronicSubmission();
      }
    } catch {}
    // console.log("PAtient Info Props ; ",this.props.location.query);
    // if(this.props.location.query){
    //   await this.setState({
    //     electModel: {
    //       ...this.setState.electModel,
    //       accountNUm: this.props.patientInfo
    //         ? this.props.patientInfo.accNum
    //         : null,
    //         status : this.props.location.query.status
    // accountNUm:this.props.match.params.id ?this.props.match.params.id:null
    //     }
    //   });

    //   this.searchPatientCharge();

    // }else{
    //   await this.setState({
    //     electModel: {
    //       ...this.setState.electModel,
    //       accountNUm: this.props.patientInfo
    //         ? this.props.patientInfo.accNum
    //         : null
    //       // accountNUm:this.props.match.params.id ?this.props.match.params.id:null
    //     }
    //   });
    // }

    // try {
    //   if (this.props.patientInfo.accNum > 0) {
    //     await this.searchPatientCharge();
    //   }
    // } catch {}

    axios
      .get(this.url + "GetProfiles", this.config)
      .then(response => {
        this.setState({
          revData: response.data.receivers,
          electModel: {
            ...this.setState.electModel,
            receiverID:
              response.data.receivers.length == 2
                ? response.data.receivers[1].id
                : null
            // accountNUm:this.props.match.params.id ?this.props.match.params.id:null
          },
          submitModel: {
            ...this.setState.submitModel,
            receiverID:
              response.data.receivers.length == 2
                ? response.data.receivers[1].id
                : null
          }
        });
      })
      .catch(error => {});
  }

  handleChange = event => {

    var myName = event.target.name ? event.target.name : ""
    if (myName == "entryDateFrom" || myName == "entryDateTo") {
    } else {
      //Carret Position
      const caret = event.target.selectionStart
      const element = event.target
      window.requestAnimationFrame(() => {
        element.selectionStart = caret
        element.selectionEnd = caret
      })
      }


    this.setState({
      electModel: {
        ...this.state.electModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase()
      },
      submitModel: {
        ...this.state.submitModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase()
      }
    });
  };
  clearFields = event => {
    this.setState({
      electModel: this.electModel,
      selectedAll: false
    });
    this.selectedVisits = [];
    this.searchElectronicSubmission();
  };

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }


  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 0
        },
        {
          //label: <MDBInput type="checkbox" onChange={this.selectALL} />,
          label: (
            <input
              style={{ width: "20px", height: "20px" }}
              type="checkbox"
              id="selectAll"
              name="selectAll"
              checked={this.state.selectedAll == true ? true : false}
              onChange={this.selectALL}
            />
            // <div class="lblChkBox">
            //   <input
            //     type="checkbox"
            //     id="selectAll"
            //     name="selectAll"
            //     checked={this.state.selectedAll == true ? true : false}
            //     onChange={this.selectALL}
            //   />
            //   <label for="selectAll">
            //     <span></span>
            //   </label>
            // </div>
          ),
          field: "ischeck",
          sort: "",
          width: 50
        },

        {
          label: "VISIT #",
          field: "visitID",
          sort: "asc",
          width: 150
        },
        {
          label: "DOS",
          field: "dos",
          sort: "asc",
          width: 150
        },
        {
          label: "ACCOUNT #",
          field: "accountNum",
          sort: "asc",
          width: 150
        },
        {
          label: "PATIENT",
          field: "patient",
          sort: "asc",
          width: 150
        },
        {
          label: "SUBSCRIBER ID",
          field: "subscriberID",
          sort: "asc",
          width: 150
        },
        {
          label: "PLAN",
          field: "insurancePlanName",
          sort: "asc",
          width: 150
        },
        {
          label: "ENTRY DATE",
          field: "visitEntryDate",
          sort: "asc",
          width: 150
        },
        {
          label: "PRACTICE",
          field: "practice",
          sort: "asc",
          width: 150
        },
        {
          label: "LOCATION",
          field: "location",
          sort: "asc",
          width: 150
        },
        {
          label: "PROVIDER",
          field: "provider",
          sort: "asc",
          width: 150
        },
        {
          label: "AMOUNT",
          field: "totalAmount",
          sort: "asc",
          width: 80
        },
        {
          label: "VALIDATION MESSAGE",
          field: "validationMessage",
          sort: "asc",
          width: 400
        }
      ],
      rows: this.state.data
    };


    var entryDateFrom = this.state.electModel.entryDateFrom
      ? this.state.electModel.entryDateFrom.slice(0, 10)
      : "";
    var entryDateTo = this.state.electModel.entryDateTo
      ? this.state.electModel.entryDateTo.slice(0, 10)
      : "";

    let popup = "";

    if (this.state.showPopup) {
      popup = (
        <ElectronicSubmissionModel
          onClose={() => this.closesubmitPlanPopup}
          id={this.state.id}
          data={this.state.output}
        ></ElectronicSubmissionModel>
      );
    } else if (this.state.showPracticePopup) {
      popup = (
        <NewPractice
          onClose={() => this.closePracticePopup}
          practiceID={this.state.id}
        ></NewPractice>
      );
    } else if (this.state.showLocationPopup) {
      popup = (
        <NewLocation
          onClose={() => this.closeLocationPopup}
          id={this.state.id}
        ></NewLocation>
      );
    } else if (this.state.showProviderPopup) {
      popup = (
        <NewProvider
          onClose={() => this.closeProviderPopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (this.state.patientPopup) {
      popup = (
        <GPopup
          onClose={() => this.closePatientPopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else if (this.state.patientPopup) {
      popup = (
        <GPopup
          onClose={() => this.closePatientPopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else if (this.state.visitPopup) {
      popup = (
        <GPopup
          onClose={() => this.closeVisitPopUp}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else if (this.state.popupName === "insuranceplan") {
      popup = (
        <NewInsurancePlan
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewInsurancePlan>
      );
    } else if (this.state.popupName === "patientplan") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <div className="mainHeading row">
          <div className="col-md-6">
            <h1>ELECTRONIC SUBMISSION SEARCH</h1>
          </div>
          <div className="col-md-6 headingRight"></div>
        </div>

        <form onSubmit={event => this.searchElectronicSub(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div class="mf-6">
                <label>
                  Receiver <span className="redlbl"> *</span>{" "}
                </label>

                <div className="selectBoxValidate">
                  <select
                    name="receiverID"
                    id="receiverID"
                    value={this.state.electModel.receiverID}
                    onChange={this.handleChange}
                  >
                    {this.state.revData.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.description}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mf-6">
                {/* <label>Status</label>

                <select
                  // disabled
                  name="primaryStatus"
                  id="primaryStatus"
                  // value={this.state.searchModel.status}
                  onChange={this.handleChange}
                >
                  {status.map(s => (
                    <option key={s.value} value={s.value}>
                      {" "}
                      {s.display}{" "}
                    </option>
                  ))}{" "}
                </select> */}
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Account#"></Label>
                <Input
                  type="text"
                  name="accountNum"
                  id="accountNum"
                  value={this.state.electModel.accountNum}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Visit#"></Label>
                <Input
                  type="text"
                  name="visitID"
                  id="visitID"
                  value={
                    this.state.electModel.visitID == null
                      ? ""
                      : this.state.electModel.visitID
                  }
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Entry Date From"></Label>
                <div className="textBoxValidate">

                  <input
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="entryDateFrom"
                    id="entryDateFrom"
                    value={entryDateFrom}
                    onChange={this.handleChange}
                  />
                  {this.state.validationModel.entryDateFromValField}
                  {this.state.validationModel.selectEntryFromValField}
                </div>
              </div>
              <div className="mf-6">
                <Label name="Entry Date To"></Label>
                <div className="textBoxValidate">

                  <input
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="entryDateTo"
                    id="entryDateTo"
                    value={entryDateTo}
                    onChange={this.handleChange}
                  />
                  {this.state.validationModel.entryDateToValField}
                  {this.state.validationModel.EntryDateToGreaterValField}
                </div>
              </div>

            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Location"></Label>
                <Input
                  type="text"
                  name="location"
                  id="location"
                  value={this.state.electModel.location}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Provider"></Label>
                <Input
                  type="text"
                  name="provider"
                  id="provider"
                  value={this.state.electModel.provider}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Plan Name"></Label>
                <Input
                  type="text"
                  name="planName"
                  id="planName"
                  value={this.state.electModel.planName}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Payer ID"></Label>
                <Input
                  type="text"
                  name="payerID"
                  id="payerID"
                  max="9"
                  value={this.state.electModel.payerID}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Submit"
                  disabled={this.isDisabled(this.props.rights.add)}
                  onClick={() => this.submitCheckedVisits()}
                />
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-grey"
                  value="Clear"
                  onClick={() => this.clearFields()}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="ELECTRONIC SUBMISSION SEARCH RESULT"
            dataObj={this.state.electModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>

        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.electronicsSubmissionSearch,
          add: state.loginInfo.rights.electronicsSubmissionSubmit
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default withRouter(
  connect(mapStateToProps, matchDispatchToProps)(ElectronicSubmission)
);
