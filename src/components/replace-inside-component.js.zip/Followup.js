import React, { Component } from "react";

import facilityIcon from "../images/facility-icon.png";
import facilityHIcon from "../images/facility-icon-hover.png";
import locationIcon from "../images/location-icon.png";
import locationHIcon from "../images/location-icon-hover.png";
import provIcon from "../images/provider-icon.png";
import provHIcon from "../images/provider-icon-hover.png";
import LeftMenuItem from "./LeftMenuItem";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class Followup extends Component {
  constructor(props) {
    super(props);

   
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    // this.state = {
    //   leftNavigationMenus: setupLeftMenu
    // };
  }

  render() {
    console.log(this.props.leftNavigationMenus);

    let setupLeftMenu = [
      {
        Category: "",
        Icon: "",
        hIcon: "",
        expanded: true,
        SubCategories: [
          {
            SubCategory: "Plan Follow Up",
            Icon: facilityIcon,
            hIcon: facilityHIcon,
           to:"/Plan Follow Up",
           handler: () => this.props.selectTabPageAction("PLAN FOLLOW UP"),
           selected: this.props.selectedTabPage == "PLAN FOLLOW UP" ? true : false
          },
          {
            SubCategory: "Patient Follow Up",
            Icon: locationIcon,
            hIcon: locationHIcon,
            to:"/Patient Follow Up",
            handler: () => this.props.selectTabPageAction("PATIENT FOLLOW UP"),
            selected: this.props.selectedTabPage == "PATIENT FOLLOW UP" ? true : false
          },
          {
            SubCategory: "Group",
            Icon: provIcon,
            hIcon: provHIcon,
            to:"/Group",
            handler: () => this.props.selectTabPageAction("GROUP"),
            selected: this.props.selectedTabPage == "GROUP" ? true : false
          },
          {
            SubCategory: "Action",
            Icon: locationIcon,
            hIcon: locationHIcon,
            to:"/Action",
            handler: () => this.props.selectTabPageAction("ACTION"),
            selected: this.props.selectedTabPage == "ACTION" ? true : false
          },
          {
            SubCategory: "Reason",
            Icon: locationIcon,
            hIcon: locationHIcon,
            to:"/Reason",
            handler: () => this.props.selectTabPageAction("REASON"),
            selected: this.props.selectedTabPage == "REASON" ? true : false
          }
        ]
      }
    ];



    let leftMenuElements = [];
    setupLeftMenu.map((catogry, i) => {
      leftMenuElements.push(<LeftMenuItem data={catogry}></LeftMenuItem>);
    });
    return leftMenuElements;
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(Followup);
