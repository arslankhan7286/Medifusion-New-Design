import React  , {Component} from 'react';

export default class DummyLeftMenu extends Component{
    constructor(props){
        super(props);
    }

    render(){
        return(

            <React.Fragment>
                <div>Hello</div>
            </React.Fragment>
        )
    }
}

