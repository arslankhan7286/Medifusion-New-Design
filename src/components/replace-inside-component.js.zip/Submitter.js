import React, { Component } from "react";

import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Button from "./Input";
import Input from "./Input";
import Swal from "sweetalert2";
import axios from "axios";
import {
  MDBDataTable,
  MDBBtn,
  MDBTableHead,
  MDBTableBody,
  MDBTable
} from "mdbreact";
import GridHeading from "./GridHeading";
import NewPractice from "./NewPractice";
import NewTeam from "./NewTeam";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import $ from "jquery";
import NewSubmitter from "./NewSubmitter";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

import Hotkeys from "react-hot-keys";

class Submitter extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/submitter/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      name: "",
      submitterName: ""
    };

    this.state = {
      searchModel: this.searchModel,
      id: 0,
      data: [],
      showPopup: false,
      loading: false
    };

    this.searchSubmitter = this.searchSubmitter.bind(this);
    this.closeSubmitterPopup = this.closeSubmitterPopup.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.openSubmitterPopup = this.openSubmitterPopup.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    console.log("test:onKeyDown", keyName, e, handle);

    if (keyName == "alt+n") {
      // alert("search key")
      this.openSubmitterPopup(0);
      console.log(e.which);
    } else if (keyName == "alt+s") {
      this.searchSubmitter(e);
      console.log(e.which);
    } else if (keyName == "alt+c") {
      // alert("clear skey")
      this.clearFields(e);
      console.log(e.which);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    console.log("test:onKeyUp", e, handle);
    if (e) {
      console.log("event has been called", e);

      // this.onKeyDown(keyName, e , handle);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  //Search Team
  searchSubmitter = e => {
    this.setState({ loading: true });

    try {
      axios
        .post(this.url + "FindSubmitters", this.state.searchModel, this.config)
        .then(response => {
          console.log("log of FindSubmitter", response.data);

          let newList = [];
          response.data.map((row, i) => {
            console.log(row);
            newList.push({
              id: row.Id,
              name: (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() => this.openSubmitterPopup(row.id)}
                >
                  {row.name}
                </MDBBtn>
              ),
              submitterName: row.name,
              address: row.address,
              receiverName: row.receiverName
            });
            console.log("log of ID", row.id);
          });

          this.setState({ data: newList, loading: false });
        })
        .catch(error => {
          this.setState({ loading: false });
          if (error.response) {
            if (error.response.status) {
              Swal.fire("Unauthorized Access", "", "error");
              return;
            }
          } else if (error.request) {
            console.log(error.request);
            return;
          } else {
            console.log("Error", error.message);
            console.log(JSON.stringify(error));
            Swal.fire("Something went Wrong", "", "error");
            return;
          }
        });
    } catch {}

    e.preventDefault();
  };

  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  openSubmitterPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  closeSubmitterPopup = () => {
    $("#myModal").hide();
    this.setState({ showPopup: false });
  };
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "SUBMITTER NAME",
          field: "submitterName",
          sort: "asc",
          width: 270
        },
        {
          label: "ADDRESS",
          field: "address",
          sort: "asc",
          width: 270
        },
        {
          label: "RECEIVER NAME",
          field: "receiverName",
          sort: "asc",
          width: 270
        }
      ],
      rows: this.state.data
    };

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewSubmitter
          onClose={() => this.closeSubmitterPopup}
          SubmitterID={this.state.id}
        ></NewSubmitter>
      );
      // console.log("SUBMITTERID",this.props.SubmitterID)
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <Hotkeys
          keyName="alt+n"
          onKeyDown={this.onKeyDown.bind(this)}
          onKeyUp={this.onKeyUp.bind(this)}
        >
          <SearchHeading
            heading="SUBMITTER SEARCH"
            handler={() => this.openSubmitterPopup(0)}
          ></SearchHeading>
        </Hotkeys>

        <form onSubmit={this.searchSubmitter}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Name"></Label>
                <Input
                  max="20"
                  type="text"
                  name="name"
                  id="name"
                  value={this.state.searchModel.name}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Submitter Name"></Label>
                <Input
                  max="20"
                  type="text"
                  name="submitterName"
                  id="submitterName"
                  value={this.state.searchModel.organizationName}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>
          </div>
          <div className="row-form row-btn">
            <div className="mf-12">
              <Hotkeys
                keyName="alt+s"
                onKeyDown={this.onKeyDown.bind(this)}
                onKeyUp={this.onKeyUp.bind(this)}
              >
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                />
              </Hotkeys>

              <Hotkeys
                keyName="alt+c"
                onKeyDown={this.onKeyDown.bind(this)}
                onKeyUp={this.onKeyUp.bind(this)}
              >
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-grey"
                  value="Clear"
                  onClick={() => this.clearFields()}
                />
              </Hotkeys>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="SUBMITTER SEARCH RESULT"
            dataObj={this.state.searchModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>

        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(Submitter);
