import React, { Component } from 'react'
import LeftSubMenuItem from './LeftSubMenuItem'



import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction'




class LeftMenuItem extends Component {
    constructor(props) {
        super(props)

        this.state = {
            //data: this.props.data,
            expanded: this.props.data.expanded,
            // image: null
        }
    }

    SidebarCollapse = () => {
        this.setState(prevState => ({
            expanded: prevState.expanded ? false : true
        }));
    }


    LinkToFunc = componentName => {
        console.log("Component Name : " , componentName);
        var name = "/" + componentName;
        console.log("Props : ", this.props);
      };

    render() {

        let leftMenuElements = []

        let id = 1;
        if (this.props.data.Category) {
            leftMenuElements.push(
                <a  data-toggle="collapse" aria-expanded={this.state.expanded}
                    className={(this.state.expanded) ?
                        'bg-dark menu-heading list-group-item list-group-item-action flex-column align-items-start' :
                        'bg-dark menu-heading list-group-item list-group-item-action flex-column align-items-start collapsed'}
                    onClick={() => this.SidebarCollapse()}>
                    <div className="d-flex w-100 justify-content-start align-items-center">
                        <span className="fa fa-dashboard fa-fw mr-3"></span>
                        {this.props.data.Category}
                        <span className="submenu-icon ml-auto"></span>
                    </div>
                </a>
            )
        }

        this.props.data.SubCategories.map((subCategory, i) => {
            //console.log(this.state.expanded)

            leftMenuElements.push(

                <div id={this.props.data.SubCategory} className={(this.state.expanded) ? 'collapse show sidebar-submenu' : 'sidebar-submenu collapse'}>
                    <LeftSubMenuItem data={subCategory} expanded={this.state.expanded} to={subCategory.to}
                        handler={() => this.props.selectTabPageAction(subCategory.SubCategory.toUpperCase())}
                        ></LeftSubMenuItem>
                </div>

                // <div id={subCategory.SubCategory} className={(this.state.expanded) ? 'collapse show sidebar-submenu' : 'sidebar-submenu collapse'}>
                //     <a href="#" className={"list-group-item list-group-item-action bg-dark text-white nav-facility"}
                //         style={{ backgroundImage: `url(${subCategory.Icon})` }}
                //         onMouseEnter={this.mouseEnter} onMouseLeave={this.mouseLeave} onClick={() => subCategory.handler()}>
                //         {subCategory.SubCategory}
                //     </a>
                // </div>
            )
        })

        return (
            leftMenuElements
        )
    }
}


function mapStateToProps(state) {
    // console.log('state from leftmenu item');
    // console.log(state);
    return {

    };
}

function matchDispatchToProps(dispatch) {
    return bindActionCreators({ selectTabPageAction: selectTabPageAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(LeftMenuItem);


