import React, { Component } from "react";
import SearchHeading from "./SearchHeading";
import NewModifier from "./NewModifier";
import Label from "./Label";
import Input from "./Input";
import $ from "jquery";
import axios from "axios";
import { MDBDataTable } from "mdbreact";
import { MDBBtn } from "mdbreact";
import Swal from "sweetalert2";
import settingIcon from "../images/setting-icon.png";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import GridHeading from "./GridHeading";

class Modifier extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/Modifier/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      modifierCode: "",
      description: ""
    };

    this.state = {
      searchModel: this.searchModel,
      data: [],
      showPopup: false,
      id: 0,
      loading: false
    };
  }

  //search insurance plan address
  searchModifier = e => {
    this.setState({ loading: true });
    axios
      .post(this.url + "findmodifier", this.state.searchModel, this.config)
      .then(response => {
        console.log("Modifier Grid Search Response : ", response.data);
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            modifier: (
              <span>
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() => this.openModifierPopup(row.id)}
                >
                  {row.modifierCode}
                </MDBBtn>
              </span>
            ),
            description: row.description
          });
        });
        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false });
        Swal.fire("Something Wrong", "Please Check Server Connection", "error");
        let errorsList = [];
        if (error.response !== null && error.response.data !== null) {
          errorsList = error.response.data;
          console.log(errorsList);
        } else console.log(error);
      });
    e.preventDefault();
  };

  //handle Change
  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  //clear fields button
  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  //open facility popup
  openModifierPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  //close facility popup
  closeModifierPopup = () => {
    $("#myModal1").hide();
    this.setState({ showPopup: false });
  };

  //handle numeric change
  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }
  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "MODIFIER",
          field: "modifier",
          sort: "asc",
          width: 150
        },
        {
          label: "DESCRIPTION",
          field: "description",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.data
    };

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewModifier
          onClose={() => this.closeModifierPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        >
          >
        </NewModifier>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <SearchHeading
          heading="MODIFIERS SEARCH"
          handler={() => this.openModifierPopup(0)}
          disabled={this.isDisabled(this.props.rights.add)}
        >
          >
        </SearchHeading>
        <form onSubmit={event => this.searchModifier(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Modifier"></Label>
                <Input
                  type="text"
                  name="modifierCode"
                  id="modifierCode"
                  max="2"
                  value={this.state.searchModel.modifierCode}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Description"></Label>
                <Input
                  max="100"
                  type="text"
                  name="description"
                  id="description"
                  value={this.state.searchModel.description}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />

                <Input
                  type="button"
                  name="clear"
                  id="clear"
                  className="btn-grey"
                  value="Clear"
                  onClick={event => this.clearFields(event)}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="MODIFIER SEARCH RESULT"
            disabled={this.isDisabled(this.props.rights.export)}
            dataObj={this.state.searchModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.modifiersSearch,
          add: state.loginInfo.rights.modifiersCreate,
          update: state.loginInfo.rights.modifiersEdit,
          delete: state.loginInfo.rights.modifiersDelete,
          export: state.loginInfo.rights.modifiersExport,
          import: state.loginInfo.rights.modifiersImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(Modifier);
