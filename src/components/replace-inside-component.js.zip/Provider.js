import React, { Component } from "react";
import { MDBBtn } from "mdbreact";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Input from "./Input";
import $ from "jquery";
import axios from "axios";
import { MDBDataTable } from "mdbreact";
import NewProvider from "./NewProvider";
import settingIcon from "../images/setting-icon.png";
import Swal from "sweetalert2";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import GridHeading from "./GridHeading";

class Provider extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/provider/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      name: "",
      lastName: "",
      firstName: "",
      npi: "",
      ssn: "",
      taxonomyCode: ""
    };

    this.state = {
      searchModel: this.searchModel,
      data: [],
      showPopup: false,
      id: 0
    };

    //binding functions to this class
    this.searchProvider = this.searchProvider.bind(this);
    this.clearFields = this.clearFields.bind(this);
    this.openProviderPopup = this.openProviderPopup.bind(this);
    this.closeProviderPopup = this.closeProviderPopup.bind(this);
    this.onPaste = this.onPaste.bind(this);
  }

  searchProvider = e => {
    this.setState({ loading: true });

    axios
      .post(this.url + "findproviders", this.state.searchModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            name: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openProviderPopup(row.id)}
              >
                {row.name}{" "}
              </MDBBtn>
            ),
            lastName: row.lastName,
            firstName: row.firstName,
            npi: row.npi,
            ssn: row.ssn,
            taxomonyCode: row.taxonomyCode,
            address: row.address,
            officePhoneNum: row.officePhoneNum
          });
        });

        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false });

        if (error.response) {
          if (error.response.status) {
            Swal.fire("Unauthorized Access", "", "error");
            return;
          }
        } else if (error.request) {
          return;
        } else {
          Swal.fire("Something went Wrong", "", "error");
          return;
        }
      });

    e.preventDefault();
  };

  handleChange = event => {
    event.preventDefault();

    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  //clear fields button
  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  //open facility popup
  openProviderPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  //close facility popup
  closeProviderPopup = () => {
    $("#providerModal").hide();
    this.setState({ showPopup: false });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  onPaste(event) {
    var x = event.target.value;
    x = x.trim();
    var regex = /^[0-9]+$/;
    if (x.length == 0) {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          [event.target.name]: x
        }
      });
      return;
    }

    if (!x.match(regex)) {
      Swal.fire("Error", "Should be Number", "error");
      return;
    } else {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          [event.target.name]: x
        }
      });
    }
    return;
  }
  //Render Method
  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          width: 270
        },
        {
          label: "FIRST NAME",
          field: "firstName",
          sort: "asc",
          width: 200
        },
        {
          label: "NPI",
          field: "npi",
          sort: "asc",
          width: 100
        },
        {
          label: "SSN",
          field: "ssn",
          sort: "asc",
          width: 150
        },
        {
          label: "TAXONOMY CODE",
          field: "taxomonyCode",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDRESS, CITY, STATE, ZIP",
          field: "address",
          sort: "asc",
          width: 150
        },
        {
          label: "OFFICE PHONE #",
          field: "officePhoneNum",
          sort: "asc",
          width: 100
        }
      ],
      rows: this.state.data
    };

    let popup = "";

    if (this.state.showPopup) {
      popup = (
        <NewProvider
          onClose={() => this.closeProviderPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        >
          >
        </NewProvider>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }
    return (
      <React.Fragment>
        {spiner}
        <SearchHeading
          heading="PROVIDER SEARCH"
          handler={() => this.openProviderPopup(0)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></SearchHeading>

        <form onSubmit={event => this.searchProvider(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Name"></Label>

                <Input
                  type="text"
                  name="name"
                  id="name"
                  max="60"
                  value={this.state.searchModel.name}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Last Name"></Label>
                <Input
                  max="35"
                  type="text"
                  name="lastName"
                  id="lastName"
                  value={this.state.searchModel.lastName}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="First Name"></Label>
                <Input
                  type="text"
                  name="firstName"
                  id="firstName"
                  max="35"
                  value={this.state.searchModel.firstName}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="NPI"></Label>
                <input
                  type="text"
                  name="npi"
                  id="npi"
                  maxLength="10"
                  value={this.state.searchModel.npi}
                  onChange={() => this.handleChange}
                  onKeyPress={event => this.handleNumericCheck(event)}
                  onInput={this.onPaste}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="SSN"></Label>
                <input
                  type="text"
                  name="ssn"
                  id="ssn"
                  maxLength="9"
                  value={this.state.searchModel.ssn}
                  onChange={() => this.handleChange}
                  onKeyPress={event => this.handleNumericCheck(event)}
                  onInput={this.onPaste}
                />
              </div>
              <div className="mf-6">
                <Label name="Taxonomy Code"></Label>
                <Input
                  type="text"
                  name="taxonomyCode"
                  id="taxonomyCode"
                  max="10"
                  value={this.state.searchModel.taxonomyCode}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />

                <Input
                  type="button"
                  name="clear"
                  id="clear"
                  className="btn-grey"
                  value="Clear"
                  onClick={event => this.clearFields(event)}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="PROVIDER SEARCH RESULT"
            disabled={this.isDisabled(this.props.rights.export)}
            dataObj={this.state.searchModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.providerSearch,
          add: state.loginInfo.rights.providerCreate,
          update: state.loginInfo.rights.providerEdit,
          delete: state.loginInfo.rights.providerDelete,
          export: state.loginInfo.rights.providerExport,
          import: state.loginInfo.rights.providerImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(Provider);
