import React, { Component } from "react";
import {NavLink} from "react-router-dom";

import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { selectTabPageAction } from '../actions/selectTabAction'



export class LeftSubMenuItem extends Component {
  constructor(props) {
    super(props);

    this.state = {
      image: this.props.data.selected
        ? this.props.data.hIcon
        : this.props.data.Icon,
      expanded: this.props.expanded,
      selected: this.props.data.selected,
      mySelected:false
    };
  }

  // mouseEnter = () => {
  //   console.log("Mouse Enter Props : " , this.props.data.selected)
  //   if (this.props.data.selected == false) {
  //     this.setState({ image: this.props.data.hIcon });
  //   }else{
  //     this.setState({ image: this.props.data.hIcon });
  //   }
  // };

  // mouseLeave = () => {
  //   console.log("Mouse Leave Props : " , this.props.data.selected)
  //   if (this.props.data.selected == false) {
  //     this.setState({ image: this.props.data.Icon });
  //   }else{
  //     this.setState({ image: this.props.data.hIcon });
  //   }
  // };

  //Khizer Code
  mouseEnter = () => {
    if (this.props.data.selected == false) {
      this.setState({ image: this.props.data.Icon });
    }else{
      this.setState({ image: this.props.data.Icon });
    }
  };

  mouseLeave = () => {
    if (this.props.data.selected == false) {
      this.setState({ image: this.props.data.Icon });
    }else{
      this.setState({ image: this.props.data.hIcon });
    }
  };

  click = () =>{
    this.setState({mySelected: !this.state.mySelected})
  }

  render() {

    // var image = this.props.data.selected ? this.props.data.hIcon:this.state.image;

    return (
      <React.Fragment>
        {/* // <div id={this.props.data.SubCategory} className={(this.state.expanded) ? 'collapse show sidebar-submenu' : 'sidebar-submenu collapse'}> */}
        {/* <a
          href="#"
          className={
            this.state.selected
              ? "list-group-item list-group-item-action bg-dark text-white nav-facility active"
              : "list-group-item list-group-item-action bg-dark text-white nav-facility"
          }
          style={{ backgroundImage: `url(${this.state.image})` }}
          onMouseEnter={this.mouseEnter}
          onMouseLeave={this.mouseLeave}
          // onClick={() => this.props.data.handler()}
          // onClick={() => this.props.handler()}
        >
          {this.props.data.SubCategory}
        </a> */}


       <div 
         >
       <NavLink
          to={this.props.to}
          className={
            this.state.mySelected
              ? "list-group-item list-group-item-action bg-dark text-white nav-facility active nav-link"
              : "list-group-item list-group-item-action bg-dark text-white nav-facility nav-link"
          }
          style={{ backgroundImage: `url(${this.props.data.selected == false ? this.props.data.Icon : this.state.image})` }}
          onMouseEnter={this.mouseEnter}
          onMouseLeave={this.mouseLeave}
          // onClick={this.click}
          onClick={() => this.props.handler()}
        >
          {this.props.data.SubCategory}
        </NavLink>
       </div>
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
 
  return {
      leftNavigationMenus: state.leftNavigationMenus
  };
}

function matchDispatchToProps(dispatch) {
  return bindActionCreators({ selectTabPageAction: selectTabPageAction }, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(LeftSubMenuItem);
