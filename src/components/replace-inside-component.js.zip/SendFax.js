import React, { Component } from "react";
import { MDBDataTable, MDBBtn, MDBInput } from "mdbreact";
import axios from "axios";
import { isNullOrUndefined } from "util";
import $ from "jquery";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import Input from "./Input";
import Swal from "sweetalert2";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class SendFax extends Component {
    constructor(props) {
        super(props);
        this.url = process.env.REACT_APP_URL + "/FAX/";

        //Authorization Token
        this.config = {
            headers: {
                Authorization: "Bearer  " + this.props.loginObject.token,
                Accept: "*/*"
            }
        };

        this.faxModel = {

            pcp: "",
            patientName: this.props.faxModel.patientName,
            patientDOB: this.props.faxModel.patientDOB,
            serviceName: this.props.faxModel.serviceName,
            provider: "",
            faxNumber: this.props.faxModel.faxNumber,
            pCBProviderID: this.props.faxModel.pcpproviderid,
            providerID: this.props.faxModel.providerid,
            referralDocumentFileName: this.props.faxModel.referralDocumentFileName
        }

        this.state = {
            faxModel: this.faxModel,
            data: [],
            popupName: "",
            loading: false

        };
        this.handleChange = this.handleChange.bind(this);
        this.sendFax = this.sendFax.bind(this);

    }


    handleChange(event) {

        console.log(event.target.name, event.target.value)
        this.setState({
            faxModel: {
                ...this.state.faxModel,
                [event.target.name]: event.target.value
            },
        });
    }

    sendFax() {
        console.log(this.state.faxModel);
        this.setState({ loading: true })
        axios
            .post(this.url + "SendFax", this.state.faxModel, this.config)
            .then(response => {
                Swal.fire("Record Saved Successfully", "", "success");

                this.setState({ loading: false });
                this.sendFaxCount = 0;

            })
            .catch(error => {
                this.sendFaxCount = 0;

                this.setState({ loading: false });
                try {
                    if (error.response) {
                        if (error.response.status) {
                            if (error.response.status == 401) {
                                Swal.fire("Unauthorized Access", "", "error");
                                return;
                            } else if (error.response.status == 404) {
                                Swal.fire("Not Found", "Failed With Status Code 404", "error");
                                return;
                            } else if (error.response.status == 400) {

                                Swal.fire("Something Wrong", error.response.data, "error");
                                return;


                            }
                        }
                    } else {
                        Swal.fire("Something Wrong", "Please Try Again", "error");
                        return;
                    }


                } catch { }
            });
    }


    render() {


        console.log("Fax Model as props", this.props.faxModel);
        console.log("Providers as Props", this.props.userProviders);
        console.log("Service Name", this.props.referralFor);

        const referralFor = [
            { value: "", display: "Please Select" },
            { value: "Most Recent Wellness Visit", display: "MOST RECENT WELLNESS VISIT" },
            { value: "Medical Clearance for Speech Therapy", display: "MEDICAL CLEARANCE FOR SPEECH THERAPY" },
            { value: "Medical Clearance for Hearing Aids", display: "MEDICAL CLEARANCE FOR HEARING AIDS" },
            { value: "Most Recent Audiological Evaluation", display: "MOST RECENT AUDIOLOGICAL EVALUATION" },
            { value: "Dizziness/Balance Testing", display: "DIZZINESS/BALANCE TESTING" },
            { value: "Most Recent Speech Language Evaluation", display: "MOST RECENT SPEECH LANGUAGE EVALUATION" },
            { value: "Auditory Brainstem Response Results", display: "AUDITORY BRAINSTEM RESPONSE RESULTS" },
        ];

        var dob = this.state.faxModel.patientDOB ? this.state.faxModel.patientDOB.slice(0, 10) : "";
        let spiner = "";
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            );
        }

        return (
            <React.Fragment>
                <div
                    id="faxModal"
                    className="modal fade bs-example-modal-new show"
                    tabIndex="-1"
                    role="dialog"
                    aria-labelledby="myLargeModalLabel"
                    style={{ display: "block", paddingRight: "17px" }}
                >
                    <div className="modal-dialog modal-lg">
                        {spiner}
                        <div className="modal-content" style={{ overflow: "hidden" }}>
                            <button
                                onClick={this.props.onClose()}
                                className="close"
                                data-dismiss="modal"
                                aria-label="Close"
                            >
                                <span aria-hidden="true"></span>
                            </button>
                            <div className="modal-header">
                                <div className="mf-12">
                                    <div className="row">
                                        <div className="mf-6 popupHeading">
                                            <h1 className="modal-title">
                                                Send Fax
                                            </h1>
                                        </div>
                                        <div className="mf-6 popupHeadingRight"></div>
                                    </div>
                                </div>
                            </div>

                            <div
                                className="modal-body"
                                style={{ maxHeight: this.state.maxHeight }}
                            >
                                <div className="mainTable">
                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>
                                                Patient Name
                                        {/* <span className="redlbl"> *</span> */}
                                            </label>

                                            <div className="textBoxValidate">
                                                <Input

                                                    type="text"
                                                    value={this.state.faxModel.patientName}
                                                    disabled={true}
                                                    name="patientName"
                                                    id="patientName"
                                                    max="60"
                                                    onChange={() => this.handleChange}
                                                />
                                            </div>
                                        </div>

                                        <div className="mf-6">
                                            <label>
                                                Patient DOB
                                                {/* <span className="redlbl"> *</span> */}
                                            </label>

                                            <div className="textBoxValidate">
                                                <input
                                                    type="date"
                                                    min="1900-01-01"
                                                    max="9999-12-31"
                                                    name="patientDOB"
                                                    min="1900-01-01"
                                                    max="9999-12-31"
                                                    disabled={true}
                                                    value={dob}
                                                    onChange={this.handleAuthChange}
                                                ></input>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>
                                                Provider
                                        {/* <span className="redlbl"> *</span> */}
                                            </label>

                                            <div className="textBoxValidate">
                                                <select
                                                    style={{ width: "100%" }}
                                                    // className={
                                                    // this.state.validationModel.providerIDValField
                                                    // ? this.errorField
                                                    // : ""
                                                    // }
                                                    name="providerID"
                                                    id="providerID"
                                                    disabled={true}
                                                    value={this.state.faxModel.providerID}
                                                    onChange={this.handleChange}
                                                >
                                                    {this.props.userProviders.map((s) => (
                                                        <option key={s.id} value={s.id}>
                                                            {s.description}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>

                                        <div className="mf-6">
                                            <label>
                                                Service Name
                                                {/* <span className="redlbl"> *</span> */}
                                            </label>

                                            <div className="textBoxValidate">
                                                <select
                                                    style={{ width: "100%" }}
                                                    name="serviceName"
                                                    id="serviceName"
                                                    disabled={true}
                                                    value={this.state.faxModel.serviceName}
                                                    onChange={this.handleChange}
                                                >
                                                    {this.props.referralFor.map((s) => (
                                                        <option key={s.value} value={s.value}>
                                                            {s.display}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row-form">
                                        <div className="mf-6">
                                            <label>
                                                Fax Number
                                        {/* <span className="redlbl"> *</span> */}
                                            </label>

                                            <div className="textBoxValidate">
                                                <Input

                                                    type="text"
                                                    value={this.state.faxModel.faxNumber}
                                                    name="faxNumber"
                                                    id="faxNumber"
                                                    max="60"
                                                    onChange={() => this.handleChange}
                                                />
                                            </div>
                                        </div>

                                        <div className="mf-6">
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <div className="mainTable">
                                        <div className="row-form row-btn">
                                            <div className="mf-12">
                                                <input
                                                    type="button"
                                                    value="Send"
                                                    className="btn-blue"
                                                    onClick={this.sendFax}

                                                ></input>

                                                <input
                                                    type="button"
                                                    value="Cancel"
                                                    id="btnCancel"
                                                    className="btn-grey"
                                                    data-dismiss="modal"
                                                    onClick={
                                                        this.props.onClose
                                                            ? this.props.onClose()
                                                            : () => this.props.onClose()
                                                    }
                                                ></input>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* {popup} */}
            </React.Fragment>
        );
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page", state);
    return {
        selectedTab:
            state.selectedTab !== null ? state.selectedTab.selectedTab : "",
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject: state.loginToken
            ? state.loginToken
            : { toekn: "", isLogin: false },
        userInfo: state.loginInfo
            ? state.loginInfo
            : { userPractices: [], name: "", practiceID: null }
    };
}
function matchDispatchToProps(dispatch) {
    return bindActionCreators(
        {
            selectTabPageAction: selectTabPageAction,
            loginAction: loginAction,
            selectTabAction: selectTabAction
        },
        dispatch
    );
}

export default connect(mapStateToProps, matchDispatchToProps)(SendFax);
