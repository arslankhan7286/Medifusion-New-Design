import React, { Component } from "react";
import { Tabs, Tab } from "react-tab-view";
import $ from "jquery";
import Swal from "sweetalert2";
import axios from "axios";
import { tsExpressionWithTypeArguments } from "@babel/types";
import { MDBDataTable } from "mdbreact";
import settingsIcon from "../images/setting-icon.png";

import Dropdown from "react-dropdown";
//redux
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class NewHistoryPractice extends Component {
  constructor(props) {
    super(props);
    // http://192.168.104.105/medi/api/Practice/FindPracticeAudit/3
    this.FindHistoryURL = process.env.REACT_APP_URL + "/Practice/";
    // this.errorField = "errorField";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.state = {
      data: [],
      maxHeight: "361",
      rowId: ""
    };
  }
  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
    $(document).ready(function() {});
  }

  componentDidMount() {
    console.log("ID : ", this.props.id);
    this.setModalMaxHeight($(".modal"));
    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function() {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    if (this.props.historyID > 0) {
      axios
        .get(
          // this.FindHistoryURL
          this.props.apiURL +
            // "FindPracticeAudit/"
            "FindAudit/" +
            this.props.historyID,
          this.config
        )
        .then(response => {
          console.log("Find Practice Audit : ", response);
          let newList = [];
          response.data.map((row, i) => {
            console.log(row);
            newList.push({
              id: row.id,
              columnName: row.columnName,
              currentValue: row.currentValue,
              newValue: row.newValue,
              // hostName: row.hostName,
              addedBy: row.addedBy,
              addedDate: row.addedDate
                ? row.addedDate.slice(5, 7) +
                  "/" +
                  row.addedDate.slice(8, 10) +
                  "/" +
                  row.addedDate.slice(0, 4) +
                  " " +
                  row.addedDate.slice(11, 19)
                : ""
            });
          });

          this.setState({ data: newList, loading: false });
        })
        .catch(error => {
          this.setState({ loading: false });
          if (error.response) {
            console.log(error.response);
            if (error.response.status) {
              Swal.fire("Unauthorized Access", "", "error");
            }
          } else if (error.request) {
            console.log(error.request);
          } else {
            console.log("Error", error.message);
          }
          //console.log(JSON.stringify(error));
        });
    }
  }

  render() {
    console.log("Practice ID:", this.props.historyID);
    console.log("API ", this.props.apiURL);
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "FIELD NAME",
          field: "columnName",
          sort: "asc",
          width: 150
        },
        {
          label: "CURRENT VALUE",
          field: "currentValue",
          sort: "asc",
          width: 270
        },
        {
          label: "NEW VALUE",
          field: "newValue",
          sort: "asc",
          width: 200
        },
        // {
        //     label: 'HOST NAME',
        //     field: 'hostName',
        //     sort: 'asc',
        //     width: 100
        // },
        {
          label: "ADDED BY",
          field: "addedBy",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDED DATE",
          field: "addedDate",
          sort: "asc",
          width: 100
        }
      ],
      rows: this.state.data
    };
    return (
      <div
        id="HistoryModal"
        className="modal fade bs-example-modal-new show"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="myLargeModalLabel"
        aria-hidden="true"
        style={{ display: "block", paddingRight: "17px" }}
      >
        <div className="modal-dialog modal-lg">
          {/* <button
                        // onClick={this.props.onClose()}
                        type="button"
                        className="close"
                        data-dismiss="modal"
                        aria-label="Close">
                        <span aria-hidden="true"></span>
                    </button> */}

          <div className="modal-content" style={{ overflow: "hidden" }}>
            <button
              onClick={
                this.props.onClose
                  ? this.props.onClose()
                  : () => this.props.onClose()
              }
              className="close"
              data-dismiss="modal"
              aria-label="Close"
            />
            <div className="mainTable fullWidthTable text-nowrap">
              <div className="mainHeading row">
                <div className="col-md-8">
                  <h1>History</h1>
                </div>
                <div className="col-md-4 headingRight"></div>
              </div>
              <div className="row-form">
                <div className="mf-12">
                  <div className="mf-12 table-grid mt-15">
                    {/* <GridHeading Heading="AGING REPORT 1"></GridHeading> */}

                    <div className="tableGridContainer text-nowrap">
                      <MDBDataTable
                        responsive={true}
                        striped
                        searching={false}
                        data={data}
                        displayEntries={false}
                        sortable={true}
                        scrollX={false}
                        scrollY={false}
                      />
                    </div>
                  </div>
                </div>
                <button
                  id="btnCancel"
                  className="btn-blue"
                  data-dismiss="modal"
                  onClick={this.props.onClose()}
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.practiceSearch,
          add: state.loginInfo.rights.practiceCreate,
          update: state.loginInfo.rights.practiceEdit,
          delete: state.loginInfo.rights.practiceDelete,
          export: state.loginInfo.rights.practiceExport,
          import: state.loginInfo.rights.practiceImport
        }
      : []
    //   taxonomyCode: state.loginInfo.taxonomy
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(NewHistoryPractice);

// export default NewHistoryPractice;
