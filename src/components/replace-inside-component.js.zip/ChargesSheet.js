import React, { Component } from "react";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import GPopup from "./GPopup";

import NewChargesSheet from "./NewChargesSheet";
import { MDBDataTable, MDBBtn } from "mdbreact";
import GridHeading from "./GridHeading";
import Swal from "sweetalert2";

import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Input from "./Input";
import axios from "axios";
import $ from "jquery";

import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

import Hotkeys from "react-hot-keys";
class ChargesSheet extends Component {
  constructor(props) {
    super(props);

    this.AddChargesSheet = process.env.REACT_APP_URL + "/DataMigration/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      externalPatientID: "",
      accountNumber: "",
      paymentProcessed: ""
    };

    this.state = {
      searchModel: this.searchModel,
      popupName: "",
      showPopup: false,
      data: [],
      loading: false,
      table: [],
      Columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "FILENAME",
          field: "fileName",
          sort: "asc",
          width: 100
        },
        {
          label: "PATIENT NAME",
          field: "patientName",
          sort: "asc",
          width: 100
        },
        {
          label: "EXTERNAL PATIENT ID",
          field: "externalPatientID",
          sort: "asc",
          width: 150
        },
        {
          label: "ACCOUNT #",
          field: "accountNumber",
          sort: "asc",
          width: 100
        },
        {
          label: "PROVIDER",
          field: "provider",
          sort: "asc",
          width: 100
        },
        {
          label: "INSURANCE NAME",
          field: "insuranceName",
          sort: "asc",
          width: 150
        },
        {
          label: "VISIT #",
          field: "visitID",
          sort: "asc",
          width: 150
        },
        {
          label: "DOS",
          field: "dos",
          sort: "asc",
          width: 270
        },
        {
          label: "CPT",
          field: "cpt",
          sort: "asc",
          width: 200
        },
        {
          label: "MODIFIERS",
          field: "modifiers",
          sort: "asc",
          width: 100
        },
        {
          label: "POS",
          field: "pos",
          sort: "asc",
          width: 100
        },
        {
          label: "CHARGES",
          field: "charges",
          sort: "asc",
          width: 100
        },
        {
          label: "INSURANCE PAYMENT",
          field: "insurancePayment",
          sort: "asc",
          width: 100
        },
        {
          label: "PATIENT PAYMENT",
          field: "patientPayment",
          sort: "asc",
          width: 100
        },
        {
          label: "ADJUSTMENT",
          field: "adjustments",
          sort: "asc",
          width: 100
        },
        {
          label: "PROCESSED PAYMENTS",
          field: "paymentProcessed",
          sort: "asc",
          width: 100
        }
      ]
    };

    this.openPopUp = this.openPopUp.bind(this);
    this.openNewChargesSheetPopUp = this.openNewChargesSheetPopUp.bind(this);
    this.closeNewChargesSheetPopUp = this.closeNewChargesSheetPopUp.bind(this);
    this.closePopup = this.closePopup.bind(this);
    this.searchChargesSheet = this.searchChargesSheet.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    console.log("test:onKeyDown", keyName, e, handle);

    if (keyName == "alt+n") {
      // alert("search key")
      this.openNewPatientSheetPopUp(0);
      console.log(e.which);
    } else if (keyName == "alt+s") {
      this.searchPatientSheet(e);
      console.log(e.which);
    } else if (keyName == "alt+c") {
      // alert("clear skey")
      this.clearFields(e);
      console.log(e.which);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    console.log("test:onKeyUp", e, handle);
    if (e) {
      console.log("event has been called", e);

      // this.onKeyDown(keyName, e , handle);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  isNull = value => {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select" ||
      value === -1
    )
      return true;
    else return false;
  };

  componentWillMount() {
    this.setState({
      table: {
        columns: this.state.Columns,
        rows: this.state.data
      }
    });
  }

  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  ///////////////------------OPEN/CLOSE POP UPs

  openNewChargesSheetPopUp(id) {
    this.setState({ showPopup: true, id: id });
    console.log(id);
  }

  closeNewChargesSheetPopUp = () => {
    $("#myModal").hide();
    this.setState({ showPopup: false });
  };

  openPopUp = (name, id) => {
    this.setState({ popupName: name, id: id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  ///////////////------------CHANGE HANDLERS

  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase()
      }
    });
    console.log(this.state.searchModel);
  };

  ///////////////------------SEARCH PATIENT DATA

  async searchChargesSheet(e) {
    e.preventDefault();
    this.setState({ loading: true });
    console.log("Search model", this.state.searchModel);
    await axios
      .post(
        this.AddChargesSheet + "FindExternalCharges",
        this.state.searchModel,
        this.config
      )
      .then(response => {
        console.log("Response", response);
        let newList = [];
        let AccountNum = "";
        let Provider = "";
        let visitID = "";

        response.data.map((row, i) => {
          console.log("charges data received ROW", row);

          ///////////////------------ACCOUNT NUMBER EXCEPTION

          if (!this.isNull(row.accountNum)) {
            AccountNum = (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPopUp("patient", row.patientID)}
              >
                {row.accountNum}
              </MDBBtn>
            );
          } else {
            AccountNum = null;
          }

          ///////////////------------PROVIDER EXCEPTION

          if (!this.isNull(row.patientID)) {
            Provider = (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPopUp("providerName", row.providerID)}
              >
                {row.provider}
              </MDBBtn>
            );
          } else if (!this.isNull(row.provider)) {
            Provider = row.provider;
          } else {
            Provider = null;
          }

          ///// Visit ID popup
          if (!this.isNull(row.visitID)) {
            visitID = (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPopUp("visit", row.visitID)}
              >
                {row.visitID}
              </MDBBtn>
            );
          } else {
            visitID = null;
          }

          newList.push({
            id: row.id,
            fileName: row.fileName,
            patientName: row.externalPatientName,
            externalPatientID: row.externalPatientID,
            accountNumber: AccountNum,
            provider: Provider,
            insuranceName: row.insuranceName,
            visitID: visitID,
            dos: row.dos,
            cpt: row.cpt,
            modifiers: row.modifiers,
            pos: row.pos,
            charges: "$" + row.charges,
            insurancePayment: "$" + row.insurancePayment,
            patientPayment: "$" + row.patientPayment,
            adjustments: row.adjustments,
            paymentProcessed: row.paymentProcessed
          });
        });

        this.setState({
          data: newList,
          loading: false,
          table: {
            columns: this.state.Columns,
            rows: newList
          }
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });
  }
  processPayments(id) {
    this.setState({ loading: true });
    axios
      .post(this.AddChargesSheet + "AddPaymentChecks", {}, this.config)
      .then(response => {
        this.setState({
          loading: false
        });
        Swal.fire("Processed Successfully", "", "success").then(sres => { });
      })
      .catch(error => {
        this.setState({ loading: false });

        try {
          if (error.response) {
            if (error.response.status) {
              if (error.response.status == 401) {
                Swal.fire("Unauthorized Access", "", "error");
                return;
              } else if (error.response.status == 404) {
                Swal.fire("Not Found", "Failed With Status Code 404", "error");
                return;
              } else if (error.response.status == 400) {
                Swal.fire("Not Found", error.response.data, "error");
                return;
              }
            }
          } else {
            Swal.fire("Something went Wrong", "", "error");
            return;
          }
        } catch { }
      });
  }
  render() {
    ///////////////------------POP UP SELECTION

    const paymentProcessed = [
      { value: "", display: "All" },
      { value: "P", display: "Yes" },
      { value: "NP", display: "No" },
      { value: "F", display: "Payment Not Received" }
    ];

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewChargesSheet
          onClose={() => this.closeNewChargesSheetPopUp}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewChargesSheet>
      );
    } else if (this.state.popupName === "providerName") {
      popup = (
        <NewProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (this.state.popupName === "patient") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else if (this.state.popupName === "visit") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    ///////////////------------LOADING SPINER

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <Hotkeys
          keyName="alt+n"
          onKeyDown={this.onKeyDown.bind(this)}
          onKeyUp={this.onKeyUp.bind(this)}
        >
          <SearchHeading
            heading="CHARGES SHEET SEARCH"
            handler={() => this.openNewChargesSheetPopUp(0)}
            handler1={() => this.processPayments(0)}
            disabled={this.isDisabled(this.props.rights.add)}
          ></SearchHeading>
        </Hotkeys>

        <form onSubmit={this.searchChargesSheet}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Account #"></Label>
                <Input
                  type="text"
                  name="accountNumber"
                  id="accountNumber"
                  max="20"
                  value={this.state.searchModel.accountNumber}
                  onChange={() => this.handleChange}
                />
              </div>

              <div className="mf-6">
                <Label name="External Patient ID"></Label>
                <Input
                  type="text"
                  name="externalPatientID"
                  id="externalPatientID"
                  max="9"
                  value={this.state.searchModel.externalPatientID}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Processed Payment"></Label>
                {/* <Input
                  type="text"
                  name="accountNumber"
                  id="accountNumber"
                  max="20"
                  value={this.state.searchModel.accountNumber}
                  onChange={() => this.handleChange}
                /> */}
                <select
                  name="paymentProcessed"
                  id="paymentProcessed"
                  value={this.state.searchModel.paymentProcessed}
                  onChange={this.handleChange}
                >
                  {paymentProcessed.map(s => (
                    <option key={s.value} value={s.value}>
                      {s.display}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mf-6"></div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-grey"
                  value="Clear"
                  onClick={() => this.clearFields()}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="CHARGES SHEET SEARCH RESULT"
            disabled={this.isDisabled(this.props.rights.export)}
            dataObj={this.state.searchModel}
            url={this.AddChargesSheet}
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={this.state.table}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>

        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.clientSearch,
        add: state.loginInfo.rights.clientCreate,
        update: state.loginInfo.rights.clientEdit,
        delete: state.loginInfo.rights.clientDelete,
        export: state.loginInfo.rights.clientExport,
        import: state.loginInfo.rights.clientImport
      }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(ChargesSheet);
