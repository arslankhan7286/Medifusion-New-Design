import React, { Component, Fragment } from "react";
import $ from "jquery";

import taxonomyIcon from "../images/code-search-icon.png";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import axios from "axios";
import Input from "./Input";
import Swal from "sweetalert2";
import Select, { components } from "react-select";
import settingsIcon from "../images/setting-icon.png";
import Dropdown from "react-dropdown";
import NewHistoryPractice from "./NewHistoryPractice";
import { MDBDataTable, MDBBtn, MDBTable } from "mdbreact";
import NumberFormat from "react-number-format";

// import Grid from '@material-ui/core/Grid';
import DateFnsUtils from "@date-io/date-fns";
import { MuiPickersUtilsProvider } from "@material-ui/pickers";
import { TimePicker } from "@material-ui/pickers";
import { KeyboardTimePicker } from "@material-ui/pickers";
import { ThemeProvider } from "@material-ui/styles";
import moment from "moment";
import Timer from "@material-ui/icons/Timer";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { userInfo } from "../actions/userInfo";
import { taxonomyCodeAction } from "../actions/TaxonomyAction";
import { ProviderAction } from "../actions/ProviderAction";
import { ResponsiveContainer } from "recharts";
import { flexbox } from "@material-ui/system";
//import { Flag } from "semantic-ui-react";

class NewProvider extends Component {
  constructor(props) {
    super(props);

    this.errorField = "errorField";
    this.url = process.env.REACT_APP_URL + "/Provider/";
    this.commonUrl = process.env.REACT_APP_URL + "/Common/";
    this.accountUrl = process.env.REACT_APP_URL + "/account/";
    this.insurancePlanurl = process.env.REACT_APP_URL + "/PatientPlan/";
    this.providerScheduleUrl = process.env.REACT_APP_URL + "/ProviderSchedule/";
    this.InsurancOptionurl =
      process.env.REACT_APP_URL + "/InsuranceBillingOption/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.saveProviderCount = 0;

    //provider Model
    this.providerModel = {
      id: 0,
      title: "",
      name: "",
      lastName: "",
      firstName: "",
      middleInitial: "",
      npi: "",
      ssn: "",
      address1: "",
      address2: "",
      city: "",
      state: "",
      zipCode: "",
      officePhoneNum: "",
      phoneNumExt: "",
      email: "",
      deaNumber: "",
      upinNumber: "",
      licenceNumber: "",
      isActive: true,
      isDeleted: false,
      practiceID:
        this.props.userInfo1.practiceID != null
          ? this.props.userInfo1.practiceID
          : null,
      notes: "",
      addedBy: "",
      updatedBy: "",
      faxNumber: "",
      billUnderProvider: false,

      taxonomyCode: null,
      payToAddress1: "",
      payToAddress2: "",
      payToCity: "",
      payToState: "",
      payToZipCode: "",
      payofficePhoneNum: "",
      insuranceBillingoption: [],
      userLocations: "",
      userLocationId: "",
      providerSchedule: []
    };

    this.insuranceBillingoption = {
      providerID: "",
      locationID: "",
      insurancePlanID: "",
      reportTaxID: false,
      payToAddress: "None"
    };

    this.providerSchedule = {
      ID: 0,
      chk: false,
      weekday: "",
      providerID: "",
      provider: "",
      locationID: "",
      location: "",
      fromTime: "",
      toTime: "",
      timeInterval: "",
      overBookAllowed: "",
      notes: "",
      day: "",
      breakfrom: "",
      breakto: ""
    };

    this.validationModel = {
      titleValField: "",
      nameValField: "",
      lastNameValField: "",
      firstNameValField: "",
      middleInitialValField: "",
      npiValField: "",
      ssnValField: "",
      taxonomyCodeValField: "",
      address1ValField: "",
      address2ValField: "",
      cityValField: "",
      stateValField: "",
      zipCodeValField: "",
      officePhoneNumValField: "",
      emailValField: "",
      deaNumberValField: "",
      upinNumberValField: "",
      licenceNumberValField: "",
      isActiveValField: true,
      isDeletedValField: false,
      notesValField: "",
      locationVal: "",
      insurancePlanIDVal: "",
      payaddVal: "",
      toTimeVal: "",
      faxNumberValField: ""
    };

    this.state = {
      editId: this.props.id,
      providerModel: this.providerModel,
      validationModel: this.validationModel,
      maxHeight: "361",
      loading: false,
      isChecked: false,
      taxonomyCode: {},
      popupName: "",
      showPopup: false,
      Checked: false,
      patientPlanData: [],
      // userLocations: [],
      userLocations: this.props.userInfo1.userLocations
        ? this.props.userInfo1.userLocations
        : [],
      insurancePlan: [],
      localModel: [],
      reportTaxID: false,
      providerSchedule: []
    };

    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.saveNewProvider = this.saveNewProvider.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
    this.handleCheckbox = this.handleCheckbox.bind(this);
    this.delete = this.delete.bind(this);
    this.handleZip = this.handleZip.bind(this);
    this.handletaxonomyCodeChange = this.handletaxonomyCodeChange.bind(this);
    this.addPlanRow = this.addPlanRow.bind(this);
    this.reportTaxIDcheck = this.reportTaxIDcheck.bind(this);
    this.handleTimeChange = this.handleTimeChange.bind(this);
    this.handleScheduleChange = this.handleScheduleChange.bind(this);
    this.selectALL = this.selectALL.bind(this);
    this.handleLocationChange = this.handleLocationChange.bind(this);
    this.onPaste = this.onPaste.bind(this);
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  async componentDidMount() {
    this.setState({ loading: true });
    this.setModalMaxHeight($(".modal"));

    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function () {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    try {
      //TaxonomyCode
      try {
        if (
          this.props.userInfo1.taxonomy == null ||
          this.props.userInfo1.taxonomy == 0
        ) {
          await axios
            .get(this.commonUrl + "GetTaxonomy", this.config)
            .then(response => {
              this.props.taxonomyCodeAction(
                this.props,
                response.data,
                "TAXONOMYCODES"
              );
            })
            .catch(error => { });
        }
      } catch { }

      try {
        //get insurance plans from get profiles
        await axios
          .get(this.insurancePlanurl + "getprofiles", this.config)
          .then(response => {
            this.setState({ insurancePlan: response.data.insurancePlans });
          })
          .then(error => { });
      } catch { }

      if (this.state.editId > 0) {
        await axios
          .get(this.url + "findprovider/" + this.state.editId, this.config)
          .then(response => {
            var providerModel = response.data;

            var providerModel = response.data;
            if (providerModel.insuranceBillingoption == null) {
              providerModel.insuranceBillingoption = [];
            }

            var taxonomyCode = [];
            try {
              if (providerModel.taxonomyCode) {
                taxonomyCode = this.props.userInfo1.taxonomy.filter(
                  option => option.value == providerModel.taxonomyCode
                )[0];
              }
            } catch { }

            this.setState({
              providerModel: providerModel,
              taxonomyCode: taxonomyCode
            });
          })
          .catch(error => {
            let errorsList = [];
            if (error.response !== null && error.response.data !== null) {
              errorsList = error.response.data;
            }
          });
      }

      ////////// Provider Scheduler ////////////////////////............................
      var locationID = this.state.userLocations[1].id;
      var providerID = this.state.providerModel.id
        ? this.state.providerModel.id
        : 0; // 0 ka chk laga ha

      try {
        axios
          .get(this.providerScheduleUrl + "FindProviderSchedule/", {
            params: {
              locationID: locationID,
              providerID: providerID
            },
            headers: {
              Authorization: "Bearer  " + this.props.loginObject.token,
              Accept: "*/*"
            }
          })
          .then(response => {
            var providerSchedule = response.data;
            this.setState({
              // providerModel: {
              //   ...this.state.providerModel,
              providerSchedule: providerSchedule
              // }
            });
          })

          .catch(error => { });
      } catch { }

      try {
        var taxonomyCode = [];
        taxonomyCode = this.props.userInfo1.taxonomy.filter(
          option => option.id
        );
      } catch { }

      try {
        let newProviderList = this.state.providerModel.insuranceBillingoption;
        for (
          var i = 0;
          i < this.state.providerModel.insuranceBillingoption.length;
          i++
        ) {
          newProviderList[i].userlocationobj = this.state.userLocations.filter(
            option =>
              option.id ==
              this.state.providerModel.insuranceBillingoption[i].locationID
          );
          newProviderList[i].insurancePlanobj = this.state.insurancePlan.filter(
            option =>
              option.id ==
              this.state.providerModel.insuranceBillingoption[i].insurancePlanID
          );
        }
        this.setState({
          providerModel: {
            ...this.state.providerModel,
            insuranceBillingoption: newProviderList
          }
        });
      } catch { }
    } catch {
      this.setState({ loading: false });
    }
    this.setState({ loading: false });
  }

  handleCheckbox() {
    this.setState({
      providerModel: {
        ...this.state.providerModel,
        billUnderProvider: !this.state.providerModel.billUnderProvider
      }
    });
  }

  handleZip(event) {
    var zip = event.target.value;

    this.setState({
      providerModel: {
        ...this.state.providerModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });

    if (zip.length == 5 || zip.length == 9) {
      axios
        .get(this.commonUrl + "GetCityStateInfo/" + zip, this.config)
        .then(response => {
          this.setState({
            providerModel: {
              ...this.state.providerModel,
              city: response.data.city.toUpperCase(),
              state: response.data.state_id
            }
          });
        })
        .catch(error => {
          this.setState({ loading: false });

          if (error.response.data == "InValid ZipCode") {
            Swal.fire("Something Wrong", "InValid ZipCode", "error");
          } else {
            Swal.fire(
              "Something Wrong",
              "Please Check Server Connection",
              "error"
            );
          }
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
          }
        });
    } else {
      // Swal.fire("Enter Valid Zip Code", "", "error");
    }
  }

  handleChange = event => {
    console.log(event.target.name, event.target.value)
    event.preventDefault();

    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    var regExpr = /[^a-zA-Z0-9 ]/g;
    var myValue = event.target.value;
    var myName = event.target.name;

    if (caret == 0 || caret <= 1) {
      myValue = myValue.trim();
    }

    if (myName == "upinNumber" || myName == "licenceNumber" || myName == "deaNumber") {
      myValue = myValue.replace(regExpr, "");
    } else {
      myValue = myValue ? myValue : "";
      myValue = myValue;
    }

    this.setState({
      providerModel: {
        ...this.state.providerModel,
        [myName]: myValue.toUpperCase()
      }
    });
  };



  // handleChange = event => {
  //   event.preventDefault();

  //   //Carret Position
  //   const caret = event.target.selectionStart;
  //   const element = event.target;
  //   window.requestAnimationFrame(() => {
  //     element.selectionStart = caret;
  //     element.selectionEnd = caret;
  //   });

  //   this.setState({
  //     providerModel: {
  //       ...this.state.providerModel,
  //       [event.target.name]: event.target.value.toUpperCase()
  //     }
  //   });
  // };


  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  handleCheck() {
    this.setState({
      providerModel: {
        ...this.state.providerModel,
        isActive: !this.state.providerModel.isActive
      }
    });
  }

  delete = e => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.setState({ loading: true });
        axios
          .delete(this.url + "DeleteProvider/" + this.state.editId, this.config)
          .then(response => {
            this.setState({
              loading: false,
              providerModel: this.providerModel,
              taxonomyCode: null
            });

            try {
              //GetProviders
              axios
                .get(this.commonUrl + "GetProvider", this.config)
                .then(response => {
                  this.props.ProviderAction(
                    this.props,
                    response.data,
                    "PROVIDER_ACTION"
                  );
                })
                .catch(error => { });
            } catch { }

            Swal.fire("Record Deleted Successfully", "", "success");
          })
          .catch(error => {
            this.setState({ loading: false });

            if (this.state.editId > 0) {
              Swal.fire(
                "Record Not Deleted!",
                "Record can not be delete, as it is being reference in other screens.",
                "error"
              );
            } else {
              Swal.fire(
                "Record Not Deleted!",
                "Don't have record to delete",
                "error"
              );
            }
          });

        // $("#btnCancel").click();
      }
    });
  };

  saveNewProvider = e => {
    if (this.saveProviderCount == 1) {
      return;
    }
    this.saveProviderCount = 1;
    e.preventDefault();
    this.setState({ loading: true });

    if (this.isNull(this.state.providerModel.officePhoneNum) === false) {
      if (this.state.providerModel.officePhoneNum.length > 10) {
        var officePhoneNum = this.state.providerModel.officePhoneNum.slice(3, 17);
        this.state.providerModel.officePhoneNum = officePhoneNum.replace(/[-_ )(]/g, "");
      }
    }

    var myVal = this.validationModel;
    myVal.validation = false;

    // // location check
    var providerScheduleVal = this.state.providerSchedule;
    var len = this.state.providerSchedule.length;
    for (var i = 0; i < len; i++) {
      providerScheduleVal[i].validation = false;

      //locationVal from validation
      if (this.state.providerSchedule[i].fromTime != null) {
        if (
          this.state.providerSchedule[i].toTime == null ||
          this.state.providerSchedule[i].toTime == 0
        ) {
          providerScheduleVal[i].toTimeVal = (
            <span className="validationMsg" style={{ marginLeft: "2%" }}>
              Please Enter To Time
            </span>
          );
          providerScheduleVal[i].validation = true;
        } else {
          providerScheduleVal[i].toTimeVal = "";
          if (providerScheduleVal[i].validation === false)
            providerScheduleVal[i].validation = false;
        }
      }
      if (this.state.providerSchedule[i].breakfrom != null) {
        if (
          this.state.providerSchedule[i].breakto == null ||
          this.state.providerSchedule[i].breakto == 0
        ) {
          providerScheduleVal[i].breaktoVal = (
            <span className="validationMsg" style={{ marginLeft: "2%" }}>
              Please Enter To Time
            </span>
          );
          providerScheduleVal[i].validation = true;
        } else {
          providerScheduleVal[i].breaktoVal = "";
          if (providerScheduleVal[i].validation === false)
            providerScheduleVal[i].validation = false;
        }
      }
    }
    //Location Otions Validation set state
    this.setState({
      providerSchedule: providerScheduleVal
    });
    for (var i = 0; i < len; i++) {
      if (providerScheduleVal[i].validation === true) {
        this.setState({ loading: false });

        return;
      }
    }

    //Billing Otions  Model Validation
    var insuranceBillingoptionVal;
    for (
      var i = 0;
      i < this.state.providerModel.insuranceBillingoption.length;
      i++
    ) {
      insuranceBillingoptionVal = {
        ...this.state.providerModel.insuranceBillingoption[i]
      };
      insuranceBillingoptionVal.validation = false;

      //locationVal from validation
      if (
        this.isNull(
          this.state.providerModel.insuranceBillingoption[i].locationID
        )
      ) {
        insuranceBillingoptionVal.locationVal = (
          <span className="validationMsg" style={{ paddingTop: "15%" }}>
            Please Select Location
          </span>
        );
        insuranceBillingoptionVal.validation = true;
      } else {
        insuranceBillingoptionVal.locationVal = "";
        if (insuranceBillingoptionVal.validation === false)
          insuranceBillingoptionVal.validation = false;
      }

      //insurancePlanIDVal from validation
      if (
        this.isNull(
          this.state.providerModel.insuranceBillingoption[i].insurancePlanID
        )
      ) {
        insuranceBillingoptionVal.insurancePlanIDVal = (
          <span className="validationMsg" style={{ paddingTop: "15%" }}>
            Please Select Plan
          </span>
        );
        insuranceBillingoptionVal.validation = true;
      } else {
        insuranceBillingoptionVal.insurancePlanIDVal = "";
        if (insuranceBillingoptionVal.validation === false)
          insuranceBillingoptionVal.validation = false;
      }

      //Billing Otions Validation set state
      this.setState({
        providerModel: {
          ...this.state.providerModel,
          insuranceBillingoption: [
            ...this.state.providerModel.insuranceBillingoption.slice(0, i),
            Object.assign(
              {},
              this.state.providerModel.insuranceBillingoption[i],
              insuranceBillingoptionVal
            ),
            ...this.state.providerModel.insuranceBillingoption.slice(i + 1)
          ]
        }
      });
    }

    if (this.isNull(this.state.providerModel.name)) {
      myVal.nameValField = <span className="validationMsg">Enter Name</span>;
      myVal.validation = true;
    } else {
      myVal.nameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.providerModel.lastName)) {
      myVal.lastNameValField = (
        <span className="validationMsg">Enter Last Name</span>
      );
      myVal.validation = true;
    } else {
      myVal.lastNameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.providerModel.firstName)) {
      myVal.firstNameValField = (
        <span className="validationMsg">Enter First Name</span>
      );
      myVal.validation = true;
    } else {
      myVal.firstNameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.providerModel.npi)) {
      myVal.npiValField = <span className="validationMsg">Enter NPI</span>;
      myVal.validation = true;
    } else if (this.state.providerModel.npi.length < 10) {
      myVal.npiValField = (
        <span className="validationMsg">NPI length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.npiValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.providerModel.taxonomyCode) === false &&
      this.state.providerModel.taxonomyCode.length < 10
    ) {
      myVal.taxonomyCodeValField = (
        <span className="validationMsg">Taxonomy Code length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.taxonomyCodeValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.providerModel.zipCode) === false &&
      this.state.providerModel.zipCode.length > 0
    ) {
      if (this.state.providerModel.zipCode.length < 5) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of alleast 5 digits
          </span>
        );
        myVal.validation = true;
      } else if (
        this.state.providerModel.zipCode.length > 5 &&
        this.state.providerModel.zipCode.length < 9
      ) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of either 5 or 9 digits
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.zipCodeValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.zipCodeValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.providerModel.officePhoneNum) === false &&
      this.state.providerModel.officePhoneNum.length < 10
    ) {
      myVal.officePhoneNumValField = (
        <span className="validationMsg">Phone # length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.officePhoneNumValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //Fax number Validation
    if (this.isNull(this.state.providerModel.faxNumber) === false) {
      if (this.state.providerModel.faxNumber.length < 10) {
        myVal.faxNumberValField = (
          <span className="validationMsg">Fax # length should be 10</span>
        );
        myVal.validation = true;
      } else {
        myVal.faxNumberValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.faxNumberValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.providerModel.ssn) === false &&
      this.state.providerModel.ssn.length < 9
    ) {
      myVal.ssnValField = (
        <span className="validationMsg">SSN length should be 9</span>
      );
      myVal.validation = true;
    } else {
      myVal.ssnValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }
    myVal.emailValField = "";
    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      this.saveProviderCount = 0;

      return;
    }

    var newproviderModel = this.state.providerModel;
    newproviderModel.providerSchedule = this.state.providerSchedule;
    axios
      .post(this.url + "saveprovider", newproviderModel, this.config)
      .then(response => {
        Swal.fire("Record Saved Successfully", "", "success");

        this.setState({ loading: false, providerModel: response.data });
        this.saveProviderCount = 0;
        try {
          //GetProviders
          axios
            .get(this.commonUrl + "GetProvider", this.config)
            .then(response => {
              this.saveProviderCount = 0;

              this.props.ProviderAction(
                this.props,
                response.data,
                "PROVIDER_ACTION"
              );
            })
            .catch(error => {
              this.saveProviderCount = 0;
            });
        } catch {
          this.saveProviderCount = 0;
        }
      })
      .catch(error => {
        this.saveProviderCount = 0;

        this.setState({ loading: false });
        try {
          if (error.response) {
            if (error.response.status) {
              if (error.response.status == 401) {
                Swal.fire("Unauthorized Access", "", "error");
                return;
              } else if (error.response.status == 404) {
                Swal.fire("Not Found", "Failed With Status Code 404", "error");
                return;
              } else if (error.response.status == 400) {
                if (error.response.data.Email) {
                  if (error.response.data.Email[0]) {
                    //Swal.fire("Something Wrong", error.response.data.Email[0], "error");
                    myVal.emailValField = (
                      <span className="validationMsg">Please enter Valid Email ID</span>
                    );
                    myVal.validation = true;
                  } else {
                    myVal.emailValField = "";
                    if (myVal.validation === false) myVal.validation = false;
                  }
                  this.setState({
                    validationModel: myVal
                  });
                } else {
                  Swal.fire("Something Wrong", error.response.data, "error");
                  return;
                }

              } else {
                Swal.fire("Something Wrong", "", "error");
                return;
              }
            }
          } else {
            Swal.fire("Something Wrong", "Please Try Again", "error");
            return;
          }


        } catch { }
      });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  handletaxonomyCodeChange(event) {
    if (event) {
      this.setState({
        taxonomyCode: event,
        // taxonomyCodeobj: event.id,
        providerModel: {
          ...this.state.providerModel,
          taxonomyCode: event.value
        }
      });
    } else {
      this.setState({
        taxonomyCode: null,
        // taxonomyCodeobj: event.id,
        providerModel: {
          ...this.state.providerModel,
          taxonomyCode: null
        }
      });
    }
  }

  openhistorypopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  handleSameAsAddress = event => {
    let Checked = !this.state.Checked;
    // this.setState ({ isChecked:isChecked }) ;
    this.setState({ Checked: Checked });

    if (Checked) {
      // alert("Click")
      this.setState({
        providerModel: {
          ...this.state.providerModel,
          payToAddress1: this.state.providerModel.address1,
          payToAddress2: this.state.providerModel.address2,
          payToCity: this.state.providerModel.city,
          payToState: this.state.providerModel.state,
          payToZipCode: this.state.providerModel.zipCode,
          payofficePhoneNum: this.state.providerModel.officePhoneNum
        }
      });
    } else {
      // alert("Not Click")

      this.setState({
        providerModel: {
          ...this.state.providerModel,
          payToAddress1: "",
          payToAddress2: "",
          payToCity: "",
          payToState: "",
          payToZipCode: "",
          payofficePhoneNum: ""
        }
      });
    }
  };

  async addPlanRow() {
    const insuranceBillingoption = { ...this.insuranceBillingoption };
    insuranceBillingoption.providerID = this.state.providerModel.id;
    await this.setState({
      providerModel: {
        ...this.state.providerModel,
        insuranceBillingoption: this.state.providerModel.insuranceBillingoption.concat(
          insuranceBillingoption
        )
      }
    });
  }

  reportTaxIDcheck(event, id) {
    let newProviderList = this.state.providerModel.insuranceBillingoption;

    newProviderList[id].reportTaxID = !newProviderList[id].reportTaxID;

    this.setState({
      providerModel: {
        ...this.state.providerModel,
        insuranceBillingoption: newProviderList
      }
    });
  }

  //Handle Time Change
  async handleTimeChange(id, time, fieldName) {
    if (
      this.state.providerSchedule[0].locationID == null ||
      this.state.providerSchedule[0].locationID == 0
    ) {
      Swal.fire("Select Location");
      return;
    }

    var dummyDate = "2019-11-11";
    if (fieldName == "fromTime") {
      dummyDate =
        this.state.providerSchedule.fromTime != ""
          ? moment(this.state.providerSchedule.fromTime)
            .format()
            .slice(0, 10)
          : "2019-11-11";
    } else if (fieldName == "toTime") {
      dummyDate =
        this.state.providerSchedule.toTime != ""
          ? moment(this.state.providerSchedule.toTime)
            .format()
            .slice(0, 10)
          : "2019-11-11";
    } else if (fieldName == "breakfrom") {
      dummyDate =
        this.state.providerSchedule.breakfrom != ""
          ? moment(this.state.providerSchedule.breakfrom)
            .format()
            .slice(0, 10)
          : "2019-11-11";
    } else if (fieldName == "breakto") {
      dummyDate =
        this.state.providerSchedule.breakto != ""
          ? moment(this.state.providerSchedule.breakto)
            .format()
            .slice(0, 10)
          : "2019-11-11";
    }

    let newProviderScheduler = this.state.providerSchedule;

    var a = moment(time);
    var model = this.state.providerSchedule;
    var newTime = dummyDate + a.format().slice(10, 19);
    // const index = event.target.id;
    // const name = event.target.name;
    newProviderScheduler[id][fieldName] = newTime;
    this.setState({
      // providerModel: {
      //   ...this.state.providerModel,
      providerSchedule: newProviderScheduler
      // }
    });
  }

  handleScheduleChange(event) {
    event.preventDefault();

    let newProviderScheduler = this.state.providerSchedule;

    const index = event.target.id;
    const name = event.target.name;
    if (this.state.editId > 0) {
      newProviderScheduler[index].id = newProviderScheduler[index].id;
    } else {
      newProviderScheduler[index].id = 0;
    }
    newProviderScheduler[index][name] = event.target.value;
    // newProviderScheduler[index].locationID = null;
    this.setState({
      // providerModel: {
      //   ...this.state.providerModel,
      providerSchedule: newProviderScheduler
      // }
    });
  }

  selectALL(event, id) {
    let newProviderSchedule = this.state.providerSchedule;

    if (newProviderSchedule[id].chk == true) {
      newProviderSchedule[id].inActive = true;
    } else {
      newProviderSchedule[id].inActive = !newProviderSchedule[id].inActive;
    }
    newProviderSchedule[id].chk = !newProviderSchedule[id].chk;
    newProviderSchedule[id].providerID = this.state.editId
      ? this.state.editId
      : this.state.providerModel.id;

    this.setState({
      // providerModel: {
      //   ...this.state.providerModel,
      providerSchedule: newProviderSchedule
      // }
    });
  }

  handleplanModelChange = event => {
    event.preventDefault();

    let newProviderList = this.state.providerModel.insuranceBillingoption;

    const index = event.target.id;
    const name = event.target.name;
    newProviderList[index][name] = event.target.value;

    this.setState({
      providerModel: {
        ...this.state.providerModel,
        insuranceBillingoption: newProviderList
      }
    });
  };

  handleLocationChange(event) {
    this.setState({
      providerModel: {
        ...this.state.providerModel,
        userLocations: event.target.value
      }
    });

    var locationID = event.target.value;
    var providerID = this.state.providerModel.id;
    var providerID = this.state.editId ? this.state.editId : 0;

    try {
      axios
        .get(this.providerScheduleUrl + "FindProviderSchedule/", {
          params: {
            locationID: event.target.value,
            providerID: providerID
          },
          headers: {
            Authorization: "Bearer  " + this.props.loginObject.token,
            Accept: "*/*"
          }
        })
        .then(response => {
          var providerSchedule = response.data;

          for (var i = 0; i < response.data.length; i++) {
            providerSchedule[i].locationID = locationID;

            if (this.state.editId > 0) {
              providerSchedule[i].providerID = this.state.editId
                ? this.state.editId
                : this.state.providerModel.id;
            }

            if (
              providerSchedule[i].addedBy == null ||
              providerSchedule[i].addedBy == ""
            ) {
              providerSchedule[i].id = 0;
            } else {
              providerSchedule[i].id = response.data[i].id;
              // if(providerSchedule[i].id = response.data[i].id){
              providerSchedule[i].chk = true;
              // }
            }
          }

          this.setState({
            providerSchedule: providerSchedule
          });
        })

        .catch(error => { });
    } catch { }
  }

  handleplanModellocChange(event, index) {
    let newProviderList = this.state.providerModel.insuranceBillingoption;
    if (event) {
      newProviderList[index].locationID = event.id;
      newProviderList[index].userlocationobj = event;

      this.setState({
        providerModel: {
          ...this.state.providerModel,
          insuranceBillingoption: newProviderList
        }
      });
    } else {
      newProviderList[index].locationID = null;
      newProviderList[index].userlocationobj = null;

      this.setState({
        providerModel: {
          ...this.state.providerModel,
          insuranceBillingoption: newProviderList
        }
      });
    }
  }

  handleplanModelInsChange(event, index) {
    let newProviderList = this.state.providerModel.insuranceBillingoption;
    if (event) {
      newProviderList[index].insurancePlanID = event.id;
      newProviderList[index].insurancePlanobj = event;

      this.setState({
        providerModel: {
          ...this.state.providerModel,
          insuranceBillingoption: newProviderList
        }
      });
    } else {
      newProviderList[index].insurancePlanID = null;
      newProviderList[index].insurancePlanobj = null;

      this.setState({
        providerModel: {
          ...this.state.providerModel,
          insuranceBillingoption: newProviderList
        }
      });
    }
  }

  async deleteRow(event, index, RowId) {
    const RowID = RowId;
    const id = event.target.id;
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        if (RowID > 0) {
          axios
            .delete(
              this.InsurancOptionurl + "DeleteInsuranceBillingOption/" + RowID,
              this.config
            )
            .then(response => {
              Swal.fire("Record Deleted Successfully", "", "success");
              let insuranceBillingoption = [
                ...this.state.providerModel.insuranceBillingoption
              ];
              insuranceBillingoption.splice(id, 1);
              this.setState({
                providerModel: {
                  ...this.state.providerModel,
                  insuranceBillingoption: insuranceBillingoption
                }
              });
            })
            .catch(error => {
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let insuranceBillingoption = [
            ...this.state.providerModel.insuranceBillingoption
          ];
          insuranceBillingoption.splice(id, 1);
          this.setState({
            providerModel: {
              ...this.state.providerModel,
              insuranceBillingoption: insuranceBillingoption
            }
          });
        }
      }
    });
  }

  onPaste(event) {
    var x = event.target.value;
    x = x.trim();

    var regex = /^[0-9]+$/;
    if (x.length == 0) {
      this.setState({
        providerModel: {
          ...this.state.providerModel,
          [event.target.name]: x
        }
      });
      return;
    }

    if (!x.match(regex)) {
      Swal.fire("Error", "Should be Number", "error");
      return;
    } else {
      this.setState({
        providerModel: {
          ...this.state.providerModel,
          [event.target.name]: x
        }
      });
    }
  }

  render() {
    const options = [
      { value: "History", label: "History", className: "dropdown" }
    ];

    var Imag;
    Imag = (
      <div>
        <img src={settingsIcon} />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup(0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );

    const isActive = this.state.providerModel.isActive;
    const usStates = [
      { value: "", display: "Select State" },
      { value: "AL", display: "AL - Alabama" },
      { value: "AK", display: "AK - Alaska" },
      { value: "AZ", display: "AZ - Arizona" },
      { value: "AR", display: "AR - Arkansas" },
      { value: "CA", display: "CA - California" },
      { value: "CO", display: "CO - Colorado" },
      { value: "CT", display: "CT - Connecticut" },
      { value: "DE", display: "DE - Delaware" },
      { value: "FL", display: "FL - Florida" },
      { value: "GA", display: "GA - Georgia" },
      { value: "HI", display: "HI - Hawaii" },
      { value: "ID", display: "ID - Idaho" },
      { value: "IL", display: "IL - Illinois" },
      { value: "IN", display: "IN - Indiana" },
      { value: "IA", display: "IA - Iowa" },
      { value: "KS", display: "KS - Kansas" },
      { value: "KY", display: "KY - Kentucky" },
      { value: "LA", display: "LA - Louisiana" },
      { value: "ME", display: "ME - Maine" },
      { value: "MD", display: "MD - Maryland" },
      { value: "MA", display: "MA - Massachusetts" },
      { value: "MI", display: "MI - Michigan" },
      { value: "MN", display: "MN - Minnesota" },
      { value: "MS", display: "MS - Mississippi" },
      { value: "MO", display: "MO - Missouri" },
      { value: "MT", display: "MT - Montana" },
      { value: "NE", display: "NE - Nebraska" },
      { value: "NV", display: "NV - Nevada" },
      { value: "NH", display: "NH - New Hampshire" },
      { value: "NJ", display: "NJ - New Jersey" },
      { value: "NM", display: "NM - New Mexico" },
      { value: "NY", display: "NY - New York" },
      { value: "NC", display: "NC - North Carolina" },
      { value: "ND", display: "ND - North Dakota" },
      { value: "OH", display: "OH - Ohio" },
      { value: "OK", display: "OK - Oklahoma" },
      { value: "OR", display: "OR - Oregon" },
      { value: "PA", display: "PA - Pennsylvania" },
      { value: "RI", display: "RI - Rhode Island" },
      { value: "SC", display: "SC - South Carolina" },
      { value: "SD", display: "SD - South Dakota" },
      { value: "TN", display: "TN - Tennessee" },
      { value: "TX", display: "TX - Texas" },
      { value: "UT", display: "UT - Utah" },
      { value: "VT", display: "VT - Vermont" },
      { value: "VA", display: "VA - Virginia" },
      { value: "WA", display: "WA - Washington" },
      { value: "WV", display: "WV - West Virginia" },
      { value: "WI", display: "WI - Wisconsin" },
      { value: "WY", display: "WY - Wyoming" }
    ];

    const titles = [
      { value: "", display: "Select Title" },
      { value: "MR", display: "MR" },
      { value: "MRS", display: "MRS" }
    ];

    const payToAddressdrop = [
      { value: "None", display: "None" },
      { value: "Provider", display: "Provider" },
      { value: "Practice", display: "Practice" }
    ];

    const timeInterval = [
      { value: "Please Select", display: "Please Select" },
      { value: "10", display: "10 mints" },
      { value: "15", display: "15 mints" },
      { value: "20", display: "20 mints" },
      { value: "25", display: "25 mints" },
      { value: "30", display: "30 mints" }
    ];

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }
    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
        // disabled={this.isDisabled(this.props.rights.update)}
        // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    let newList = [];
    var patientPlanData = {};

    this.state.providerModel.insuranceBillingoption.map((row, index) => {
      newList.push({
        id: row.id,
        id: "row.providerId",

        location: (
          <div style={{ width: "100px" }}>
            <Select
              type="text"
              max="10"
              value={
                this.state.providerModel.insuranceBillingoption[index]
                  .userlocationobj
              }
              // value={this.state.userlocationobj}
              name="locationID"
              id={index}
              onChange={event => this.handleplanModellocChange(event, index)}
              options={this.state.userLocations}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => { },
                clearIndicator: defaultStyles => ({
                  ...defaultStyles,
                  color: "#286881"
                }),
                container: defaultProps => ({
                  ...defaultProps,
                  position: "absolute",
                  width: "180px"
                }),
                indicatorsContainer: defaultStyles => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "0",
                  marginTop: "0px",
                  height: "36px",
                  borderBottomRightRadius: "10px",
                  borderTopRightRadius: "10px"
                  // borderRadius:"0 6px 6px 0"
                }),
                indicatorContainer: defaultStyles => ({
                  ...defaultStyles,
                  padding: "9px",
                  marginBottom: "0",
                  marginTop: "1px",
                  // borderBottomRightRadius: "5px",
                  // borderTopRightRadius: "5px",
                  borderRadius: "0 4px 4px 0"
                }),
                dropdownIndicator: defaultStyles => ({
                  ...defaultStyles,
                  backgroundColor: "#d8ecf3",
                  color: "#286881",
                  borderRadius: "3px",
                  display: "none"
                }),
                input: defaultStyles => ({
                  ...defaultStyles,
                  margin: "0px",
                  padding: "0px"
                  // display:'none'
                }),
                singleValue: defaultStyles => ({
                  ...defaultStyles,
                  fontSize: "16px",
                  transition: "opacity 300ms"
                  // display:'none'
                }),
                control: defaultStyles => ({
                  ...defaultStyles,
                  minHeight: "33px",
                  height: "33px",
                  height: "33px",
                  paddingLeft: "10px",
                  //borderColor:"transparent",
                  borderColor: "#C6C6C6",
                  boxShadow: "none",
                  borderColor: "#C6C6C6",
                  "&:hover": {
                    borderColor: "#C6C6C6"
                  }
                  // display:'none'
                })
              }}
            />
            {this.state.providerModel.insuranceBillingoption[index].locationVal}
          </div>
        ),
        insurancePlan: (
          <div style={{ width: "100px" }}>
            <Select
              type="text"
              max="10"
              value={
                this.state.providerModel.insuranceBillingoption[index]
                  .insurancePlanobj
              }
              // value={this.state.userlocationobj}
              name="insurancePlanID"
              id={index}
              onChange={event => this.handleplanModelInsChange(event, index)}
              options={this.state.insurancePlan}
              placeholder=""
              isClearable={true}
              isSearchable={true}
              openMenuOnClick={false}
              escapeClearsValue={true}
              styles={{
                indicatorSeparator: () => { },
                clearIndicator: defaultStyles => ({
                  ...defaultStyles,
                  color: "#286881"
                }),
                container: defaultProps => ({
                  ...defaultProps,
                  position: "absolute",
                  width: "190px"
                }),
                indicatorsContainer: defaultStyles => ({
                  ...defaultStyles,
                  padding: "0px",
                  marginBottom: "0",
                  marginTop: "0px",
                  height: "36px",
                  borderBottomRightRadius: "10px",
                  borderTopRightRadius: "10px"
                  // borderRadius:"0 6px 6px 0"
                }),
                indicatorContainer: defaultStyles => ({
                  ...defaultStyles,
                  padding: "9px",
                  marginBottom: "0",
                  marginTop: "1px",
                  // borderBottomRightRadius: "5px",
                  // borderTopRightRadius: "5px",
                  borderRadius: "0 4px 4px 0"
                }),
                dropdownIndicator: defaultStyles => ({
                  ...defaultStyles,
                  backgroundColor: "#d8ecf3",
                  color: "#286881",
                  borderRadius: "3px",
                  display: "none"
                }),
                input: defaultStyles => ({
                  ...defaultStyles,
                  margin: "0px",
                  padding: "0px"
                  // display:'none'
                }),
                singleValue: defaultStyles => ({
                  ...defaultStyles,
                  fontSize: "16px",
                  transition: "opacity 300ms"
                  // display:'none'
                }),
                control: defaultStyles => ({
                  ...defaultStyles,
                  minHeight: "33px",
                  height: "33px",
                  height: "33px",
                  paddingLeft: "10px",
                  //borderColor:"transparent",
                  borderColor: "#C6C6C6",
                  boxShadow: "none",
                  borderColor: "#C6C6C6",
                  "&:hover": {
                    borderColor: "#C6C6C6"
                  }
                  // display:'none'
                })
              }}
            />
            {
              this.state.providerModel.insuranceBillingoption[index]
                .insurancePlanIDVal
            }
          </div>
        ),
        reportTaxId: (
          <div style={{ width: "123%", marginLeft: "33%", marginTop: "1%" }}>
            <div
              class="lblChkBox"
              onClick={event => this.reportTaxIDcheck(event, index)}
            >
              <input
                type="checkbox"
                id={index}
                name="reportTaxID"
                checked={
                  this.state.providerModel.insuranceBillingoption[index]
                    .reportTaxID
                }
              />
              <label for="reportTaxID">
                <span></span>
              </label>
            </div>
          </div>
        ),
        payToAddress: (
          <div style={{ marginLeft: "-40%", width: "141%" }}>
            <select
              name="payToAddress"
              id={index}
              value={
                this.state.providerModel.insuranceBillingoption[index]
                  .payToAddress
              }
              onChange={this.handleplanModelChange}
            >
              {payToAddressdrop.map(s => (
                <option key={s.value} value={s.value}>
                  {s.display}
                </option>
              ))}
            </select>
            {this.state.providerModel.insuranceBillingoption[index].payaddVal}
          </div>
        ),
        remove: (
          <div style={{ width: "50px", textAlign: "center" }}>
            <button
              className="removeBtn"
              name="deleteCPTBtn"
              id={index}
              onClick={(event, index) => this.deleteRow(event, index, row.id)}
            ></button>
          </div>
        )
      });
    });

    patientPlanData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "LOCATION",
          field: "location",
          sort: "asc",
          width: 150
        },
        {
          label: "INSURANCE PLAN",
          field: "insurancePlan",
          sort: "asc",
          width: 150
        },
        {
          label: "REPORT TAX ID",
          field: "reportTaxId",
          sort: "asc",
          width: 150
        },
        {
          label: "PAY TO ADDRESS",
          field: "payToAddress",
          sort: "asc",
          width: 150
        },
        {
          label: "",
          field: "remove",
          sort: "asc",
          width: 150
        }
      ],
      rows: newList
    };

    let plangrid = "";
    plangrid = (
      <div className="table-grid mt-15">
        <div className="row headingTable">
          <div className="mf-6">{/* <h1>PROVIDER</h1> */}</div>
          <div className="mf-6 headingRightTable">
            <button class="btn-blue" onClick={this.addPlanRow}>
              Add Row{" "}
            </button>
          </div>
        </div>

        <div className="tableGridContainer text-nowrap">
          <div className="tableGridContainer">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={patientPlanData}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
      </div>
    );

    ///////////////////////?/////////////////////////////// Scheduler ///////////////////////?///////////////////////////////

    var providerSchedulerGrid = {};
    let schedulernewList = [];

    this.state.providerSchedule = this.state.providerSchedule
      ? this.state.providerSchedule
      : [];
    this.state.providerSchedule.map((row, index) => {
      schedulernewList.push({
        id: row.id,

        chk: (
          // <div style={{ width: "125%",marginLeft: "-39%",}}>
          <div
            class="lblChkBox"
            onClick={event => this.selectALL(event, index)}
          >
            <input
              type="checkbox"
              id={index}
              name="chk"
              //  onChange={this.selectALL}
              // checked={this.state.providerModel.providerSchedule[index].chk}
              checked={this.state.providerSchedule[index].chk}
            />
            <label for="chk">
              <span></span>
            </label>
          </div>
        ),

        // weekday: (this.state.providerModel.providerSchedule[index].dayofWeek),
        weekday: this.state.providerSchedule[index].dayofWeek,

        fromTime: (
          // <div style={{ width: "123%"}}>
          <div>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
              <KeyboardTimePicker
                margin="none"
                // type="text"
                name="fromTime"
                id={index}
                // value={this.state.providerModel.providerSchedule[index].fromTime}
                value={this.state.providerSchedule[index].fromTime}
                onChange={this.handleScheduleChange}
                label=""
                format="hh:mm:ss a"
                placeholder="08:00:00 AM"
                mask="__:__:__ _M"
                views={["hours", "minutes", "seconds"]}
                onChange={time => {
                  this.handleTimeChange(index, time, "fromTime");
                }}
              />
            </MuiPickersUtilsProvider>
          </div>
          // </div>
        ),
        toTime: (
          // <div style={{ width: "123%"}}>
          <div>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
              <KeyboardTimePicker
                margin="none"
                name="toTime"
                id={index}
                // value={this.state.providerModel.providerSchedule[index].toTime}
                value={this.state.providerSchedule[index].toTime}
                onChange={this.handleScheduleChange}
                label=""
                format="hh:mm:ss a"
                placeholder="08:00:00 AM"
                mask="__:__:__ _M"
                views={["hours", "minutes", "seconds"]}
                onChange={time => {
                  this.handleTimeChange(index, time, "toTime");
                }}
              />
            </MuiPickersUtilsProvider>
            {this.state.providerSchedule[index].toTimeVal}
          </div>

          // </div>
        ),
        timeInterval: (
          // <div style={{ width: "141%" }}>
          <select
            // style={{ width: "141%" }}
            name="timeInterval"
            id={index}
            // value={this.state.providerModel.providerSchedule[index].timeInterval}
            value={this.state.providerSchedule[index].timeInterval}
            onChange={this.handleScheduleChange}
          >
            {timeInterval.map(s => (
              <option key={s.value} value={s.value}>
                {s.display}
              </option>
            ))}
          </select>
          // </div>
        ),
        breakfrom: (
          // <div style={{ width: "141%" }}>
          <div style={{ width: "115%" }}>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
              <KeyboardTimePicker
                margin="none"
                name="breakfrom"
                id={index}
                // value={this.state.providerModel.providerSchedule[index].breakfrom}
                value={this.state.providerSchedule[index].breakfrom}
                onChange={this.handleScheduleChange}
                label=""
                format="hh:mm:ss a"
                placeholder="08:00:00 AM"
                mask="__:__:__ _M"
                views={["hours", "minutes", "seconds"]}
                onChange={time => {
                  this.handleTimeChange(index, time, "breakfrom");
                }}
              />
            </MuiPickersUtilsProvider>
          </div>
          // </div>
        ),
        breakto: (
          // <div style={{  width: "141%" }}>
          <div style={{ width: "115%" }}>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
              <KeyboardTimePicker
                margin="none"
                name="breakto"
                id={index}
                // value={this.state.providerModel.providerSchedule[index].breakto}
                value={this.state.providerSchedule[index].breakto}
                onChange={this.handleScheduleChange}
                label=""
                format="hh:mm:ss a"
                placeholder="08:00:00 AM"
                mask="__:__:__ _M"
                views={["hours", "minutes", "seconds"]}
                onChange={time => {
                  this.handleTimeChange(index, time, "breakto");
                }}
              />
            </MuiPickersUtilsProvider>
            {this.state.providerSchedule[index].breaktoVal}
          </div>

          // </div>
        )
      });
    });

    providerSchedulerGrid = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc"
          // width: 150
        },
        {
          label: "",
          field: "chk",
          sort: "asc"
          // width: 150
        },

        {
          label: "DAY",
          field: "weekday",
          sort: "asc"
          // width: 150
        },
        {
          label: "FROM TIME",
          field: "fromTime",
          sort: "asc"
          // width: 150
        },
        {
          label: "TO TIME",
          field: "toTime",
          sort: "asc"
          // width: 150
        },
        {
          label: "SLOTS",
          field: "timeInterval",
          sort: "asc"
          // width: 150
        },
        {
          label: "BREAK FROM",
          field: "breakfrom",
          sort: "asc"
          // width: 150
        },
        {
          label: "BREAK TO",
          field: "breakto",
          sort: "asc"
          // width: 150
        }
      ],
      rows: schedulernewList
    };

    let schedulergrid = "";
    schedulergrid = (
      <div className="table-grid mt-15">
        <div className="row headingTable">
          <div className="mf-6">
            <h1>PROVIDER SCHEDULER</h1>
          </div>
          <div className="mf-6 headingRightTable"></div>
        </div>

        <div className="tableGridContainer text-nowrap">
          <div className="tableGridContainer">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={providerSchedulerGrid}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
      </div>
    );

    return (
      <React.Fragment>
        <div
          id="providerModal"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          aria-hidden="true"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div
            className="modal-dialog modal-lg"
            style={{ overflowY: " initial !important" }}
          >
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <div className="modal-header">
                <button
                  style={{ marginTop: "-40px", marginRight: "-40px" }}
                  onClick={this.props.onClose()}
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true"></span>
                </button>
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.providerModel.name.toUpperCase() +
                          " - " +
                          this.state.providerModel.id
                          : "NEW PROVIDER"}
                      </h1>
                    </div>
                    <div
                      className="mf-6 popupHeadingRight"
                      style={{ paddingRight: "3%" }}
                    >
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkBox"
                          id="isActive"
                          name="isActive"
                          checked={!isActive}
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                        disabled={this.isDisabled(this.props.rights.delete)}
                      >
                        Delete
                      </Input>
                      {this.state.editId > 0 ? dropdown : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight, overflowY: "auto" }}
              >
                <div className="mainTable">
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        Name <span className="redlbl"> *</span>
                      </label>

                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.nameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.providerModel.name}
                          name="name"
                          id="name"
                          max="60"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.nameValField}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Title</label>
                      <select
                        name="title"
                        id="title"
                        value={this.state.providerModel.title}
                        onChange={this.handleChange}
                      >
                        {titles.map(s => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="row-form" style={{ marginLeft: "60px" }}>
                    <div className="mf-6">
                      <div className="row-form">
                        <div className="mf-6">
                          <label>
                            LastName <span className="redlbl">*</span>
                          </label>

                          <div className="textBoxValidate">
                            <Input
                              className={
                                this.state.validationModel.lastNameValField
                                  ? this.errorField
                                  : ""
                              }
                              type="text"
                              value={this.state.providerModel.lastName}
                              name="lastName"
                              id="lastName"
                              max="35"
                              onChange={() => this.handleChange}
                            />
                            {this.state.validationModel.lastNameValField}
                          </div>
                        </div>
                        <div className="mf-4" style={{ marginLeft: "20px" }}>
                          <label>MI</label>
                          <Input
                            type="text"
                            max="3"
                            value={this.state.providerModel.middleInitial}
                            name="middleInitial"
                            id="middleInitial"
                            onChange={() => this.handleChange}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>
                        First Name <span className="redlbl"> *</span>
                      </label>

                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.firstNameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.providerModel.firstName}
                          name="firstName"
                          id="firstName"
                          max="35"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.firstNameValField}
                      </div>
                    </div>
                  </div>
                  <div className="mf-12 headingOne mt-25">
                    <p>Legal Information</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        NPI <span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <input
                          className={
                            this.state.validationModel.npiValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.providerModel.npi}
                          name="npi"
                          id="npi"
                          maxLength="10"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                          onInput={this.onPaste}
                        />
                        {this.state.validationModel.npiValField}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>SSN</label>
                      <div className="textBoxValidate">
                        <input
                          className={
                            this.state.validationModel.ssnValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.providerModel.ssn}
                          name="ssn"
                          id="ssn"
                          maxLength="9"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                          onInput={this.onPaste}
                        />
                        {this.state.validationModel.ssnValField}
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Taxonomy Code</label>
                      <div //className="textBoxValidate"
                        className="selectBoxValidate autSelectControl"
                      >
                        <Select
                          className={
                            this.state.validationModel.taxonomyCodeValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          max="10"
                          value={this.state.taxonomyCode}
                          name="taxonomyCode"
                          id="taxonomyCode"
                          // onChange={() => this.handleChange}
                          onChange={event =>
                            this.handletaxonomyCodeChange(event)
                          }
                          options={this.props.userInfo1.taxonomy}
                          placeholder=""
                          isClearable={true}
                          isSearchable={true}
                          openMenuOnClick={false}
                          escapeClearsValue={true}
                          styles={{
                            indicatorSeparator: () => { },
                            clearIndicator: defaultStyles => ({
                              ...defaultStyles,
                              color: "#286881"
                            }),
                            container: defaultProps => ({
                              ...defaultProps,
                              position: "absolute",
                              width: "29%"
                            }),
                            indicatorsContainer: defaultStyles => ({
                              ...defaultStyles,
                              padding: "0px",
                              marginBottom: "0",
                              marginTop: "0px",
                              height: "36px",
                              borderBottomRightRadius: "10px",
                              borderTopRightRadius: "10px"
                              // borderRadius:"0 6px 6px 0"
                            }),
                            indicatorContainer: defaultStyles => ({
                              ...defaultStyles,
                              padding: "9px",
                              marginBottom: "0",
                              marginTop: "1px",
                              // borderBottomRightRadius: "5px",
                              // borderTopRightRadius: "5px",
                              borderRadius: "0 4px 4px 0"
                            }),
                            dropdownIndicator: defaultStyles => ({
                              display: "none"
                            }),
                            input: defaultStyles => ({
                              ...defaultStyles,
                              margin: "0px",
                              padding: "0px"
                              // display:'none'
                            }),
                            singleValue: defaultStyles => ({
                              ...defaultStyles,
                              fontSize: "16px",
                              transition: "opacity 300ms"
                              // display:'none'
                            }),
                            control: defaultStyles => ({
                              ...defaultStyles,
                              minHeight: "33px",
                              height: "33px",
                              height: "33px",
                              paddingLeft: "10px",
                              //borderColor:"transparent",
                              borderColor: "#C6C6C6",
                              boxShadow: "none",
                              borderColor: "#C6C6C6",
                              "&:hover": {
                                borderColor: "#C6C6C6"
                              }
                              // display:'none'
                            })
                          }}
                        />
                        {this.state.validationModel.taxonomyCodeValField}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>DEA Number</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.deaNumber}
                        name="deaNumber"
                        id="deaNumber"
                        max="20"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>UPIN Number</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.upinNumber}
                        name="upinNumber"
                        id="upinNumber"
                        max="20"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>License Number</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.licenceNumber}
                        name="licenceNumber"
                        id="licenceNumber"
                        max="20"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Fax #</label>
                      <input
                        className={
                          this.state.validationModel.faxNumberValField
                            ? this.errorField
                            : ""
                        }
                        type="text"
                        value={this.state.providerModel.faxNumber}
                        name="faxNumber"
                        id="faxNumber"
                        maxLength="10"
                        onChange={() => this.handleChange}
                        onKeyPress={event => this.handleNumericCheck(event)}
                        onInput={this.onPaste}
                      />
                      <div className="textBoxValidate">
                        {this.state.validationModel.faxNumberValField}
                      </div>
                    </div>
                    <div className="mf-6"></div>
                  </div>

                  <div className="mf-12 headingOne mt-25">
                    <p>Address Information</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Address 1</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.address1}
                        name="address1"
                        id="address1"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Address 2</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.address2}
                        name="address2"
                        id="address2"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>City - State</label>
                      <div className="textBoxTwoField">
                        <Input
                          type="text"
                          value={this.state.providerModel.city}
                          name="city"
                          id="city"
                          max="20"
                          onChange={() => this.handleChange}
                        />
                        <select
                          name="state"
                          id="state"
                          value={this.state.providerModel.state}
                          onChange={this.handleChange}
                        >
                          {usStates.map(s => (
                            <option key={s.value} value={s.value}>
                              {s.display}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Zip Code - Fax</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.zipCodeValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.providerModel.zipCode}
                            name="zipCode"
                            id="zipCode"
                            max="9"
                            onChange={() => this.handleZip}
                            onKeyPress={event => this.handleNumericCheck(event)}
                          />
                          {this.state.validationModel.zipCodeValField}
                        </div>

                        <div className="twoColValidate">
                          <input
                            className={
                              this.state.validationModel.officePhoneNumValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.providerModel.faxNumber}
                            name="faxNumber"
                            id="faxNumber"
                            maxLength="10"
                            onChange={() => this.handleChange}
                            onKeyPress={event => this.handleNumericCheck(event)}
                            onInput={this.onPaste}
                          />
                          {this.state.validationModel.faxNumber}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Email</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.email}
                        name="email"
                        id="email"
                        max="60"
                        onChange={() => this.handleChange}
                      />
                      <div className="textBoxValidate">
                        {this.state.validationModel.emailValField}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Phone - Extension</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <NumberFormat
                            format="00 (###) ###-####"
                            mask="_"
                            className={
                              this.state.validationModel.officePhoneNumValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.providerModel.officePhoneNum}
                            max="10"
                            name="officePhoneNum"
                            id="officePhoneNum"
                            onChange={this.handleChange}
                          // onKeyPress={event => this.handleNumericCheck(event)}
                          />

                          {this.state.validationModel.officePhoneNumValField}
                        </div>
                        <div className="twoColValidate">
                          <input
                            className={
                              this.state.validationModel.faxNumberValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.providerModel.phoneNumExt}
                            maxLength="4"
                            name="phoneNumExt"
                            id="phoneNumExt"
                            onChange={() => this.handleChange}
                            onKeyPress={event => this.handleNumericCheck(event)}
                            onInput={this.onPaste}
                          />
                          {/* {this.state.validationModel.faxNumberValField} */}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12 field_full-8">
                      <label>Notes:</label>
                      <textarea
                        name="notes"
                        id="notes"
                        cols="30"
                        rows="10"
                        value={this.state.providerModel.notes}
                        onChange={this.handleChange}
                      ></textarea>
                    </div>
                  </div>

                  <div className="row-form headingOneChkBox mt-25">
                    <div className="mf-6">
                      <p>Pay to Address Information</p>
                    </div>

                    <div
                      className="mf-6 popupHeadingRight"
                      style={{ paddingRight: "120px" }}
                    >
                      <div className="lblChkBox">
                        <input
                          type="checkbox"
                          id="sameAsAddress"
                          name="sameAsAddress"
                          checked={this.state.Checked}
                          onChange={this.handleSameAsAddress}
                        />
                        <label htmlFor="sameAsAddress">
                          <span> Same As Address </span>
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>Address 1</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.payToAddress1}
                        name="payToAddress1"
                        id="payToAddress1"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Address 2</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.payToAddress2}
                        name="payToAddress2"
                        id="payToAddress2"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>City - State</label>
                      <div className="textBoxTwoField">
                        <Input
                          type="text"
                          value={this.state.providerModel.payToCity}
                          name="payToCity"
                          id="payToCity"
                          max="20"
                          onChange={() => this.handleChange}
                        />
                        <select
                          name="payToState"
                          id="payToState"
                          value={this.state.providerModel.payToState}
                          onChange={this.handleChange}
                        >
                          {usStates.map(s => (
                            <option key={s.value} value={s.value}>
                              {s.display}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Zip Code - Phone</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.zipCodeValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.providerModel.payToZipCode}
                            name="payToZipCode"
                            id="payToZipCode"
                            max="9"
                            onChange={() => this.handleZip}
                            onKeyPress={event => this.handleNumericCheck(event)}
                          />
                          {this.state.validationModel.zipCodeValField}
                        </div>

                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.officePhoneNumValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.providerModel.payofficePhoneNum}
                            name="officePhoneNum"
                            id="officePhoneNum"
                            max="10"
                            onChange={() => this.handleChange}
                            onKeyPress={event => this.handleNumericCheck(event)}
                          />
                          {this.state.validationModel.officePhoneNumValField}
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* <div className="row-form">
                    <div className="mf-6">
                      <label>Email</label>
                      <Input
                        type="text"
                        value={this.state.providerModel.email}
                        name="email"
                        id="email"
                        max="30"
                        onChange={() => this.handleChange}
                      />
                      <div className="textBoxValidate">
                        {this.state.validationModel.emailValField}
                      </div>
                    </div>
                    <div className="mf-6">&nbsp;</div>
                  </div> */}
                  {/* <div className="row-form">
                    <div className="mf-12 field_full-8">
                      <label>Notes:</label>
                      <textarea
                        name="notes"
                        id="notes"
                        cols="30"
                        rows="10"
                        value={this.state.providerModel.notes}
                        onChange={this.handleChange}
                      ></textarea>
                    </div>
                  </div> */}

                  <div className="row-form headingOneChkBox mt-25">
                    <div className="mf-6">
                      <p>Insurnace Billing Option</p>
                    </div>

                    <div
                      className="mf-6 popupHeadingRight"
                      style={{ paddingRight: "120px" }}
                    >
                      <div className="lblChkBox">
                        <input
                          type="checkbox"
                          id="billUnderProvider"
                          name="billUnderProvider"
                          checked={this.state.providerModel.billUnderProvider}
                          onChange={this.handleCheckbox}
                        //value={this.state.providerModel.billUnderProvider}
                        />

                        <label htmlFor="billUnderProvider">
                          <span> Bill Under Provider </span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12">{plangrid}</div>
                  </div>

                  {/* //////////////////////// Scheluer ///////////////////////////// */}

                  <div className="row-form headingOneChkBox mt-25">
                    <div className="mf-6">
                      <p>Scheduler Setting</p>
                    </div>

                    <div
                      className="mf-6 popupHeadingRight"
                      style={{ paddingRight: "120px" }}
                    >
                      <label htmlFor="Locations" style={{ marginLeft: "54%" }}>
                        <span> Locations </span>
                      </label>
                      <div className="textBoxTwoField">
                        <div
                          className="twoColValidate"
                          style={{ marginLeft: "98%", marginTop: "-9%" }}
                        >
                          <select
                            style={{ width: "169px", marginLeft: "-40%" }}
                            name="userLocations"
                            id="userLocations"
                            value={this.state.providerModel.userLocations}
                            onChange={this.handleLocationChange}
                          >
                            {this.state.userLocations.map(s => (
                              <option key={s.id} value={s.id}>
                                {s.description}
                              </option>
                            ))}
                          </select>
                          {/* {this.state.validationModel.zipCodeValField} */}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12">{schedulergrid}</div>
                  </div>
                </div>

                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <input
                          type="button"
                          value="Save"
                          className="btn-blue"
                          onClick={this.saveNewProvider}
                          disabled={this.isDisabled(
                            this.state.editId > 0
                              ? this.props.rights.update
                              : this.props.rights.add
                          )}
                        ></input>

                        <input
                          type="button"
                          value="Cancel"
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        ></input>

                        {/* <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                          Cancel
                        </button> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.providerSearch,
        add: state.loginInfo.rights.providerCreate,
        update: state.loginInfo.rights.providerEdit,
        delete: state.loginInfo.rights.providerDelete,
        export: state.loginInfo.rights.providerExport,
        import: state.loginInfo.rights.providerImport
      }
      : [],
    taxonomyCode:
      state.loginInfo.taxonomy == null ? [] : state.loginInfo.taxonomy
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
      userInfo: userInfo,
      taxonomyCodeAction: taxonomyCodeAction,
      ProviderAction: ProviderAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewProvider);
