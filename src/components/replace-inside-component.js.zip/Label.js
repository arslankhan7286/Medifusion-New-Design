import React from 'react'

function Label(props) {

    return (
        <label name={props.name}>{props.name}</label>
    )
}

export default Label
