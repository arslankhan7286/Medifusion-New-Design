import React, { Component } from "react";
import axios from "axios";

import Input from "./Input";
import Label from "./Label";
import Swal from "sweetalert2";
import $ from "jquery";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import insuranceCardFront from "../images/insurance-card-front.jpg";
import insuranceCardBack from "../images/insurance-card-back.jpg";
import uploadPicIcon from "../images/upload-pic-icon.png";
import TopForm from "../components/TopForm/TopForm";

import { isNullOrUndefined } from "util";
import { MDBDataTable } from "mdbreact";
import { MDBBtn } from "mdbreact";
import NewPatientPayment from "./NewPatientPayment";
import { tsExpressionWithTypeArguments } from "@babel/types";
import { EOVERFLOW } from "constants";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import GridHeading from "./GridHeading";
import SearchHeading from "./SearchHeading";

class PatientPayment extends Component {
  constructor(props) {
    super(props);
    this.patientPaymentUrl = process.env.REACT_APP_URL + "/PatientPayment/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*",
      },
    };

    this.patientPaymentModel = {
      id: "",
      paymentDate: null,
      status: "",
      checkNumber: "",
      patientID: this.props.id,
    };

    this.state = {
      data: [],
      patientPaymentModel: this.patientPaymentModel,
      showPopup: false,
      id: 0,
      editid: this.props.id,
    };

    this.handleChange = this.handleChange.bind(this);
    this.openPopup = this.openPopup.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
  }

  searchpayment = (e) => {
    console.log("model", this.state.patientPaymentModel);
    this.setState({ loading: true });
    axios
      .post(
        this.patientPaymentUrl + "FindPatientPayment/",
        this.state.patientPaymentModel,
        this.config
      )
      .then((response) => {
        console.log("Patient Payment Search Response : ", response.data);

        let newList = [];
        response.data.map((row, i) => {
          var paymentDate = row.paymentDate === null ? "  " : row.paymentDate; // handle null condition
          var paymentMethod =
            row.paymentMethod === null ? "  " : row.paymentMethod;
          var paymentAmount =
            row.paymentAmount === null ? "  " : row.paymentAmount;
          var allocatedAmount =
            row.allocatedAmount === null ? "  " : row.allocatedAmount;
          var remainingAmount =
            row.remainingAmount === null ? "  " : row.remainingAmount;
          var status = row.status === null ? "  " : row.status;

          newList.push({
            id: row.id,

            paymentDate: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPopup(row.id)}
              >
                {row.paymentDate}
              </MDBBtn>
            ),
            paymentMethod: paymentMethod,
            paymentAmount: paymentAmount > 0 ? "$" + paymentAmount : "",
            allocatedAmount: allocatedAmount > 0 ? "$" + allocatedAmount : "",
            remainingAmount: remainingAmount > 0 ? "$" + remainingAmount : "",
            status: status,
            checkNumber: row.checkNumber,
          });
        });
        this.setState({ data: newList, loading: false });
      })
      .catch((error) => {
        this.setState({ loading: false });
        Swal.fire("Something Wrong", "Please Check Server Connection", "error");
        let errorsList = [];
        if (error.response !== null && error.response.data !== null) {
          errorsList = error.response.data;
          console.log(errorsList);
        } else console.log(error);
      });
    e.preventDefault();
  };

  handleChange = (event) => {
    this.setState({
      patientPaymentModel: {
        ...this.state.patientPaymentModel,
        [event.target.name]:
          event.target.name == "checkNumber"
            ? event.target.value.toUpperCase()
            : event.target.value,
      },
    });
  };

  closePopup = () => {
    $("#myModal1").hide();
    this.setState({ showPopup: false });
  };

  openPopup = (id) => {
    this.setState({ showPopup: true, id: id });
  };

  //clear fields button
  clearFields = (event) => {
    this.setState({
      patientPaymentModel: this.patientPaymentModel,
    });
  };

  handleDateChange = (date) => {
    this.setState({
      patientPaymentModel: {
        ...this.state.patientPaymentModel,
        paymentDate: date.target.value,
      },
    });
  };

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  render() {
    console.log("id", this.state.patientPaymentModel[0]);

    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150,
        },
        {
          label: "PAYMENT DATE",
          field: "paymentDate",
          sort: "asc",
          width: 150,
        },
        {
          label: "PAYMENT METHOD",
          field: "paymentMethod",
          sort: "asc",
          width: 150,
        },
        {
          label: "PAYMENT AMOUNT",
          field: "paymentAmount",
          sort: "asc",
          width: 150,
        },
        {
          label: "ALLOCATED AMOUNT",
          field: "allocatedAmount",
          sort: "asc",
          width: 150,
        },
        {
          label: "REMAINING AMOUNT",
          field: "remainingAmount",
          sort: "asc",
          width: 150,
        },
        {
          label: "STATUS",
          field: "status",
          sort: "asc",
          width: 150,
        },
      ],
      rows: this.state.data,
    };

    const status = [
      { value: "", display: "Select Status" },
      { value: "O", display: "Open" },
      { value: "C", display: "Close" },
    ];

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewPatientPayment
          onClose={() => this.closePopup}
          pid={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewPatientPayment>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <GifLoader
          loading={true}
          imageSrc={Eclips}
          // imageStyle={imageStyle}
          overlayBackground="rgba(0,0,0,0.5)"
        />
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <TopForm patientID={this.props.id} />
        <div className="col py-3">
          <div className="col-md-12">
            <div className="mainHeading row">
              <div className="col-md-6">
                <h1>PATIENT PAYMENT SEARCH</h1>
              </div>
              <div className="col-md-6 headingRight">
                <button
                  data-toggle="modal"
                  data-target=".bs-example-modal-new"
                  className="btn-blue-icon"
                  disabled={this.isDisabled(this.props.rights.add)}
                  onClick={() => this.openPopup(0)}
                >
                  Add New +{" "}
                </button>
              </div>
            </div>
            {/* <SearchHeading heading='PATIENT PAYMENT SEARCH' 
                    disabled={this.isDisabled(this.props.rights.add)}
                    onClick={() => this.openPopup(0)}>
                                      </SearchHeading> */}
            <form onSubmit={(event) => this.searchpayment(event)}>
              <div className="mainTable">
                <div className="row-form">
                  <div className="mf-4">
                    <label>Payment Date </label>
                    <div class="textBoxValidate">
                      <input
                        type="date"
                        name="planBeginDate"
                        id="planBeginDate"
                        value={this.state.patientPaymentModel.paymentDate}
                        onChange={this.handleDateChange}
                      />
                    </div>
                  </div>
                  <div class="mf-4">
                    <label>Check#</label>
                    <input
                      type="text"
                      name="checkNumber"
                      value={this.state.patientPaymentModel.checkNumber}
                      onChange={this.handleChange}
                    />
                  </div>
                  <div class="mf-4">
                    <label>Status</label>
                    <select
                      name="status"
                      id="status"
                      value={this.state.patientPaymentModel.status}
                      onChange={this.handleChange}
                    >
                      {status.map((s) => (
                        <option key={s.value} value={s.value}>
                          {s.display}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div class="modal-footer">
                <div class="mainTable">
                  <div class="row-form row-btn">
                    <div class="mf-12">
                      <Input
                        type="submit"
                        name="name"
                        id="name"
                        className="btn-blue"
                        value="Search"
                        disabled={this.isDisabled(this.props.rights.search)}
                      />

                      <button
                        class="btn-grey"
                        data-dismiss="modal"
                        onClick={(event) => this.clearFields(event)}
                      >
                        {" "}
                        Clear{" "}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
            <div className="mf-12 table-grid mt-15">
              <GridHeading
                Heading="PATIENT PAYMENT SEARCH RESULT"
                disabled={this.isDisabled(this.props.rights.export)}
              ></GridHeading>

              <div className="tableGridContainer text-nowrap">
                <MDBDataTable
                  responsive={true}
                  striped
                  bordered
                  searching={false}
                  data={data}
                  displayEntries={false}
                  sortable={true}
                  scrollX={false}
                  scrollY={false}
                />
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.patientPaymentSearch,
        add: state.loginInfo.rights.patientPaymentCreate,
        update: state.loginInfo.rights.patientPaymentUpdate,
        delete: state.loginInfo.rights.patientPaymentDelete,
        export: state.loginInfo.rights.patientPaymentExport,
        import: state.loginInfo.rights.patientPaymentImport,
      }
      : [],
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(PatientPayment);
