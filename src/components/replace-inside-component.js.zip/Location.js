import React, { Component } from "react";
import axios from "axios";
import { MDBDataTable, MDBBtn } from "mdbreact";
import Input from "./Input";
import Label from "./Label";
import GridHeading from "./GridHeading";
import searchIcon from "../images/search-icon.png";
import refreshIcon from "../images/refresh-icon.png";
import newBtnIcon from "../images/new-page-icon.png";
import settingsIcon from "../images/setting-icon.png";
import NewLocation from "./NewLocation.js";
import SearchHeading from "./SearchHeading";
import Swal from "sweetalert2";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

import $ from "jquery";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import NewPractice from "./NewPractice";

import Hotkeys from "react-hot-keys";
export class Location extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/Location/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      name: "",
      organizationName: "",
      practice: "",
      npi: "",
      posCode: "",
      address: ""
    };
    this.state = {
      searchModel: this.searchModel,
      id: 0,
      data: [],
      showPopup: false,
      showPracticePopup: false,
      loading: false
    };

    this.searchLocation = this.searchLocation.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.clearFields = this.clearFields.bind(this);
    this.onPaste = this.onPaste.bind(this);
    this.openLocationPopup = this.openLocationPopup.bind(this);
    this.closeLocationPopup = this.closeLocationPopup.bind(this);
    this.openPracticePopup = this.openPracticePopup.bind(this);
    this.closePracticePopup = this.closePracticePopup.bind(this);
  }
  onKeyDown(keyName, e, handle) {
    if (keyName == "alt+n") {
      // alert("search key")
      this.openLocationPopup(0);
    } else if (keyName == "alt+s") {
      this.searchLocation(e);
    } else if (keyName == "alt+c") {
      // alert("clear skey")
      this.clearFields(e);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }
  onKeyUp(keyName, e, handle) {
    if (e) {
      // this.onKeyDown(keyName, e , handle);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  searchLocation = e => {
    e.preventDefault();
    this.setState({ loading: true });

    axios
      .post(this.url + "FindLocations", this.state.searchModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            name: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openLocationPopup(row.id)}
              >
                {row.name}
              </MDBBtn>
            ),
            organizationName: row.organizationName,
            practice: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPracticePopup(row.practiceID)}
              >
                {row.practice}
              </MDBBtn>
            ),
            npi: row.npi,
            posCode: row.posCode,
            address: row.address
          });
        });
        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false });
      });
    e.preventDefault();
  };

  handleChange = event => {
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    event.preventDefault();
    this.setState({
      searchModel: { [event.target.name]: event.target.value.toUpperCase() }
    });
  };

  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  openLocationPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  closeLocationPopup = () => {
    $("#locationModal").hide();
    this.setState({ showPopup: false });
  };

  openPracticePopup = id => {
    this.setState({ showPracticePopup: true, id: id });
  };

  closePracticePopup = () => {
    $("#practiceModal").hide();
    this.setState({ showPracticePopup: false });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  onPaste(event) {
    var x = event.target.value;
    x = x.trim();
    var regex = /^[0-9]+$/;
    if (x.length == 0) {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          [event.target.name]: x
        }
      });
      return;
    }

    if (!x.match(regex)) {
      Swal.fire("Error", "Should be Number", "error");
      return;
    } else {
      this.setState({
        searchModel: {
          ...this.state.searchModel,
          [event.target.name]: x
        }
      });
      // this.setState({
      //   searchModel: { [event.target.name]: x }
      // });
    }
    return;
  }

  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc"
          // width: 150,
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc"
          // width: 250
        },
        {
          label: "ORGANIZATION NAME",
          field: "organizationName",
          sort: "asc"
          // width: 150
        },
        {
          label: "PRACTICE",
          field: "practice",
          sort: "asc"
          // width: 150
        },
        {
          label: "NPI",
          field: "npi",
          sort: "asc"
          // width: 150
        },
        {
          label: "POSCODE",
          field: "posCode",
          sort: "asc"
          // width: 150
        },
        {
          label: "ADDRESS",
          field: "address",
          sort: "asc"
          // width: 150
        }
      ],
      rows: this.state.data
    };
    let popup = "";

    if (this.state.showPopup) {
      popup = (
        <NewLocation
          onClose={() => this.closeLocationPopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewLocation>
      );
    } else if (this.state.showPracticePopup) {
      popup = (
        <NewPractice
          onClose={() => this.closePracticePopup}
          practiceID={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
        ></NewPractice>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }
    return (
      <div>
        <React.Fragment>
          {spiner}

          <Hotkeys
            keyName="alt+n"
            onKeyDown={this.onKeyDown.bind(this)}
            onKeyUp={this.onKeyUp.bind(this)}
          >
            <SearchHeading
              heading="LOCATION SEARCH"
              handler={() => this.openLocationPopup(0)}
              disabled={this.isDisabled(this.props.rights.add)}
            ></SearchHeading>
          </Hotkeys>

          <form onSubmit={event => this.searchLocation(event)}>
            <div className="mainTable">
              <div className="row-form">
                <div className="mf-6">
                  <Label name="Name"></Label>
                  <Input
                    type="text"
                    name="name"
                    id="name"
                    max="60"
                    value={this.state.searchModel.name}
                    onChange={() => this.handleChange}
                  />
                </div>
                <div className="mf-6">
                  <Label name="Organization Name"></Label>
                  <Input
                    type="text"
                    name="organizationName"
                    id="organizationName"
                    max="60"
                    value={this.state.searchModel.organizationName}
                    onChange={() => this.handleChange}
                  />
                </div>
              </div>

              <div className="row-form">
                <div className="mf-6">
                  <Label name="Practice"></Label>
                  <Input
                    type="text"
                    name="practice"
                    id="practice"
                    max="20"
                    value={this.state.searchModel.practice}
                    onChange={() => this.handleChange}
                  />
                </div>
                <div className="mf-6">
                  <Label name="NPI"></Label>
                  <input
                    type="text"
                    name="npi"
                    id="npi"
                    maxLength="10"
                    onKeyPress={event => this.handleNumericCheck(event)}
                    value={this.state.searchModel.npi}
                    onChange={() => this.handleChange}
                    onInput={this.onPaste}
                  />
                </div>
              </div>

              <div className="row-form">
                <div className="mf-6">
                  <Label name="POS Code"></Label>
                  <Input
                    type="text"
                    name="posCode"
                    id="posCode"
                    max="20"
                    value={this.state.searchModel.posCode}
                    onChange={() => this.handleChange}
                  />
                </div>
                <div className="mf-6">
                  <label>&nbsp;</label>
                </div>
              </div>

              <div className="row-form row-btn">
                <div className="mf-12">
                  <div className="mf-12">
                    <Hotkeys
                      keyName="alt+s"
                      onKeyDown={this.onKeyDown.bind(this)}
                      onKeyUp={this.onKeyUp.bind(this)}
                    >
                      <Input
                        type="submit"
                        name="name"
                        id="name"
                        className="btn-blue"
                        value="Search"
                        disabled={this.isDisabled(this.props.rights.search)}
                      />
                    </Hotkeys>

                    <Hotkeys
                      keyName="alt+c"
                      onKeyDown={this.onKeyDown.bind(this)}
                      onKeyUp={this.onKeyUp.bind(this)}
                    >
                      <Input
                        type="button"
                        name="name"
                        id="name"
                        className="btn-grey"
                        value="Clear"
                        onClick={() => this.clearFields()}
                      />
                    </Hotkeys>
                  </div>
                </div>
              </div>
            </div>
          </form>

          <div className="mf-12 table-grid mt-15">
            <GridHeading
              Heading="LOCATION SEARCH RESULT"
              disabled={this.isDisabled(this.props.rights.export)}
              dataObj={this.state.searchModel}
              url={this.url}
              methodName="Export"
              methodNamePdf="ExportPdf"
              length={this.state.data.length}
            ></GridHeading>

            <div className="tableGridContainer text-nowrap">
              <MDBDataTable
                responsive={true}
                striped
                bordered
                searching={false}
                data={data}
                displayEntries={false}
                sortable={true}
                scrollX={false}
                scrollY={false}
              />
            </div>
          </div>

          {popup}
        </React.Fragment>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.locationSearch,
          add: state.loginInfo.rights.locationCreate,
          update: state.loginInfo.rights.locationEdit,
          delete: state.loginInfo.rights.locationDelete,
          export: state.loginInfo.rights.locationExport,
          import: state.loginInfo.rights.locationImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(Location);
