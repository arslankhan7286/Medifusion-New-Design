import React, { Component } from "react";
import $ from "jquery";
import axios from "axios";
import Input from "./Input";
import Swal from "sweetalert2";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import Dropdown from "react-dropdown";
import settingsIcon from "../images/setting-icon.png";
import NewHistoryPractice from "./NewHistoryPractice";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { ModifierAction } from "../actions/ModifierAction";

import Hotkeys from "react-hot-keys";

class NewModifier extends Component {
  constructor(props) {
    super(props);

    this.errorField = "errorField";
    this.url = process.env.REACT_APP_URL + "/modifier/";
    this.commonUrl = process.env.REACT_APP_URL + "/Common/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };
    this.saveModifierCount = 0;
    this.validationModel = {
      modifierValField: "",
      descriptionValField: ""
    };
    this.modifierModal = {
      code: "",
      description: "",
      isActive: true,
      anesthesiaBaseUnits: "",
      defaultFees: ""
    };

    this.state = {
      modifierModal: this.modifierModal,
      validationModel: this.validationModel,
      editId: this.props.id,
      maxHeight: "361",
      loading: false,
      showPopup: false
    };
  }

  onKeyDown(keyName, e, handle) {
    console.log("test:onKeyDown", keyName, e, handle);

    if (keyName == "alt+s") {
      // alert("save key")
      this.saveModifier();
      console.log(e.which);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    console.log("test:onKeyUp", e, handle);
    if (e) {
      console.log("event has been called", e);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  async componentDidMount() {
    await this.setState({ loading: true });
    this.setModalMaxHeight($(".modal"));
    // if ($('.modal.in').length != 0) {
    //     this.setModalMaxHeight($('.modal.in'));
    // }

    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function() {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    if (this.state.editId > 0) {
      await axios
        .get(this.url + "findModifier/" + this.state.editId, this.config)
        .then(response => {
          console.log("Response : ", response.data);
          this.setState({ modifierModal: response.data });
        })
        .catch(error => {
          this.setState({ loading: false });
          try {
            let errorsList = [];
            if (error.response !== null && error.response.data !== null) {
              errorsList = error.response.data;
              console.log(errorsList);
            }
          } catch {
            console.log(error);
          }
        });
    }
    this.setState({ loading: false });
  }

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  handleChange = event => {
    event.preventDefault();
    this.setState({
      modifierModal: {
        ...this.state.modifierModal,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  handleCheck = () => {
    this.setState({
      modifierModal: {
        ...this.state.modifierModal,
        isActive: !this.state.modifierModal.isActive
      }
    });
  };

  saveModifier = e => {
    console.log("Before Update", this.saveModifierCount);
    if (this.saveModifierCount == 1) {
      return;
    }
    this.saveModifierCount = 1;
    console.log(this.state.modifierModal);
    // e.preventDefault();
    this.setState({ loading: true });

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.modifierModal.code) === true) {
      myVal.modifierValField = (
        <span className="validationMsg">Modifier is required</span>
      );
      myVal.validation = true;
    } else {
      myVal.modifierValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.modifierModal.description) === true) {
      myVal.descriptionValField = (
        <span className="validationMsg">Description is required</span>
      );
      myVal.validation = true;
    } else {
      myVal.descriptionValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      this.saveModifierCount = 0;
      return;
    }

    axios
      .post(this.url + "savemodifier", this.state.modifierModal, this.config)
      .then(response => {
        this.saveModifierCount = 0;
        //Get Modifiers API
        axios
          .get(this.commonUrl + "getModifiers", this.config)
          .then(modifierRes => {
            console.log("CPT Response : ", modifierRes.data);
            this.props.ModifierAction(
              this.props,
              modifierRes.data,
              "MODIFIER_ACTION"
            );
          })
          .catch(cptError => {
            this.saveModifierCount = 0;
            console.log("CPT Error : ", cptError);
          });
        this.setState({
          modifierModal: response.data,
          editId: response.data.id,
          loading: false
        });
        Swal.fire("Record Saved Successfully", "", "success");
        // $("#btnCancel").click();
      })
      .catch(error => {
        this.saveModifierCount = 0;
        this.setState({ loading: false });

        try {
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
            console.log(errorsList);
          }
        } catch {
          console.log(error);
        }
      });
  };

  delete = e => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.setState({ loading: true });

        axios
          .delete(this.url + "deleteModifier/" + this.state.editId, this.config)
          .then(response => {
            this.setState({ loading: false });

            //Get Modifiers API
            axios
              .get(this.commonUrl + "getModifiers", this.config)
              .then(modifierRes => {
                console.log("CPT Response : ", modifierRes.data);
                this.props.ModifierAction(
                  this.props,
                  modifierRes.data,
                  "MODIFIER_ACTION"
                );
              })
              .catch(cptError => {
                console.log("CPT Error : ", cptError);
              });

            console.log("Delete Response :", response);
            Swal.fire("Record Deleted Successfully", "", "success");
          })
          .catch(error => {
            this.setState({ loading: false });

            console.log(error);
            if (this.state.editId > 0) {
              Swal.fire(
                "Record Not Deleted!",
                "Record can not be delete, as it is being reference in other screens.",
                "error"
              );
            } else {
              Swal.fire(
                "Record Not Deleted!",
                "Don't have record to delete",
                "error"
              );
            }
          });
        $("#btnCancel").click();
      }
    });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  openhistorypopup = id => {
    this.setState({ showPopup: true, id: id });
  };
  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  render() {
    const isActive = this.state.modifierModal.isActive;
    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    const options = [
      { value: "History", label: "History", className: "dropdown" }
    ];

    var Imag;
    Imag = (
      <div>
        <img src={settingsIcon} />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup(0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
          // disabled={this.isDisabled(this.props.rights.update)}
          // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    return (
      <React.Fragment>
        <div
          id="myModal1"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          aria-hidden="true"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={
                  this.props.onClose
                    ? this.props.onClose()
                    : () => this.props.onClose()
                }
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.modifierModal.code
                          : "NEW MODIFIER"}
                      </h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkBox"
                          id="isActive"
                          name="isActive"
                          checked={!isActive}
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                        disabled={this.isDisabled(this.props.rights.delete)}
                      >
                        Delete
                      </Input>
                      {this.state.editId > 0 ? dropdown : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable">
                  {/* <div className="mf-12 headingOne mt-25">
                    <p>Modifier Information</p>
                  </div> */}
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        Modifier<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.modifierValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.modifierModal.code}
                          name="code"
                          id="code"
                          max="2"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.modifierValField}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>
                        Description<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.descriptionValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.modifierModal.description}
                          name="description"
                          id="description"
                          max="100"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.descriptionValField}
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12 headingOne mt-25">
                      <p>Anesthesia Settings</p>
                    </div>
                    <div className="mf-6">
                      <label>Base Units</label>
                      <div className="textBoxValidate">
                        <Input
                          type="text"
                          value={this.state.modifierModal.anesthesiaBaseUnits}
                          name="anesthesiaBaseUnits"
                          id="anesthesiaBaseUnits"
                          max="3"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        />
                      </div>
                    </div>
                    <div className="mf-6"></div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12 headingOne mt-25">
                      <p>Fees Settings</p>
                    </div>
                    <div className="mf-6">
                      <label>Default Fee</label>
                      <div className="textBoxValidate">
                        <Input
                          type="text"
                          value={this.state.modifierModal.defaultFees}
                          name="defaultFees"
                          id="defaultFees"
                          max="10"
                          onChange={() => this.handleChange}
                          onKeyPress={event => this.handleNumericCheck(event)}
                        />
                      </div>
                    </div>
                    <div className="mf-6"></div>
                  </div>
                </div>

                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <Hotkeys
                          keyName="alt+s"
                          onKeyDown={this.onKeyDown.bind(this)}
                          onKeyUp={this.onKeyUp.bind(this)}
                        >
                          <input
                            type="button"
                            value="Save"
                            className="btn-blue"
                            onClick={this.saveModifier}
                            disabled={this.isDisabled(
                              this.state.editId > 0
                                ? this.props.rights.update
                                : this.props.rights.add
                            )}
                          ></input>
                        </Hotkeys>

                        <input
                        type="button"
                        value="Cancel"
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                        </input>

                        {/* <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                          Cancel
                        </button> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}
function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.modifiersSearch,
          add: state.loginInfo.rights.modifiersCreate,
          update: state.loginInfo.rights.modifiersEdit,
          delete: state.loginInfo.rights.modifiersDelete,
          export: state.loginInfo.rights.modifiersExport,
          import: state.loginInfo.rights.modifiersImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
      ModifierAction: ModifierAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewModifier);
