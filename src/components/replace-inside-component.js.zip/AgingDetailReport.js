import React, { Component } from "react";
import Label from "./Label";
import Input from "./Input";
import {
  MDBDataTable,
  MDBBtn,
  MDBTableHead,
  MDBTableBody,
  MDBTable
} from "mdbreact";
import GridHeading from "./GridHeading";
import axios from "axios";
import Swal from "sweetalert2";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import moment from "moment";
//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class AgingDetailReport extends Component {
  constructor(props) {
    super(props);
    this.url = process.env.REACT_APP_URL + "/RFirstAgingReport/";
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      patientAccountNumber: "",
      patientName: "",
      dateOfServiceFrom: "",
      dateOfServiceTo: "",
      entryDateFrom: "",
      entryDateTo: "",
      submittedDateTo: "",
      submittedDateFrom: "",
      payerName: "",
      Plan: "",
      ageType: "D"
    };

    //Validation Model
    this.validationModel = {
      dosFromValField: "",
      dosToFDValField: "",
      dosToGreaterValField: null,
      dosToGreaterValField: null,
      selectDOSFromValField: null,
      EntryDateToGreaterValField: null,
      selectEntryFromValField: null,
      entryDateFromValField: "",
      entryDateToValField: "",
      submittedDateFromValField: "",
      submittedDateToValField: "",
      SubmitDateToGreaterValField: "",
      selectSubmitFromValField: "",
      validation: false
    };

    this.state = {
      searchModel: this.searchModel,
      validationModel: this.validationModel,
      data: [],
      loading: false
    };
  }

  searchAgingReports = e => {
    console.log("Model for Search: ", this.state.searchModel);
    e.preventDefault();
    this.setState({ loading: true });

    var myVal = this.validationModel;
    myVal.validation = false;

    //DOS From Future Date Validation
    if (this.isNull(this.state.searchModel.dateOfServiceFrom) == false) {
      if (
        new Date(
          moment(this.state.searchModel.dateOfServiceFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.dosFromValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.dosFromValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.dosFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //DOS To Future Date Validation
    if (this.isNull(this.state.searchModel.dateOfServiceTo) == false) {
      if (
        new Date(
          moment(this.state.searchModel.dateOfServiceTo)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.dosToFDValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.dosToFDValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.dosToFDValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //DOS To must be greater than DOS From Validation
    if (
      this.isNull(this.state.searchModel.dateOfServiceFrom) == false &&
      this.isNull(this.state.searchModel.dateOfServiceTo) == false
    ) {
      if (
        new Date(
          moment(this.state.searchModel.dateOfServiceFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment(this.state.searchModel.dateOfServiceTo)
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.dosToGreaterValField = (
          <span className="validationMsg">
            DOS To must be greater than DOS From
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.dosToGreaterValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.dosToGreaterValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }
    //if DOs To is selected Then Make sure than DOS Form is also selected Validation
    if (
      this.isNull(this.state.searchModel.dateOfServiceFrom) == true &&
      this.isNull(this.state.searchModel.dateOfServiceTo) == false
    ) {
      console.log("Select DOS From");
      myVal.selectDOSFromValField = (
        <span className="validationMsg">Select DOS From</span>
      );
      myVal.validation = true;
      if (myVal.validation == false) myVal.validation = false;
    } else {
      myVal.selectDOSFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Entry Date From Future Date Validation
    if (this.isNull(this.state.searchModel.entryDateFrom) == false) {
      if (
        new Date(
          moment(this.state.searchModel.entryDateFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.entryDateFromValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.entryDateFromValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.entryDateFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Entry Date To Future Date Validation
    if (this.isNull(this.state.searchModel.entryDateTo) == false) {
      if (
        new Date(
          moment(this.state.searchModel.entryDateTo)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.entryDateToValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.entryDateToValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.entryDateToValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Entry Date To must be greater than Entry Date From Validation
    if (
      this.isNull(this.state.searchModel.entryDateFrom) == false &&
      this.isNull(this.state.searchModel.entryDateTo) == false
    ) {
      if (
        new Date(
          moment(this.state.searchModel.entryDateFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment(this.state.searchModel.entryDateTo)
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.EntryDateToGreaterValField = (
          <span className="validationMsg">
            Entry Date To must be greater than Entry Date From
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.EntryDateToGreaterValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.EntryDateToGreaterValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }
    //if Entry Date To is selected Then Make sure than Entry date Form is also selected Validation
    if (
      this.isNull(this.state.searchModel.entryDateFrom) == true &&
      this.isNull(this.state.searchModel.entryDateTo) == false
    ) {
      console.log("Select DOS From");
      myVal.selectEntryFromValField = (
        <span className="validationMsg">Select Entry Date From</span>
      );
      myVal.validation = true;
      if (myVal.validation == false) myVal.validation = false;
    } else {
      myVal.selectEntryFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Submitted Date From Future Date Validation
    if (this.isNull(this.state.searchModel.submittedDateFrom) == false) {
      if (
        new Date(
          moment(this.state.searchModel.submittedDateFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.submittedDateFromValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.submittedDateFromValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.submittedDateFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //submittedDate  To must be greater than submittedDate From Validation
    if (
      this.isNull(this.state.searchModel.submittedDateFrom) == false &&
      this.isNull(this.state.searchModel.submittedDateTo) == false
    ) {
      if (
        new Date(
          moment(this.state.searchModel.submittedDateFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment(this.state.searchModel.submittedDateTo)
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.SubmitDateToGreaterValField = (
          <span className="validationMsg">
            Submit Date To must be greater than Submit Date From
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.SubmitDateToGreaterValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.SubmitDateToGreaterValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Submitted Date From Future Date Validation
    if (this.isNull(this.state.searchModel.submittedDateTo) == false) {
      if (
        new Date(
          moment(this.state.searchModel.submittedDateTo)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.submittedDateToValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.submittedDateToValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.submittedDateToValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }
    //if Submit Date To is selected Then Make sure than Submit date Form is also selected Validation
    if (
      this.isNull(this.state.searchModel.submittedDateFrom) == true &&
      this.isNull(this.state.searchModel.submittedDateTo) == false
    ) {
      console.log("Select DOS From");
      myVal.selectSubmitFromValField = (
        <span className="validationMsg">Select Submit Date From</span>
      );
      myVal.validation = true;
      if (myVal.validation == false) myVal.validation = false;
    } else {
      myVal.selectSubmitFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    if (myVal.validation == true) {
      this.setState({ validationModel: myVal, loading: false });
      Swal.fire(
        "Something Wrong",
        "Please Select All Fields Properly",
        "error"
      );
      return;
    }

    axios
      .post(this.url + "FindAgingReportV1", this.state.searchModel, this.config)
      .then(response => {
        console.log("Aging Report Search Response : ", response.data);
        let newList = [];
        // response.data.map((row, i) => {
        //   newList.push({
        //     id: "row.id",
        //     payerName: row.payerName,
        //     current: this.isNull(row.current) == true ? " " : row.current + " ",
        //     isBetween30And60:
        //       this.isNull(row.isBetween30And60) == true
        //         ? " "
        //         : row.isBetween30And60 + " ",
        //     isBetween61And90:
        //       this.isNull(row.isBetween61And90) == true
        //         ? " "
        //         : row.isBetween61And90 + " ",
        //     isBetween91And120:
        //       this.isNull(row.isBetween91And120) == true
        //         ? " "
        //         : row.isBetween91And120 + " ",
        //     isGreaterThan120:
        //       this.isNull(row.isGreaterThan120) == true
        //         ? " "
        //         : row.isGreaterThan120 + " ",
        //     totalBalance:
        //       this.isNull(row.totalBalance) == true
        //         ? " "
        //         : row.totalBalance + " "
        //   });
        // });
        this.setState({ data: newList, loading: false });
        console.log(
          "new data",
          this.state.data,
          "loading ",
          this.state.loading
        );
      })
      .catch(error => {
        this.setState({ loading: false });
        Swal.fire("Something Wrong", "Please Check Server Connection", "error");
      });
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  //handle Change
  handleChange = event => {
    console.log(event.target.value);
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };
  //clear fields button
  clearFields = event => {
    var myVal = { ...this.validationModel };
    myVal.dosFromValField = "";
    myVal.dosToFDValField = "";
    myVal.dosToGreaterValField = "";
    myVal.selectDOSFromValField = "";
    // myVal.dosToGreaterValField="";

    myVal.entryDateFromValField = "";

    myVal.entryDateToValField = "";
    myVal.EntryDateToGreaterValField = "";
    myVal.selectEntryFromValField = "";

    myVal.submittedDateFromValField = "";
    myVal.submittedDateToValField = "";
    myVal.SubmitDateToGreaterValField = "";
    myVal.selectSubmitFromValField = "";
    myVal.validation = false;

    this.setState({
      searchModel: this.searchModel,
      validationModel: myVal
    });
  };

  render() {
    const ageType = [
      { value: "D", display: "DOS" },
      { value: "E", display: "ENTRY DATE" },
      { value: "S", display: "SUBMIT DATE" }
    ];
    var submittedDateFrom = this.state.searchModel.submittedDateFrom
      ? this.state.searchModel.submittedDateFrom.slice(0, 10)
      : "";
    var submittedDateTo = this.state.searchModel.submittedDateTo
      ? this.state.searchModel.submittedDateTo.slice(0, 10)
      : "";
    var entryDateFrom = this.state.searchModel.entryDateFrom
      ? this.state.searchModel.entryDateFrom.slice(0, 10)
      : "";
    var entryDateTo = this.state.searchModel.entryDateTo
      ? this.state.searchModel.entryDateTo.slice(0, 10)
      : "";
    var dateOfServiceFrom = this.state.searchModel.dateOfServiceFrom
      ? this.state.searchModel.dateOfServiceFrom.slice(0, 10)
      : "";
    var dateOfServiceTo = this.state.searchModel.dateOfServiceTo
      ? this.state.searchModel.dateOfServiceTo.slice(0, 10)
      : "";

    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "PAYER NAME",
          field: "payerName",
          sort: "asc",
          width: 150
        },
        {
          label: "VISIT NO",
          field: "visitNo",
          sort: "asc",
          width: 270
        },
        {
          label: "DOS",
          field: "dos",
          sort: "asc",
          width: 200
        },
        {
          label: "BILLED AMOUNT",
          field: "buildAmount",
          sort: "asc",
          width: 100
        },
        {
          label: "ALLOWED AMOUNT",
          field: "allowedAmount",
          sort: "asc",
          width: 150
        },
        {
          label: "ADJUSTMENT",
          field: "adjustment",
          sort: "asc",
          width: 100
        },
        {
          label: "BALANCE",
          field: "balance",
          sort: "asc",
          width: 100
        }
      ],
      rows: this.state.data
    };

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <GifLoader
          loading={true}
          imageSrc={Eclips}
          // imageStyle={imageStyle}
          overlayBackground="rgba(0,0,0,0.5)"
        />
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <div className="mainHeading row">
          <div className="col-md-8">
            <h1>AGING DETAIL REPORT</h1>
          </div>
          <div className="col-md-4 headingRight pt-3">
            <label>
              <font size="3" style={{ fontWeight: "bold" }}>
                Age Unit &nbsp;
              </font>
            </label>
            <select
              name="ageType"
              id="ageType"
              value={this.state.searchModel.ageType}
              onChange={this.handleChange}
              style={{ width: "52%" }}
            >
              {ageType.map(s => (
                <option key={s.value} value={s.value}>
                  {s.display}
                </option>
              ))}
            </select>
          </div>
          <div className="col-md-4 headingRight"></div>
        </div>

        <form onSubmit={event => this.searchAgingReports(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Patient Account #"></Label>
                <Input
                  type="text"
                  name="patientAccountNumber"
                  id="patientAccountNumber"
                  max="30"
                  onChange={() => this.handleChange}
                  value={this.state.searchModel.patientAccountNumber}
                />
              </div>
              <div className="mf-6">
                <Label name="Patient Name"></Label>
                <Input
                  type="text"
                  name="patientName"
                  id="patientName"
                  onChange={() => this.handleChange}
                  value={this.state.searchModel.patientName}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="DOS From"></Label>
                <div className="textBoxValidate">
                  <input
                    className="myInput"
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="dateOfServiceFrom"
                    id="dateOfServiceFrom"
                    onChange={this.handleChange}
                    value={dateOfServiceFrom}
                    min="1900-01-01"
                    max="9999-12-31"
                  />
                  {this.state.validationModel.dosFromValField}
                  {this.state.validationModel.selectDOSFromValField}
                </div>
              </div>
              <div className="mf-6">
                <Label name="DOS To"></Label>
                <div className="textBoxValidate">
                  <input
                    className="myInput"
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="dateOfServiceTo"
                    id="dateOfServiceTo"
                    onChange={this.handleChange}
                    value={dateOfServiceTo}
                    min="1900-01-01"
                    max="9999-12-31"
                  />
                  {this.state.validationModel.dosToFDValField}
                  {this.state.validationModel.dosToGreaterValField}
                </div>
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Entry Date From"></Label>
                <div className="textBoxValidate">
                  <input
                    className="myInput"
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="entryDateFrom"
                    id="entryDateFrom"
                    onChange={this.handleChange}
                    value={entryDateFrom}
                    min="1900-01-01"
                    max="9999-12-31"
                  />
                  {this.state.validationModel.entryDateFromValField}
                  {this.state.validationModel.selectEntryFromValField}
                </div>
              </div>
              <div className="mf-6">
                <Label name="Entry Date To"></Label>
                <div className="textBoxValidate">
                  <input
                    className="myInput"
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="entryDateTo"
                    id="entryDateTo"
                    onChange={this.handleChange}
                    value={entryDateTo}
                    min="1900-01-01"
                    max="9999-12-31"
                  />
                  {this.state.validationModel.entryDateToValField}
                  {this.state.validationModel.EntryDateToGreaterValField}
                </div>
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Submitted Date From"></Label>
                <div className="textBoxValidate">
                  <input
                    className="myInput"
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="submittedDateFrom"
                    id="submittedDateFrom"
                    onChange={this.handleChange}
                    value={submittedDateFrom}
                    min="1900-01-01"
                    max="9999-12-31"
                  />
                  {this.state.validationModel.submittedDateFromValField}
                  {this.state.validationModel.selectSubmitFromValField}
                </div>
              </div>
              <div className="mf-6">
                <Label name="Submitted Date To"></Label>
                <div className="textBoxValidate">
                  <input
                    className="myInput"
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="submittedDateTo"
                    id="submittedDateTo"
                    onChange={this.handleChange}
                    value={submittedDateTo}
                    min="1900-01-01"
                    max="9999-12-31"
                  />
                  {this.state.validationModel.submittedDateToValField}
                  {this.state.validationModel.SubmitDateToGreaterValField}
                </div>
              </div>
            </div>
            <div className="row-form">
              <div className="mf-6">
                <Label name="Plan"></Label>
                <Input
                  type="text"
                  name="Plan"
                  id="Plan"
                  onChange={() => this.handleChange}
                  value={this.state.searchModel.Plan}
                />
              </div>
              <div className="mf-3"></div>
              <div className="mf-3"></div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                />
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-grey"
                  value="Clear"
                  onClick={event => this.clearFields(event)}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="AGING DETAIL"
            dataObj={this.state.searchModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              striped
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
              responsive={true}
            />
          </div>
        </div>
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(AgingDetailReport);
