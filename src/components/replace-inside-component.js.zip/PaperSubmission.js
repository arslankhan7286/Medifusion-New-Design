import React, { Component } from "react";
import Label from "./Label";
import Input from "./Input";
import axios from "axios";
import { MDBDataTable, MDBInput, MDBBtn } from "mdbreact";
import GridHeading from "./GridHeading";
import PaperSubmissionModal from "./PaperSubmissionModal";
//import viewHCFAFile from './viewHCFAFile';
import GPopup from "./GPopup";
import { withRouter } from "react-router-dom";
import $ from "jquery";
import Swal from "sweetalert2";
import { isNullOrUndefined } from "util";
import moment from "moment";

import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import NewInsurancePlan from "./NewInsurancePlan";

export class PaperSubmission extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/PaperSubmission/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.paperModel = {
      formType: "",
      accountNum: "",
      visitID: null,
      practice: "",
      provider: "",
      planName: "",
      payerID: "",
      location: "",
      entryDateFrom: "",
      entryDateTo: ""
    };

    this.submitModel = {
      formType: "",
      clientID: 1,
      visits: [],
      processedClaims: null,
      isFileSubmitted: false,
      ErrorVisits: [],
      filePath: "",
      errorMessage: "",
      sessionId: "",
      submissionLogID: null
    };

    this.validationModel = {
      EntryDateToGreaterValField: null,
      selectEntryFromValField: null,
      entryDateFromValField: "",
      entryDateToValField: "",
      validation: false
    };

    this.state = {
      paperModel: this.paperModel,
      submitModel: this.submitModel,
      validationModel: this.validationModel,
      data: [],
      initialData: [],
      revData: [],
      selectedAll: false,
      checked: [],
      output: {},
      showPopup: false,
      id: 0,
      showPopup: false,
      showPracticePopup: false,
      showLocationPopup: false,
      showProviderPopup: false,
      showPatientPopup: false,
      showVisitPopup: false,
      loading: false,
      popupName: ""
    };

    this.selectedVisits = [];

    this.handleChange = this.handleChange.bind(this);
    this.clearFields = this.clearFields.bind(this);
    this.toggleCheck = this.toggleCheck.bind(this);
    this.isChecked = this.isChecked.bind(this);
    this.selectALL = this.selectALL.bind(this);
    this.submitCheckedVisits = this.submitCheckedVisits.bind(this);
    this.searchPaperSub = this.searchPaperSub.bind(this);
    this.closesubmitPlanPopup = this.closesubmitPlanPopup.bind(this);
    this.opensubmitPlanPopup = this.opensubmitPlanPopup.bind(this);
    this.openPatientPopup = this.openPatientPopup.bind(this);
    this.closePatientPopup = this.closePatientPopup.bind(this);
    this.openVisitPopUp = this.openVisitPopUp.bind(this);
    this.closeVisitPopup = this.closeVisitPopup.bind(this);
  }

  //Open Patient Popup
  openPatientPopup = id => {
    this.setState({ showPatientPopup: true, id: id });
  };

  //Close Patient Popup
  closePatientPopup = () => {
    $("#myModal").hide();
    this.setState({ showPatientPopup: false });
  };

  //Open Visit Popup
  openVisitPopUp = id => {
    this.setState({ showVisitPopup: true, id: id });
  };

  //Close Visit Popup
  closeVisitPopup = () => {
    $("#myModal").hide();
    this.setState({ showVisitPopup: false });
  };

  openPracticePopup = id => {
    this.setState({ showPracticePopup: true, id: id });
  };

  closePracticePopup = () => {
    $("#myModal").hide();
    this.setState({ showPracticePopup: false });
  };

  openLocationPopup = id => {
    this.setState({ showLocationPopup: true, id: id });
  };

  closeLocationPopup = () => {
    $("#myModal").hide();
    this.setState({ showLocationPopup: false });
  };

  openProviderPopup = id => {
    this.setState({ showProviderPopup: true, id: id });
  };

  closeProviderPopup = () => {
    $("#myModal").hide();
    this.setState({ showProviderPopup: false });
  };

  // Open Patient Plan By Subscriber ID Popup
  openPatientPlanPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  };
  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };
  openPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  };

  isChecked = id => {
    //return this.state.submitModel.visits.filter(name => name === id)[0] ? true : false
    return this.selectedVisits.filter(name => name === id)[0] ? true : false;
  };

  val(value) {
    if (isNullOrUndefined(value)) return " ";
    else return value;
  }

  searchPaperSubmission = () => {
    this.setState({ loading: true });


    var myVal = this.validationModel;
    myVal.validation = false;

    //Entry Date From Future Date Validation
    if (this.isNull(this.state.paperModel.entryDateFrom) == false) {
      if (
        new Date(
          moment(this.state.paperModel.entryDateFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.entryDateFromValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.entryDateFromValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.entryDateFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Entry Date To Future Date Validation
    if (this.isNull(this.state.paperModel.entryDateTo) == false) {
      if (
        new Date(
          moment(this.state.paperModel.entryDateTo)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment()
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.entryDateToValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.entryDateToValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.entryDateToValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Entry Date To must be greater than Entry Date From Validation
    if (
      this.isNull(this.state.paperModel.entryDateFrom) == false &&
      this.isNull(this.state.paperModel.entryDateTo) == false
    ) {
      if (
        new Date(
          moment(this.state.paperModel.entryDateFrom)
            .format()
            .slice(0, 10)
        ).getTime() >
        new Date(
          moment(this.state.paperModel.entryDateTo)
            .format()
            .slice(0, 10)
        ).getTime()
      ) {
        myVal.EntryDateToGreaterValField = (
          <span className="validationMsg">
            Entry Date To must be greater than Entry Date From
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.EntryDateToGreaterValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.EntryDateToGreaterValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }
    //if Entry Date To is selected Then Make sure than Entry date Form is also selected Validation
    if (
      this.isNull(this.state.paperModel.entryDateFrom) == true &&
      this.isNull(this.state.paperModel.entryDateTo) == false
    ) {
      console.log("Select DOS From");
      myVal.selectEntryFromValField = (
        <span className="validationMsg">Select Entry Date From</span>
      );
      myVal.validation = true;
      if (myVal.validation == false) myVal.validation = false;
    } else {
      myVal.selectEntryFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }


    if (myVal.validation == true) {
      this.setState({ validationModel: myVal, loading: false });
      Swal.fire(
        "Something Wrong",
        "Please Select All Fields Properly",
        "error"
      );
      return;
    }
    axios
      .post(this.url + "FindVisits", this.state.paperModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.visitID,
            ischeck: (
              <input
                style={{ width: "20px", height: "20px" }}
                type="checkbox"
                id={row.visitID}
                name={row.visitID}
                onChange={this.toggleCheck}
                checked={this.isChecked(row.visitID)}
              />
              // <div class="lblChkBox">
              //   <input
              //     type="checkbox"
              //     id={row.visitID}
              //     name={row.visitID}
              //     onChange={this.toggleCheck}
              //     checked={this.isChecked(row.visitID)}
              //   />
              //   <label for={row.visitID}>
              //     <span></span>
              //   </label>
              // </div>
            ),
            visitID: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openVisitPopUp(row.visitID)}
              >
                {" "}
                {this.val(row.visitID)}
              </MDBBtn>
            ),
            dos: this.val(row.dos),
            accountNum: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPatientPopup(row.patientID)}
              >
                {" "}
                {this.val(row.accountNum)}
              </MDBBtn>
            ),
            patient: this.val(row.patient),
            subscriberID: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.openPatientPlanPopup("patientplan", row.patientID)
                }
              >
                {" "}
                {this.val(row.subscriberID)}
              </MDBBtn>
            ),
            visitEntryDate: row.visitEntryDate,
            insurancePlanName: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.openPopup("insuranceplan", row.insurancePlanID)
                }
              >
                {" "}
                {this.val(row.planName)}
              </MDBBtn>
            ),
            practice: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openPracticePopup(row.practiceID)}
              >
                {" "}
                {this.val(row.practice)}
              </MDBBtn>
            ),
            location: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openLocationPopup(row.locationID)}
              >
                {" "}
                {this.val(row.location)}
              </MDBBtn>
            ),
            provider: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openProviderPopup(row.providerID)}
              >
                {" "}
                {this.val(row.provider)}
              </MDBBtn>
            ),
            // totalAmount: this.val(row.totalAmount),
            totalAmount: isNullOrUndefined(row.totalAmount)
              ? ""
              : "$" + row.totalAmount,
            validationMessage: row.validationMessage
          });
        });

        //setTimeout(function () {
        this.setState({
          data: newList,
          initialData: response.data,
          loading: false
        });
        //}.bind(this), 3000);

        // this.setState({
        //     data: newList,
        //     initialData: response.data,
        //     loading: false
        // });
      })
      .catch(error => {
        //setTimeout(function () {
        this.setState({ loading: false });
        //}.bind(this), 3000);
      });
  };
  // Search Paper Submission
  searchPaperSub = e => {
    e.preventDefault();

    if (
      this.state.paperModel.formType === "" ||
      this.state.paperModel.formType === null ||
      this.state.paperModel.formType === undefined
    ) {
      Swal.fire({
        type: "error",
        text: "Please Select the HCFA Template "
      });
      return;
    }

    this.searchPaperSubmission();
    e.preventDefault();
  };

  selectALL = e => {
    let newValue = !this.state.selectedAll;
    this.setState({ ...this.state, selectedAll: newValue });

    let newList = [];
    this.selectedVisits = [];
    this.state.initialData.map((row, i) => {
      if (newValue === true) this.selectedVisits.push(Number(row.visitID));

      newList.push({
        id: row.id,
        //ischeck: <MDBInput type="checkbox" id={row.visitID} onChange={this.toggleCheck} checked={this.isChecked(row.visitID)} />,
        ischeck: (
          <input
            style={{ width: "20px", height: "20px" }}
            type="checkbox"
            id={row.visitID}
            name={row.visitID}
            onChange={this.toggleCheck}
            checked={this.isChecked(row.visitID)}
          />
          // <div class="lblChkBox">
          //   <input
          //     type="checkbox"
          //     id={row.visitID}
          //     name={row.visitID}
          //     onChange={this.toggleCheck}
          //     checked={this.isChecked(row.visitID)}
          //   />
          //   <label for={row.visitID}>
          //     <span></span>
          //   </label>
          // </div>
        ),
        visitID: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openVisitPopUp(row.visitID)}
          >
            {" "}
            {this.val(row.visitID)}
          </MDBBtn>
        ),
        dos: this.val(row.dos),
        accountNum: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPatientPopup(row.patientID)}
          >
            {" "}
            {this.val(row.accountNum)}
          </MDBBtn>
        ),
        patient: this.val(row.patient),
        subscriberID: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() =>
              this.openPatientPlanPopup("patientplan", row.patientID)
            }
          >
            {" "}
            {this.val(row.subscriberID)}
          </MDBBtn>
        ),
        visitEntryDate: row.visitEntryDate,
        insurancePlanName: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPopup("insuranceplan", row.insurancePlanID)}
          >
            {" "}
            {this.val(row.planName)}
          </MDBBtn>
        ),
        practice: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPracticePopup(row.practiceID)}
          >
            {" "}
            {this.val(row.practice)}
          </MDBBtn>
        ),
        location: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openLocationPopup(row.locationID)}
          >
            {" "}
            {this.val(row.location)}
          </MDBBtn>
        ),
        provider: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openProviderPopup(row.providerID)}
          >
            {" "}
            {this.val(row.provider)}
          </MDBBtn>
        ),
        totalAmount: isNullOrUndefined(row.totalAmount)
          ? ""
          : "$" + row.totalAmount,
        validationMessage: row.validationMessage
      });
    });

    this.setState({
      data: newList,
      submitModel: { ...this.state.submitModel, visits: this.selectedVisits }
    });
  };

  toggleCheck = e => {
    let checkedArr = this.selectedVisits;
    let newList = [];

    checkedArr.filter(name => name === Number(e.target.id))[0]
      ? (checkedArr = checkedArr.filter(name => name !== Number(e.target.id)))
      : checkedArr.push(Number(e.target.id));

    this.selectedVisits = checkedArr;

    this.state.initialData.map((row, i) => {
      newList.push({
        id: row.id,
        //ischeck: <MDBInput type="checkbox" id={row.visitID} onChange={this.toggleCheck} checked={this.isChecked(row.visitID)} />,
        ischeck: (
          <input
            style={{ width: "20px", height: "20px" }}
            type="checkbox"
            id={row.visitID}
            name={row.visitID}
            onChange={this.toggleCheck}
            checked={this.isChecked(row.visitID)}
          />
          // <div class="lblChkBox">
          //   <input
          //     type="checkbox"
          //     id={row.visitID}
          //     name={row.visitID}
          //     onChange={this.toggleCheck}
          //     checked={this.isChecked(row.visitID)}
          //   />
          //   <label for={row.visitID}>
          //     <span></span>
          //   </label>
          // </div>
        ),
        visitID: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openVisitPopUp(row.visitID)}
          >
            {" "}
            {this.val(row.visitID)}
          </MDBBtn>
        ),
        dos: this.val(row.dos),
        accountNum: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPatientPopup(row.patientID)}
          >
            {" "}
            {this.val(row.accountNum)}
          </MDBBtn>
        ),
        patient: this.val(row.patient),
        subscriberID: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() =>
              this.openPatientPlanPopup("patientplan", row.patientID)
            }
          >
            {" "}
            {this.val(row.subscriberID)}
          </MDBBtn>
        ),
        visitEntryDate: row.visitEntryDate,
        insurancePlanName: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPopup("insuranceplan", row.insurancePlanID)}
          >
            {" "}
            {this.val(row.planName)}
          </MDBBtn>
        ),
        practice: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPracticePopup(row.practiceID)}
          >
            {" "}
            {this.val(row.practice)}
          </MDBBtn>
        ),
        location: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openLocationPopup(row.locationID)}
          >
            {" "}
            {this.val(row.location)}
          </MDBBtn>
        ),
        provider: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openProviderPopup(row.providerID)}
          >
            {" "}
            {this.val(row.provider)}
          </MDBBtn>
        ),
        // totalAmount: this.val(row.totalAmount),
        totalAmount: isNullOrUndefined(row.totalAmount)
          ? ""
          : "$" + row.totalAmount,
        validationMessage: row.validationMessage
      });
    });

    this.setState({
      data: newList,
      submitModel: { ...this.state.submitModel, visits: this.selectedVisits }
    });
  };

  opensubmitPlanPopup = id => {
    this.setState({ showPopup: true, id: id });
  };
  closesubmitPlanPopup = () => {
    $("#myModal").hide();
    this.setState({ showPopup: false });
    $("#searchID").click();
    this.searchPaperSubmission();
  };

  submitCheckedVisits = e => {
    if (
      this.state.submitModel.visits === null ||
      this.state.submitModel.visits.length === 0
    ) {
      Swal.fire({
        type: "info",
        text: "Please Select the Visit(s)"
      });
      return;
    } else {
      this.setState({ ...this.state, loading: true });

      axios
        .post(this.url + "SubmitVisits", this.state.submitModel, this.config)
        .then(response => {
          this.setState({ loading: false });
          if (
            isNullOrUndefined(response.data.errorMessage) === false &&
            response.data.errorMessage.length > 0
          ) {
            Swal.fire({
              type: "error",
              text: response.data.errorMessage
            });
          } else if (response.data.isisFileSubmitted === true) {
            Swal.fire({
              type: "success",
              text: "File Submitted Successfully"
            }).then(sres => {
              this.searchPaperSubmission();
            });
          } else {
            this.selectedVisits = [];
            this.setState({
              output: response.data,
              showPopup: true,
              loading: false
            });
          }
        })
        .catch(error => {
          this.setState({ loading: false });
          let errorList = [];
        });
    }
  };

  async componentWillMount() {
    try {
      if (this.props.location.query.formType == "HCFA 1500") {
        await this.setState({
          paperModel: {
            ...this.state.paperModel,
            formType: this.props.location.query.formType
            // accountNUm:this.props.match.params.id ?this.props.match.params.id:null
          }
        });

        this.searchPaperSubmission();
      }
    } catch {}
    axios
      .get(this.url + "GetProfiles", this.config)
      .then(response => {
        this.setState({
          revData: response.data.receivers
        });
      })
      .catch(error => {
      });
  }

  handleChange = event => {

    var myName = event.target.name ? event.target.name : "";
    if (myName == "entryDateTo" || myName == "entryDateFrom") {
    } else {

      //Carret Position
      const caret = event.target.selectionStart
      const element = event.target
      window.requestAnimationFrame(() => {
        element.selectionStart = caret
        element.selectionEnd = caret
      })

}
      this.setState({
        paperModel: {
          ...this.state.paperModel,
          [event.target.name]: event.target.value.toUpperCase()
        },
        submitModel: {
          ...this.state.submitModel,
          [event.target.name]: event.target.value.toUpperCase()
        }
      });
    


    event.preventDefault();
  };

  clearFields = event => {
    this.selectedVisits = [];
    this.setState({
      paperModel: this.paperModel,
      selectedAll: false
    });

    this.searchPaperSubmission();
  };
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 0
        },
        {
          //label: <MDBInput type="checkbox" onChange={this.selectALL} />,
          label: (
            <input
              style={{ width: "20px", height: "20px" }}
              type="checkbox"
              id="selectAll"
              name="selectAll"
              checked={this.state.selectedAll}
              onChange={this.selectALL}
            />
            // <div class="lblChkBox">
            //   <input
            //     type="checkbox"
            //     id="selectAll"
            //     name="selectAll"
            //     onChange={this.selectALL}
            //   />
            //   <label for="selectAll">
            //     <span></span>
            //   </label>
            // </div>
          ),
          field: "ischeck",
          sort: "",
          width: 50
        },
        {
          label: "VISIT #",
          field: "visitID",
          sort: "asc",
          width: 150
        },
        {
          label: "DOS",
          field: "dos",
          sort: "asc",
          width: 150
        },
        {
          label: "ACCOUNT #",
          field: "accountNum",
          sort: "asc",
          width: 150
        },
        {
          label: "PATIENT",
          field: "patient",
          sort: "asc",
          width: 150
        },
        {
          label: "SUBSCRIBER ID",
          field: "subscriberID",
          sort: "asc",
          width: 150
        },
        {
          label: "ENTRY DATE",
          field: "visitEntryDate",
          sort: "asc",
          width: 150
        },
        {
          label: "PLAN",
          field: "insurancePlanName",
          sort: "asc",
          width: 150
        },
        {
          label: "PRACTICE",
          field: "practice",
          sort: "asc",
          width: 150
        },
        {
          label: "LOCATION",
          field: "location",
          sort: "asc",
          width: 150
        },
        {
          label: "PROVIDER",
          field: "provider",
          sort: "asc",
          width: 150
        },
        {
          label: "AMOUNT",
          field: "totalAmount",
          sort: "asc",
          width: 150
        },
        {
          label: "VALIDATION MSG",
          field: "validationMessage",
          sort: "asc",
          width: 250
        }
      ],
      rows: this.state.data
    };
    const formType = [
      { value: "", display: "Select Title" },
      { value: "HCFA 1500", display: "HCFA 1500" },
      { value: "PLAIN 1500", display: "Plain 1500" }
    ];


    var entryDateFrom = this.state.paperModel.entryDateFrom
      ? this.state.paperModel.entryDateFrom.slice(0, 10)
      : "";
    var entryDateTo = this.state.paperModel.entryDateTo
      ? this.state.paperModel.entryDateTo.slice(0, 10)
      : "";

    let popup = "";

    if (this.state.showPopup) {
      popup = (
        <PaperSubmissionModal
          onClose={() => this.closesubmitPlanPopup}
          id={this.state.id}
          data={this.state.output}
        ></PaperSubmissionModal>
      );
    } else if (this.state.showPracticePopup) {
      popup = (
        <NewPractice
          onClose={() => this.closePracticePopup}
          practiceID={this.state.id}
        ></NewPractice>
      );
    } else if (this.state.showLocationPopup) {
      popup = (
        <NewLocation
          onClose={() => this.closeLocationPopup}
          id={this.state.id}
        ></NewLocation>
      );
    } else if (this.state.showProviderPopup) {
      popup = (
        <NewProvider
          onClose={() => this.closeProviderPopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (this.state.showPatientPopup) {
      popup = (
        <GPopup
          onClose={() => this.closePatientPopup}
          popupName="patient"
          id={this.state.id}
        ></GPopup>
      );
    } else if (this.state.showVisitPopup) {
      popup = (
        <GPopup
          onClose={() => this.closeVisitPopup}
          popupName="visit"
          id={this.state.id}
        ></GPopup>
      );
    } else if (this.state.popupName === "insuranceplan") {
      popup = (
        <NewInsurancePlan
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewInsurancePlan>
      );
    } else if (this.state.popupName === "patientplan") {
      popup = (
        <GPopup
          onClose={() => this.closePopup}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <div className="mainHeading row">
          <div className="col-md-6">
            <h1>PAPER SUBMISSION SEARCH</h1>
          </div>
        </div>

        <form onSubmit={event => this.searchPaperSub(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <label>HCFA Template</label>
                <select
                  name="formType"
                  id="formType"
                  value={this.state.paperModel.formType}
                  onChange={this.handleChange}
                >
                  {formType.map(s => (
                    <option key={s.value} value={s.value}>
                      {s.display}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mf-6">&nbsp;</div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Account #"></Label>
                <Input
                  type="text"
                  name="accountNum"
                  id="accountNum"
                  value={this.state.paperModel.accountNum}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Visit #"></Label>
                <Input
                  type="text"
                  name="visitID"
                  id="visitID"
                  value={
                    this.state.paperModel.visitID == null
                      ? ""
                      : this.state.paperModel.visitID
                  }
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Entry Date From"></Label>
                <div className="textBoxValidate">
                  <input
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="entryDateFrom"
                    id="entryDateFrom"
                    value={entryDateFrom}
                    onChange={this.handleChange}
                  />
                  {this.state.validationModel.entryDateFromValField}
                  {this.state.validationModel.selectEntryFromValField}
                </div>
              </div>
              <div className="mf-6">
                <Label name="Entry Date To"></Label>
                <div className="textBoxValidate">
                  <input
                    type="date"
                    min="1900-01-01"
                    max="9999-12-31"
                    name="entryDateTo"
                    id="entryDateTo"
                    value={entryDateTo}
                    onChange={this.handleChange}
                  />
                  {this.state.validationModel.entryDateToValField}
                  {this.state.validationModel.EntryDateToGreaterValField}
                </div>
              </div>

            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Location"></Label>
                <Input
                  type="text"
                  name="location"
                  id="location"
                  value={this.state.paperModel.location}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Provider"></Label>
                <Input
                  type="text"
                  name="provider"
                  id="provider"
                  value={this.state.paperModel.provider}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <Label name="Plan Name"></Label>
                <Input
                  type="text"
                  name="planName"
                  id="planName"
                  value={this.state.paperModel.planName}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                {/* <Label name='Payer ID'></Label>
                                <Input type='text' name='payerID' id='payerID' max='9'
                                    value={this.state.paperModel.payerID} onChange={() => this.handleChange} /> */}
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Submit"
                  disabled={this.isDisabled(this.props.rights.add)}
                  onClick={() => this.submitCheckedVisits()}
                />
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-grey"
                  value="Clear"
                  onClick={() => this.clearFields()}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="PAPER SUBMISSION SEARCH RESULT"
            dataObj={this.state.paperModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>

        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.paperSubmissionSearch,
          add: state.loginInfo.rights.paperSubmissionSubmit
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default withRouter(
  connect(mapStateToProps, matchDispatchToProps)(PaperSubmission)
);
