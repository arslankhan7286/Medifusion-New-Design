import React, { Component } from "react";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

import Label from "./Label";
import Button from "./Input";
import Input from "./Input";
import SearchInput2 from "./SearchInput2";
import Swal from "sweetalert2";
import axios from "axios";

import $ from "jquery";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import plusSrc from "../images/plus-icon.png";

class NewChargesSheet extends Component {
  constructor(props) {
    super(props);

    this.AddChargesSheet = process.env.REACT_APP_URL + "/DataMigration/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*",
       
      },
      // timeout:600000
    };

    this.uploadModel = {
      content: "",
      name: "",
      size: "",
      type: ""
    };

    this.loadChargesCount = 0;

    this.errorField = "errorField";

    this.validationModel = {
      fileUploadVal: "",
      typeVal: "",
      providerVal: "",
      locationVal: "",
      validation: false
    };

    //--------Model to be sent
    this.ChargesSheetModel = {
      type: null,
      uploadModel: this.uploadModel,
      providerID: null,
      practiceID: 14,
      locationID: null
    };

    this.state = {
      validationModel: this.validationModel,
      ChargesSheetModel: this.ChargesSheetModel,
      showPopup: false,
      loading: false,
      maxHeight: "361",
      filePath: "",
      location: [],
      provider: []
    };

    this.handleChange = this.handleChange.bind(this);
    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.LoadClientSheetData = this.LoadClientSheetData.bind(this);
    this.isNull = this.isNull.bind(this);
  }

  async componentDidMount() {
    this.setModalMaxHeight($(".modal"));
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  isNull = value => {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  };

  handleChange = event => {
    event.preventDefault();
    this.setState({
      ChargesSheetModel: {
        ...this.state.ChargesSheetModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase()
      }
    });
  };

  ProcessFileLoad(e) {
    e.preventDefault();

    try {
      let reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      let file = e.target.files[0];

      console.log("File : ", file);

      reader.onloadend = e => {
        try {
          this.uploadModel.content = reader.result;
          this.uploadModel.name = file.name;
          this.uploadModel.size = file.size;
          this.uploadModel.type = file.type;
        } catch {}

        console.log("Content", this.uploadModel.content);

        var Filetype = this.uploadModel.name.substr(
          this.uploadModel.name.indexOf(".")
        );
        console.log("file type", Filetype);
        if (Filetype == ".xlsx") {
          this.setState({
            filePath: file.name
          });
        } else {
          Swal.fire("Error", "Invalid File", "error");
        }
      };
    } catch {}
  }

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  LoadClientSheetData() {
    //---------------------------- VALIDATIONS

    if (this.loadChargesCount == 1) {
      return;
    }
    this.loadChargesCount = 1;

    this.setState({ loading: true });
    console.log("ChargesSheetModel", this.state.ChargesSheetModel);

    var myVal = this.validationModel;
    myVal.validation = false;

    //---------------------------- TYPE VALIDATION

    if (this.isNull(this.state.ChargesSheetModel.type)) {
      myVal.typeVal = <span className="validationMsg">Select Type</span>;
      myVal.validation = true;
    } else {
      myVal.typeVal = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //---------------------------- PROVIDER ID VALIDATION

    if (this.isNull(this.state.ChargesSheetModel.providerID)) {
      myVal.providerVal = (
        <span className="validationMsg">Select Provider</span>
      );
      myVal.validation = true;
    } else {
      myVal.providerVal = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //---------------------------- LOCATION ID VALIDATION

    if (this.isNull(this.state.ChargesSheetModel.locationID)) {
      myVal.locationVal = (
        <span className="validationMsg">Select Location</span>
      );
      myVal.validation = true;
    } else {
      myVal.locationVal = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    //---------------------------- FILE UPLOAD VALIDATION

    if (this.isNull(this.state.ChargesSheetModel.uploadModel.content)) {
      myVal.fileUploadVal = <span className="validationMsg">Select File</span>;
      myVal.validation = true;
    } else {
      myVal.fileUploadVal = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (myVal.validation === true) {
      this.setState({ loading: false });
      Swal.fire("Please Select All Fields Properly", "", "error");
      this.loadChargesCount = 0;
      return;
    }

    axios
      .post(
        this.AddChargesSheet + "AddChargeData",
        this.state.ChargesSheetModel,
        this.config
      )
      .then(response => {
        this.loadChargesCount = 0;
        console.log("Response", response);
        this.setState({ loading: false });
        Swal.fire("File Loaded Successfully", "", "success");
      })
      .catch(error => {
        this.loadChargesCount = 0;
        console.log("respone error", error.response);
        console.log("respone error message", error.message);
        console.log("error", error);
        if (error.response) {
          if (error.response.status) {
            if (error.response.status == 400) {
              this.setState({ loading: false });
              Swal.fire(error.response.data, error.message, "error");
              return;
            } else {
              this.setState({ loading: false });
              Swal.fire("File Not Loaded!", "", "error");
              return;
            }
          }
        } else {
          this.setState({ loading: false });
          Swal.fire("File Not Loaded!", "", "error");
          return;
        }
      });

    this.setState({
      validationModel: myVal
    });
  }

  render() {
    try {
      if (this.props.userInfo1.userPractices.length > 0) {
        // if (this.state.practice.length == 0) {
        //   if (this.state.editId == 0) {
        let locID =
          this.props.userInfo1.userLocations.length > 1
            ? this.props.userInfo1.userLocations[1].id
            : null;
        let provID =
          this.props.userInfo1.userProviders.length > 1
            ? this.props.userInfo1.userProviders[1].id
            : null;

        this.setState({
          ChargesSheetModel: {
            ...this.state.ChargesSheetModel,
            practiceID: this.props.userInfo1.practiceID
            // locationID: locID,
            // providerID: provID
          }
          // location: this.props.userInfo1.userLocations,
          // provider: this.props.userInfo1.userProviders
        });
      }
      // else {
      //   this.setState({
      //     ChargesSheetModel: {
      //       ...this.state.ChargesSheetModel,
      //       practiceID: this.props.userInfo1.practiceID
      //     },
      //     location: this.props.userInfo1.userLocations,
      //     provider: this.props.userInfo1.userProviders
      //   });
      // }
      //   }
      // }
    } catch {}

    const TypeOptions = [
      { value: null, display: "Please Select" },
      { value: "OFFICEALLY", display: "OFFICEALLY" }
    ];

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        <div
          id="myModal"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {/* <button onClick={this.props.onClose()} className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button> */}
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={this.props.onClose()}
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.clientModel.name +
                            " - " +
                            this.state.clientModel.organizationName +
                            " "
                          : "NEW CHARGES SHEET"}
                      </h1>
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <form>
                  <div className="mainTable">
                    <div className="row-form">
                      <div className="mf-6">
                        <label>
                          Type
                          <span className="redlbl"> *</span>
                        </label>

                        <div className="textBoxValidate">
                          <select
                            className={
                              this.state.validationModel.typeVal
                                ? this.errorField
                                : ""
                            }
                            name="type"
                            id="type"
                            value={this.state.ChargesSheetModel.type}
                            onChange={this.handleChange}
                            style={{"width":"100%"}}
                          >
                            {TypeOptions.map(s => (
                              <option key={s.value} value={s.value}>
                                {s.display}
                              </option>
                            ))}
                          </select>
                          {this.state.validationModel.typeVal}
                        </div>
                      </div>

                      <div className="mf-6">
                        <label>
                          Upload File
                          <span className="redlbl"> *</span>
                        </label>
                        <div className="textBoxValidate">
                          <label
                            for="file-upload"
                            id="file-upload-style"
                            className={
                              this.state.validationModel.fileUploadVal
                                ? this.errorField
                                : ""
                            }
                            // class="custom-file-upload btn-blue"
                          >
                            Browse
                            <input
                              id="file-upload"
                              type="file"
                              onChange={e => this.ProcessFileLoad(e)}
                            />
                          </label>
                          <label id="validPath">{this.state.filePath}</label>
                          {this.state.validationModel.fileUploadVal}
                        </div>
                      </div>
                    </div>
                    <div className="row-form">
                      <div className="mf-6">
                        <label>
                          Default Provider
                          <span className="redlbl"> *</span>
                        </label>
                        <div className="textBoxValidate">
                          <select
                            className={
                              this.state.validationModel.providerVal
                                ? this.errorField
                                : ""
                            }
                            name="providerID"
                            id="providerID"
                            value={this.state.ChargesSheetModel.providerID}
                            onChange={this.handleChange}
                            style={{"width":"100%"}}
                          >
                            {this.props.userInfo1.userProviders.map(s => (
                              <option key={s.id} value={s.id}>
                                {s.description}
                              </option>
                            ))}
                          </select>
                          {this.state.validationModel.providerVal}
                        </div>
                      </div>

                      <div className="mf-6">
                        <label>
                          Default Location
                          <span className="redlbl"> *</span>
                        </label>

                        <div className="textBoxValidate">
                          <select
                            className={
                              this.state.validationModel.locationVal
                                ? this.errorField
                                : ""
                            }
                            name="locationID"
                            id="locationID"
                            value={this.state.ChargesSheetModel.locationID}
                            onChange={this.handleChange}
                            style={{"width":"100%"}}
                          >
                            {this.props.userInfo1.userLocations.map(s => (
                              <option key={s.id} value={s.id}>
                                {s.description}
                              </option>
                            ))}
                          </select>
                          {this.state.validationModel.locationVal}
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <div className="mainTable">
                  <div className="row-form row-btn">
                    <div className="mf-12">
                      <Input
                        type="button"
                        value="Load File"
                        className="btn-blue"
                        onClick={this.LoadClientSheetData}
                        disabled={this.isDisabled(
                          this.state.editId > 0
                            ? this.props.rights.update
                            : this.props.rights.add
                        )}
                      />
                      <Input
                        type="button"
                        value="Cancel"
                        id="btnCancel"
                        className="btn-grey"
                        data-dismiss="modal"
                        onClick={
                          this.props.onClose
                            ? this.props.onClose()
                            : () => this.props.onClose()
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    userProviders: state.loginInfo
      ? state.loginInfo.userProviders
        ? state.loginInfo.userProviders
        : []
      : [],
    userRefProviders: state.loginInfo
      ? state.loginInfo.userRefProviders
        ? state.loginInfo.userRefProviders
        : []
      : [],
    userLocations: state.loginInfo
      ? state.loginInfo.userLocations
        ? state.loginInfo.userLocations
        : []
      : [],
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.patientSearch,
          add: state.loginInfo.rights.patientCreate,
          update: state.loginInfo.rights.patientEdit,
          delete: state.loginInfo.rights.patientDelete,
          export: state.loginInfo.rights.patientExport,
          import: state.loginInfo.rights.patientImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewChargesSheet);
