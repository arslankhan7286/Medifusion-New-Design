import React, { Component } from "react";
import $ from "jquery";
import axios from "axios";
import Input from "./Input";
import Swal from "sweetalert2";
import Select from "react-select";
import { Tabs, Tab } from "react-tab-view";
import { MDBDataTable } from "mdbreact";
import { MDBBtn } from "mdbreact";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class EditCharge extends Component {
  constructor(props) {
    super(props);

    this.submissionHistoryUrl =
      process.env.REACT_APP_URL + "/ChargeSubmissionHistory/";
    this.resubmissionHistoryUrl =
      process.env.REACT_APP_URL + "/ResubmitHistory/";
    this.chargeUrl = process.env.REACT_APP_URL + "/Charge/";
    this.visitUrl = process.env.REACT_APP_URL + "/visit/";
    this.patientPlanUrl = process.env.REACT_APP_URL + "/patientPlan/";
    this.paymentLedgerUrl = process.env.REACT_APP_URL + "/PaymentLedger/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.currentIndex = 0;
    this.submitSearchModel = {
      addedDate: "",
      submitType: "",
      receiver: "",
      formType: "",
      plan: "",
      coverage: "",
      addedBy: ""
    };

    this.resubmitModel = {
      addedDate: "",
      addedBy: ""
    };

    this.auditModel = {
      addedDate: "",
      field: "",
      previousValue: "",
      newValue: "",
      addedBy: ""
    };

    this.paymentLedgerModel = {
      id: "",
      chargeID: "",
      visitID: "",
      patientPlanID: "",
      patientPaymentChargeID: "",
      paymentChargeID: "",
      adjustmentCodeID: "",
      adjustmentCode: "",
      ledgerBy: "",
      ledgerType: "",
      ledgerDescription: "",
      ledgerDate: "",
      amount: "",
      covrage: "",
      addedBy: ""
    };

    this.chargeValidationModel = {
      dosToValField: "",
      validation: false
    };

    this.chargeModel = {
     
      id: null,
      cptid: null,
      cptObj: {},
      dateOfServiceFrom: "",
      dateOfServiceTo: "",
      modifier1ID: null,
      units: "",
      isSubmitted: false,
      submittetdDate: "",
      submissionLogID: null,
      isDontPrint: false,
      patientID: null,

      ndcUnits: "",
      ndcNumber: "",
      ndcMeasurementUnit: "",
      primaryPatientPlanID: null,
      secondaryPatientPlanID: null,
      tertiaryPatientPlanID: null,

      primaryBilledAmount: "",
      primaryPlanAmount: "",
      primaryPlanAllowed: "",
      primaryPlanPaid: "",
      primaryWriteOff: "",

      //Secondary Plan Fields
      secondaryBilledAmount: "",
      secondaryAllowed: "",
      secondaryWriteOff: "",
      secondaryPaid: "",
      secondaryPatResp: "",
      secondaryBal: "",
      secondaryTransferred: "",
      secondaryStatus: ""
    };

    this.state = {
      submitSearchModel: this.submitSearchModel,
      editId : this.props.chargeId ? this.props.chargeId : 0,
      submitdata: [],
      id: 0,
      resubmitModel: this.resubmitModel,
      resubmitdata: [],

      auditModel: this.auditModel,
      auditdata: [],

      paymentLedgerModel: this.paymentLedgerModel,
      paymentLedgerdata: [],

      chargeModel: this.chargeModel,
      chargeValidationModel: this.chargeValidationModel,
      practice: [],
      location: [],
      provider: [],
      refProvider: [],
      supProvider: [],
      pos: [],

      patientPlanDropdown: [],
      primaryPlanName: "",
      secondaryPlanName: "",
      cptOptions: [],
      options: [],
      modifierOptions: [],
      chargesList:this.props.chargesList ? this.props.chargesList:[],
      cptLabel: "",
      icd1Label: "",
      icd2Label: "",
      icd3Label: "",
      icd4Label: "",
      modifierLabel: "",
      maxHeight: "361",
      loading: false
    };
    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.saveCharge = this.saveCharge.bind(this);
    this.handleNDCUnitsChange = this.handleNDCUnitsChange.bind(this);
    this.reSubmitCharge = this.reSubmitCharge.bind(this);
    this.isNull = this.isNull.bind(this);
    this.nextVisit = this.nextVisit.bind(this);
    this.previousVisit = this.previousVisit.bind(this);
    //  this.searchSubmit= this.searchSubmit.bind(this);
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  async componentDidMount() {
    this.setModalMaxHeight($(".modal"));
    // if ($('.modal.in').length != 0) {
    //     this.setModalMaxHeight($('.modal.in'));
    // }

    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function() {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);


    this.setState({ loading: true });

    await axios
      .get(this.chargeUrl + "FindCharge/" + this.state.editId, this.config)
      .then(response => {
        this.setState({
          chargeModel: response.data
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });

    await axios
      .get(this.visitUrl + "GetProfiles", this.config)
      .then(response => {
        this.setState({
          visitModel: {
            ...this.state.chargeModel
          },
          // practice: response.data.practice,
          // location: response.data.location,
          // provider: response.data.provider,
          // refProvider: response.data.refProvider,
          // supProvider: response.data.refProvider,
          // pos: response.data.pos,
          patientDropDown: response.data.patientInfo,
          // options: response.data.icd,
          // modifierOptions: response.data.modifier,
          // cptOptions: response.data.cpt
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });

    await axios
      .get(
        this.patientPlanUrl +
          "GetpatientPlansByPatientID/" +
          this.state.chargeModel.patientID,
        this.config
      )
      .then(res => {
        let primaryPatientPlan = res.data.filter(
          patientPlan => patientPlan.description == "P"
        );
        this.setState({
          primaryPlanName:
            primaryPatientPlan.length > 0
              ? "Primary - " + primaryPatientPlan[0].description2
              : ""
        });
        let secondaryPatientPlan = res.data.filter(
          patientPlan => patientPlan.description == "S"
        );
        this.setState({
          secondaryPlanName:
            secondaryPatientPlan.length > 0
              ? "Secondary - " + secondaryPatientPlan[0].description2
              : ""
        });
        // this.setState({
        //   primaryPlanName: "Primary - " + res.data.coverage

        // })
      });

    var cpt = {};
    cpt = await this.props.cptCodes.filter(
      option => option.id == this.state.chargeModel.cptid
    );

    const icd1 = await this.props.icdCodes.filter(
      option => option.id == this.props.icd1Id
    );
    const icd2 = await this.props.icdCodes.filter(
      option => option.id == this.props.icd2Id
    );
    const icd3 = await this.props.icdCodes.filter(
      option => option.id == this.props.icd3Id
    );
    const icd4 = await this.props.icdCodes.filter(
      option => option.id == this.props.icd4Id
    );

    var modifier1 = await this.props.modifiers.filter(
      option => option.id == this.state.chargeModel.modifier1ID
    );
    var modifier2 = await this.props.modifiers.filter(
      option => option.id == this.state.chargeModel.modifier2ID
    );
    var modifier3 = await this.props.modifiers.filter(
      option => option.id == this.state.chargeModel.modifier3ID
    );
    var modifier4 = await this.props.modifiers.filter(
      option => option.id == this.state.chargeModel.modifier4ID
    );

   
    // + " , " +  modifier2.length>0 ? modifier2[0].label : "" + " , " + modifier3.length>0 ? modifier3[0].label : "" + " , " +  modifier4.length>0 ? modifier4[0].label : "" ;

    // let modifiers = modifier1.length > 0 ? modifier1[0].label : "";
    //     modifiers = modifiers + modifier2.length>0 ? modifier2[0].label : "";
    //     modifiers = modifiers +  modifier3.length>0 ? modifier3[0].label : "";
    //     modifiers = modifiers + modifier4.length>0 ? modifier4[0].label : "";
    // console.log("Modifiers : " , modifiers)
    // this.setState({
    //   loading: false,
    //   modifierLabel: "modifiers"
    // });

    await this.setState({
      cptLabel: cpt[0].label,
      icd1Label: icd1.length > 0 ? icd1[0].label : "",
      icd2Label: icd2.length > 0 ? icd2[0].label : "",
      icd3Label: icd3.length > 0 ? icd3[0].label : "",
      icd4Label: icd4.length > 0 ? icd4[0].label : "",
      modifierLabel:
        (modifier1.length > 0 ? modifier1[0].label : "") +
        (modifier2.length > 0 ? modifier2[0].label + " , " : "") +
        (modifier3.length > 0 ? modifier3[0].label + " , " : "") +
        (modifier4.length > 0 ? modifier4[0].label + " , " : "")
    });

    //submit grid
    await axios
      .get(
        this.submissionHistoryUrl +
          "FindChargeSubmission/" +
          this.state.editId,
        this.config
      )
      .then(response => {
        let newList = [];

        response.data.map((row, i) => {
          // var formType = row.formType == null ? "  " : row.formType; // handle null condition
          var submitType = row.submitType == null ? "  " : row.submitType;
          // var date = row.addedDate.slice(0, 10);

          newList.push({
            id: row.id,
            date: row.addedDate.slice(0, 10),
            submitType: submitType,
            receiver: row.receiver,
            formType: row.formType,
            Plan: row.plan,
            coverage: row.coverage,
            user: row.user
          });
          this.setState({ submitdata: newList });
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });

    //re-submit grid
    await axios
      .get(
        this.resubmissionHistoryUrl +
          "GetResubmitChargeHistory/" +
          this.state.editId,
        this.config
      )
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          var date = row.addedDate.slice(0, 10);
          newList.push({
            id: row.id,
            date: date,
            user: row.addedBy
          });
          this.setState({ resubmitdata: newList });
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });

    //audit grid
    await axios
      .get(
        this.chargeUrl + "GetChargeAudit/" + this.state.editId,
        this.config
      )
      .then(response => {
        let newList = [];

        response.data.map((row, i) => {
          var date = row.addedDate ? row.addedDate.slice(0, 10) : "";
          date = row.addedDate
            ? row.addedDate.slice(5, 7) +
              "/" +
              row.addedDate.slice(8, 10) +
              "/" +
              row.addedDate.slice(0, 4)
            : "";

          newList.push({
            id: row.id,
            date: date,
            field: row.columnName,
            //previousValue: row.currentValue.replace(/-/g, "/"),
            previousValue: this.handleDate(row.columnName, row.currentValue),
            //newValue: row.newValue.replace(/-/g, "/"),
            newValue: this.handleDate(row.columnName, row.newValue),
            user: row.addedBy
          });
          this.setState({ auditdata: newList });
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });

    //payment ledger grid
    await axios
      .get(
        this.paymentLedgerUrl + "GetPaymentLedger/" + this.state.editId,
        this.config
      )
      .then(response => {
        let newList = [];

        response.data.map((row, i) => {
          var ledgerDate = row.ledgerDate.slice(0, 10);
          newList.push({
            id: row.id,
            ledgerDate: row.ledgerDate,
            ledgerBy: row.ledgerBy,
            ledgerType: row.ledgerType,
            ledgerDescription:
              this.isNull(row.ledgerDescription) == true
                ? " "
                : row.ledgerDescription,
            checkNumber: row.checkNumber,
            amount: row.amount > 0 ? "$" + row.amount : "",
            covrage: this.isNull(row.covrage) == true ? " " : row.covrage,
            addedBy: this.isNull(row.addedBy) == true ? " " : row.addedBy
          });
          this.setState({ paymentLedgerdata: newList });
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });

    this.setState({ loading: false });
  }

  handleDate = (field, data) => {
    if (field === "SubmittetdDate") {
      var d = data ? data.slice(0, 10) : "";
      d = d
        ? data.slice(5, 7) + "/" + data.slice(8, 10) + "/" + data.slice(0, 4)
        : "";
      console.log(d);
      return d;
    } else return data;
  };

  handleChange(event) {
    if (event.target.name == "isDontPrint") {
      this.setState({
        chargeModel: {
          ...this.state.chargeModel,
          isDontPrint: !this.state.chargeModel.isDontPrint
        }
      });
    } else {
      this.setState({
        chargeModel: {
          ...this.state.chargeModel,
          [event.target.name]:
            event.target.value == "Please Select"
              ? null
              : event.target.value.toUpperCase()
        }
      });
    }
  }

  handleNDCUnitsChange = event => {
    const amount = event.target.value;
    var name = event.target.name;
    var regexp = /^\d+(\.(\d{1,2})?)?$/;

    if (regexp.test(amount)) {
      this.setState({
        chargeModel: {
          ...this.state.chargeModel,
          [name]: Number(amount)
        }
      });
    } else if (amount == "") {
      this.setState({
        chargeModel: {
          ...this.state.chargeModel,
          [name]: ""
        }
      });
    }
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  saveCharge() {
    // var chargeVal;
    // chargeVal = { ...this.chargeValidationModel };
    // chargeVal.validation = false;
    // //DOS To greater than check
    // if (
    //   !this.isNull(this.state.chargeModel.dateOfServiceFrom) &&
    //   !this.isNull(this.state.chargeModel.dateOfServiceTo)
    // ) {
    //   var dosFrom = new Date(this.state.chargeModel.dateOfServiceFrom);
    //   var dosTo = new Date(this.state.chargeModel.dateOfServiceTo);
    //   if (dosTo < dosFrom) {
    //     chargeVal.dosToValField = (
    //       <span className="validationMsg">
    //         DOS To must be greater than DOS From
    //       </span>
    //     );
    //     chargeVal.validation = true;
    //   }
    // } else {
    //   chargeVal.dosToValField = "";
    //   if (chargeVal.validation === false) chargeVal.validation = false;
    // }

    // this.setState({
    //   chargeValidationModel: chargeVal
    // });

    // if (chargeVal.validation === true) {
    //   Swal.fire(
    //     "SOMETHING WRONG",
    //     "Please Select All Fields Properly",
    //     "error"
    //   );
    //   return;
    // }

    axios
      .post(this.chargeUrl + "savecharge", this.state.chargeModel, this.config)
      .then(response => {
        this.setState({
          chargeModel: response.data
        });
        Swal.fire("Record Saved Successfully", "", "success");
      })
      .catch(error => {
        Swal.fire("Please Select All Fields Properly", "", "error");
      });
  }

  //Save NDC
  saveNDC = () => {
    // this.setState({
    //   chargeModel:{
    //     ...this.state.chargeModel,
    //     ndcNumbe
    //   }
    // })
  };
  //resubmit Charge
  reSubmitCharge() {
    if (this.state.chargeModel.isSubmitted === true) {
      axios
        .get(this.visitUrl + "ResubmitCharge/" + this.state.chargeModel.id)
        .then(response => {
          this.setState({ chargeModel: response.data });

          this.componentDidMount();

          Swal.fire("SUCCESS", "Charge Re-Submited Successfully", "success");
        });
    } else {
      Swal.fire(
        "SOMETHING WRONG",
        "Charge can not be Re-Submitted,First Submit the Charge",
        "error"
      );
    }
  }

   //Previous Visit
   async previousVisit(){
   
    if((this.currentIndex-1) < 0 ){
      Swal.fire("No More Charges","","warning");
      return
    }
    this.currentIndex = this.currentIndex-1;
    var charge = this.state.chargesList[this.currentIndex];
    await this.setState({
      editId:charge.id , 
    chargeModel:{
      ...this.state.chargeModel,
      id:0
    }});
    this.componentDidMount();
  }


  //NextVisit
  async nextVisit (){
   
    if((this.currentIndex+1) >= this.state.chargesList.length){
      Swal.fire("No More Charges","","warning");
      return
    }
    this.currentIndex = this.currentIndex+1;
    var charge = this.state.chargesList[this.currentIndex];
    await this.setState({editId:charge.id , 
    chargeModel:{
      ...this.state.chargeModel,
      id:0
    }});
    this.componentDidMount();
  }



  render() {
    try{ this.state.chargesList.filter((charge , index) => {if(charge.id == this.state.editId){this.currentIndex = index}});}catch{}



    if (this.props.userInfo.userPractices.length > 0) {
      if (this.state.practice.length == 0) {
        this.setState({
          visitModel: {
            ...this.state.visitModel,
            practiceID: this.props.userInfo.practiceID
          },
          practice: this.props.userInfo.userPractices,
          location: this.props.userInfo.userLocations,
          provider: this.props.userInfo.userProviders,
          refProvider: this.props.userInfo.userRefProviders
        });
      }
    }

    var dosFrom = this.state.chargeModel.dateOfServiceFrom
      ? this.state.chargeModel.dateOfServiceFrom.slice(0, 10)
      : "";
    var dosTo = this.state.chargeModel.dateOfServiceTo
      ? this.state.chargeModel.dateOfServiceTo.slice(0, 10)
      : "";
    var submittedDate = this.state.chargeModel.submittetdDate
      ? this.state.chargeModel.submittetdDate.slice(0, 10)
      : "";
    submittedDate = submittedDate
      ? submittedDate.slice(5, 7) +
        "/" +
        submittedDate.slice(8, 10) +
        "/" +
        submittedDate.slice(0, 4)
      : "";

      const status =   [
        { value: "N", display: "New Charge" },
        { value: "S", display: "Submitted" },
        { value: "K", display: "999 Accepted" },
        { value: "D", display: "999 Denied" },
        { value: "E", display: "999 has Errors" },
        { value: "P", display: "Paid" },
        { value: "DN", display: "Denied" },
        { value: "PT_P", display: "Patient Paid" },
        { value: "PPTS", display: "Paid-Transfered To Sec" },
        { value: "PPTT", display: "Paid-Transfered To Ter" },
        { value: "PPTP", display: "Paid-Transfered To Patient" },
        { value: "SPTP", display: "Paid-Transfered To Patient" },
        { value: "SPTT", display: "Paid-Transfered To Ter" },
        { value: "PR_TP", display: "Pat. Resp. Transferred to Pat" },
        { value: "PPTM", display: "Paid - Medigaped" },
        { value: "M", display: "Medigaped " },
        { value: "R", display: "Rejected" },
        { value: "A1AY", display: "Received By Clearing House" },
        { value: "A0PR", display: "Farwarded to Payer" },
        { value: "A1PR", display: "Received By Payer" },
        { value: "A2PR", display: "Accepted By Payer" },		
        { value: "TS", display: "Transferred to Secendary" },
        { value: "TT", display: "Accepted By Tertiary" },
        { value: "PTPT", display: "Plan to Patient Transfer" }	
        
      ];

    const headers = ["Payment Ledger", "Submit", "Re-Submit", "Audit"];

    const insuranceInfoHeaders = ["Primary Plan", "Secondary Plan"];

    const submitdata = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "DATE",
          field: "date",
          sort: "asc",
          width: 150
        },
        {
          label: "SUBMIT TYPE",
          field: "submitType",
          sort: "asc",
          width: 150
        },
        {
          label: "RECEIVER ",
          field: "receiver",
          sort: "asc",
          width: 150
        },
        {
          label: "FORM TYPE",
          field: "formType",
          sort: "asc",
          width: 150
        },
        {
          label: "PLAN",
          field: "Plan",
          sort: "asc",
          width: 150
        },
        {
          label: "COVERAGE",
          field: "coverage",
          sort: "asc",
          width: 150
        },
        {
          label: "USER",
          field: "user",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.submitdata
    };

    const resubmitdata = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "DATE",
          field: "date",
          sort: "asc",
          width: 150
        },
        {
          label: "USER",
          field: "user",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.resubmitdata
    };

    const auditdata = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "DATE",
          field: "date",
          sort: "asc",
          width: 150
        },
        {
          label: "FIELD",
          field: "field",
          sort: "asc",
          width: 150
        },
        {
          label: "PREVIOUS VALUE",
          field: "previousValue",
          sort: "asc",
          width: 150
        },
        {
          label: "NEW VALUE",
          field: "newValue",
          sort: "asc",
          width: 150
        },
        {
          label: "USER",
          field: "user",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.auditdata
    };

    const paymentLedgerdata = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "LEDGER DATE",
          field: "ledgerDate",
          sort: "asc",
          width: 150
        },
        {
          label: "LEDGER BY",
          field: "ledgerBy",
          sort: "asc",
          width: 150
        },
        {
          label: "LEDGER TYPE",
          field: "ledgerType",
          sort: "asc",
          width: 150
        },
        {
          label: "LEDGER DESCRIPTION",
          field: "ledgerDescription",
          sort: "asc",
          width: 150
        },
        {
          label: "CHECK NUM",
          field: "checkNumber",
          sort: "asc",
          width: 150
        },

        {
          label: "AMOUNT",
          field: "amount",
          sort: "asc",
          width: 150
        },
        {
          label: "COVERAGE",
          field: "covrage",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDED BY",
          field: "addedBy",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.paymentLedgerdata
    };

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    const ndcUnitOfMeasurement = [
      { value: "", display: "Select State" },
      { value: "F2", display: "International Unit " },
      { value: "GR", display: "Gram" },
      { value: "ML", display: "Milliliter" },
      { value: "UN", display: "Unit" }
    ];
    return (
      <div
        id="editChargeModal"
        className="modal fade bs-example-modal-new show"
        tabindex="-1"
        role="dialog"
        aria-labelledby="myLargeModalLabel"
        aria-hidden="true"
        style={{ display: "block", paddingRight: "17px" }}
      >
        <div className="modal-dialog modal-lg">
          {/* <button
            type="button"
            className="close"
            data-dismiss="modal"
            aria-label="Close"
            onClick={this.props.onClose()}
          >
            <span aria-hidden="true"></span>
          </button> */}

          <div className="modal-content" style={{ overflow: "hidden" }}>
            <button
              type="button"
              className="close"
              data-dismiss="modal"
              aria-label="Close"
              onClick={this.props.onClose()}
            >
              <span aria-hidden="true"></span>
            </button>
            {spiner}

            <div className="modal-body">
              <div className="mainTable wSpace">
                <div className="mf-12 headingtwo">
                  <div className="row-form">
                    <div className="mf-4 mt-25">
                      <p>CHARGE # {this.state.chargeModel.id}</p>
                    </div>
                    <div className="mf-4">
                    <Input
                        type="button"
                        value="<="
                        className="btn-blue"
                        onClick={this.previousVisit}
                        style={{ marginLeft: "20px" }}
                      ></Input>
                      <Input
                        type="button"
                        value="=>"
                        className="btn-blue"
                        onClick={this.nextVisit}
                        style={{ marginLeft: "20px" }}
                      ></Input>
                    </div>
                    <div className="col-md-4 headingRight">
                      <button
                        className="btn-blue"
                        onClick={this.reSubmitCharge}
                      >
                        Re-Submit
                      </button>
                    </div>
                  </div>
                </div>
                <div className="mainTable fullWidthTable mt-25">
                  <div className="row-form" style={{ height: "43px" }}>
                    {/* <div className="mf-4">
                      <label>Charge ID</label>
                      <input
                        disabled
                        type="text"
                        value={this.state.chargeModel.id}
                        name="id"
                        id=""
                      ></input>
                    </div> */}
                    <div className="mf-4">
                      <label>CPT </label>
                      <input
                        disabled
                        type="text"
                        value={this.state.cptLabel}
                        name="cptid"
                        id=""
                      ></input>
                    </div>
                    <div className="mf-8  field_full-8">
                      <label> Service Desc</label>
                      <input
                        type="text"
                        value={this.state.chargeModel.description}
                        onChange={this.handleChange}
                        max="30"
                        name="description"
                        id="description"
                      ></input>
                    </div>
                    <div className="mf-4">&nbsp;</div>
                  </div>
                  <div className="row-form">
                    <div className="mf-4">
                      <label>DOS From</label>
                      <div class="textBoxValidate">
                        <input
                          disabled
                          style={{
                            width: "215px",
                            marginLeft: "0px"
                          }}
                          className="myInput"
                          type="date"
                          name="dateOfServiceFrom"
                          id="dateOfServiceFrom"
                          value={dosFrom}
                          onChange={this.handleChange}
                        ></input>
                      </div>
                    </div>
                    <div className="mf-4">
                      <label>DOS To </label>
                      <div class="textBoxValidate">
                        <input
                          disabled
                          style={{
                            width: "215px",
                            marginLeft: "0px"
                          }}
                          className="myInput"
                          type="date"
                          name="dateOfServiceTo"
                          id="dateOfServiceTo"
                          value={dosTo}
                          onChange={this.handleChange}
                        ></input>
                        {this.state.chargeValidationModel.dosToValField}
                      </div>
                    </div>
                    <div className="mf-4">
                      <label>Units </label>
                      <input
                        disabled
                        type="text"
                        value={this.state.chargeModel.units}
                        name="units"
                        id=""
                        onChange={this.handleChange}
                      ></input>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-4">
                      <label>ICD1</label>
                      <input
                        disabled
                        type="text"
                        value={this.state.icd1Label}
                        name="icd1Id"
                        id=""
                      ></input>
                    </div>
                    <div className="mf-4">
                      <label>ICD2 </label>
                      <input
                        disabled
                        type="text"
                        value={this.state.icd2Label}
                        name="icd1Id"
                        id=""
                      ></input>
                    </div>
                    <div className="mf-4">
                      <label>Modifiers</label>
                      <input
                        disabled
                        type="text"
                        value={this.state.modifierLabel}
                        name="modifier1ID"
                        id=""
                      ></input>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-4">
                      <label>ICD3</label>
                      <input
                        disabled
                        type="text"
                        value={this.state.icd3Label}
                        name="icd1Id"
                        id=""
                      ></input>
                    </div>
                    <div className="mf-4">
                      <label>ICD4 </label>
                      <input
                        disabled
                        type="text"
                        value={this.state.icd4Label}
                        name="icd1Id"
                        id=""
                      ></input>
                    </div>
                    <div className="mf-4">
                      <div
                        className="lblChkBox"
                        style={{ marginLeft: "106px", marginTop: "15px" }}
                      >
                        <input
                          type="checkbox"
                          id="isDontPrintCB"
                          name="isDontPrint"
                          checked={this.state.chargeModel.isDontPrint}
                          onClick={this.handleChange}
                        />
                        <label
                          htmlFor="isDontPrintCB"
                          style={{ width: "auto" }}
                        >
                          Don't Print
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mf-12 headingtwo mt-25">
                  <p>NDC Info</p>
                </div>
                <div className="mainTable fullWidthTable">
                  <div className="row-form">
                    <div className="mf-4">
                      <label>NDC #</label>
                      <input
                        max="10"
                        type="text"
                        value={this.state.chargeModel.ndcNumber}
                        onChange={this.handleChange}
                        name="ndcNumber"
                        id=""
                      ></input>
                    </div>

                    <div className="mf-4">
                      <label>NDC Units</label>
                      <input
                        max="10"
                        type="text"
                        value={this.state.chargeModel.ndcUnits}
                        onChange={this.handleNDCUnitsChange}
                        name="ndcUnits"
                        id=""
                      ></input>
                    </div>

                    <div className="mf-4">
                      <label>NDC UOM</label>
                      <select
                        name="ndcMeasurementUnit"
                        id="ndcMeasurementUnit"
                        value={this.state.chargeModel.ndcMeasurementUnit}
                        onChange={this.handleChange}
                      >
                        {ndcUnitOfMeasurement.map(s => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* <div className="row-form">
                     <button className="btn-blue" onClick={this.saveNDC}>Save NDC</button>
                  </div> */}
                </div>

                <div className="mf-12 headingtwo mt-25">
                  <p>Submission Info</p>
                </div>
                <div className="mainTable fullWidthTable">
                  <div className="row-form">
                    <div className="mf-4">
                      <label>Submitted</label>
                      <div className="lblChkBox ml-25 mt-2">
                        <input
                          type="checkbox"
                          checked={this.state.chargeModel.isSubmitted}
                          id="markInactive0"
                          name=""
                        />
                        <label for="markInactive0">
                          <span></span>
                        </label>
                      </div>
                    </div>
                    <div className="mf-4">
                      <label>Submitted Date </label>
                      <input
                        disabled
                        type="text"
                        value={this.state.chargeModel.isSubmitted ? submittedDate : ""}
                        name="submittetdDate"
                        id=""
                      ></input>
                    </div>
                    <div className="mf-4">
                      <label>Submission Batch</label>
                      <input
                        disabled
                        type="text"
                        value={this.state.chargeModel.submissionLogID}
                        name="submissionLogID"
                        id=""
                      ></input>
                    </div>
                  </div>
                  <div className="row-form">
                  <div className="mf-12 field_full-12">
                    <label>Rejection Reason</label>
                    <textarea
                        readOnly
                        value={this.state.chargeModel.rejectionReason}
                        // name="description"
                        // id="description"
                        cols="30"
                        rows="10"
                        // onChange={this.handleChange}
                      ></textarea>
                    {/* <input
                      disabled
                      type="text"
                      value={this.state.visitModel.rejectionReason}
                      name=""
                      id=""
                    ></input> */}
                  </div>
                </div>
                </div>

                <div className="mf-12 headingtwo mt-25">
                  <p>Insurance Info</p>
                </div>

                <div class="mainTable fullWidthTable">
                  <div class="row-form">
                    <div class="mf-12">
                      <Tabs
                        headers={insuranceInfoHeaders}
                        style={{ cursor: "default" }}
                      >
                        <Tab>
                          <div>
                            <div class="row-form">
                              <div class="mf-4">
                                <label
                                // className={
                                //   this.state.chargeModel.primaryPatientPlanID
                                //     ? "txtUnderline"
                                //     : ""
                                // }
                                // onClick={
                                //   this.state.chargeModel.primaryPatientPlanID
                                //     ? () =>
                                //         this.openPopup(
                                //           "insuranceplan",
                                //           this.state.chargeModel
                                //             .primaryPatientPlanID
                                //         )
                                //     : undefined
                                // }
                                >
                                  Plan
                                </label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.primaryPlanName}
                                  name="primaryPlanName"
                                  id="primaryPlanName"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Billed</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={
                                    this.state.chargeModel.primaryBilledAmount
                                  }
                                  name="primaryBilledAmount"
                                  id="primaryBilledAmount"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Allowed</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.chargeModel.primaryAllowed}
                                  name="primaryAllowed"
                                  id="primaryAllowed"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                            </div>

                            <div class="row-form">
                              <div class="mf-4">
                                <label>WriteOff</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.chargeModel.primaryWriteOff}
                                  name="primaryWriteOff"
                                  id="primaryWriteOff"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Paid</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.chargeModel.primaryPaid}
                                  name="primaryPaid"
                                  id="primaryPaid"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Plan Bal</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.chargeModel.primaryBal}
                                  name="primaryBal"
                                  id="primaryBal"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                            </div>

                            <div className="row-form">
                              <div class="mf-4">
                                <label>Patient Bal</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={
                                    this.state.chargeModel.primaryPatientBal
                                  }
                                  name="primaryPatientBal"
                                  id="primaryPatientBal"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Patient Paid</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.chargeModel.patientPaid}
                                  name="patientPaid"
                                  id="patientPaid"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Transferred</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={
                                    this.state.chargeModel.primaryTransferred
                                  }
                                  name="primaryTransferred"
                                  id="primaryTransferred"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                            </div>

                            <div className="row-form">
                              <div class="mf-4">
                                <label>Status</label>

                                <select
                                  disabled
                                  name="primaryStatus"
                                  id="primaryStatus"
                                  value={this.state.chargeModel.primaryStatus}
                                  onChange={this.handleChange}
                                >
                                  {status.map(s => (
                                    <option key={s.value} value={s.value}>
                                      {" "}
                                      {s.display}{" "}
                                    </option>
                                  ))}{" "}
                                </select>
                              </div>
                              <div class="mf-4"></div>
                              <div class="mf-4"></div>
                            </div>
                          </div>
                        </Tab>
                        <Tab>
                          <div>
                            <div class="row-form">
                              <div class="mf-4">
                                <label
                                // className={
                                //   this.state.chargeModel.secondaryPatientPlanID
                                //     ? "txtUnderline"
                                //     : ""
                                // }
                                // onClick={
                                //   this.state.chargeModel.secondaryPatientPlanID
                                //     ? () =>
                                //         this.openPopup(
                                //           "insuranceplan",
                                //           this.state.chargeModel
                                //             .secondaryPatientPlanID
                                //         )
                                //     : undefined
                                // }
                                >
                                  Plan
                                </label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.secondaryPlanName}
                                  name="secondaryPlanName"
                                  id="secondaryPlanName"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Billed</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={
                                    this.state.chargeModel.secondaryBilledAmount
                                  }
                                  name="secondaryBilledAmount"
                                  id="secondaryBilledAmount"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Allowed</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={
                                    this.state.chargeModel.secondaryAllowed
                                  }
                                  name="secondaryAllowed"
                                  id="secondaryAllowed"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                            </div>

                            <div class="row-form">
                              <div class="mf-4">
                                <label>WriteOff</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={
                                    this.state.chargeModel.secondaryWriteOff
                                  }
                                  name="secondaryWriteOff"
                                  id="secondaryWriteOff"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Paid</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.chargeModel.secondaryPaid}
                                  name="secondaryPaid"
                                  id="secondaryPaid"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Plan Bal</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.chargeModel.secondaryBal}
                                  name="secondaryBal"
                                  id="secondaryBal"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                            </div>

                            <div className="row-form">
                              <div class="mf-4">
                                <label>Patient Bal</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={
                                    this.state.chargeModel.secondaryPatResp
                                  }
                                  name="secondaryPatResp"
                                  id="secondaryPatResp"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Patient Paid</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={this.state.chargeModel.patientPaid}
                                  name="patientPaid"
                                  id="patientPaid"
                                  onChange={this.handleChange}
                                ></input>
                              </div>
                              <div class="mf-4">
                                <label>Transferred</label>
                                <input
                                  type="text"
                                  disabled="disabled"
                                  value={
                                    this.state.chargeModel.secondaryTransferred
                                  }
                                  name="secondaryTransferred"
                                  id="secondaryTransferred"
                                  //onChange={this.handleChange}
                                ></input>
                              </div>
                            </div>

                            <div className="row-form">
                              <div class="mf-4">
                                <label>Status</label>

                                <select
                                  disabled
                                  name="secondaryStatus"
                                  id="secondaryStatus"
                                  value={this.state.chargeModel.secondaryStatus}
                                  onChange={this.handleChange}
                                >
                                  {status.map(s => (
                                    <option key={s.value} value={s.value}>
                                      {" "}
                                      {s.display}{" "}
                                    </option>
                                  ))}{" "}
                                </select>
                              </div>

                              <div class="mf-4"></div>
                              <div class="mf-4"></div>
                            </div>
                          </div>
                        </Tab>
                      </Tabs>
                    </div>
                  </div>
                </div>

                {/* <div className="mainTable fullWidthTable">
                  <div className="row-form">
                    <div className="mf-12">

                      <fieldset>


                        <div className="row-form">
                          <div className="mf-4">
                            <label>Plan Name</label>
                            <input type="text" disabled="disabled" value={this.state.primaryPlanName} name="primaryPlanName" id=""></input>
                          </div>
                          <div className="mf-4">
                            <label>Billed</label>
                            <input type="text" disabled="disabled" value={this.state.chargeModel.primaryBilledAmount} name="primaryBilledAmount" id=""></input>
                          </div>
                          <div className="mf-4">
                            <label>Paid</label>
                            <input type="text" disabled="disabled" value={this.state.chargeModel.primaryPlanPaid} name="primaryPlanPaid" id=""></input>
                          </div>
                        </div>

                        <div className="row-form">
                          <div className="mf-4">
                            <label>Status</label>
                            < select
                              disabled
                              name="status"
                              id="status"
                              value={
                                this.state.chargeModel.status
                              }
                            >
                              {
                                status.map(s => (
                                  <option key={
                                    s.value
                                  }
                                    value={
                                      s.value
                                    } > {
                                      s.display
                                    } </option>
                                ))
                              } </select>
                          </div>
                          <div className="mf-4">
                            <label>Allowed</label>
                            <input type="text" disabled="disabled" value={this.state.chargeModel.primaryPlanAllowed} name="primaryPlanAllowed" id=""></input>
                          </div>
                          <div className="mf-4">
                            <label>Patient Amount</label>
                            <input type="text" disabled="disabled" value={this.state.chargeModel.primaryWriteOff} name="primaryWriteOff" id=""></input>
                          </div>
                        </div>
                      </fieldset>

                    </div>
                    <div className="mf-4">
                      <label>&nbsp;</label>
                    </div>
                    <div className="mf-4">
                      <label>&nbsp;</label>
                    </div>
                  </div>
                </div> */}

                <div className="mf-12 headingtwo mt-25">
                  <p>Legal Entities</p>
                </div>
                <div className="mainTable fullWidthTable wSpace">
                  <div className="row-form">
                    <div className="mf-4">
                      <label>Practice</label>
                      <select
                        disabled
                        name="practiceID"
                        id="practiceID"
                        value={this.state.chargeModel.practiceID}
                        onChange={this.handleChange}
                      >
                        {this.state.practice.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                    </div>
                    <div className="mf-4">
                      <label>Location</label>
                      <select
                        disabled
                        name="locationID"
                        id="locationID"
                        value={this.state.chargeModel.locationID}
                        onChange={this.handleChange}
                      >
                        {this.state.location.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                    </div>
                    <div className="mf-4">
                      <label>POS</label>
                      <select
                        disabled
                        name="posid"
                        id="posid"
                        value={this.state.chargeModel.posid}
                        onChange={this.handleChange}
                      >
                        {this.props.posCodes.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-4">
                      <label>Provider</label>
                      <select
                        disabled
                        name="providerID"
                        id="providerID"
                        value={this.state.chargeModel.providerID}
                        onChange={this.handleChange}
                      >
                        {this.state.provider.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                    </div>
                    <div className="mf-4">
                      <label>Ref. Provider</label>
                      <select
                        disabled
                        name="refProviderID"
                        id="refProviderID"
                        value={this.state.chargeModel.refProviderID}
                        onChange={this.handleChange}
                      >
                        {this.state.refProvider.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                    </div>
                    <div className="mf-4">
                      <label>Supervising Provider</label>
                      <select
                        disabled
                        name="supervisingProvID"
                        id="supervisingProvID"
                        value={this.state.chargeModel.supervisingProvID}
                        onChange={this.handleChange}
                      >
                        {this.state.provider.map(s => (
                          <option key={s.id} value={s.id}>
                            {" "}
                            {s.description}{" "}
                          </option>
                        ))}{" "}
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* tabs fileds             */}
              <div className="mainTable fullWidthTable">
                <div className="row-form">
                  <div className="mf-12">
                    <Tabs headers={headers} style={{ cursor: "default" }}>
                      <Tab>
                        <div style={{ marginTop: "20px" }}>
                          <div
                            className="mainTable fullWidthTable wSpace"
                            style={{ maxWidth: "100%" }}
                          >
                            <div className="row-form">
                              <div className="mf-12">
                                <div className="tableGridContainer">
                                  <div className="tableGridContainer">
                                    <MDBDataTable
                                      responsive={true}
                                      striped
                                      bordered
                                      searching={false}
                                      data={paymentLedgerdata}
                                      displayEntries={false}
                                      sortable={true}
                                      scrollX={false}
                                      scrollY={false}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Tab>
                      <Tab>
                        <div style={{ marginTop: "20px" }}>
                          <div
                            className="mainTable fullWidthTable wSpace"
                            style={{ maxWidth: "100%" }}
                          >
                            <div className="row-form">
                              <div className="mf-12">
                                <div className="tableGridContainer">
                                  <div className="tableGridContainer">
                                    <MDBDataTable
                                      responsive={true}
                                      striped
                                      bordered
                                      searching={false}
                                      data={submitdata}
                                      displayEntries={false}
                                      sortable={true}
                                      scrollX={false}
                                      scrollY={false}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Tab>
                      <Tab>
                        <div style={{ marginTop: "20px" }}>
                          <div
                            className="mainTable fullWidthTable wSpace"
                            style={{ maxWidth: "100%" }}
                          >
                            <div className="row-form">
                              <div className="mf-12">
                                <div className="tableGridContainer">
                                  <div className="tableGridContainer">
                                    <MDBDataTable
                                      responsive={true}
                                      striped
                                      bordered
                                      searching={false}
                                      data={resubmitdata}
                                      displayEntries={false}
                                      sortable={true}
                                      scrollX={false}
                                      scrollY={false}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Tab>
                      <Tab>
                        <div style={{ marginTop: "20px" }}>
                          <div
                            className="mainTable fullWidthTable wSpace"
                            style={{ maxWidth: "100%" }}
                          >
                            <div className="row-form">
                              <div className="mf-12">
                                <div className="tableGridContainer">
                                  <div className="tableGridContainer">
                                    <MDBDataTable
                                      responsive={true}
                                      striped
                                      bordered
                                      searching={false}
                                      data={auditdata}
                                      displayEntries={false}
                                      sortable={true}
                                      scrollX={false}
                                      scrollY={false}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Tab>
                    </Tabs>
                  </div>
                </div>
              </div>

              <div className="modal-footer">
                <div className="mainTable">
                  <div className="row-form row-btn">
                    <div className="mf-12">
                      <button className="btn-blue" onClick={this.saveCharge}>
                        Save{" "}
                      </button>
                      <button
                        className="btn-grey"
                        data-dismiss="modal"
                        onClick={this.props.onClose()}
                      >
                        Cancel{" "}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    cptCodes: state.loginInfo
      ? state.loginInfo.cpt
        ? state.loginInfo.cpt
        : []
      : [],
    icdCodes: state.loginInfo
      ? state.loginInfo.icd
        ? state.loginInfo.icd
        : []
      : [],
    posCodes: state.loginInfo
      ? state.loginInfo.pos
        ? state.loginInfo.pos
        : []
      : [],
    modifiers: state.loginInfo
      ? state.loginInfo.modifier
        ? state.loginInfo.modifier
        : []
      : [],
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(EditCharge);
