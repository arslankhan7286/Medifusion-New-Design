import React from "react";

import settingIcon from "../images/setting-icon.png";
import Input from "./Input";
import Swal from "sweetalert2";
import axios from "axios";
import { saveAs } from "file-saver";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";


import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

 class GridHeading extends React.Component {
  constructor(props){
    super(props);

    this.state={
      loading:false

    }
  }

   exportPdf = ()=> {
     this.setState({loading:true})
     var fileName = this.props.Heading;
     fileName = fileName.replace("SEARCH RESULT","");
  if (this.props.length > 0) {
    console.log("Hello")
    axios
      .post(this.props.url + this.props.methodNamePdf , this.props.dataObj, {
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer  " + this.props.loginObject.token,
          Accept: "*/*"
        },
        responseType: "blob"
      })
      .then(function(res) {
        var blob = new Blob([res.data], {
          type: "application/pdf"
        });

        saveAs(blob, fileName+".pdf");     
           this.setState({loading:false})
      }).catch(error =>{
        this.setState({loading:false})
      });
  } else {
    this.setState({loading:false})
    Swal.fire("Perform The Search First", "", "error");
  }
}

exportExcel = ()=> {
  this.setState({loading:true});
  var fileName = this.props.Heading;
     fileName = fileName.replace("SEARCH RESULT","");
  if (this.props.length > 0) {
    axios
      .post(this.props.url + this.props.methodName, this.props.dataObj, {
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer  " + this.props.loginObject.token,
          Accept: "*/*"
        },
        responseType: "blob"
      })
      .then(function(res) {
        var blob = new Blob([res.data], {
          type:
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        });

        saveAs(blob, fileName+".xlsx");
        this.setState({loading:false})
      }).catch(error =>{
        this.setState({loading:false})
      });
  } else {
    this.setState({loading:false})
    Swal.fire("Perform The Search First", "", "error");
  }
}

 render(){

   //Spinner
   let spiner = "";
   if (this.state.loading == true) {
     spiner = (
       <GifLoader
         loading={true}
         imageSrc={Eclips}
         // imageStyle={imageStyle}
         overlayBackground="rgba(0,0,0,0.5)"
       />
     );
   }



  return (
    <div className="row headingTable">
      {spiner}
      <div className="mf-6">
        <h1>{this.props.Heading}</h1>
      </div>
      <div className="mf-6 headingRightTable">
        <React.Fragment>
          <Input
            type="buttonExcel"
            name="name"
            id="name"
            value="Export Excel"
            disabled={this.props.disabled}
            dataObj={this.props.dataObj}
            url={this.props.url}
            length={this.props.length}
            onClick={() => this.exportExcel}
          />

          <Input
            type="buttonPdf"
            name="name"
            id="name"
            value="Export PDF"
            disabled={this.props.disabled}
            dataObj={this.props.dataObj}
            url={this.props.url}
            length={this.props.length}
            onClick={()=>this.exportPdf}
          />
        </React.Fragment>
      </div>
    </div>
  );
 }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.electronicsSubmissionSearch,
          add: state.loginInfo.rights.electronicsSubmissionSubmit
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(GridHeading);