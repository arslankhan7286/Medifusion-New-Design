import React, { Component } from "react";
import LeftMenuItem from "./LeftMenuItem";
import facilityIcon from "../images/facility-icon.png";
import facilityHIcon from "../images/facility-icon-hover.png";
import locationIcon from "../images/location-icon.png";
import locationHIcon from "../images/location-icon-hover.png";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction"

export class NewBatchDocLeftMenu extends Component {
  constructor(props) {
    super(props);
  }


  render() {
    let NewBatchDocLeftMenu = {
      Category: "",
      Icon: "",
      hIcon: "",
      expanded: true,
      SubCategories: [
        {
          SubCategory: "Batch  Document",
          Icon: facilityIcon,
          hIcon: facilityHIcon,
          to:"/BatchDocument",
          handler: () => this.props.selectTabPageAction("BATCHDOCUMENT"),
            selected: this.props.selectedTabPage == "BATCHDOCUMENT" ? true : false
        },
        {
          SubCategory: "Document Type",
          Icon: facilityIcon,
          hIcon: facilityHIcon,
          to:"/DocumentType",
          handler: () => this.props.selectTabPageAction("DOCUMENTTYPE"),
            selected: this.props.selectedTabPage == "DOCUMENTTYPE" ? true : false
        }
      ]
    };
    let leftMenuElements = (
      <LeftMenuItem data={NewBatchDocLeftMenu}></LeftMenuItem>
    );

    return leftMenuElements;
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(NewBatchDocLeftMenu);
