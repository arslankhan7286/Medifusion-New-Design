import React, { Component } from "react";
import $ from "jquery";
import axios from "axios";
import Input from "./Input";
import Swal from "sweetalert2";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { ICDAction } from "../actions/ICDAction";

import Hotkeys from "react-hot-keys";

class NewICD extends Component {
  constructor(props) {
    super(props);

    this.errorField = "errorField";
    this.url = process.env.REACT_APP_URL + "/icd/";
    this.commonUrl = process.env.REACT_APP_URL + "/Common/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.saveICDCount = 0;

    this.validationModel = {
      icdCodeValField: "",
      descriptionValField: ""
    };
    this.icdModel = {
      icdCode: "",
      description: "",
      isValid: true
    };

    this.state = {
      icdModel: this.icdModel,
      validationModel: this.validationModel,
      editId: this.props.id,
      maxHeight: "361",
      loading: false
    };
  }

  onKeyDown(keyName, e, handle) {
    console.log("test:onKeyDown", keyName, e, handle);

    if (keyName == "alt+s") {
      // alert("save key")
      this.saveICD();
      console.log(e.which);
    }

    this.setState({
      output: `onKeyDown ${keyName}`
    });
  }

  onKeyUp(keyName, e, handle) {
    console.log("test:onKeyUp", e, handle);
    if (e) {
      console.log("event has been called", e);
    }
    this.setState({
      output: `onKeyUp ${keyName}`
    });
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  async componentDidMount() {
    this.setState({ loading: true });

    await this.setModalMaxHeight($(".modal"));
    var zIndex = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-Index", zIndex);
    setTimeout(function () {
      $(".modal-backdrop")
        .not(".modal-stack")
        .css("z-Index", zIndex - 1)
        .addClass("modal-stack");
    }, 0);

    if (this.state.editId > 0) {
      await axios
        .get(this.url + "findicd/" + this.state.editId, this.config)
        .then(response => {
          console.log("Response : ", response.data);
          this.setState({ icdModel: response.data });
        })
        .catch(error => {
          try {
            let errorsList = [];
            if (error.response !== null && error.response.data !== null) {
              errorsList = error.response.data;
              console.log(errorsList);
            }
          } catch {
            this.setState({ loading: false });
            console.log(error);
          }
        });
    }
    this.setState({ loading: false });
  }

  handleChange = event => {
    event.preventDefault();
    this.setState({
      icdModel: {
        ...this.state.icdModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select"
    )
      return true;
    else return false;
  }

  handleCheck = () => {
    this.setState({
      icdModel: {
        ...this.state.icdModel,
        isActive: !this.state.icdModel.isActive
      }
    });
  };

  handleIsValid = () => {
    this.setState({
      icdModel: {
        ...this.state.icdModel,
        isValid: !this.state.icdModel.isValid
      }
    });
  };

  saveICD = e => {
    console.log("Before Update", this.saveICDCount);
    if (this.saveICDCount == 1) {
      return;
    }
    this.saveICDCount = 1;
    console.log(this.state.icdModel);
    e.preventDefault();
    this.setState({ loading: true });

    var myVal = this.validationModel;
    myVal.validation = false;
    var dotfind = this.state.icdModel.icdCode.indexOf(".");

    if (this.isNull(this.state.icdModel.icdCode)) {
      myVal.icdCodeValField = <span className="validationMsg">Enter ICD</span>;
      myVal.validation = true;
    } else {
      if (dotfind == -1) {
        if (this.state.icdModel.icdCode.length > 7) {
          myVal.icdCodeValField = (
            <span className="validationMsg">ICD length should be 7</span>
          );
          myVal.validation = true;
        } else {
          myVal.icdCodeValField = "";
          if (myVal.validation === false) myVal.validation = false;
        }
      } else {
        if (this.state.icdModel.icdCode.length > 8) {
          myVal.icdCodeValField = (
            <span className="validationMsg">
              ICD (with point) length should be 8
            </span>
          );
          myVal.validation = true;
        }
      }
    }

    if (this.isNull(this.state.icdModel.description) === true) {
      myVal.descriptionValField = (
        <span className="validationMsg">Description is required</span>
      );
      myVal.validation = true;
    } else {
      myVal.descriptionValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    this.setState({
      validationModel: myVal
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      this.saveICDCount = 0;
      return;
    }

    axios
      .post(this.url + "saveicd", this.state.icdModel, this.config)
      .then(response => {
        console.log("ICD Response : ", response.data);
        // Get CPT API
        var newICDList = this.props.icdCodes.concat({
          id: response.data.id,
          value: response.data.description,
          label: response.data.icdCode,
          description: response.data.description,
          description1: response.data.id,
          description2: null,
          anesthesiaUnits: null,
          category: null
        });
        this.props.ICDAction(this.props, newICDList, "SETICD");
        this.setState({
          icdModel: response.data,
          editId: response.data.id,
          loading: false
        });
        Swal.fire("Record Saved Successfully", "", "success");
        this.saveICDCount = 0;
        // $("#btnCancel").click();
      })
      .catch(error => {
        this.saveICDCount = 0;
        this.setState({ loading: false });
        console.log(error);
      });
  };

  delete = e => {
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(result => {
      if (result.value) {
        this.setState({ loading: true });

        axios
          .delete(this.url + "deleteicd/" + this.state.editId, this.config)
          .then(response => {
            this.setState({ loading: false });

            console.log("Delete Response :", response);
            Swal.fire("Record Deleted Successfully", "", "success");

            //Get CPT API
            axios
              .get(this.commonUrl + "getICD", this.config)
              .then(icdRes => {
                console.log("CPT Response : ", icdRes.data);
                this.props.ICDAction((this.props, icdRes.data, "SETICD"));
              })
              .catch(cptError => {
                console.log("CPT Error : ", cptError);
              });
          })
          .catch(error => {
            this.setState({ loading: false });

            console.log(error);
            if (this.state.editId > 0) {
              Swal.fire(
                "Record Not Deleted!",
                "Record can not be delete, as it is being reference in other screens.",
                "error"
              );
            } else {
              Swal.fire(
                "Record Not Deleted!",
                "Don't have record to delete",
                "error"
              );
            }
          });
        $("#btnCancel").click();
      }
    });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  render() {
    const isActive = this.state.icdModel.isActive;
    const isValid = this.state.icdModel.isValid;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        <div
          id="myModal1"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          aria-hidden="true"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={
                  this.props.onClose
                    ? this.props.onClose()
                    : () => this.props.onClose()
                }
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.icdModel.icdCode
                          : "NEW ICD"}
                      </h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkBox"
                          id="isActive"
                          name="isActive"
                          checked={!isActive}
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                        disabled={this.isDisabled(this.props.rights.delete)}
                      >
                        Delete
                      </Input>
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable">
                  {/* <div className="mf-12 headingOne mt-25">
                    <p>ICD Information</p>
                  </div> */}
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        ICD Code<span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.icdCodeValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.icdModel.icdCode}
                          name="icdCode"
                          id="icdCode"
                          max="7"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.icdCodeValField}
                      </div>
                    </div>

                    <div className="mf-6">
                      <div
                        className="lblChkBox"
                        onClick={this.handleIsValid}
                        style={{
                          marginLeft: "50px",
                          marginTop: "10px"
                        }}
                      >
                        <input
                          type="checkBox"
                          id="isValid"
                          name="isValid"
                          checked={!isValid}
                        />
                        <label> Is Valid</label>
                      </div>
                    </div>

                    <div className="mf-12 field_full-8 mt-15">
                      <label>Description:</label>
                      <textarea
                        value={this.state.icdModel.description}
                        name="description"
                        id="description"
                        cols="30"
                        rows="10"
                        onChange={this.handleChange}
                      ></textarea>
                    </div>
                    <div className="textBoxValidate">
                      {this.state.validationModel.descriptionValField}
                    </div>
                  </div>
                </div>

                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <Hotkeys
                          keyName="alt+s"
                          onKeyDown={this.onKeyDown.bind(this)}
                          onKeyUp={this.onKeyUp.bind(this)}
                        >
                          <input
                            type="button"
                            value="Save"
                            className="btn-blue"
                            onClick={this.saveICD}
                            disabled={this.isDisabled(
                              this.state.editId > 0
                                ? this.props.rights.update
                                : this.props.rights.add
                            )}
                          ></input>
                        </Hotkeys>


                        <input
                          type="button"
                          value="Cancel"
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                        </input>

                        {/* 
                        <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                          Cancel
                        </button> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    icdCodes: state.loginInfo
      ? state.loginInfo.icd
        ? state.loginInfo.icd
        : []
      : [],
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.icdSearch,
        add: state.loginInfo.rights.icdCreate,
        update: state.loginInfo.rights.icdEdit,
        delete: state.loginInfo.rights.icdDelete,
        export: state.loginInfo.rights.icdExport,
        import: state.loginInfo.rights.icdImport
      }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
      ICDAction: ICDAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewICD);
