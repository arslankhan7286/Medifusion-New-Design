import React, { Component, Fragment } from "react";
import $ from "jquery";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import taxonomyIcon from "../images/code-search-icon.png";
import axios from "axios";
import Input from "./Input";
import leftNavMenusReducer from "../reducers/leftNavMenusReducer";
import Swal from "sweetalert2";
import {
  MDBDataTable,
  MDBBtn,
  MDBTableHead,
  MDBTableBody,
  MDBTable,
} from "mdbreact";
import GridHeading from "./GridHeading";
import { Tabs, Tab } from "react-tab-view";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";
import RefProvider from "./NewRefferingProvider";
import Select, { components } from "react-select";
import settingsIcon from "../images/setting-icon.png";
import Dropdown from "react-dropdown";
import NewHistoryPractice from "./NewHistoryPractice";
import plusSrc from "../images/plus-icon.png";

import TextField from "@material-ui/core/TextField";
import Autocomplete from "@material-ui/lab/Autocomplete";
import NumberFormat from "react-number-format";
import TaxonomyCode from "./TaxonomyCode";
//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { taxonomyCodeAction } from "../actions/TaxonomyAction";

import Hotkeys from "react-hot-keys";

export class NewPractice extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/Practice/";
    this.accountUrl = process.env.REACT_APP_URL + "/account/";
    this.commonUrl = process.env.REACT_APP_URL + "/Common/";
    this.clientURL = process.env.REACT_APP_URL + "/client/";

    this.errorField = "errorField";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*",
      },
    };
    this.savePracticeCount = 0;

    this.practiceModel = {
      id: 0,
      name: "",
      organizationName: "",
      taxID: "",
      npi: "",
      practice: "",
      taxonomyCode: null,
      cliaNumber: "",
      clientID: null,
      address1: "",
      address2: "",
      city: "",
      state: "",
      zipCode: null,
      officePhoneNum: "",
      phoneNumExt: "",
      email: "",
      website: "",
      faxNumber: "",
      payToAddress1: "",
      payToAddress2: "",
      payToCity: "",
      payToState: "",
      payToZipCode: "",
      defaultLocationID: 0,
      workingHours: "",
      notes: "",
      isActive: true,
      isDeleted: false,
      sameAsAddress: false,
      ssn: "",
      providerName: "",
      type: "",
      provLastName: "",
      provFirstName: "",
      mainAuthIdentityCustom: null,
      statementExportType: "PLD",
      statementMessage: "",
      statementAgingDays: 30,
      statementMaxCount: 3,
      cellNumber: "",
      contactPersonName: "",
      invoicePercentage: "",
      minimumMonthlyAmount: "",
      numberOfFullTimeEmployees: null,
      fTEPerDayRate: "",
      fTEPerWeekRate: "",
      fTEPerMonthRate: "",
      includePatientCollection: false,
      clientCategory: "",
      refferedBy: "",
      pmSoftwareName: "",
      ehrSoftwareName: "",
      statementPhoneNumber: "",
      statementFaxNumber: "",
      appointmentPhoneNumber: "",
    };

    this.validationModel = {
      nameValField: "",
      organizationNameValField: "",
      npiValField: "",
      taxIDValField: "",
      taxonomyCodeValField: "",
      cliaNumberValField: "",
      address1ValField: "",
      address2ValField: "",
      cityValField: "",
      stateValField: "",
      zipCodeValField: "",
      officePhoneNumValField: "",
      emailValField: "",
      websiteValField: "",
      faxNumberValField: "",
      payToAddress1ValField: "",
      payToAddress2ValField: "",
      payToCityValField: "",
      payToStateValField: "",
      payToZipCodeValField: "",
      notesValField: "",
      clientValField: "",
      validation: false,
      ssnValField: "",
      typeValField: "",
      provLastNameValField: "",
      provFirstNameValField: "",
      // vendorValField: ""
    };

    this.state = {
      editId: this.props.practiceID,
      practiceModel: this.practiceModel,
      validationModel: this.validationModel,
      maxHeight: "361",
      loading: false,
      client: [],
      typePractice: false,
      typeValue: "",
      type: "",
      popupName: "",
      id: 0,
      isChecked: false,
      loading: false,
      taxonomyCode: {},
      sameAsClient: false,
      showTaxonomyPopup: false,
      includePatientCollection: false,
    };

    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.savePractice = this.savePractice.bind(this);
    this.handleSameAsAddress = this.handleSameAsAddress.bind(this);
    this.delete = this.delete.bind(this);
    this.handleChangeType = this.handleChangeType.bind(this);
    this.handleZip = this.handleZip.bind(this);
    this.handletaxonomyCodeChange = this.handletaxonomyCodeChange.bind(this);
    this.onPaste = this.onPaste.bind(this);
    this.handleSameAsClient = this.handleSameAsClient.bind(this);
    this.includePatientCollection = this.includePatientCollection.bind(this);
  }

  onKeyDown(keyName, e, handle) {
    if (keyName == "alt+s") {
      // alert("save key")
      this.savePractice();
    }

    this.setState({
      output: `onKeyDown ${keyName}`,
    });
  }

  onKeyUp(keyName, e, handle) {
    if (e) {
    }
    this.setState({
      output: `onKeyUp ${keyName}`,
    });
  }

  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  async componentDidMount() {
    this.setModalMaxHeight($(".modal"));
    this.setState({ loading: true });
    //Location

    try {
      await axios
        .get(this.url + "GetProfiles/" + this.state.editId, this.config)
        .then((response) => {
          let arrayToPush = [];
          const pushToProvider = [];
          const pushToReferral = [];
          response.data.location.map((row, i) => {
            arrayToPush.push({
              id: row.id,
              name: (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() => this.openPopup("Location", row.id)}
                >
                  {row.name}
                </MDBBtn>
              ),
              organizationName: row.organizationName,
              practice: row.practice,
              npi: row.npi,
              posCode: row.posCode,
              address: row.address,
              officePhoneNum: row.officePhoneNum,
            });
          });
          response.data.provider.map((row, i) => {
            //Its working upto here
            pushToProvider.push({
              id: row.id,
              name: (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() => this.openPopup("Provider", row.id)}
                >
                  {row.name}
                </MDBBtn>
              ),
              lastName: row.lastName,
              firstName: row.firstName,
              npi: row.npi,
              ssn: row.ssn,
              texonomycode: row.taxonomyCode,
              address: row.address,
              phone: row.officePhoneNum,
            });
          });

          // let pushToReferral = [];
          response.data.refProvider.map((row, i) => {
            pushToReferral.push({
              referingId: row.id,
              name: (
                <MDBBtn
                  className="gridBlueBtn"
                  onClick={() => this.openPopup("RefProvider", row.id)}
                >
                  {row.name}
                </MDBBtn>
              ),
              lastName: row.lastName,

              firstName: row.firstName,
              npi: row.npi,
              ssn: row.ssn,
              taxonomyCode: row.taxonomyCode,
              address: row.address,
              officePhoneNum: row.PhoneNumber,
            });
          });

          this.setState({
            RefProviderData: pushToReferral,
            locationData: arrayToPush,
            providerData: pushToProvider,
          });
        })
        .catch((error) => {
          if (error.response) {
            if (error.response.status) {
              Swal.fire("Unauthorized Access", "", "error");
            }
          } else if (error.request) {
          } else {
          }
        });

      // if ($('.modal.in').length != 0) {
      //     this.setModalMaxHeight($('.modal.in'));
      // }
      var zIndex = 1040 + 10 * $(".modal:visible").length;
      $(this).css("z-Index", zIndex);
      setTimeout(function () {
        $(".modal-backdrop")
          .not(".modal-stack")
          .css("z-Index", zIndex - 1)
          .addClass("modal-stack");
      }, 0);

      await axios
        .get(this.accountUrl + "getProfiles", this.config)
        .then((response) => {
          this.setState({ client: response.data.clients });
        })
        .catch((error) => {
          if (error.response) {
            if (error.response.status) {
              //Swal.fire("Unauthorized Access" , "" , "error");
              return;
            }
          } else if (error.request) {
            return;
          } else {
            //Swal.fire("Something went Wrong" , "" , "error");
            return;
          }
        });

      //TaxonomyCode
      if (
        this.props.userInfo1.taxonomy == null ||
        this.props.userInfo1.taxonomy.length == 0
      ) {
        await axios
          .get(this.commonUrl + "GetTaxonomy", this.config)
          .then((response) => {
            this.props.taxonomyCodeAction(
              this.props,
              response.data,
              "TAXONOMYCODES"
            );
          })
          .catch((error) => { });
      }

      if (this.state.editId > 0) {
        await axios({
          url: this.url + "FindPractice/" + this.state.editId,
          method: "get",
          headers: {
            Authorization: "Bearer  " + this.props.loginObject.token,
            Accept: "*/*",
          },
        })
          .then((response) => {
            this.setState({ practiceModel: response.data, typePractice: true });
          })
          .catch((error) => {
            if (error.response) {
              if (error.response.status) {
                Swal.fire("Unauthorized Access", "", "error");
              }
            } else if (error.request) {
            } else {
              Swal.fire("Something Wrong", "Please Try Again", "error");
            }
          });
      }

      this.setState({
        taxonomyCode: this.props.taxonomyCode.filter(
          (option) => option.value == this.state.practiceModel.taxonomyCode
        ),
      });
    } catch {
      await this.setState({ loading: false });
    }
    await this.setState({ loading: false });
  }

  handleSameAsAddress = (event) => {
    let isChecked = !this.state.isChecked;
    // this.setState ({ isChecked:isChecked }) ;
    this.setState({ isChecked: isChecked });

    if (isChecked) {
      //alert("Click")
      this.setState({
        practiceModel: {
          ...this.state.practiceModel,
          payToAddress1: this.state.practiceModel.address1,
          payToAddress2: this.state.practiceModel.address2,
          payToCity: this.state.practiceModel.city,
          payToState: this.state.practiceModel.state,
          payToZipCode: this.state.practiceModel.zipCode,
        },
      });
    } else {
      // alert("Not Click")

      this.setState({
        practiceModel: {
          ...this.state.practiceModel,
          payToAddress1: "",
          payToAddress2: "",
          payToCity: "",
          payToState: "",
          payToZipCode: "",
        },
      });
    }

    // this.state.practiceModel.payToAddress1=this.state.practiceModel.address1;
    // this.state.practiceModel.payToAddress2=this.state.practiceModel.address2;
    // this.state.practiceModel.payToCity=this.state.practiceModel.city;
    // this.state.practiceModel.payToState=this.state.practiceModel.state;
    // this.state.practiceModel.payToZipCode=this.state.practiceModel.zipCode;

    //event.preventDefault();
    //alert('same address')
    // this.setState({
    //     practiceModel: {
    //         ...this.state.practiceModel,
    //         sameAsAddress: !this.state.practiceModel.sameAsAddress
    //     }
    // });
    // if (this.state.practiceModel.sameAsAddress) {
    //     this.setState({
    //         practiceModel: {
    //             ...this.state.practiceModel,
    //             payToAddress1: this.state.practiceModel.address1,
    //             paytoAddress2: this.state.practiceModel.address2,
    //             payToCity: this.state.practiceModel.city,
    //             paytoState: this.state.practiceModel.state,
    //             paytoZipCode: this.state.practiceModel.zipCode
    //         }
    //     });
    // } else {
    //     this.setState({
    //         practiceModel: {
    //             ...this.state.practiceModel,
    //             paytoAddress: '',
    //             payToCity: '',
    //             paytoState: '',
    //             paytoZipCode: '',
    //         }
    //     });
    // }
  };

  handleZip(event) {
    var zip = event.target.value;

    this.setState({
      practiceModel: {
        ...this.state.practiceModel,
        [event.target.name]: event.target.value,
      },
    });

    if (zip.length == 5 || zip.length == 9) {
      axios
        .get(this.commonUrl + "GetCityStateInfo/" + zip, this.config)
        .then((response) => {
          this.setState({
            practiceModel: {
              ...this.state.practiceModel,
              city: response.data.city.toUpperCase(),
              state: response.data.state_id,
            },
          });
        })
        .catch((error) => {
          this.setState({ loading: false });

          if (error.response.data == "InValid ZipCode") {
            Swal.fire("Something Wrong", "InValid ZipCode", "error");
          } else {
            Swal.fire(
              "Something Wrong",
              "Please Check Server Connection",
              "error"
            );
          }
          let errorsList = [];
          if (error.response !== null && error.response.data !== null) {
            errorsList = error.response.data;
          }
        });
    } else {
      // Swal.fire("Enter Valid Zip Code", "", "error");
    }
  }

  // handleChange = event => {
  //   //Carret Position
  //   const caret = event.target.selectionStart;
  //   const element = event.target;
  //   window.requestAnimationFrame(() => {
  //     element.selectionStart = caret;
  //     element.selectionEnd = caret;
  //   });

  //   var myValue;
  //   event.preventDefault();
  //   var myName = event.target.name ? event.target.name : "";
  //   if (myName == "cliaNumber") {
  //     myValue = event.target.value ? event.target.value : "";
  //     event.target.value = myValue.trim();
  //   }

  //   event.preventDefault();
  //   this.setState({
  //     practiceModel: {
  //       ...this.state.practiceModel,
  //       [event.target.name]: event.target.value.toUpperCase()
  //     }
  //   });
  // };

  //Yawar Code
  handleChange = (event) => {
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    // Expression to Match every field except Email
    var regExpr = /[^a-zA-Z0-9 ]/g;
    var myValue = event.target.value;
    var myName = event.target.name;

    if (caret == 0 || caret <= 1) {
      myValue = myValue.trim();
    }

    if (myName == "cliaNumber") {
      myValue = myValue ? myValue : "";
      myValue = myValue.trim();
      myValue = myValue.replace(regExpr, "");
    } else if (myName == "name" || myName == "organizationName") {
      myValue = myValue.replace(regExpr, "");
    } else if (myName == "invoicePercentage") {
      if (myValue < 0) {
        Swal.fire("Something Wrong", "Enter Valid Value", "error");
        return;
      }
      if (myValue > 100) {
        Swal.fire("Something Wrong", "Enter Valid Value", "error");
        return;
      }
      myValue = Number(myValue).toFixed(2);
    } else {
      if (myName == "statementMessage") {
        myValue = myValue;
      } else if (myName == "statementExportType") {
        myValue = myValue;
      } else {
        myValue = myValue ? myValue : "";
        myValue = myValue.toUpperCase();
      }
    }
    this.setState({
      practiceModel: {
        ...this.state.practiceModel,
        [myName]: myValue,
      },
    });
  };

  handleChangeType = (event) => {
    this.setState({
      typePractice: true,
      type: event.target.value,
      // type: event.target.value
      practiceModel: {
        ...this.state.practiceModel,
        [event.target.name]: event.target.value,
      },
    });
  };

  handleCheck = () => {
    this.setState({
      practiceModel: {
        ...this.state.practiceModel,
        isActive: !this.state.practiceModel.isActive,
      },
    });
  };

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  isNull(value) {
    if (value === "" || value === null || value === undefined) return true;
    else return false;
  }

  savePractice = (e) => {
    if (this.savePracticeCount == 1) {
      return;
    }
    this.savePracticeCount = 1;
    // if (this.state.loading == true) {
    //   return;
    // }

    this.setState({ loading: true });

    if (this.isNull(this.state.practiceModel.officePhoneNum) === false) {
      if (this.state.practiceModel.officePhoneNum.length > 10) {
        var officePhoneNum = this.state.practiceModel.officePhoneNum.slice(
          3,
          17
        );
        this.state.practiceModel.officePhoneNum = officePhoneNum.replace(
          /[-_ )(]/g,
          ""
        );
      }
    }

    if (this.isNull(this.state.practiceModel.statementPhoneNumber) === false) {
      if (this.state.practiceModel.statementPhoneNumber.length > 10) {
        var statementPhoneNumber = this.state.practiceModel.statementPhoneNumber.slice(
          3,
          17
        );
        this.state.practiceModel.statementPhoneNumber = statementPhoneNumber.replace(
          /[-_ )(]/g,
          ""
        );
      }
    }

    if (
      this.isNull(this.state.practiceModel.appointmentPhoneNumber) === false
    ) {
      if (this.state.practiceModel.appointmentPhoneNumber.length > 10) {
        var appointmentPhoneNumber = this.state.practiceModel.appointmentPhoneNumber.slice(
          3,
          17
        );
        this.state.practiceModel.appointmentPhoneNumber = appointmentPhoneNumber.replace(
          /[-_ )(]/g,
          ""
        );
      }
    }

    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.practiceModel.name)) {
      myVal.nameValField = <span className="validationMsg">Enter Name</span>;
      myVal.validation = true;
    } else {
      myVal.nameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.practiceModel.organizationName)) {
      myVal.organizationNameValField = (
        <span className="validationMsg">Enter Organization Name</span>
      );
      myVal.validation = true;
    } else {
      myVal.organizationNameValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.practiceModel.npi)) {
      myVal.npiValField = <span className="validationMsg">Enter NPI</span>;
      myVal.validation = true;
    } else if (this.state.practiceModel.npi.length < 10) {
      myVal.npiValField = (
        <span className="validationMsg">NPI length should be 10</span>
      );
      myVal.validation = true;
    } else {
      myVal.npiValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (
      this.isNull(this.state.practiceModel.taxID) &&
      this.state.practiceModel.type == "GP"
    ) {
      myVal.taxIDValField = <span className="validationMsg">Enter Tax ID</span>;
      myVal.validation = true;
    } else if (
      this.state.practiceModel.taxID.length < 9 &&
      this.state.practiceModel.type == "GP"
    ) {
      myVal.taxIDValField = (
        <span className="validationMsg">Tax ID length should be 9</span>
      );
      myVal.validation = true;
    } else {
      myVal.taxIDValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.practiceModel.taxonomyCode) === false) {
    }
    // if (
    //         this.state.practiceModel.taxonomyCode.length < 10
    // ) {
    //   myVal.taxonomyCodeValField = (
    //     <span className="validationMsg">Taxonomy Code length should be 9</span>
    //   );
    //   myVal.validation = true;
    // }
    if (this.isNull(this.state.practiceModel.clientID)) {
      myVal.clientValField = (
        <span className="validationMsg">Select Client</span>
      );
      myVal.validation = true;
    } else {
      myVal.clientValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }
    ////////////
    if (this.isNull(this.state.practiceModel.type)) {
      myVal.typeValField = <span className="validationMsg">Select Type</span>;
      myVal.validation = true;
    } else {
      myVal.typeValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.state.practiceModel.type == "SP") {
      if (this.isNull(this.state.practiceModel.ssn)) {
        myVal.ssnValField = <span className="validationMsg">Enter SSN</span>;
        myVal.validation = true;
      } else if (
        this.isNull(this.state.practiceModel.ssn) === false &&
        this.state.practiceModel.ssn.length < 9
      ) {
        myVal.ssnValField = (
          <span className="validationMsg">SSN length should be 9</span>
        );
        myVal.validation = true;
      } else {
        myVal.ssnValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }

      if (this.isNull(this.state.practiceModel.provFirstName)) {
        myVal.provFirstNameValField = (
          <span className="validationMsg">Enter First Name</span>
        );
        myVal.validation = true;
      } else {
        myVal.provFirstNameValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }

      if (this.isNull(this.state.practiceModel.provLastName)) {
        myVal.provLastNameValField = (
          <span className="validationMsg">Enter Last Name</span>
        );
        myVal.validation = true;
      } else {
        myVal.provLastNameValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.ssnValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.practiceModel.cliaNumber) == false) {
      if (
        this.state.practiceModel.cliaNumber.length > 10 &&
        this.state.practiceModel.cliaNumber.length < 10
      ) {
        myVal.cliaNumberValField = (
          <span className="validationMsg">cliaNumber length should be 10</span>
        );
        myVal.validation = true;
      } else {
        myVal.cliaNumberValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    }

    if (this.isNull(this.state.practiceModel.zipCode) === false) {
      if (
        this.state.practiceModel.zipCode.length > 0 &&
        this.state.practiceModel.zipCode.length < 5
      ) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of alleast 5 digits
          </span>
        );
        myVal.validation = true;
      } else if (
        this.state.practiceModel.zipCode.length > 5 &&
        this.state.practiceModel.zipCode.length < 9
      ) {
        myVal.zipCodeValField = (
          <span className="validationMsg">
            Zip should be of either 5 or 9 digits
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.zipCodeValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    } else {
      myVal.zipCodeValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    // Patient Statement Vendor Drop down
    if (this.isNull(this.state.practiceModel.statementExportType)) {
      myVal.vendorValField = (
        <span className="validationMsg" style={{ marginLeft: "34%" }}>
          Select Vendor
        </span>
      );
      myVal.validation = true;
    } else {
      myVal.vendorValField = "";
      if (myVal.validation === false) myVal.validation = false;
    }

    if (this.isNull(this.state.practiceModel.faxNumber) === false) {
      if (this.state.practiceModel.faxNumber.length < 10) {
        myVal.faxNumberValField = (
          <span className="validationMsg">Fax # length should be 10</span>
        );
        myVal.validation = true;
      } else {
        myVal.faxNumberValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    }

    if (this.isNull(this.state.practiceModel.officePhoneNum) === false) {
      if (this.state.practiceModel.officePhoneNum.length < 10) {
        myVal.officePhoneNumValField = (
          <span className="validationMsg">Phone # length should be 10</span>
        );
        myVal.validation = true;
      } else {
        myVal.officePhoneNumValField = "";
        if (myVal.validation === false) myVal.validation = false;
      }
    }

    myVal.emailValField = "";
    this.setState({
      validationModel: myVal,
    });

    if (myVal.validation === true) {
      this.setState({ loading: false });
      this.savePracticeCount = 0;

      return;
    }

    var config = {
      headers: { Authorization: "Bearer  " + this.props.loginObject.token },
    };

    axios
      .post(this.url + "SavePractice", this.state.practiceModel, this.config)
      .then((response) => {
        this.savePracticeCount = 0;

        var practiceModal = response.data;
        practiceModal.mainAuthIdentityCustom = null;
        this.setState({ loading: false, practiceModel: practiceModal });
        Swal.fire("Record Saved Successfully", "", "success");
      })
      .catch((error) => {
        this.savePracticeCount = 0;

        this.setState({ loading: false });
        try {
          if (error.response) {
            if (error.response.status) {
              if (error.response.status == 401) {
                Swal.fire("Unauthorized Access", "", "error");
                return;
              } else if (error.response.status == 404) {
                Swal.fire("Not Found", "Failed With Status Code 404", "error");
                return;
              } else if (error.response.status == 400) {
                if (error.response.data.Email) {
                  if (error.response.data.Email[0]) {
                    myVal.emailValField = (
                      <span
                        className="validationMsg"
                        style={{ marginLeft: "-25%" }}
                      >
                        Please enter Valid Email ID
                      </span>
                    );
                    myVal.validation = true;
                  } else {
                    myVal.emailValField = "";
                    if (myVal.validation === false) myVal.validation = false;
                  }
                  this.setState({
                    validationModel: myVal,
                  });
                } else {
                  Swal.fire("Error", error.response.data, "error");
                  return;
                }
              } else {
                Swal.fire("Something Wrong", "Please Try Again", "error");
                return;
              }
            }
          } else {
            Swal.fire("Something went Wrong", "", "error");
            return;
          }
        } catch { }
      });

    // e.preventDefault();
  };

  delete = (e) => {
    var config = {
      headers: { Authorization: "Bearer  " + this.props.loginObject.token },
    };

    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        this.setState({ loading: true });
        axios
          .delete(this.url + "DeletePractice/" + this.state.editId, config)
          .then((response) => {
            this.setState({ loading: false });
            Swal.fire("Record Deleted Successfully", "", "success");
          })
          .catch((error) => {
            this.setState({ loading: false });

            if (this.state.editId > 0) {
              Swal.fire(
                "Record Not Deleted!",
                "Record can not be delete, as it is being reference in other screens.",
                "error"
              );
            } else {
              Swal.fire(
                "Record Not Deleted!",
                "Don't have record to delete",
                "error"
              );
            }
            if (error.response) {
              if (error.response.status) {
                // Swal.fire("Unauthorized Access", "", "error");
              }
            } else if (error.request) {
            } else {
            }
          });

        $("#btnCancel").click();
      }
    });
  };

  openPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  handletaxonomyCodeChange(event) {
    if (event) {
      this.setState({
        taxonomyCode: event,
        // taxonomyCodeobj: event.id,
        practiceModel: {
          ...this.state.practiceModel,
          taxonomyCode: event.value,
        },
      });
    } else {
      this.setState({
        taxonomyCode: null,
        // taxonomyCodeobj: event.id,
        practiceModel: {
          ...this.state.practiceModel,
          taxonomyCode: null,
        },
      });
    }
  }
  openhistorypopup = (id) => {
    this.setState({ showPopup: true, id: id });
  };
  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  onPaste(event) {
    var x = event.target.value;
    x = x.trim();

    var regex = /^[0-9]+$/;
    if (x.length > 10) {
      // if (x.length > 9) {
      x = x.trimRight();
      Swal.fire("Error", "Length of NPI Should be 10", "error");
      // }
    } else if (x.length == 0) {
      this.setState({
        practiceModel: {
          ...this.state.practiceModel,
          [event.target.name]: x,
        },
      });
      return;
    }

    if (!x.match(regex)) {
      Swal.fire("Error", "NPI Should be Number", "error");
      return;
    } else {
      this.setState({
        practiceModel: {
          ...this.state.practiceModel,
          [event.target.name]: x,
        },
      });
    }
    return;
  }

  handleSameAsClient(event) {
    let isChecked = !this.state.sameAsClient;
    if (
      this.state.practiceModel.clientID == "" ||
      this.state.practiceModel.clientID == null
    ) {
      Swal.fire("Select Client", "", "error");
    } else {
      this.setState({ sameAsClient: isChecked });
      axios
        .get(
          this.clientURL + "findClient/" + this.state.practiceModel.clientID,
          this.config
        )
        .then((response) => {
          if (isChecked) {
            this.setState({
              practiceModel: {
                ...this.state.practiceModel,
                // id: response.data.id ? response.data.id : "",
                name: response.data.name ? response.data.name : "",
                organizationName: response.data.organizationName
                  ? response.data.organizationName
                  : "",
                taxID: response.data.taxID ? response.data.taxID : "",
                clientID: response.data.id ? response.data.id : "",
                address1: response.data.address ? response.data.address : "",
                address2: response.data.address ? response.data.address : "",
                city: response.data.city ? response.data.city : "",
                state: response.data.state ? response.data.state : "",
                zipCode: response.data.zipCode ? response.data.zipCode : "",
                officePhoneNum: response.data.officePhoneNo
                  ? response.data.officePhoneNo
                  : "",
                phoneNumExt: response.data.id ? response.data.id : "",
                email: response.data.officeEmail
                  ? response.data.officeEmail
                  : "",
                faxNumber: response.data.faxNo ? response.data.faxNo : "",
                ZipCode: this.state.practiceModel.zipCode,
              },
            });
          } else {
            this.setState({
              practiceModel: {
                ...this.state.practiceModel,
                // id: "",
                name: "",
                organizationName: "",
                taxID: "",
                clientID: "",
                address1: "",
                address2: "",
                city: "",
                state: "",
                zipCode: "",
                officePhoneNum: "",
                phoneNumExt: "",
                email: "",
                faxNumber: "",
              },
            });
          }
        })
        .catch((error) => {
          // console.log(error);
        });
    }
  }

  includePatientCollection(event) {
    let isChecked = !this.state.practiceModel.includePatientCollection;
    this.setState({
      practiceModel: {
        ...this.state.practiceModel,
        includePatientCollection: isChecked,
      },
    });
  }

  openTaxonomyPopup = (id) => {
    this.setState({ showTaxonomyPopup: true, id: id });
  };
  closeTaxonomyPopup = (id) => {
    this.setState({ showTaxonomyPopup: false, id: id });
  };
  render() {
    const headers = ["Location", "Provider", "Referring Providers"];

    const locationData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150,
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150,
        },
        {
          label: "ORGANIZATION NAME",
          field: "organizationName",
          sort: "asc",
          width: 300,
        },
        {
          label: "PRACTICE",
          field: "practice",
          sort: "asc",
          width: 250,
        },

        {
          label: "NPI",
          field: "npi",
          sort: "asc",
          width: 200,
        },
        {
          label: "POS CODE",
          field: "posCode",
          sort: "asc",
          width: 150,
        },
        {
          label: "ADDRESS",
          field: "address",
          sort: "asc",
          width: 100,
        },
      ],
      rows: this.state.locationData,
    };
    const providerData = {
      columns: [
        {
          label: "ID",
          field: "Id",
          sort: "asc",
          width: 150,
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150,
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          width: 150,
        },
        {
          label: "FIRST NAME ",
          field: "firstName",
          sort: "asc",
          width: 150,
        },
        {
          label: "NPI",
          field: "npi",
          sort: "asc",
          width: 150,
        },

        {
          label: "SSN",
          field: "ssn",
          sort: "asc",
          width: 150,
        },
        {
          label: "TEXONOMY CODE",
          field: "texonomycode",
          sort: "asc",
          width: 150,
        },
        {
          label: "ADDRESS ,CITY, STATE, ZIP",
          field: "address",
          sort: "asc",
          width: 150,
        },
        {
          label: "OFFICE PHONE#",
          field: "phone",
          sort: "asc",
          width: 150,
        },
      ],
      rows: this.state.providerData,
    };

    const RefProviderData = {
      columns: [
        {
          label: "ID",
          field: "referingId",
          sort: "asc",
          width: 150,
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150,
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          width: 150,
        },
        {
          label: "FIRST NAME ",
          field: "firstName",
          sort: "asc",
          width: 150,
        },
        {
          label: "NPI",
          field: "npi",
          sort: "asc",
          width: 150,
        },

        {
          label: "SSN",
          field: "ssn",
          sort: "asc",
          width: 150,
        },
        {
          label: "TEXONOMY CODE",
          field: "taxonomyCode",
          sort: "asc",
          width: 150,
        },
        {
          label: "ADDRESS ,CITY, STATE, ZIP",
          field: "address",
          sort: "asc",
          width: 150,
        },
        {
          label: "OFFICE PHONE#",
          field: "officePhoneNum",
          sort: "asc",
          width: 150,
        },
      ],
      rows: this.state.RefProviderData,
    };

    const type = [
      { value: "", display: "Select Type" },
      { value: "SP", display: "Solo Practice" },
      { value: "GP", display: "Group Practice" },
    ];
    const usStates = [
      { value: "", display: "Select State" },
      { value: "AL", display: "AL - Alabama" },
      { value: "AK", display: "AK - Alaska" },
      { value: "AZ", display: "AZ - Arizona" },
      { value: "AR", display: "AR - Arkansas" },
      { value: "CA", display: "CA - California" },
      { value: "CO", display: "CO - Colorado" },
      { value: "CT", display: "CT - Connecticut" },
      { value: "DE", display: "DE - Delaware" },
      { value: "FL", display: "FL - Florida" },
      { value: "GA", display: "GA - Georgia" },
      { value: "HI", display: "HI - Hawaii" },
      { value: "ID", display: "ID - Idaho" },
      { value: "IL", display: "IL - Illinois" },
      { value: "IN", display: "IN - Indiana" },
      { value: "IA", display: "IA - Iowa" },
      { value: "KS", display: "KS - Kansas" },
      { value: "KY", display: "KY - Kentucky" },
      { value: "LA", display: "LA - Louisiana" },
      { value: "ME", display: "ME - Maine" },
      { value: "MD", display: "MD - Maryland" },
      { value: "MA", display: "MA - Massachusetts" },
      { value: "MI", display: "MI - Michigan" },
      { value: "MN", display: "MN - Minnesota" },
      { value: "MS", display: "MS - Mississippi" },
      { value: "MO", display: "MO - Missouri" },
      { value: "MT", display: "MT - Montana" },
      { value: "NE", display: "NE - Nebraska" },
      { value: "NV", display: "NV - Nevada" },
      { value: "NH", display: "NH - New Hampshire" },
      { value: "NJ", display: "NJ - New Jersey" },
      { value: "NM", display: "NM - New Mexico" },
      { value: "NY", display: "NY - New York" },
      { value: "NC", display: "NC - North Carolina" },
      { value: "ND", display: "ND - North Dakota" },
      { value: "OH", display: "OH - Ohio" },
      { value: "OK", display: "OK - Oklahoma" },
      { value: "OR", display: "OR - Oregon" },
      { value: "PA", display: "PA - Pennsylvania" },
      { value: "RI", display: "RI - Rhode Island" },
      { value: "SC", display: "SC - South Carolina" },
      { value: "SD", display: "SD - South Dakota" },
      { value: "TN", display: "TN - Tennessee" },
      { value: "TX", display: "TX - Texas" },
      { value: "UT", display: "UT - Utah" },
      { value: "VT", display: "VT - Vermont" },
      { value: "VA", display: "VA - Virginia" },
      { value: "WA", display: "WA - Washington" },
      { value: "WV", display: "WV - West Virginia" },
      { value: "WI", display: "WI - Wisconsin" },
      { value: "WY", display: "WY - Wyoming" },
    ];
    const options = [
      { value: "History", label: "History", className: "dropdown" },
    ];

    const statementExportType = [
      { value: "", display: "Select Type" },
      { value: "PLD", display: "PLD" },
      { value: "Manual Statement", display: "Manual Statement" },
    ];

    const clientCategory = [
      { value: "", display: "Select Type" },
      { value: "A", display: "A" },
      { value: "B", display: "B" },
      { value: "C", display: "C" },
      { value: "D", display: "D" },
    ];
    var Imag;
    Imag = (
      <div>
        <img src={settingsIcon} />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup(0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );
    const isActive = this.state.practiceModel.isActive;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    //////////////////// handle ssn /////////////////
    let typeValuefield = "";
    if (
      this.state.typePractice === true &&
      this.state.practiceModel.type == "SP"
    ) {
      //  alert("Hi:True" + this.state.typeValue)
      typeValuefield = (
        <div>
          <div className="row-form">
            <div className="mf-6">
              <label>
                SSN <span className="redlbl"> *</span>
              </label>
              <div className="textBoxValidate">
                <input
                  className={
                    this.state.validationModel.npiValField
                      ? this.errorField
                      : ""
                  }
                  type="text"
                  value={this.state.practiceModel.ssn}
                  name="ssn"
                  id="ssn"
                  maxLength="9"
                  onChange={() => this.handleChange}
                  onKeyPress={(event) => this.handleNumericCheck(event)}
                  onInput={this.onPaste}
                />
                {/* <Input name="ssn" id="ssn" max='9'/> */}
                {this.state.validationModel.ssnValField}
              </div>
            </div>
            <div className="mf-6">
              <label>
                Provider First Name <span className="redlbl"> *</span>
              </label>
              <div className="textBoxValidate">
                <Input
                  // className={
                  //   this.state.validationModel.npiValField ? this.errorField : ""
                  // }
                  type="text"
                  value={this.state.practiceModel.provFirstName}
                  name="provFirstName"
                  id="provFirstName"
                  maxLength="20"
                  disabled={this.state.editId > 0 ? true : false}
                  onChange={() => this.handleChange}
                />

                {this.state.validationModel.provFirstNameValField}
              </div>
            </div>
          </div>

          <div className="row-form">
            <div className="mf-6">
              <label>
                Provier Last Name<span className="redlbl"> *</span>
              </label>
              <div className="textBoxValidate">
                <Input
                  // className={
                  //   this.state.validationModel.npiValField ? this.errorField : ""
                  // }
                  type="text"
                  value={this.state.practiceModel.provLastName}
                  name="provLastName"
                  id="provLastName"
                  maxLength="20"
                  disabled={this.state.editId > 0 ? true : false}
                  onChange={() => this.handleChange}
                />
                {this.state.validationModel.provLastNameValField}
              </div>
            </div>
            <div className="mf-6"></div>
          </div>
        </div>
      );
    } else {
      //alert("Hi:False" + this.state.typeValue)
    }
    ////////////////////////// Invoice Information Later on display will be on basis of Role ////////////////////////////

    let invoiceInfo = "";
    invoiceInfo = (
      <div>
        <div className="row-form headingOneChkBox mt-25">
          <div className="mf-6">
            <p>Invoice Detail</p>
          </div>
          <div
            className="mf-6 popupHeadingRight"
            style={{ paddingRight: "163px" }}
          ></div>
          {/*// <div className="lblChkBox">
            //   <input
            //     type="checkbox"
            //     id="includePatientCollection"
            //     name="includePatientCollection"
            //     checked={this.state.practiceModel.includePatientCollection}
            //     onChange={this.includePatientCollection}
            //   />
            //   <label htmlFor="includePatientCollection">
            //     <span> Include Patient Collection </span>
            //   </label>
            // </div>
          </div> */}
        </div>
        <div className="row-form">
          <div className="mf-6">
            <label>Invoice Percentage</label>
            <Input
              type="text"
              value={this.state.practiceModel.invoicePercentage}
              name="invoicePercentage"
              id="invoicePercentage"
              // max="55"
              onChange={() => this.handleChange}
              onKeyPress={(event) => this.handleNumericCheck(event)}
            />
          </div>
          <div className="mf-6">
            <label>Minimum Monthly Amt</label>
            <Input
              type="text"
              value={this.state.practiceModel.minimumMonthlyAmount}
              name="minimumMonthlyAmount"
              id="minimumMonthlyAmount"
              // max="55"
              onChange={() => this.handleChange}
              onKeyPress={(event) => this.handleNumericCheck(event)}
            />
          </div>
        </div>

        <div className="row-form">
          <div className="mf-6">
            <label>Full Time Employees #</label>
            <Input
              type="text"
              value={this.state.practiceModel.numberOfFullTimeEmployees}
              name="numberOfFullTimeEmployees"
              id="numberOfFullTimeEmployees"
              // max="55"
              onChange={() => this.handleChange}
              onKeyPress={(event) => this.handleNumericCheck(event)}
            />
          </div>
          <div className="mf-6">
            <label>FTE Per Day Rate</label>
            <Input
              type="text"
              value={this.state.practiceModel.ftePerDayRate}
              name="ftePerDayRate"
              id="ftePerDayRate"
              // max="55"
              onChange={() => this.handleChange}
              onKeyPress={(event) => this.handleNumericCheck(event)}
            />
          </div>
        </div>

        <div className="row-form">
          <div className="mf-6">
            <label>FTE Per Week Rate</label>
            <Input
              type="text"
              value={this.state.practiceModel.ftePerWeekRate}
              name="ftePerWeekRate"
              id="ftePerWeekRate"
              // max="55"
              onChange={() => this.handleChange}
              onKeyPress={(event) => this.handleNumericCheck(event)}
            />
          </div>
          <div className="mf-6">
            <label>FTE Per Month Rate</label>
            <Input
              type="text"
              value={this.state.practiceModel.ftePerMonthRate}
              name="ftePerMonthRate"
              id="ftePerMonthRate"
              // max="55"
              onChange={() => this.handleChange}
              onKeyPress={(event) => this.handleNumericCheck(event)}
            />
          </div>
        </div>

        <div className="row-form">
          <div className="mf-6" style={{ marginLeft: "-16%" }}>
            <div className="lblChkBox">
              <input
                type="checkbox"
                id="includePatientCollection"
                name="includePatientCollection"
                checked={this.state.practiceModel.includePatientCollection}
                onChange={this.includePatientCollection}
              />
              <label htmlFor="includePatientCollection">
                <span> Include Patient Collection </span>
              </label>
            </div>
          </div>
        </div>
      </div>
    );

    let popup = "";
    if (this.state.popupName == "Location") {
      popup = (
        <NewLocation
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewLocation>
      );
    } else if (this.state.popupName == "Provider") {
      popup = (
        <NewProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else if (this.state.popupName == "RefProvider") {
      popup = (
        <RefProvider
          onClose={() => this.closePopup}
          id={this.state.id}
        ></RefProvider>
      );
    } else if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.props.practiceID}
          apiURL={this.url}
        // disabled={this.isDisabled(this.props.rights.update)}
        // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else if (this.state.showTaxonomyPopup) {
      popup = (
        <TaxonomyCode onClose={() => this.closeTaxonomyPopup}></TaxonomyCode>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    return (
      <React.Fragment>
        <div
          id="practiceModal"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}
            {/* <button
              //  onClick={this.props.onClose()}
              className="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true"></span>
            </button> */}

            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={
                  this.props.onClose
                    ? this.props.onClose()
                    : () => this.props.onClose()
                }
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>
              <div className="modal-header">
                <div className="mf-12">
                  <div className="row">
                    <div className="mf-6 popupHeading">
                      <h1 className="modal-title">
                        {this.state.editId > 0
                          ? this.state.practiceModel.name.toUpperCase() +
                          " - " +
                          this.state.practiceModel.id
                          : "NEW PRACTICE"}
                      </h1>
                    </div>
                    <div className="mf-6 popupHeadingRight">
                      <div className="lblChkBox">
                        <input
                          type="checkbox"
                          checked={this.state.sameAsClient}
                          disabled={this.state.editId > 0 ? true : false}
                          id="sameAsClient"
                          name="sameAsClient"
                          onChange={(event) => this.handleSameAsClient(event)}
                        />
                        <label htmlFor="sameAsClient">
                          <span>Same As client</span>
                        </label>
                      </div>
                      <div className="lblChkBox" onClick={this.handleCheck}>
                        <input
                          type="checkbox"
                          checked={!isActive}
                          id="isActive"
                          name="isActive"
                        />
                        <label htmlFor="markInactive">
                          <span>Mark Inactive</span>
                        </label>
                      </div>
                      <Input
                        type="button"
                        value="Delete"
                        className="btn-blue"
                        onClick={this.delete}
                        disabled={this.isDisabled(this.props.rights.delete)}
                      >
                        Delete
                      </Input>
                      {this.state.editId > 0 ? dropdown : ""}

                      {/* <Dropdown
                        className="TodayselectContainer"
                        options={options}
                        onChange={() => this.openhistorypopup(0)}
                        //  value={options}
                        // placeholder={"Select an option"}
                        placeholder={Imag}
                      /> */}
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable">
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        Name
                        <span className="redlbl"> *</span>
                      </label>

                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.nameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.practiceModel.name}
                          name="name"
                          id="name"
                          max="60"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.nameValField}
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>
                        Organization Name <span className="redlbl"> *</span>
                      </label>

                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.organizationNameValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.practiceModel.organizationName}
                          name="organizationName"
                          id="organizationName"
                          max="100"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.organizationNameValField}
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        NPI <span className="redlbl"> *</span>
                      </label>
                      <div className="textBoxValidate">
                        <input
                          className={
                            this.state.validationModel.npiValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.practiceModel.npi}
                          name="npi"
                          id="npi"
                          maxLength="10"
                          onChange={() => this.handleChange}
                          onKeyPress={(event) => this.handleNumericCheck(event)}
                          onInput={this.onPaste}
                        />
                        {this.state.validationModel.npiValField}
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>Tax ID </label>
                      <div className="textBoxValidate">
                        <input
                          className={
                            this.state.validationModel.taxIDValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.practiceModel.taxID}
                          name="taxID"
                          id="taxID"
                          maxLength="9"
                          onChange={() => this.handleChange}
                          onKeyPress={(event) => this.handleNumericCheck(event)}
                          onInput={this.onPaste}
                        />
                        {this.state.validationModel.taxIDValField}
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6 ">
                      <label>Taxonomy Code</label>

                      <div className="selectBoxValidate addBoxCol">
                        {/* <div style={{ marginLeft: "34%" }}> */}
                        <Select
                          type="text"
                          value={this.state.taxonomyCode}
                          name="taxonomyCode"
                          id="taxonomyCode"
                          max="10"
                          onChange={(event) =>
                            this.handletaxonomyCodeChange(event)
                          }
                          options={this.props.taxonomyCode}
                          placeholder=""
                          isClearable={true}
                          isSearchable={true}
                          // menuPosition="static"
                          openMenuOnClick={false}
                          escapeClearsValue={true}
                          styles={{
                            icon: {
                              fill: "blue",
                            },
                            indicatorSeparator: () => { },
                            clearIndicator: (defaultStyles) => ({
                              ...defaultStyles,
                              color: "#286881",
                            }),
                            container: (defaultProps) => ({
                              ...defaultProps,
                              position: "absolute",
                              width: "26%",
                            }),
                            indicatorsContainer: (defaultStyles) => ({
                              ...defaultStyles,
                              padding: "0px",
                              marginBottom: "0",
                              marginTop: "0px",
                              height: "36px",
                              borderBottomRightRadius: "10px",
                              borderTopRightRadius: "10px",
                              // borderRadius:"0 6px 6px 0"
                            }),
                            indicatorContainer: (defaultStyles) => ({
                              ...defaultStyles,
                              padding: "9px",
                              marginBottom: "0",
                              marginTop: "1px",
                              // borderBottomRightRadius: "5px",
                              // borderTopRightRadius: "5px",
                              borderRadius: "0 4px 4px 0",
                            }),
                            dropdownIndicator: (defaultStyles) => ({
                              display: "none",
                            }),
                            input: (defaultStyles) => ({
                              ...defaultStyles,
                              margin: "0px",
                              padding: "0px",
                              // display:'none'
                            }),
                            singleValue: (defaultStyles) => ({
                              ...defaultStyles,
                              fontSize: "16px",
                              transition: "opacity 300ms",
                              // display:'none'
                            }),
                            control: (defaultStyles) => ({
                              ...defaultStyles,
                              minHeight: "33px",
                              height: "33px",
                              height: "33px",
                              paddingLeft: "10px",
                              //borderColor:"transparent",
                              borderColor: "#C6C6C6",
                              boxShadow: "none",
                              borderColor: "#C6C6C6",
                              "&:hover": {
                                borderColor: "#C6C6C6",
                              },
                              // display:'none'
                            }),
                          }}
                        />
                        <img
                          src={plusSrc}
                          onClick={() => this.openTaxonomyPopup(0)}
                        />
                        {/* </div> */}
                        {/* <img src={taxonomyIcon} /> */}
                        <div className="textBoxValidate">
                          {this.state.validationModel.taxonomyCodeValField}
                        </div>
                      </div>
                    </div>

                    <div className="mf-6 mf-icon">
                      <label>CLIA</label>

                      <div className="textBoxValidate">
                        <Input
                          className={
                            this.state.validationModel.cliaNumberValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.practiceModel.cliaNumber}
                          name="cliaNumber"
                          id="cliaNumber"
                          max="10"
                          onChange={() => this.handleChange}
                        />

                        {this.state.validationModel.cliaNumberValField}
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>
                        Client
                        <span className="redlbl"> *</span>
                      </label>

                      <select
                        className={
                          this.state.validationModel.clientValField
                            ? this.errorField
                            : ""
                        }
                        name="clientID"
                        id="clientID"
                        value={this.state.practiceModel.clientID}
                        disabled={this.props.practiceID > 0 ? true : false}
                        onChange={this.handleChange}
                      >
                        {this.state.client.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.description}
                          </option>
                        ))}
                      </select>
                      <div className="textBoxValidate">
                        {" "}
                        {this.state.validationModel.clientValField}
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>
                        Type
                        <span className="redlbl"> *</span>
                      </label>
                      <select
                        name="type"
                        id="type"
                        disabled={this.state.editId > 0 ? true : false}
                        value={this.state.practiceModel.type}
                        onChange={this.handleChangeType}
                      >
                        {type.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                      <div className="textBoxValidate">
                        {" "}
                        {this.state.validationModel.typeValField}
                      </div>
                    </div>
                  </div>

                  {typeValuefield}

                  <div className="mf-12 headingOne mt-25">
                    <p>Address Information</p>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Address 1</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.address1}
                        name="address1"
                        id="address1"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Address 2</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.address2}
                        name="address2"
                        id="address2"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>City - State</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.cityValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.practiceModel.city}
                            name="city"
                            id="city"
                            max="20"
                            onChange={() => this.handleChange}
                          />
                          {this.state.validationModel.cityValField}
                        </div>

                        <div className="twoColValidate">
                          <select
                            className={
                              this.state.validationModel.stateValField
                                ? this.errorField
                                : ""
                            }
                            name="state"
                            id="state"
                            value={this.state.practiceModel.state}
                            onChange={this.handleChange}
                          >
                            {usStates.map((s) => (
                              <option key={s.value} value={s.value}>
                                {s.display}
                              </option>
                            ))}
                          </select>
                          {this.state.validationModel.stateValField}
                        </div>
                      </div>
                    </div>

                    <div className="mf-6">
                      <label>Zip Code - Fax</label>

                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <Input
                            className={
                              this.state.validationModel.zipCodeValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.practiceModel.zipCode}
                            max="9"
                            name="zipCode"
                            id="zipCode"
                            onChange={() => this.handleZip}
                            onKeyPress={(event) =>
                              this.handleNumericCheck(event)
                            }
                          />
                          {this.state.validationModel.zipCodeValField}
                        </div>

                        <div className="twoColValidate">
                          <input
                            className={
                              this.state.validationModel.faxNumberValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.practiceModel.faxNumber}
                            maxLength="10"
                            name="faxNumber"
                            id="faxNumber"
                            onChange={() => this.handleChange}
                            onKeyPress={(event) =>
                              this.handleNumericCheck(event)
                            }
                            onInput={this.onPaste}
                          />
                          {this.state.validationModel.faxNumberValField}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>Office Phone #- Extension</label>
                      <div className="textBoxTwoField textBoxValidate">
                        <div className="twoColValidate">
                          <NumberFormat
                            format="00 (###) ###-####"
                            mask="_"
                            className={
                              this.state.validationModel.officePhoneNumValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.practiceModel.officePhoneNum}
                            max="10"
                            name="officePhoneNum"
                            id="officePhoneNum"
                            onChange={this.handleChange}
                            // onInput={this.onPaste}
                            onKeyPress={(event) =>
                              this.handleNumericCheck(event)
                            }
                          />
                          {this.state.validationModel.officePhoneNumValField}
                        </div>
                        <div className="twoColValidate">
                          <input
                            className={
                              this.state.validationModel.faxNumberValField
                                ? this.errorField
                                : ""
                            }
                            type="text"
                            value={this.state.practiceModel.phoneNumExt}
                            maxLength="4"
                            name="phoneNumExt"
                            id="phoneNumExt"
                            onChange={() => this.handleChange}
                            onKeyPress={(event) =>
                              this.handleNumericCheck(event)
                            }
                            onInput={this.onPaste}
                          />
                          {/* {this.state.validationModel.faxNumberValField} */}
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Cell #</label>
                      <NumberFormat
                        format="00 (###) ###-####"
                        mask="_"
                        type="text"
                        name="cellNumber"
                        id="cellNumber"
                        max="10"
                        value={this.state.practiceModel.cellNumber}
                        onChange={this.handleChange}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>Contact Person Name</label>

                      <div className="textBoxValidate">
                        <Input
                          type="text"
                          value={this.state.practiceModel.contactPersonName}
                          name="contactPersonName"
                          id="contactPersonName"
                          max="60"
                          onChange={() => this.handleChange}
                        />
                      </div>
                    </div>
                    <div className="mf-6">
                      <label>Website</label>
                      <div className="twoColValidate">
                        <Input
                          className={
                            this.state.validationModel.websiteValField
                              ? this.errorField
                              : ""
                          }
                          type="text"
                          value={this.state.practiceModel.website}
                          name="website"
                          id="website"
                          max="50"
                          onChange={() => this.handleChange}
                        />
                        {this.state.validationModel.websiteValField}
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-12 field_full-8">
                      <label> Email</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.email}
                        name="email"
                        id="email"
                        max="60"
                        onChange={() => this.handleChange}
                      />
                      <div className="textBoxValidate">
                        {this.state.validationModel.emailValField}
                      </div>
                    </div>
                  </div>
                  <div className="row-form headingOneChkBox mt-25">
                    <div className="mf-6">
                      <p>Pay to Address Information</p>
                    </div>
                    {/* AZIZ: 28/10/2019 - COMMETING 'SAME AS ADDRESS' FOR NOW - TECHNICALITY ISSUE */}
                    <div
                      className="mf-6 popupHeadingRight"
                      style={{ paddingRight: "120px" }}
                    >
                      <div className="lblChkBox">
                        <input
                          type="checkbox"
                          id="sameAsAddress"
                          name="sameAsAddress"
                          checked={this.state.isChecked}
                          onChange={this.handleSameAsAddress}
                        />
                        <label htmlFor="sameAsAddress">
                          <span> Same As Address </span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Address 1</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.payToAddress1}
                        name="payToAddress1"
                        id="payToAddress1"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Address 2</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.payToAddress2}
                        name="payToAddress2"
                        id="payToAddress2"
                        max="55"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>City - State</label>
                      <div className="textBoxTwoField">
                        <Input
                          type="text"
                          value={this.state.practiceModel.payToCity}
                          name="payToCity"
                          id="payToCity"
                          max="20"
                          onChange={() => this.handleChange}
                        />

                        <select
                          name="payToState"
                          id="payToState"
                          value={this.state.practiceModel.payToState}
                          onChange={this.handleChange}
                        >
                          {usStates.map((s) => (
                            <option key={s.value} value={s.value}>
                              {s.display}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="mf-6">
                      {/* <label>Zip Code -  Fax</label> */}
                      <label>Zip Code</label>
                      <div className="textBoxTwoField">
                        <Input
                          type="text"
                          className={
                            this.state.validationModel.payToZipCodeValField
                              ? this.errorField
                              : ""
                          }
                          value={this.state.practiceModel.payToZipCode}
                          max="9"
                          name="payToZipCode"
                          id="payToZipCode"
                          onChange={() => this.handleZip}
                          onKeyPress={(event) => this.handleNumericCheck(event)}
                        />

                        {this.state.validationModel.payToZipCodeValField}
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-12 field_full-8">
                      <label>Notes:</label>
                      <textarea
                        value={this.state.practiceModel.notes}
                        name="notes"
                        id="notes"
                        cols="30"
                        rows="10"
                        onChange={this.handleChange}
                      ></textarea>
                    </div>
                  </div>

                  {/* Patient STatement */}

                  <div className="row-form headingOneChkBox mt-25">
                    <div className="mf-6">
                      <p>Statement Options</p>
                    </div>
                    <div className="mf-6"></div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Vendor</label>
                      <select
                        name="statementExportType"
                        id="statementExportType"
                        value={this.state.practiceModel.statementExportType}
                        onChange={this.handleChange}
                      >
                        {statementExportType.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                      {/* {this.state.validationModel.vendorValField} */}
                    </div>
                    <div className="mf-6">
                      <label>Aging Days</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.statementAgingDays}
                        name="statementAgingDays"
                        id="statementAgingDays"
                        // max="55"
                        onChange={() => this.handleChange}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>Maximum Statement</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.statementMaxCount}
                        name="statementMaxCount"
                        id="statementMaxCount"
                        // max="55"
                        onChange={() => this.handleChange}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Phone #</label>
                      <NumberFormat
                        format="00 (###) ###-####"
                        mask="_"
                        type="text"
                        name="statementPhoneNumber"
                        id="statementPhoneNumber"
                        max="10"
                        value={this.state.practiceModel.statementPhoneNumber}
                        onChange={this.handleChange}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <label>Fax #</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.statementFaxNumber}
                        name="statementFaxNumber"
                        id="statementFaxNumber"
                        max="10"
                        onChange={() => this.handleChange}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      />
                    </div>
                    <div className="mf-6">
                      <label>Appointment Phone #</label>
                      <NumberFormat
                        format="00 (###) ###-####"
                        mask="_"
                        type="text"
                        name="appointmentPhoneNumber"
                        id="appointmentPhoneNumber"
                        max="10"
                        value={this.state.practiceModel.appointmentPhoneNumber}
                        onChange={this.handleChange}
                        onKeyPress={(event) => this.handleNumericCheck(event)}
                      />
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-12 field_full-8">
                      <label>Message</label>
                      <textarea
                        value={this.state.practiceModel.statementMessage}
                        name="statementMessage"
                        id="statementMessage"
                        cols="30"
                        rows="10"
                        onChange={this.handleChange}
                      ></textarea>
                    </div>
                  </div>

                  {/* Invoice Information  */}

                  {invoiceInfo}

                  {/* Others  */}

                  <div className="row-form headingOneChkBox mt-25">
                    <div className="mf-6">
                      <p>Others</p>
                    </div>
                    <div className="mf-6"></div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>Client Category</label>
                      <select
                        name="clientCategory"
                        id="clientCategory"
                        value={this.state.practiceModel.clientCategory}
                        onChange={this.handleChange}
                      >
                        {clientCategory.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.display}
                          </option>
                        ))}
                      </select>
                      {/* {this.state.validationModel.vendorValField} */}
                    </div>
                    <div className="mf-6">
                      <label>Referred By</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.refferedBy}
                        name="refferedBy"
                        id="refferedBy"
                        max="50"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <label>PM Software Name</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.pmSoftwareName}
                        name="pmSoftwareName"
                        id="pmSoftwareName"
                        max="50"
                        onChange={() => this.handleChange}
                      />
                    </div>
                    <div className="mf-6">
                      <label>EHR Software Name</label>
                      <Input
                        type="text"
                        value={this.state.practiceModel.ehrSoftwareName}
                        name="ehrSoftwareName"
                        id="ehrSoftwareName"
                        max="50"
                        onChange={() => this.handleChange}
                      />
                    </div>
                  </div>

                  {/* Billing Responsiblities */}
                  {/* 
                  <div className="row-form headingOneChkBox mt-25">
                    <div className="mf-6">
                      <p>Billing Responsiblities</p>
                    </div>
                    <div className="mf-6"></div>
                  </div>
                  <div className="row-form" style={{ marginLeft: "12%", fontWeight: "bold", fontSize: "large" }}>
                    <div className="mf-6">
                      <p>BellMedex</p>
                    </div>
                    <div className="mf-6">
                      <p>Client</p>
                    </div>
                  </div>
                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Appointment Scheduling </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Appointment Scheduling </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Benefit Verification </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Benefit Verification </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Prior Authorization </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Prior Authorization </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Coding </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Coding </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Charge Entry </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Charge Entry </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Payment Posting </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Payment Posting </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> AR - Follwup </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> AR - Follwup </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Patient Statement </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> Patient Statement </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row-form">
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> OLD AR - Follwup </span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="mf-6">
                      <div
                        className="mf-6 popupHeadingRight"
                        style={{ paddingRight: "163px" }}
                      >
                        <div className="lblChkBox">
                          <input
                            type="checkbox"
                            id="includePatientCollection"
                            name="includePatientCollection"
                            checked={this.state.practiceModel.includePatientCollection}
                            onChange={this.includePatientCollection}
                          />
                          <label htmlFor="includePatientCollection">
                            <span> OLD AR - Follwup </span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div> */}
                </div>

                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <Hotkeys
                          keyName="alt+s"
                          onKeyDown={this.onKeyDown.bind(this)}
                          onKeyUp={this.onKeyUp.bind(this)}
                        >
                          <input
                            type="button"
                            value="Save"
                            className="btn-blue"
                            onClick={this.savePractice}
                            disabled={this.isDisabled(
                              this.state.editId > 0
                                ? this.props.rights.update
                                : this.props.rights.add
                            )}
                          ></input>
                        </Hotkeys>

                        <input
                          type="button"
                          value="Cancel"
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        ></input>
                        {/* 
                        <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={
                            this.props.onClose
                              ? this.props.onClose()
                              : () => this.props.onClose()
                          }
                        >
                          Cancel
                        </button> */}
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <Tabs headers={headers}>
                    <Tab>
                      <div className="mf-12 mt-15 ">
                        <div className="tableGridContainer mb-15">
                          <MDBDataTable
                            responsive={true}
                            striped
                            searching={false}
                            data={locationData}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                          />
                        </div>
                      </div>
                    </Tab>
                    <Tab>
                      <div className="mf-12 mt-15 ">
                        <div className="tableGridContainer mb-15">
                          <MDBDataTable
                            responsive={true}
                            striped
                            searching={false}
                            data={providerData}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                          />
                        </div>
                      </div>
                    </Tab>
                    <Tab>
                      <div className="mf-12 mt-15 ">
                        <div className="tableGridContainer mb-15 text-nowrap">
                          <MDBDataTable
                            responsive={true}
                            striped
                            searching={false}
                            data={RefProviderData}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                          />
                        </div>
                      </div>
                    </Tab>
                  </Tabs>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    // id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo1: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.practiceSearch,
        add: state.loginInfo.rights.practiceCreate,
        update: state.loginInfo.rights.practiceEdit,
        delete: state.loginInfo.rights.practiceDelete,
        export: state.loginInfo.rights.practiceExport,
        import: state.loginInfo.rights.practiceImport,
      }
      : [],
    taxonomyCode:
      state.loginInfo.taxonomy == null ? [] : state.loginInfo.taxonomy,
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
      taxonomyCodeAction: taxonomyCodeAction,
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(NewPractice);
