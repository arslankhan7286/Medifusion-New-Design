import React, { Component } from "react";
import Label from "./Label";
import Input from "./Input";
import axios from "axios";
import { MDBDataTable, MDBBtn } from "mdbreact";
import GridHeading from "./GridHeading";
import searchIcon from "../images/search-icon.png";
import refreshIcon from "../images/refresh-icon.png";
import newBtnIcon from "../images/new-page-icon.png";
import settingsIcon from "../images/setting-icon.png";
import NewInsurance from "./NewInsurance.js";
import SearchHeading from "./SearchHeading";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";

import $ from "jquery";
import { isNull } from "util";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

class Insurance extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/Insurance/";
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      name: "",
      organizationName: "",
      address: "",
      phoneNumber: "",
      website: "" //10
    };
    this.state = {
      searchModel: this.searchModel,
      id: 0,
      data: [],
      showPopup: false,
      loading: false
    };

    this.searchInsurance = this.searchInsurance.bind(this);

    this.clearFields = this.clearFields.bind(this);

    this.closeInsurancePopup = this.closeInsurancePopup.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.openInsurancePopup = this.openInsurancePopup.bind(this);
  }

  searchInsurance = e => {
    this.setState({ loading: true });
    e.preventDefault();
    axios
      .post(this.url + "FindInsurances", this.state.searchModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            name: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() => this.openInsurancePopup(row.id)}
              >
                {row.name}
              </MDBBtn>
            ),
            organizationName: row.organizationName,
            address: row.address,
            officePhoneNum: row.officePhoneNum,
            email: row.email == null ? "" : row.email,
            website: row.website
          });
        });

        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false });
      });

    e.preventDefault();
  };

  openInsurancePopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  closeInsurancePopup = () => {
    $("#myModal").hide();
    this.setState({ showPopup: false });
  };

  handleChange = event => {
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    this.setState({
      searchModel: { [event.target.name]: event.target.value.toUpperCase() }
    });
  };
  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };
  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "DESCRIPTION",
          field: "organizationName",
          sort: "asc",
          width: 150
        },
        {
          label: "ADDRESS",
          field: "address",
          sort: "asc",
          width: 150
        },
        {
          label: "PHONE NUMBER",
          field: "officePhoneNum",
          sort: "asc",
          width: 150
        },
        {
          label: "EMAIL",
          field: "email",
          sort: "asc",
          width: 150
        },
        {
          label: "WEBSITE",
          field: "website",
          sort: "asc",
          width: 150
        }
      ],
      rows: this.state.data
    };

    let popup = "";

    if (this.state.showPopup) {
      popup = (
        <NewInsurance
          onClose={() => this.closeInsurancePopup}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewInsurance>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <SearchHeading
          heading="INSURANCE SEARCH"
          handler={() => this.openInsurancePopup(0)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></SearchHeading>

        <form onSubmit={event => this.searchInsurance(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Name"></Label>
                <Input
                  type="text"
                  name="name"
                  id="name"
                  value={this.state.searchModel.name}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Description "></Label>
                <Input
                  type="text"
                  name="organizationName"
                  id="organizationName"
                  value={this.state.searchModel.organizationName}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>
            <div className="row-form">
              <div className="mf-6">
                <Label name="Address"></Label>
                <Input
                  type="text"
                  name="address"
                  id="address"
                  value={this.state.searchModel.address}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Phone #"></Label>
                <Input
                  type="text"
                  name="phoneNumber"
                  id="phoneNumber"
                  max="10"
                  onKeyPress={event => this.handleNumericCheck(event)}
                  value={this.state.searchModel.phoneNumber}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-grey"
                  value="Clear"
                  onClick={() => this.clearFields()}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="INSURANCE SEARCH RESULT"
            disabled={this.isDisabled(this.props.rights.export)}
            dataObj={this.state.searchModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
          search: state.loginInfo.rights.insuranceSearch,
          add: state.loginInfo.rights.insuranceCreate,
          update: state.loginInfo.rights.insuranceEdit,
          delete: state.loginInfo.rights.insuranceDelete,
          export: state.loginInfo.rights.insuranceExport,
          import: state.loginInfo.rights.insuranceImport
        }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(Insurance);
