import React, { Component } from "react";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import GPopup from "./GPopup";

import NewInsuranceMapping from "../components/NewInsuranceMapping";
import { MDBDataTable, MDBBtn } from "mdbreact";
import GridHeading from "./GridHeading";

import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Input from "./Input";
import axios from "axios";
import $ from "jquery";

import NewInsurancePlan from "./NewInsurancePlan";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { isNull } from "util";

class InsuranceMapping extends Component {
  constructor(props) {
    super(props);

    this.ExInsuranceMapping =
      process.env.REACT_APP_URL + "/ExInsuranceMapping/"; // Method : FindExInsuranceMapping
    this.insurancePlanUrl = process.env.REACT_APP_URL + "/insurancePlan/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      externalInsuranceName: "",
      insurancePlanID: ""
    };

    this.state = {
      searchModel: this.searchModel,
      popupName: "",
      showPopup: false,
      data: [],
      loading: false,
      table: [],
      Columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "EXTERNAL INSURANCE NAME",
          field: "externalInsuranceName",
          sort: "asc",
          width: 100
        },
        {
          label: "MEDIFUSION INSURANCE NAME",
          field: "planName",
          sort: "asc",
          width: 150
        }
      ]
    };

    this.openPopUp = this.openPopUp.bind(this);
    this.openNewInsuranceMappingPopUp = this.openNewInsuranceMappingPopUp.bind(this);
    this.closeNewInsuranceMappingPopUp = this.closeNewInsuranceMappingPopUp.bind(this);
    this.closePopup = this.closePopup.bind(this);
    this.searchInsuranceMappings = this.searchInsuranceMappings.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  componentWillMount() {
    this.setState({
      table: {
        columns: this.state.Columns,
        rows: this.state.data
      }
    });
  }

  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  ///////////////------------OPEN/CLOSE POP UPs

  openNewInsuranceMappingPopUp(id) {
    this.setState({ showPopup: true, id: id });
    console.log(id);
  }

  closeNewInsuranceMappingPopUp = () => {
    $("#insuranceMapping").hide();
    this.setState({ showPopup: false });
  };

  openPopUp = (name, id) => {
    console.log(id);
    if (name == "insurancePlan") {
      axios
        .get(this.insurancePlanUrl + "findInsurancePlan/" + id, this.config)
        .then(response => {
          console.log("Insurance Plan Response : ", response.data);
          this.setState({
            id: id,
            popupName: "insurancePlan"
          });
        })
        .catch(error => {
          console.log(error);
        });
    } else this.setState({ popupName: name, id: id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  ///////////////------------CHANGE HANDLERS

  handleChange = event => {
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]:
          event.target.value == "Please Select"
            ? null
            : event.target.value.toUpperCase()
      }
    });
    console.log(this.state.searchModel);
  };

  ///////////////------------SEARCH PATIENT DATA

  async searchInsuranceMappings(e) {
    e.preventDefault();
    this.setState({ loading: true });
    console.log("Search model", this.state.searchModel);
    await axios
      .post(
        this.ExInsuranceMapping + "FindExInsuranceMapping",
        this.state.searchModel,
        this.config
      )
      .then(response => {
        let newList = [];

        console.log("Insurance data received Response", response);
        response.data.map((row, i) => {
          console.log("Insurance data received ROW", row);

          newList.push({
            id: row.id,
            externalInsuranceName: row.externalInsuranceName,
            planName: (
              <MDBBtn
                className="gridBlueBtn"
                onClick={() =>
                  this.openPopUp("insurancePlan", row.insurancePlanID)
                }
              >
                {row.planName}
              </MDBBtn>
            )
          });
        });

        console.log("NewList", newList);

        this.setState({
          data: newList,
          loading: false,
          table: {
            columns: this.state.Columns,
            rows: newList
          }
        });
      })
      .catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });
  }

  render() {
    ///////////////------------POP UP SELECTION

    let popup = "";
    if (this.state.showPopup) {
      console.log("add new button", this.state.showPopup);
      popup = (
        <NewInsuranceMapping
          onClose={() => this.closeNewInsuranceMappingPopUp}
          id={this.state.id}
          disabled={this.isDisabled(this.props.rights.update)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></NewInsuranceMapping>
      );
    } else if (this.state.popupName === "insurancePlan") {
      console.log("POPUP", this.state.popupName);
      popup = (
        <NewInsurancePlan
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewInsurancePlan>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    ///////////////------------LOADING SPINER

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        {popup}
        <SearchHeading
          heading="INSURANCE MAPPING"
          handler={() => this.openNewInsuranceMappingPopUp(0)}
          disabled={this.isDisabled(this.props.rights.add)}
        ></SearchHeading>

        <form onSubmit={this.searchInsuranceMappings}>
          <div className="mainTable wSpace">
            <div className="row-form">
              <div className="mf-6">
                <Label name="External Insurance Name"></Label>
                <Input
                  type="text"
                  name="externalInsuranceName"
                  id="externalInsuranceName"
                  max="100"
                  value={this.state.searchModel.externalInsuranceName}
                  onChange={() => this.handleChange}
                />
              </div>

              <div className="mf-6">
                <Label name="Medifusion Insurance Name"></Label>
                <Input
                  type="text"
                  name="planName"
                  id="planName"
                  max="100"
                  value={this.state.searchModel.planName}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="name"
                  id="name"
                  className="btn-blue"
                  value="Search"
                  disabled={this.isDisabled(this.props.rights.search)}
                />
                <Input
                  type="button"
                  name="name"
                  id="name"
                  className="btn-grey"
                  value="Clear"
                  onClick={() => this.clearFields()}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          <GridHeading
            Heading="INSURANCE MAPPING SEARCH RESULT"
            disabled={this.isDisabled(this.props.rights.export)}
            dataObj={this.state.searchModel}
            url={this.AddPatientSheet}
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer text-nowrap">
            <MDBDataTable
              responsive={true}
              striped
              bordered
              searching={false}
              data={this.state.table}
              displayEntries={false}
              sortable={true}
              scrollX={false}
              scrollY={false}
            />
          </div>
        </div>
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  console.log("state from Header Page", state);
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.clientSearch,
        add: state.loginInfo.rights.clientCreate,
        update: state.loginInfo.rights.clientEdit,
        delete: state.loginInfo.rights.clientDelete,
        export: state.loginInfo.rights.clientExport,
        import: state.loginInfo.rights.clientImport
      }
      : []
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, matchDispatchToProps)(InsuranceMapping);
