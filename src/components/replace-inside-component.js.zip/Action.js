import React, { Component } from "react";

import NewAction from "./NewAction";

import Label from "./Label";
import Input from "./Input";

import settingIcon from "../images/setting-icon.png";

import SearchHeading from "./SearchHeading";
import { MDBDataTable, MDBBtn } from "mdbreact";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import GridHeading from "./GridHeading";

import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";

import $ from "jquery";
import axios from "axios";

class Action extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/Action/";
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*"
      }
    };

    this.searchModel = {
      name: "",
      description: "",
      user: ""
    };

    this.state = {
      searchModel: this.searchModel,
      data: [],
      usersData: [],
      id: 0,
      showPopup: false,
      loading: false,
      isActive: true
    };
    this.handleChange = this.handleChange.bind(this);
    this.searchAction = this.searchAction.bind(this);
    this.openActionPopup = this.openActionPopup.bind(this);
    this.closeActionPopup = this.closeActionPopup.bind(this);
  }

  openActionPopup = id => {
    this.setState({ showPopup: true, id: id });
  };

  closeActionPopup() {
    $("#actionModal").hide();
    this.setState({ showPopup: false });
  }

  searchAction = e => {
    e.preventDefault();

    this.setState({ loading: true });
    axios
      .post(this.url + "FindActions", this.state.searchModel, this.config)
      .then(response => {
        let newList = [];
        response.data.map((row, i) => {
          newList.push({
            id: row.id,
            name: (
              <MDBBtn
                className="gridBlueBtn"
                size="sm"
                onClick={() => this.openActionPopup(row.id)}
              >
                {row.name}
              </MDBBtn>
            ),
            description: row.description,
            user: row.user
          });
        });

        this.setState({ data: newList, loading: false });
      })
      .catch(error => {
        this.setState({ loading: false });
      });
  };

  clearFields = event => {
    this.setState({
      searchModel: this.searchModel
    });
  };

  handleChange = event => {
    //Carret Position
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });
    event.preventDefault();
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase()
      }
    });
  };

  componentWillMount() {
    axios
      .get(this.url + "GetProfiles", this.config)
      .then(response => {
        this.setState({
          usersData: response.data.users
        });
      })
      .catch(error => {});
  }

  render() {
    const data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150
        },
        {
          label: "NAME",
          field: "name",
          sort: "asc",
          width: 150
        },
        {
          label: "DESCRIPTION",
          field: "description",
          sort: "asc",
          width: 270
        },
        {
          label: "USER",
          field: "user",
          sort: "asc",
          width: 270
        }
      ],
      rows: this.state.data
    };

    let popup = "";

    if (this.state.showPopup) {
      popup = (
        <NewAction
          onClose={() => this.closeActionPopup}
          id={this.state.id}
        ></NewAction>
      );
    } else popup = <React.Fragment></React.Fragment>;

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <GifLoader
          loading={true}
          imageSrc={Eclips}
          // imageStyle={imageStyle}
          overlayBackground="rgba(0,0,0,0.5)"
        />
      );
    }

    return (
      <React.Fragment>
        {spiner}

        <SearchHeading
          heading="ACTION SEARCH"
          handler={() => this.openActionPopup(0)}
        ></SearchHeading>

        <form onSubmit={event => this.searchAction(event)}>
          <div className="mainTable">
            <div className="row-form">
              <div className="mf-6">
                <Label name="Name"></Label>

                <Input
                  type="text"
                  name="name"
                  id="name"
                  max="50"
                  value={this.state.searchModel.name}
                  onChange={() => this.handleChange}
                />
              </div>
              <div className="mf-6">
                <Label name="Description"></Label>
                <Input
                  max="100"
                  type="text"
                  name="description"
                  id="description"
                  value={this.state.searchModel.description}
                  onChange={() => this.handleChange}
                />
              </div>
            </div>

            <div className="row-form">
              <div className="mf-6">
                <label>User ID</label>

                <div className="selectBoxValidate">
                  <select
                    name="user"
                    id="user"
                    value={this.state.searchModel.user}
                    onChange={this.handleChange}
                  >
                    {this.state.usersData.map(s => (
                      <option key={s.id} value={s.description3}>
                        {s.description2}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mf-6"></div>
            </div>

            <div className="row-form row-btn">
              <div className="mf-12">
                <Input
                  type="submit"
                  name="search"
                  id="search"
                  className="btn-blue"
                  value="Search"
                />
                <Input
                  type="button"
                  name="clear"
                  id="clear"
                  className="btn-grey"
                  value="Clear"
                  onClick={event => this.clearFields(event)}
                />
              </div>
            </div>
          </div>
        </form>

        <div className="mf-12 table-grid mt-15">
          {/* <div className="row headingTable">
                        <div className="mf-6">
                            <h1>ACTION SEARCH RESULT</h1>
                        </div>
                        <div className="mf-6 headingRightTable">
                            <a href="javascript:;">
                                <img src={settingIcon} alt="" />
                            </a>
                        </div>
                    </div> */}
          <GridHeading
            Heading="ACTION SEARCH RESULT"
            dataObj={this.state.searchModel}
            url={this.url}
            methodName="Export"
            methodNamePdf="ExportPdf"
            length={this.state.data.length}
          ></GridHeading>

          <div className="tableGridContainer">
            <MDBDataTable
              striped
              bordered
              searching={false}
              data={data}
              displayEntries={false}
              sortable={true}
              scrollX={false}
            />
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    //id: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null }
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction
    },
    dispatch
  );
}

export default connect(mapStateToProps, null)(Action);
