import React, { Component } from "react";

import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Button from "./Input";
import Input from "./Input";
import SearchInput2 from "./SearchInput2";

import axios from "axios";
import {
    MDBDataTable,
    MDBBtn,
    MDBTableHead,
    MDBTableBody,
    MDBTable,
} from "mdbreact";

import GridHeading from "./GridHeading";

import $ from "jquery";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { NewInsurancePlan } from "./NewInsurancePlan";
import NewInsurancePortal from "./NewInsurancePortal";

class InsurancePoral extends Component {
    constructor(props) {
        super(props);

        this.url = process.env.REACT_APP_URL + "/Portal/";
        //Authorization Token
        this.config = {
            headers: {
                Authorization: "Bearer  " + this.props.loginObject.token,
                Accept: "*/*",
            },
        };

        this.searchModel = {
            portalType: "",
            name: "",
        };

        this.state = {
            searchModel: this.searchModel,
            id: 0,
            data: [],
            showPopup: false,
            showInsurancePopup: false,
            loading: false,
        };

        this.searchInsurancePortal = this.searchInsurancePortal.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.openInsurancePortal = this.openInsurancePortal.bind(this);
        this.closeInsurancePortal = this.closeInsurancePortal.bind(this);
    }

    searchInsurancePortal = (e) => {
        this.setState({ loading: true });
        console.log(this.state.searchModel);
        axios
            .post(this.url + "FindOnlinePortal", this.state.searchModel, this.config)
            .then((response) => {
                console.log(response);

                let newList = [];
                response.data.map((row, i) => {
                    newList.push({
                        id: row.id,
                        name: (
                            <span>
                                <MDBBtn
                                    className="gridBlueBtn"
                                    onClick={() => this.openInsurancePortal(row.id)}
                                >
                                    {row.name}
                                </MDBBtn>
                            </span>
                        ),
                        portalType: row.portalType,
                        url: row.url,
                        insurancePlan: row.insurancePlan,
                        username: row.username,
                        password: row.password,
                    });
                });

                this.setState({ data: newList, loading: false });
            })
            .catch((error) => {
                this.setState({ loading: false });

                console.log(error);
            });

        e.preventDefault();
    };

    handleChange = (event) => {
        var Evalue = "";
        event.preventDefault();
        if (event.target.name == "name") {
            Evalue = event.target.value.toUpperCase();
        } else {
            Evalue = event.target.value;
        }
        this.setState({
            searchModel: {
                ...this.state.searchModel,
                [event.target.name]: Evalue,
            },
        });
    };

    clearFields = (event) => {
        this.setState({
            searchModel: this.searchModel,
        });
    };

    openInsurancePortal = (id) => {
        this.setState({ showPopup: true, id: id });
    };

    closeInsurancePortal = () => {
        $("#myModal1").hide();
        this.setState({ showPopup: false });
    };

    handleNumericCheck(event) {
        if (event.charCode >= 48 && event.charCode <= 57) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }
    isDisabled(value) {
        if (value == null || value == false) return "disabled";
    }

    render() {
        const data = {
            columns: [
                {
                    label: "ID",
                    field: "id",
                    sort: "asc",
                    width: 150,
                },

                {
                    label: "NAME",
                    field: "name",
                    sort: "asc",
                    width: 270,
                },
                {
                    label: "PORTAL TYPE",
                    field: "portalType",
                    sort: "asc",
                    width: 150,
                },
                {
                    label: "URL",
                    field: "url",
                    sort: "asc",
                    width: 200,
                },
                {
                    label: "INSURANCE PLAN",
                    field: "insurancePlan",
                    sort: "asc",
                    width: 100,
                },
                {
                    label: "USER NAME",
                    field: "username",
                    sort: "asc",
                    width: 100,
                },
                {
                    label: "PASSWORD",
                    field: "password",
                    sort: "asc",
                    width: 100,
                },

            ],
            rows: this.state.data,
        };

        const portalType = [
            { value: "", display: "Select Type" },
            { value: "Insurance", display: "Insurance" },
            { value: "Other", display: "Other" },
        ];

        let popup = "";

        if (this.state.showPopup) {
            popup = (
                <NewInsurancePortal
                    onClose={() => this.closeInsurancePortal}
                    id={this.state.id}
                ></NewInsurancePortal>
            );
        } else popup = <React.Fragment></React.Fragment>;

        let spiner = "";
        if (this.state.loading == true) {
            spiner = (
                <GifLoader
                    loading={true}
                    imageSrc={Eclips}
                    // imageStyle={imageStyle}
                    overlayBackground="rgba(0,0,0,0.5)"
                />
            );
        }

        return (
            <React.Fragment>
                {spiner}
                <SearchHeading
                    heading="INSURANCE PORTAL SEARCH"
                    handler={() => this.openInsurancePortal(0)}
                    disabled={this.isDisabled(this.props.rights.add)}
                ></SearchHeading>

                <form onSubmit={(event) => this.searchInsurancePortal(event)}>
                    <div className="mainTable">
                        <div className="row-form">
                            <div className="mf-6">
                                <label>Portal Type</label>
                                <select
                                    name="portalType"
                                    id="portalType"
                                    value={this.state.searchModel.portalType}
                                    onChange={this.handleChange}
                                >
                                    {portalType.map((s) => (
                                        <option key={s.value} value={s.value}>
                                            {s.display}
                                        </option>
                                    ))}
                                </select>
                                {/* {this.state.validationModel.vendorValField} */}
                            </div>

                            <div className="mf-6">
                                <Label name="Name"></Label>
                                <Input
                                    type="text"
                                    name="name"
                                    id="name"
                                    max="200"
                                    value={this.state.searchModel.name}
                                    onChange={() => this.handleChange}
                                />
                            </div>
                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">
                                <Input
                                    type="submit"
                                    name="name"
                                    id="name"
                                    className="btn-blue"
                                    value="Search"
                                    disabled={this.isDisabled(this.props.rights.search)}
                                />
                                <Input
                                    type="button"
                                    name="name"
                                    id="name"
                                    className="btn-grey"
                                    value="Clear"
                                    onClick={() => this.clearFields()}
                                />
                            </div>
                        </div>
                    </div>
                </form>

                <div className="mf-12 table-grid mt-15">
                    <GridHeading
                        Heading="INSURANCE PORTAL SEARCH RESULT"
                        disabled={this.isDisabled(this.props.rights.export)}
                        dataObj={this.state.searchModel}
                        url={this.url}
                        methodName="Export"
                        methodNamePdf="ExportPdf"
                        length={this.state.data.length}
                    ></GridHeading>

                    <div className="tableGridContainer text-nowrap">
                        <MDBDataTable
                            responsive={true}
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                            scrollY={false}
                        />
                    </div>
                </div>

                {popup}
            </React.Fragment>
        );
    }
}

function mapStateToProps(state) {
    console.log("state from Header Page", state);
    return {
        selectedTab:
            state.selectedTab !== null ? state.selectedTab.selectedTab : "",
        selectedTabPage: state.selectedTabPage,
        selectedPopup: state.selectedPopup,
        id: state.selectedTab !== null ? state.selectedTab.id : 0,
        setupLeftMenu: state.leftNavigationMenus,
        loginObject: state.loginToken
            ? state.loginToken
            : { toekn: "", isLogin: false },
        userInfo: state.loginInfo
            ? state.loginInfo
            : { userPractices: [], name: "", practiceID: null },
        rights: state.loginInfo
            ? {
                search: state.loginInfo.rights.insurancePlanSearch,
                add: state.loginInfo.rights.insurancePlanCreate,
                update: state.loginInfo.rights.insurancePlanEdit,
                delete: state.loginInfo.rights.insurancePlanDelete,
                export: state.loginInfo.rights.insurancePlanExport,
                import: state.loginInfo.rights.insurancePlanImport,
                newIns: state.loginInfo.rights.insuranceEdit,
            }
            : [],
    };
}
function matchDispatchToProps(dispatch) {
    return bindActionCreators(
        {
            selectTabPageAction: selectTabPageAction,
            loginAction: loginAction,
            selectTabAction: selectTabAction,
        },
        dispatch
    );
}

export default connect(mapStateToProps, matchDispatchToProps)(InsurancePoral);
