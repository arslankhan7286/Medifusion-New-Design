import React, { Component } from "react";

import $ from "jquery";

import { MDBDataTable, MDBBtn } from "mdbreact";

import Label from "./Label";
import Input from "./Input";

import axios from "axios";

import Swal from "sweetalert2";
import { Tabs, Tab } from "react-tab-view";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import Dropdown from "react-dropdown";
import settingsIcon from "../images/setting-icon.png";
import NewHistoryPractice from "./NewHistoryPractice";
//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import GPopup from "./GPopup";
import EditCharge from "./EditCharge";

import { isNullOrUndefined } from "util";
import NewInsurancePlan from "./NewInsurancePlan";

export class NewPatientPlanModel extends Component {
  constructor(props) {
    super(props);
    this.url = process.env.REACT_APP_URL + "/PatientFollowup/";
    this.Notesurl = process.env.REACT_APP_URL + "/Notes/";

    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*",
      },
    };

    this.patientPlanModel = {
      visitID: "",
      reasonID: "",
      actionID: "",
      groupID: "",
      practiceID: "",
      locationID: "",
      providerID: "",
      referingProviderID: "",
      insurancePlanID: "",
      patientID: "",

      followUpDate: "",
      folowupAge: "",
      tickleDate: "",
      statement1SentDate: "",
      statement2SentDate: "",
      status: "",
      addedBy: "",

      updatedBy: "",
      gPatientFollowupCharge: [],
      note: [],
    };

    //Charge Model
    this.chargeModel = {
      iD: "",
      patientFollowUpID: "",
      patientID: "",
      visitID: "",
      chargeID: "",
      plan: "",
      dOS: "",
      cPT: "",
      billedAmount: "",
      paidAmount: "",
      allowedAmount: "",
      copay: "",
      deductible: "",
      coInsurance: "",
      patientPaid: "",
      patientAmount: "",
      AddedBy: "",
      AddedDate: "",
      clientID: this.props.userInfo.clientID,
      validation: false,
    };

    //Notes Model
    this.notesModel = {
      id: 0,
      practiceID: null,
      patientFollowUpID: null,
      notesDate: null,
      note: null,
      addedBy: null,
      addedDate: null,
      updatedBy: null,
      updatedDate: null,
      noteValField: "",
      validation: false,
    };

    this.patientModal = {
      patientID: "",
      patientName: "",
      accountNumber: "",
      dob: "",
      practiceID: "",

      practiceName: "",
      locationID: "",
      locationName: "",
      providerID: "",
      providerName: "",
      refProviderID: "",
      refProviderName: "",
      supProviderID: "",
      supProviderName: "",

      reasonID: "",
      reason: "",
      actionID: "",
      action: "",
      groupID: "",
      group: "",

      planName: "",
      subscriberName: "",
      subscriberID: "",
    };

    this.state = {
      note: this.note,
      patientPlanModel: this.patientPlanModel,
      patientModal: this.patientModal,
      editId: this.props.id,
      data: [],
      id: 0,
      note: [],
      resData: [],
      remCodeData: [],
      groupData: [],
      actionData: [],
      adjData: [],
      locData: [],
      proData: [],
      refproData: [],
      supproData: [],
      practionData: [],

      submissionData: "",

      chargePopup: false,
      visitPopup: false,
      popupName: "",
      isActive: true,
      showPopup: false,
    };
    this.setModalMaxHeight = this.setModalMaxHeight.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.addRowNotes = this.addRowNotes.bind(this);
    this.handleNoteChange = this.handleNoteChange.bind(this);
    this.deleteRowNotes = this.deleteRowNotes.bind(this);
    this.openVisitPopup = this.openVisitPopup.bind(this);
    this.closeVisitPopUp = this.closeVisitPopUp.bind(this);
    this.openChargePopup = this.openChargePopup.bind(this);
    this.closeChargePopup = this.closeChargePopup.bind(this);
    this.openPopup = this.openPopup.bind(this);
    this.closePopup = this.closePopup.bind(this);
    this.val = this.val.bind(this);
  }
  setModalMaxHeight(element) {
    this.$element = $(element);
    this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
    var dialogMargin = $(window).width() < 768 ? 20 : 60;
    var contentHeight = $(window).height() - (dialogMargin + borderWidth);
    var headerHeight = this.$element.find(".modal-header").outerHeight() || 0;
    var footerHeight = this.$element.find(".modal-footer").outerHeight() || 0;
    var maxHeight = contentHeight - (headerHeight + footerHeight);

    this.setState({ maxHeight: maxHeight });
  }

  openPopup = (name, id) => {
    this.setState({ popupName: name, id: id });
  };

  closePopup = () => {
    $("#myModal").hide();
    this.setState({ popupName: "" });
  };

  openVisitPopup(name, id) {
    this.setState({ popupName: name, visitPopup: true, id: id });
  }

  //Close Visit Popup
  closeVisitPopUp() {
    this.setState({ popupName: "", visitPopup: false });
  }

  openChargePopup(name, id) {
    this.setState({ popupName: name, chargePopup: true, id: id });
  }

  //Close Charge Popup
  closeChargePopup() {
    this.setState({ popupName: "", chargePopup: false });
  }

  val(value) {
    if (isNullOrUndefined(value)) return " ";
    else return value;
  }

  async componentWillMount() {
    await this.setState({ loading: true });

    try {
      await axios
        .get(this.url + "GetProfiles", this.config)
        .then((response) => {
          this.setState({
            resData: response.data.reason,
            groupData: response.data.group,
            actionData: response.data.action,
          });
        })
        .catch((error) => { });

      await axios
        .get(this.url + "FindPatientInfo/" + this.props.id, this.config)

        .then((response) => {
          let newList = [];
          response.data.map((row, i) => {
            newList.push({
              id: row.id,

              patientID: row.patientID,
              patientName: row.patientName,
              accountNumber: row.accountNumber,
              dob: row.dob,
              practiceID: row.practiceID,

              practiceName: row.practiceName,
              locationID: row.locationID,
              locationName: row.locationName,
              providerID: row.providerID,
              providerName: row.providerName,
              refProviderID: row.refProviderID,
              refProviderName: row.refProviderName,
              supProviderID: row.supProviderID,
              supProviderName: row.supProviderName,

              groupID: row.groupID,
              group: row.group,
              actionID: row.actionID,
              action: row.action,
              reasonID: row.reasonID,
              reason: row.reason,

              planName: row.planName,
              insuredName: row.insuredName,
              insuredID: row.insuredID,
            });
          });

          this.setState({ data: newList });
        })
        .catch((error) => { });

      await this.setModalMaxHeight($(".modal"));

      var zIndex = 1040 + 10 * $(".modal:visible").length;
      $(this).css("z-Index", zIndex);
      setTimeout(function () {
        $(".modal-backdrop")
          .not(".modal-stack")
          .css("z-Index", zIndex - 1)
          .addClass("modal-stack");
      }, 0);

      if (this.state.editId > 0) {
        await axios
          .get(
            this.url + "FindPatientFollowUp/" + this.state.editId,
            this.config
          )
          .then((response) => {
            this.setState({ patientPlanModel: response.data });
          })
          .catch((error) => { });

        await axios
          .get(this.url + "FindPatientInfo/" + this.state.editId, this.config)
          .then((response) => {
            this.setState({ patientModal: response.data });
          })
          .catch((error) => { });
      }
    } catch {
      this.setState({ loading: false });
    }

    this.setState({ loading: false });
  }

  handleChange = (event) => {
    event.preventDefault();

    this.setState({
      patientPlanModel: {
        ...this.state.patientPlanModel,
        [event.target.name]: event.target.value,
      },
    });
  };

  savePatientFollowupModel = (e) => {
    this.setState({ loading: true });

    // var myVal = this.notesModel;
    // myVal.validation = false;
    //Notes Validation
    //Notes Validation
    var note = [];
    var notesVal;
    var length = 0;
    if (this.isNull(this.state.patientPlanModel.note)) {
      note = [];
    } else {
      note = this.state.patientPlanModel.note;
      length = note.length - 1;
      note.validation = false;
      if (length > 1) {
        if (this.isNull(this.state.patientPlanModel.note[length].note)) {
          note[length].noteValField = (
            <span className="validationMsg">Enter Notes</span>
          );
          note[length].validation = true;
        } else {
          note[length].noteValField = "";
          note[length].validation = false;
        }

        if (note[length].validation == true) {
          this.setState({
            loading: false,
            patientPlanModel: {
              ...this.state.patientPlanModel,
              note: note,
            },
          });
          Swal.fire("", "Please Check Notes", "error");
          return;
        }
      }
    }
    //  for (var i = 0; i < note.length; i++) {
    //    notesVal = { ...this.state.patientPlanModel.note[i] };
    //    notesVal.validation = false;
    //    //Notes validation
    //    if (this.isNull(this.state.patientPlanModel.note[i].note)) {
    //      notesVal.noteValField = (
    //        <span className="validationMsg">Enter Notes</span>
    //      );
    //      notesVal.validation = true;
    //    } else {
    //      notesVal.noteValField = "";
    //      if (notesVal.validation === false) notesVal.validation = false;
    //    }

    //    //Notes validation set state
    //    this.setState({
    //     patientPlanModel: {
    //        ...this.state.patientPlanModel,
    //        note: [
    //          ...this.state.patientPlanModel.note.slice(0, i),
    //          Object.assign({}, this.state.patientPlanModel.note[i], notesVal),
    //          ...this.state.patientPlanModel.note.slice(i + 1)
    //        ]
    //      }
    //    });
    //  }

    //  //Notes
    //  for (var i = 0; i < note.length; i++) {
    //    if (this.state.patientPlanModel.note[i].validation == true) {
    //      this.setState({ loading: false });
    //      Swal.fire("Something Wrong", "Please Check All Note Fields", "error");
    //      return;
    //    }
    //  }

    axios
      .post(
        this.url + "SavePatientFollowUp",
        this.state.patientPlanModel,
        this.config
      )

      .then((response) => {
        this.setState({
          patientPlanModel: response.data,
          editId: response.data.id,
        });

        Swal.fire("Record Saved Successfully", "", "success");
        this.componentWillMount();
      })
      .catch((error) => { });

    e.preventDefault();
  };

  async deleteRowNotes(event, index, NoteRowId) {
    const NoteRowID = NoteRowId;
    const id = event.target.id;
    Swal.fire({
      title: "Are you sure, you want to delete this record?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.value) {
        //KHIZER CODE-------------------------DeleteNote
        if (NoteRowID > 0) {
          axios
            .delete(this.Notesurl + "DeleteNotes/" + NoteRowID, this.config)
            .then((response) => {
              Swal.fire("Record Deleted Successfully", "", "success");
              let note = [...this.state.patientPlanModel.note];
              note.splice(id, 1);
              this.setState({
                patientPlanModel: {
                  ...this.state.patientPlanModel,
                  note: note,
                },
              });
            })
            .catch((error) => {
              if (error.response) {
                if (error.response.status) {
                  if (error.response.status == 400) {
                    Swal.fire("Error", error.response.data, "error");
                  } else {
                    Swal.fire(
                      "Record Not Deleted!",
                      "Record can not be delete, as it is being referenced in other screens.",
                      "error"
                    );
                  }
                }
              } else {
                Swal.fire(
                  "Record Not Deleted!",
                  "Record can not be delete, as it is being referenced in other screens.",
                  "error"
                );
              }
            });
        } else {
          Swal.fire("Record Deleted Successfully", "", "success");
          let note = [...this.state.patientPlanModel.note];
          note.splice(id, 1);
          this.setState({
            patientPlanModel: {
              ...this.state.patientPlanModel,
              note: note,
            },
          });
        }
      }
    });
  }

  // async deleteRowNotes(event, index, chargeId) {
  //   alert("TEst");
  //   const chargeID = chargeId;
  //   const id = event.target.id;
  //   Swal.fire({
  //     title: "Are you sure, you want to delete this record?",
  //     text: "",
  //     type: "warning",
  //     showCancelButton: true,
  //     confirmButtonColor: "#3085d6",
  //     cancelButtonColor: "#d33",
  //     confirmButtonText: "Yes, delete it!"
  //   }).then(result => {
  //     if (result.value) {
  //       if (chargeID) {
  //         axios
  //           .delete(this.Notesurl + "DeleteNotes/" + chargeId, this.config)
  //           .then(response => {
  //             Swal.fire("Record Deleted Successfully", "", "success");
  //             let note = [...this.state.patientPlanModel.note];
  //           //note.splice(id, 1);
  //           this.setState({
  //             patientPlanModel: {
  //               ...this.state.patientPlanModel,
  //               note: note
  //             }
  //           });
  //           })
  //           .catch(error => {
  //             Swal.fire(
  //               "Record Not Deleted!",
  //               "Record can not be delete, as it is being referenced in other screens.",
  //               "error"
  //             );
  //           });
  //       }

  //     }
  //   });
  // }

  async addRowNotes(event) {
    const note = { ...this.notesModel };
    var len = this.state.patientPlanModel.note
      ? this.state.patientPlanModel.note.length
      : 0;
    if (len == 0) {
      await this.setState({
        patientPlanModel: {
          ...this.state.patientPlanModel,
          note: this.state.patientPlanModel.note.concat(note),
        },
      });
      return;
    } else {
      len = len - 1;
      if (this.isNull(this.state.patientPlanModel.note[len].note)) {
        Swal.fire("First Enter Previous Notes", "", "error");
        return;
      } else {
        await this.setState({
          patientPlanModel: {
            ...this.state.patientPlanModel,
            note: this.state.patientPlanModel.note.concat(note),
          },
        });
      }
    }
  }

  async handleNoteChange(event) {
    var value = event.target.value;
    const caret = event.target.selectionStart;
    const element = event.target;
    window.requestAnimationFrame(() => {
      element.selectionStart = caret;
      element.selectionEnd = caret;
    });

    if (caret == 0 || caret <= 1) {
      value = value.trim();
    }

    let newNotesList = this.state.patientPlanModel.note;

    const index = event.target.id;
    const name = event.target.name;
    newNotesList[index][name] = value.toUpperCase();

    await this.setState({
      patientPlanModel: {
        ...this.state.patientPlanModel,
        note: newNotesList,
      },
    });
  }

  isNull(value) {
    if (value === "" || value === null || value === undefined) return true;
    else return false;
  }

  openhistorypopup = (id) => {
    this.setState({ showPopup: true, id: id });
  };
  closehistoryPopup = () => {
    $("#HistoryModal").hide();
    this.setState({ showPopup: false });
  };

  render() {
    // const headers = ["Patient Followup", "Other 1", "Other 2"];
    const headers = ["Patient Followup"];

    // const tabHeaders = ["Notes", "Charges"];
    const tabHeaders = ["Charges", "Notes"];

    var newList = [];
    var tableData = {};
    var addtickleDate = this.state.patientPlanModel.tickleDate
      ? this.state.patientPlanModel.tickleDate.slice(0, 10)
      : "";
    var addFollowUpDate = this.state.patientPlanModel.addedDate
      ? this.state.patientPlanModel.addedDate.slice(0, 10)
      : "";

    var statY = this.state.patientPlanModel.statement1SentDate
      ? this.state.patientPlanModel.statement1SentDate.slice(0, 4)
      : "";
    var statM = this.state.patientPlanModel.statement1SentDate
      ? this.state.patientPlanModel.statement1SentDate.slice(5, 7)
      : "";
    var statD = this.state.patientPlanModel.statement1SentDate
      ? this.state.patientPlanModel.statement1SentDate.slice(8, 10)
      : "";

    var stat1Y = this.state.patientPlanModel.statement2SentDate
      ? this.state.patientPlanModel.statement2SentDate.slice(0, 4)
      : "";
    var stat1M = this.state.patientPlanModel.statement2SentDate
      ? this.state.patientPlanModel.statement2SentDate.slice(5, 7)
      : "";
    var stat1D = this.state.patientPlanModel.statement2SentDate
      ? this.state.patientPlanModel.statement2SentDate.slice(8, 10)
      : "";

    let chargeList = [];
    var data = {};
    this.state.patientPlanModel.gPatientFollowupCharge.map((row, index) => {
      chargeList.push({
        id: row.id,
        visitID: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openVisitPopup("visit", row.visitID)}
          >
            {" "}
            {this.val(row.visitID)}
          </MDBBtn>
        ),
        chargeID: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openChargePopup("charge", row.chargeID)}
          >
            {" "}
            {this.val(row.chargeID)}
          </MDBBtn>
        ),
        plan: (
          <MDBBtn
            className="gridBlueBtn"
            onClick={() => this.openPopup("insuranceplan", row.insurancePlanID)}
          >
            {row.plan}
          </MDBBtn>
        ),
        dos: row.dos,
        cpt: row.cpt,
        billedAmount: row.billedAmount,
        allowedAmount: row.allowedAmount,
        paidAmount: row.paidAmount,
        patientPaid: row.patientPaid,
        patientBal: (
          <span style={{ color: "red", fontWeight: "bold" }}>
            {row.patientBal}
          </span>
        ),
        copay: row.copay,
        deductible: row.deductible,
        coInsurance: row.coInsurance,
        tickleDate: row.tickleDate,
        status: row.status,
      });
    });
    data = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150,
        },
        {
          label: "VISIT",
          field: "visitID",
          sort: "asc",
          width: 150,
        },
        {
          label: "CHARGE #",
          field: "chargeID",
          sort: "asc",
          width: 150,
        },
        {
          label: "PLAN",
          field: "plan",
          sort: "asc",
          width: 150,
        },
        {
          label: "DOS",
          field: "dos",
          sort: "asc",
          width: 300,
        },
        {
          label: "CPT",
          field: "cpt",
          sort: "asc",
          width: 150,
        },
        {
          label: "BILLED",
          field: "billedAmount",
          sort: "asc",
          width: 150,
        },
        {
          label: "ALLOWED",
          field: "allowedAmount",
          sort: "asc",
          width: 150,
        },
        {
          label: "PAID",
          field: "paidAmount",
          sort: "asc",
          width: 150,
        },
        {
          label: "PAT.PAID",
          field: "patientPaid",
          sort: "asc",
          width: 150,
        },
        {
          label: "PATIENT BAL",
          field: "patientBal",
          sort: "asc",
          width: 150,
        },
        {
          label: "COPAY",
          field: "copay",
          sort: "asc",
          width: 150,
        },
        {
          label: "DEDUCTIBLE",
          field: "deductible",
          sort: "asc",
          width: 150,
        },

        {
          label: "CO-INS",
          field: "coInsurance",
          sort: "asc",
          width: 150,
        },
        {
          label: "TICKLE DATE",
          field: "tickleDate",
          sort: "asc",
          width: 150,
        },
        {
          label: "STATUS",
          field: "status",
          sort: "asc",
          width: 150,
        },
      ],
      rows: chargeList,
    };

    //// notes Map  ////////

    this.state.patientPlanModel.note.map((row, index) => {
      var notesDate = this.isNull(row.notesDate)
        ? ""
        : row.notesDate.slice(0, 10);

      if (notesDate != "") {
        var YY = notesDate.slice(0, 4);
        var DD = notesDate.slice(5, 7);
        var MM = notesDate.slice(8, 10);
      }

      newList.push({
        id: row.id,

        notesDate: (
          <div style={{ width: "86px" }}>
            <span>{notesDate != "" ? MM + "/" + DD + "/" + YY : ""}</span>

            {/* <input
              style={{
                background: "url(" + samll_doc_icon + ") no-repeat right",
              }}
              className="smallCalendarIcon"
              type="date"
              name="notesDate"
              id={index}
              value={notesDate}
              onChange={this.handleNoteChange}
            ></input> */}
          </div>
        ),

        note: (
          <div style={{ width: "100%" }}>
            <textarea
              className="Note-textarea"
              style={{
                width: "100%",
                height: "100%",
                padding: "10px",
              }}
              rows="1"
              cols="60"
              name="note"
              value={this.state.patientPlanModel.note[index].note}
              id={index}
              onChange={this.handleNoteChange}
            ></textarea>
            {this.state.patientPlanModel.note[index].noteValField}
          </div>

          // <div >
          //   <input
          //     // style={{
          //     //   width: " 350px",
          //     //   marginRight: "0px",
          //     //   padding: "7px 5px"
          //     // }}
          //     type="text"
          //     value={this.state.patientPlanModel.note[index].note}
          //     name="note"
          //     id={index}
          //     onChange={this.handleNoteChange}
          //   ></input>
          // </div>
        ),

        addedBy: (
          <div style={{ width: "150px" }}>
            <span>{this.state.patientPlanModel.note[index].addedBy}</span>
          </div>
        ),

        remove: (
          <div style={{ width: "50px", textAlign: "center" }}>
            <button
              className="removeBtn"
              name="deleteCPTBtn"
              id={index}
              onClick={(event, index) =>
                this.deleteRowNotes(event, index, row.id)
              }
            >
              X
            </button>
          </div>
        ),
      });
    });

    tableData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          //  width: 100
        },
        {
          label: "DATE",
          field: "notesDate",
          sort: "asc",
          // width: 400
        },
        {
          label: "NOTES",
          field: "note",
          sort: "asc",
          // width: 200
        },
        {
          label: "ADDED BY",
          field: "addedBy",
          sort: "asc",
          // width: 50
        },

        {
          label: "",
          field: "remove",
          sort: "asc",
          // width: 0
        },
      ],
      rows: newList,
    };

    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    const options = [
      { value: "History", label: "History", className: "dropdown" },
    ];

    var Imag;
    Imag = (
      <div>
        <img src={settingsIcon} />
      </div>
    );

    var dropdown;
    dropdown = (
      <Dropdown
        className="TodayselectContainer"
        options={options}
        onChange={() => this.openhistorypopup(0)}
        //  value={options}
        // placeholder={"Select an option"}
        placeholder={Imag}
      />
    );

    let popup = "";
    if (this.state.showPopup) {
      popup = (
        <NewHistoryPractice
          onClose={() => this.closehistoryPopup}
          historyID={this.state.editId}
          apiURL={this.url}
        // disabled={this.isDisabled(this.props.rights.update)}
        // disabled={this.isDisabled(this.props.rights.add)}
        ></NewHistoryPractice>
      );
    } else if (this.state.visitPopup) {
      popup = (
        <GPopup
          onClose={() => this.closeVisitPopUp}
          id={this.state.id}
          popupName={this.state.popupName}
        ></GPopup>
      );
    } else if (this.state.popupName === "insuranceplan") {
      popup = (
        <NewInsurancePlan
          onClose={() => this.closePopup}
          id={this.state.id}
        ></NewInsurancePlan>
      );
    } else if (this.state.chargePopup) {
      popup = (
        <EditCharge
          onClose={() => this.closeChargePopup}
          chargeId={this.state.id}
        ></EditCharge>
      );
    } else {
      popup = <React.Fragment></React.Fragment>;
    }

    return (
      <React.Fragment>
        <div
          id="patientPlanModal"
          className="modal fade bs-example-modal-new show"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          style={{ display: "block", paddingRight: "17px" }}
        >
          <div className="modal-dialog modal-lg">
            {spiner}
            <div className="modal-content" style={{ overflow: "hidden" }}>
              <button
                onClick={this.props.onClose()}
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true"></span>
              </button>

              <div
                className="modal-body"
                style={{ maxHeight: this.state.maxHeight }}
              >
                <div className="mainTable fullWidthTable">
                  <div className="row-form">
                    <div className="mf-12">
                      {this.state.editId > 0 ? dropdown : ""}
                      <Tabs headers={headers} style={{ cursor: "default" }}>
                        <Tab>
                          <div style={{ marginTop: "20px" }}>
                            <div
                              className="mainTable fullWidthTable wSpace"
                              style={{ maxWidth: "100%" }}
                            >
                              <div className="row-form">
                                <div className="mf-4">
                                  <Label name="Reason"></Label>

                                  <div className="selectBoxValidate">
                                    <select
                                      name="reasonID"
                                      id="reasonID"
                                      value={
                                        this.state.patientPlanModel.reasonID
                                      }
                                      onChange={this.handleChange}
                                    >
                                      {this.state.resData.map((s) => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>
                                <div className="mf-4">
                                  <Label name="Action"></Label>

                                  <div className="selectBoxValidate">
                                    <select
                                      name="actionID"
                                      id="actionID"
                                      value={
                                        this.state.patientPlanModel.actionID
                                      }
                                      onChange={this.handleChange}
                                    >
                                      {this.state.actionData.map((s) => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>
                                <div className="mf-4">
                                  <Label name="Group"></Label>

                                  <div className="selectBoxValidate">
                                    <select
                                      name="groupID"
                                      id="groupID"
                                      value={
                                        this.state.patientPlanModel.groupID
                                      }
                                      onChange={this.handleChange}
                                    >
                                      {this.state.groupData.map((s) => (
                                        <option key={s.id} value={s.id}>
                                          {s.description}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>
                              </div>

                              <div className="row-form">
                                <div className="mf-4">
                                  <Label name="Follow up Date"></Label>

                                  <div className="textBoxValidate">
                                    <input
                                      style={{
                                        width: "215px",
                                        marginLeft: "0px",
                                      }}
                                      className="myInput"
                                      type="date"
                                      name="followUpDate"
                                      id="followUpDate"
                                      value={addFollowUpDate}
                                      onChange={this.handleChange}
                                    ></input>
                                  </div>
                                </div>
                                <div className="mf-4">
                                  <Label name="Follow up Age "></Label>

                                  <Input
                                    type="text"
                                    value={this.state.patientPlanModel.age}
                                    name="age"
                                    id="age"
                                    onChange={() => this.handleChange}
                                  ></Input>
                                </div>
                                <div className="mf-4">
                                  <Label name="Tickle Date"></Label>

                                  <div className="textBoxValidate">
                                    <input
                                      style={{
                                        width: "215px",
                                        marginLeft: "0px",
                                      }}
                                      className="myInput"
                                      type="date"
                                      name="tickleDate"
                                      id="tickleDate"
                                      value={addtickleDate}
                                      onChange={this.handleChange}
                                    ></input>
                                  </div>
                                </div>
                              </div>
                              <div className="row-form">
                                <div className="mf-4">
                                  <Label name="Statment 1 Sent Date"></Label>

                                  <div className="textBoxValidate">
                                    <Input
                                      disabled="disabled"
                                      type="text"
                                      value={
                                        this.state.patientPlanModel
                                          .statement1SentDate
                                          ? statM + "/" + statD + "/" + statY
                                          : ""
                                      }
                                      name="statement1SentDate"
                                      id="statement1SentDate"
                                      onChange={() => this.handleChange}
                                    ></Input>
                                  </div>
                                </div>
                                <div className="mf-4">
                                  <Label name="Statment 2 Sent Date"></Label>
                                  <div className="textBoxValidate">
                                    <Input
                                      disabled="disabled"
                                      type="text"
                                      value={
                                        this.state.patientPlanModel
                                          .statement2SentDate
                                          ? stat1M + "/" + stat1D + "/" + stat1Y
                                          : ""
                                      }
                                      name="statement2SentDate"
                                      id="statement2SentDate"
                                      onChange={() => this.handleChange}
                                    ></Input>
                                  </div>
                                </div>
                                <div className="mf-4">
                                  <Label name="Status"></Label>
                                  <div className="textBoxValidate">
                                    <Input
                                      type="text"
                                      value={this.state.patientPlanModel.status}
                                      disabled={true}
                                      name="status"
                                      id="status"
                                      onChange={() => this.handleChange}
                                    ></Input>
                                  </div>
                                </div>
                              </div>

                              {/* <div className="row-form">
                                <div className="mf-12 field_full-12">
                                  <label>Notes:</label>
                                  <textarea
                                    name="notes"
                                    id="notes"
                                    cols="30"
                                    rows="10"
                                    value={this.state.patientPlanModel.notes}
                                    onChange={this.handleChange}
                                  ></textarea>
                                </div>
                              </div>
                              {/* <div className="headingOne mt-25">
                                                                <p>Submission Info</p>
                                                            </div> */}

                              {/* <div className="mf-12 table-grid mt-15">
                                <div className="tableGridContainer">
                                  <MDBDataTable
                                    responsive={true}
                                    striped
                                    bordered
                                    searching={false}
                                    data={data}
                                    displayEntries={false}
                                    sortable={true}
                                    scrollX={false}
                                    scrollY={false}
                                  />
                                </div>
                              </div> */}

                              {/* ///////Tabs/////////////////// */}

                              <div>
                                <div class="row-form">
                                  <div class="mf-12 mf-tabs-container">
                                    <Tabs
                                      headers={tabHeaders}
                                      style={{ cursor: "default" }}
                                    >
                                      <Tab>
                                        {" "}
                                        <div class="mainTable fullWidthTable">
                                          <div class="mf-12 table-grid mt-15">
                                            <div class="row headingTable">
                                              <div class="mf-6">
                                                {/* <h1>CHARGES</h1> */}
                                              </div>
                                              {/* <div class="mf-6 headingRightTable">
                                                                         
                                                                            <button class="btn-blue" onClick={this.addCPTRowIncharge}>

                                                                                Add CPT{" "}
                                                                            </button>
                                                                            </div> */}
                                            </div>

                                            <div>
                                              <div className="tableGridContainer text-nowrap">
                                                <MDBDataTable
                                                  striped
                                                  bordered
                                                  searching={false}
                                                  data={data}
                                                  displayEntries={false}
                                                  //sortable={true}
                                                  scrollX={false}
                                                  scrollY={false}
                                                  responsive
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </Tab>
                                      <Tab>
                                        {" "}
                                        <div class="mainTable fullWidthTable">
                                          <div class="mf-12 table-grid mt-15">
                                            <div class="row headingTable">
                                              <div class="mf-6">
                                                {/* <h1>NOTES</h1> */}
                                              </div>
                                              <div class="mf-6 headingRightTable">
                                                <button
                                                  class="btn-blue"
                                                  onClick={this.addRowNotes}
                                                >
                                                  Add Note{" "}
                                                </button>
                                              </div>
                                            </div>

                                            <div>
                                              <div className="tableGridContainer">
                                                <MDBDataTable
                                                  striped
                                                  bordered
                                                  searching={false}
                                                  data={tableData}
                                                  displayEntries={false}
                                                  //sortable={true}
                                                  scrollX={false}
                                                  scrollY={false}
                                                  responsive
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        >
                                      </Tab>
                                    </Tabs>
                                  </div>
                                </div>
                              </div>

                              <div className="row-form">
                                {/* <div className="mf-4">
                                                                    <Label name="Practice"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.practiceName} name="practiceName" id="practiceName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Location"></Label>

                                                                    <div className="textBoxValidate">
                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.locationName} name="locationName" id="locationName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Provider"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.providerName} name="providerName" id="providerName" onChange={() => this.handleChange}></Input>


                                                                    </div>
                                                                </div> */}
                              </div>

                              <div className="row-form">
                                {/* <div className="mf-4">
                                                                    <Label name="Ref. Provider"></Label>

                                                                    <div className="textBoxValidate">

                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.refProviderName} name="refProviderName" id="refProviderName" onChange={() => this.handleChange}></Input>

                                                                    </div>
                                                                </div>
                                                                <div className="mf-4">
                                                                    <Label name="Sup. Provider "></Label>

                                                                    <div className="textBoxValidate">


                                                                        <Input disabled="disabled" type="text" value={this.state.patientModal.supProviderName} name="supProviderName" id="supProviderName" onChange={() => this.handleChange}></Input>


                                                                    </div>



                                                                </div>
                                                                <div className="mf-4">
                                                                    &nbsp;
                                                                </div> */}
                              </div>
                              <div className="headingOne mt-25">
                                <p>Patient Detail</p>
                              </div>
                              <div className="row-form">
                                <div className="mf-4">
                                  <Label name="Account #"></Label>

                                  <Input
                                    type="text"
                                    disabled="disabled"
                                    value={
                                      this.state.patientModal.accountNumber
                                    }
                                    name="accountNumber"
                                    id="accountNumber"
                                    onChange={() => this.handleChange}
                                  ></Input>
                                </div>
                                <div className="mf-4">
                                  <Label name="Patient Name"></Label>

                                  <Input
                                    type="text"
                                    disabled="disabled"
                                    value={this.state.patientModal.patientName}
                                    name="patientName"
                                    id="patientName"
                                    onChange={() => this.handleChange}
                                  ></Input>
                                </div>
                                <div className="mf-4">
                                  <Label name="DOB"></Label>

                                  <div className="textBoxValidate">
                                    <Input
                                      type="text"
                                      disabled="disabled"
                                      value={this.state.patientModal.dob}
                                      name="dob"
                                      id="dob"
                                      onChange={() => this.handleChange}
                                    ></Input>
                                  </div>
                                </div>
                              </div>

                              <div className="row-form">
                                <div className="mf-4">
                                  <Label name="Plan Name"></Label>

                                  <Input
                                    type="text"
                                    disabled="disabled"
                                    value={this.state.patientModal.planName}
                                    name="planName"
                                    id="planName"
                                    onChange={() => this.handleChange}
                                  ></Input>
                                </div>
                                <div className="mf-4">
                                  <Label name="Subscriber Name"></Label>

                                  <Input
                                    type="text"
                                    disabled="disabled"
                                    value={
                                      this.state.patientModal.subscriberName
                                    }
                                    name="subscriberName"
                                    id="subscriberName"
                                    onChange={() => this.handleChange}
                                  ></Input>
                                </div>
                                <div className="mf-4">
                                  <Label name="Subscriber ID "></Label>

                                  <Input
                                    type="text"
                                    disabled="disabled"
                                    value={this.state.patientModal.subscriberID}
                                    name="subscriberID"
                                    id="subscriberID"
                                    onChange={() => this.handleChange}
                                  ></Input>
                                </div>
                              </div>
                            </div>
                          </div>
                        </Tab>
                        {/* <Tab>
                          <div style={{ marginTop: "20px" }}>
                            <div
                              className="mainTable fullWidthTable wSpace"
                              style={{ maxWidth: "100%" }}
                            >
                              <div className="headingOne mt-25">
                                <p>Submission Info</p>
                              </div>

                              <div className="headingOne mt-25">
                                <p>Legal Entities</p>
                              </div>
                            </div>
                          </div>
                        </Tab>
                        <Tab>
                          <div style={{ marginTop: "20px" }}>
                            <div
                              className="mainTable fullWidthTable wSpace"
                              style={{ maxWidth: "100%" }}
                            >
                              <div className="headingOne mt-25">
                                <p>Submission Info</p>
                              </div>

                              <div className="headingOne mt-25">
                                <p>Legal Entities</p>
                              </div>
                            </div>
                          </div>
                        </Tab> */}
                      </Tabs>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <div className="mainTable">
                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <button
                          className="btn-blue"
                          onClick={this.savePatientFollowupModel}
                        >
                          Save{" "}
                        </button>
                        <button
                          id="btnCancel"
                          className="btn-grey"
                          data-dismiss="modal"
                          onClick={this.props.onClose()}
                        >
                          Cancel{" "}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {popup}
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedTab:
      state.selectedTab !== null ? state.selectedTab.selectedTab : "",
    selectedTabPage: state.selectedTabPage,
    selectedPopup: state.selectedPopup,
    reduxID: state.selectedTab !== null ? state.selectedTab.id : 0,
    setupLeftMenu: state.leftNavigationMenus,
    loginObject: state.loginToken
      ? state.loginToken
      : { toekn: "", isLogin: false },
    userInfo: state.loginInfo
      ? state.loginInfo
      : { userPractices: [], name: "", practiceID: null },
    rights: state.loginInfo
      ? {
        search: state.loginInfo.rights.patientPlanSearch,
        add: state.loginInfo.rights.patientPlanCreate,
        update: state.loginInfo.rights.patientPlanUpdate,
        delete: state.loginInfo.rights.patientPlanDelete,
        export: state.loginInfo.rights.patientPlanExport,
        import: state.loginInfo.rights.patientPlanImport,
      }
      : [],
  };
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
    },
    dispatch
  );
}

export default connect(
  mapStateToProps,
  matchDispatchToProps
)(NewPatientPlanModel);
