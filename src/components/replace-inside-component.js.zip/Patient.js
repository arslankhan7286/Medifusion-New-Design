//Package Import
import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { MDBBtn } from "mdbreact";
import $ from "jquery";
import axios from "axios";
import { MDBDataTable } from "mdbreact";
import Swal from "sweetalert2";
import dob_icon from "../images/dob-icon.png";
import Eclips from "../images/loading_spinner.gif";
import GifLoader from "react-gif-loader";
import moment from "moment";

//Local Components Import
import NewPractice from "./NewPractice";
import NewLocation from "./NewLocation";
import NewProvider from "./NewProvider";
import GridHeading from "./GridHeading";
import SearchHeading from "./SearchHeading";
import Label from "./Label";
import Input from "./Input";

//Redux Actions
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { selectTabPageAction } from "../actions/selectTabAction";
import { loginAction } from "../actions/LoginAction";
import { selectTabAction } from "../actions/selectTabAction";
import { selectPatient } from "../actions/selectPatient";
import { setPatientGridData } from "../actions/SetPatientGridDataAction";

class Patient extends Component {
  constructor(props) {
    super(props);

    this.url = process.env.REACT_APP_URL + "/patient/";
    this.id = 0;
    //Authorization Token
    this.config = {
      headers: {
        Authorization: "Bearer  " + this.props.loginObject.token,
        Accept: "*/*",
      },
    };

    this.cursor = 0;
    this.lastNameRef = React.createRef();
    this.firstNameRef = React.createRef();

    this.searchModel = {
      lastName: "",
      firstName: "",
      accountNum: "",
      medicalRecordNumber: "",
      ssn: "",
      dob: "",
      insuredID: "",
      practice: "",
      location: "",
      provider: "",
      plan: "",

      entryDateFrom: "",
      entryDateTo: "",

      inActive: false,
    };

    this.validationModel = {
      dobValField: null,
      selectEntryDateFromValField: null,
      entryDateToGreaterValField: null,
      validation: false,
    };

    this.state = {
      searchModel: this.searchModel,
      validationModel: this.validationModel,
      data: this.props.patientGridData ? this.props.patientGridData : [],
      patientCBList: [],
      showpracticePopup: false,
      showLocationPopup: false,
      showProviderPopup: false,
      loading: false,
      //----SCHEDULAR DATA
      advSearchData: [],
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handleNumericCheck = this.handleNumericCheck.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
    this.newPatientPopup = this.newPatientPopup.bind(this);
    this.toggleCheck = this.toggleCheck.bind(this);
    this.searchPatient = this.searchPatient.bind(this);
    this.clearFields = this.clearFields.bind(this);

    this.handleEnterToChange = this.handleEnterToChange.bind(this);
    this.handleEnterFromChange = this.handleEnterFromChange.bind(this);
  }

  openpracticePopup = (id) => {
    this.setState({ showpracticePopup: true, id: id });
  };

  closepracticePopup = () => {
    $("#myModal").hide();
    this.setState({ showpracticePopup: false });
  };

  openLocationPopup = (id) => {
    this.setState({ showLocationPopup: true, id: id });
  };

  closeLocationPopup = () => {
    $("#myModal").hide();
    this.setState({ showLocationPopup: false });
  };

  openProviderPopup = (id) => {
    this.setState({ showProviderPopup: true, id: id });
  };

  closeProviderPopup = () => {
    $("#myModal").hide();
    this.setState({ showProviderPopup: false });
  };

  isNull(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value === "Please Select" ||
      value === "Please Coverage" ||
      value === "Please Relationship"
    )
      return true;
    else return false;
  }

  replace(field, replaceWhat, replaceWith) {
    if (this.isNull(field)) return field;
    else return field.replace(replaceWhat, replaceWith);
  }

  handleChange = (event) => {
    if (
      event.target.name === "entryDateFrom" ||
      event.target.name === "entryDateTo"
    ) {
    } else {
      const caret = event.target.selectionStart;
      const element = event.target;
      window.requestAnimationFrame(() => {
        element.selectionStart = caret;
        element.selectionEnd = caret;
      });
    }

    //Carret Position

    this.setState({
      searchModel: {
        ...this.state.searchModel,
        [event.target.name]: event.target.value.toUpperCase(),
      },
    });

    event.preventDefault();
  };

  async searchPatient() {
    var myVal = this.validationModel;
    myVal.validation = false;

    if (this.isNull(this.state.searchModel.dob) == false) {
      if (
        new Date(
          moment(this.state.searchModel.dob).format().slice(0, 10)
        ).getTime() > new Date(moment().format().slice(0, 10)).getTime()
      ) {
        myVal.dobValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.dobValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.dobValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //if Entry Date To is selected Then Make sure than Entry Date Form is also selected Validation
    if (
      this.isNull(this.state.searchModel.entryDateFrom) == true &&
      this.isNull(this.state.searchModel.entryDateTo) == false
    ) {
      myVal.selectEntryDateFromValField = (
        <span className="validationMsg">Select Entry Date From</span>
      );
      myVal.validation = true;
      if (myVal.validation == false) myVal.validation = false;
    } else {
      myVal.selectEntryDateFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //DOS To must be greater than DOS From Validation
    if (
      this.isNull(this.state.searchModel.entryDateFrom) == false &&
      this.isNull(this.state.searchModel.entryDateTo) == false
    ) {
      if (
        new Date(
          moment(this.state.searchModel.entryDateFrom).format().slice(0, 10)
        ).getTime() >
        new Date(
          moment(this.state.searchModel.entryDateTo).format().slice(0, 10)
        ).getTime()
      ) {
        myVal.entryDateToGreaterValField = (
          <span className="validationMsg">
            Entry Date To must be greater than Entry Date From
          </span>
        );
        myVal.validation = true;
      } else {
        myVal.entryDateToGreaterValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.entryDateToGreaterValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    if (this.isNull(this.state.searchModel.entryDateFrom) == false) {
      if (
        new Date(
          moment(this.state.searchModel.entryDateFrom).format().slice(0, 10)
        ).getTime() > new Date(moment().format().slice(0, 10)).getTime()
      ) {
        myVal.enterDateFromValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.enterDateFromValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.enterDateFromValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    //Enter Date To Future Date Validation
    if (this.isNull(this.state.searchModel.entryDateTo) == false) {
      if (
        new Date(
          moment(this.state.searchModel.entryDateTo).format().slice(0, 10)
        ).getTime() > new Date(moment().format().slice(0, 10)).getTime()
      ) {
        myVal.enterDateToValField = (
          <span className="validationMsg">Future date can't be selected</span>
        );
        myVal.validation = true;
      } else {
        myVal.enterDateToValField = null;
        if (myVal.validation == false) myVal.validation = false;
      }
    } else {
      myVal.enterDateToValField = null;
      if (myVal.validation == false) myVal.validation = false;
    }

    if (myVal.validation == true) {
      this.setState({ validationModel: myVal });
      Swal.fire(
        "Something Wrong",
        "Please Select All Fields Properly",
        "error"
      );
      return;
    }

    await this.setState({ loading: true });
    var accountNUm = this.props.patientInfo
      ? this.props.patientInfo.accNum
      : null;
    await axios
      .post(this.url + "FindPatients", this.state.searchModel, this.config)
      .then((response) => {
        // var patientCBList = [];
        // for (var i = 0; i < response.data.length; i++) {
        //   if (response.data[i].accountNum == accountNUm) {
        //     patientCBList.push(true);
        //   } else {
        //     patientCBList.push(false);
        //   }
        // }
        this.setState({
          data: response.data,
          // patientCBList: patientCBList,
          loading: false,
        });
      })
      .catch((error) => {
        this.setState({ loading: false });
        if (error.response) {
          if (error.response.status) {
            if (error.response.status == 404) {
              Swal.fire("Error", "404 No Record Found", "error");
            } else if (error.response.status == 401) {
              Swal.fire("Error", "401 UnAuthorize Access", "error");
            } else if (error.response.status == 400) {
              Swal.fire("400 Bad Request", error.request.response, "error");
            }
          }
        }
      });
  }

  handleEnterFromChange = (date) => {
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        entryDateFrom: date,
      },
    });
  };

  handleEnterToChange = (date) => {
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        entryDateTo: date,
      },
    });
  };

  handleSearch(event) {
    event.preventDefault();
    if (event) {
      this.searchPatient();
    } else {
      return true;
    }
  }

  async toggleCheck(event, patInfo) {
    var index = Number(event.target.name);
    var patientCBList = this.state.patientCBList;

    await patientCBList.map((cb, i) => {
      if (index == i) {
        patientCBList[i] = !patientCBList[i];
        if (patientCBList[i] == false) {
          this.props.selectPatient({ ID: null, accNum: null });
        } else {
          this.props.selectPatient(patInfo);
        }
      } else {
        patientCBList[i] = false;
      }
    });

    this.setState({ patientCBList: patientCBList });
  }

  openPatient = (patientInfo) => {
    this.props.selectPatient(patientInfo);
    this.props.history.push("/Charges/" + patientInfo.ID);
  };

  async clearFields(event) {
    var searchModel = { ...this.searchModel };
    searchModel.dob = null;
    searchModel.entryDateFrom = null;
    searchModel.entryDateTo = null;

    await this.setState({ searchModel: searchModel });

    this.handleSearch(event);
  }

  handleNumericCheck(event) {
    if (event.charCode >= 48 && event.charCode <= 57) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  handleCheck() {
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        inActive: !this.state.searchModel.inActive,
      },
    });
  }

  handleDateChange = (date) => {
    this.setState({
      searchModel: {
        ...this.state.searchModel,
        dob: date.target.value,
      },
    });
  };

  // openPopup(id) {}

  newPatientPopup(id, accNumber) {
    this.props.selectTabAction("NewPatient", id);
    this.props.selectPatient({ ID: id, accNum: accNumber });
    this.props.setPatientGridData(this.state.data);
    this.props.history.push("/NewPatient");
  }

  isDisabled(value) {
    if (value == null || value == false) return "disabled";
  }

  //----------------------------SCHEDULAR FUNCTION

  selectRow(data) {
    let count = 0;
    console.log("data", data);
    Array.from(document.querySelectorAll(".dataTable")).forEach((tab) => {
      // console.log("tab", tab.childNodes[1].childNodes);
      tab.childNodes[1].childNodes.forEach((row) => {
        console.log("ROW", row);
        console.log("innerHTML", row.childNodes);
        row.setAttribute("class", "SchedularRowNotSelected");

        for (const td of row.childNodes) {
          if (data.id == td.textContent) {
            if (count == 0) {
              row.setAttribute("class", "SchedularRowSelected");
              count++;
            }
          }
        }
      });
    });

    this.setState({
      advSearchData: data,
    });
  }

  sendRowData() {
    if (this.state.advSearchData.length == 0) {
      Swal.fire("Please Select A Row", "", "error");
    } else {
      this.props.rowSelect(this.state.advSearchData);
      this.props.closeAdvSrch();
    }
  }

  render() {
    var newDate = new Date(this.state.searchModel.dob);
    var day = newDate.getDate();
    var month = newDate.getMonth() + 1;
    var year = newDate.getFullYear();
    newDate = year + "-" + month + "-" + day;

    let newList = [];
    this.state.data.map((row, i) => {
      if (this.props.SchedularAdvSearch) {
        newList.push({
          id: row.id,
          accountNo: (
            <MDBBtn
              className="gridBlueBtn"
              onClick={() => this.newPatientPopup(row.id, row.accountNum)}
            >
              {" "}
              {row.accountNum}
            </MDBBtn>
          ),
          lastName: row.lastName,
          firstName: row.firstName,
          medicalRecordNumber: row.medicalRecordNumber,
          ssn: row.ssn,
          dob: row.dob,
          practice: (
            <MDBBtn
              className="gridBlueBtn"
              onClick={() => this.openpracticePopup(row.practiceID)}
            >
              {" "}
              {row.practice}
            </MDBBtn>
          ),
          location: (
            <MDBBtn
              className="gridBlueBtn"
              onClick={() => this.openLocationPopup(row.locationID)}
            >
              {" "}
              {row.location}
            </MDBBtn>
          ),
          provider: (
            <MDBBtn
              className="gridBlueBtn"
              onClick={() => this.openProviderPopup(row.providerID)}
            >
              {" "}
              {row.provider}
            </MDBBtn>
          ),
          clickEvent: () => this.selectRow(row),
        });
      } else {
        newList.push({
          id: row.id,
          accountNo: (
            <MDBBtn
              className="gridBlueBtn"
              onClick={() => this.newPatientPopup(row.id, row.accountNum)}
            >
              {" "}
              {row.accountNum}
            </MDBBtn>
          ),
          lastName: row.lastName,
          firstName: row.firstName,
          medicalRecordNumber: row.medicalRecordNumber,
          ssn: row.ssn,
          dob: row.dob,
          practice: (
            <MDBBtn
              className="gridBlueBtn"
              onClick={() => this.openpracticePopup(row.practiceID)}
            >
              {" "}
              {row.practice}
            </MDBBtn>
          ),
          location: (
            <MDBBtn
              className="gridBlueBtn"
              onClick={() => this.openLocationPopup(row.locationID)}
            >
              {" "}
              {row.location}
            </MDBBtn>
          ),
          provider: (
            <MDBBtn
              className="gridBlueBtn"
              onClick={() => this.openProviderPopup(row.providerID)}
            >
              {" "}
              {row.provider}
            </MDBBtn>
          ),
        });
      }
    });

    const tableData = {
      columns: [
        {
          label: "ID",
          field: "id",
          sort: "asc",
          width: 150,
        },
        // {
        //   label: "",
        //   field: "openVisit",
        //   sort: "asc",
        //   width: 150
        // },
        {
          label: "ACCOUNT #",
          field: "accountNo",
          sort: "asc",
          width: 150,
        },
        {
          label: "LAST NAME",
          field: "lastName",
          sort: "asc",
          width: 150,
        },
        {
          label: "FIRST NAME",
          field: "firstName",
          sort: "asc",
          width: 150,
        },
        // {
        //   label: "PLAN",
        //   field: "plan",
        //   sort: "asc",
        //   width: 150
        // },
        {
          label: "MEDICAL RECORD #",
          field: "medicalRecordNumber",
          sort: "asc",
          width: 150,
        },
        {
          label: "SSN",
          field: "ssn",
          sort: "asc",
          width: 150,
        },
        {
          label: "DOB",
          field: "dob",
          sort: "asc",
          width: 150,
        },
        {
          label: "PRACTICE",
          field: "practice",
          sort: "asc",
          width: 150,
        },
        {
          label: "LOCATION",
          field: "location",
          sort: "asc",
          width: 150,
        },
        {
          label: "PROVIDER",
          field: "provider",
          sort: "asc",
          width: 150,
        },
      ],
      rows: newList,
    };
    let popup = "";

    if (this.state.showpracticePopup) {
      popup = (
        <NewPractice
          onClose={() => this.closepracticePopup}
          practiceID={this.state.id}
        ></NewPractice>
      );
    } else if (this.state.showLocationPopup) {
      popup = (
        <NewLocation
          onClose={() => this.closeLocationPopup}
          id={this.state.id}
        ></NewLocation>
      );
    } else if (this.state.showProviderPopup) {
      popup = (
        <NewProvider
          onClose={() => this.closeProviderPopup}
          id={this.state.id}
        ></NewProvider>
      );
    } else popup = <React.Fragment></React.Fragment>;

    //Spinner
    let spiner = "";
    if (this.state.loading == true) {
      spiner = (
        <div className="spiner">
          <GifLoader
            loading={true}
            imageSrc={Eclips}
            // imageStyle={imageStyle}
            overlayBackground="rgba(0,0,0,0.5)"
          />
        </div>
      );
    }

    return (
      <React.Fragment>
        {spiner}
        <div>
          <div>
            <div>
              {this.props.SchedularAdvSearch ? (
                <SearchHeading
                  heading="ADVANCE PATIENT SEARCH"
                  handler={() => this.props.changePatientMode()}
                  disabled={this.isDisabled(this.props.rights.add)}
                ></SearchHeading>
              ) : (
                <SearchHeading
                  heading="PATIENT SEARCH"
                  handler={() => this.newPatientPopup(0, 0)}
                  disabled={this.isDisabled(this.props.rights.add)}
                ></SearchHeading>
              )}

              <div className="container-fluid">
                <form
                  onSubmit={(event) => {
                    this.handleSearch(event);
                  }}
                >
                  <div
                    className="mainTable fullWidthTable"
                    style={{ maxWidth: "1500px" }}
                  >
                    <div className="row-form">
                      <div className="mf-3">
                        <Label name="Last Name"></Label>
                        <input
                          ref={this.lastNameRef}
                          type="text"
                          name="lastName"
                          id="lastName"
                          max="35"
                          value={this.state.searchModel.lastName}
                          onChange={this.handleChange}
                        ></input>
                      </div>
                      <div className="mf-3">
                        <Label name="First Name"></Label>
                        <input
                          ref={this.firstNameRef}
                          type="text"
                          name="firstName"
                          id="firstName"
                          max="35"
                          value={this.state.searchModel.firstName}
                          onChange={this.handleChange}
                        ></input>
                      </div>
                      <div className="mf-3">
                        <Label name="Account#"></Label>
                        <Input
                          type="text"
                          name="accountNum"
                          id="accountNum"
                          value={this.state.searchModel.accountNum}
                          onChange={(event) => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="MRN"></Label>
                        <Input
                          type="text"
                          name="medicalRecordNumber"
                          id="medicalRecordNumber"
                          max="20"
                          value={this.state.searchModel.medicalRecordNumber}
                          onChange={(event) => this.handleChange}
                        ></Input>
                      </div>
                    </div>
                    <div className="row-form">
                      <div className="mf-3">
                        <Label name="SSN"></Label>
                        <Input
                          type="text"
                          name="ssn"
                          id="ssn"
                          max="9"
                          value={this.state.searchModel.ssn}
                          onChange={(event) => this.handleChange}
                          onKeyPress={(event) => this.handleNumericCheck(event)}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="DOB"></Label>
                        <div>
                          <div className="textBoxValidate">
                            <input
                              min="1900-01-01"
                              max="9999-12-31"
                              type="date"
                              min="1900-01-01"
                              max="9999-12-31"
                              name="dob"
                              id="dob"
                              value={
                                this.state.searchModel.dob == null
                                  ? ""
                                  : this.state.searchModel.dob
                              }
                              onChange={this.handleDateChange}
                            ></input>
                            {this.state.validationModel.dobValField}
                          </div>
                          {/* <img src={dob_icon}></img> */}
                        </div>

                        {/* <DatePicker
                          dateFormat="MM/dd/yyyy"
                          isClearable
                          showYearDropdown
                          selected={this.state.searchModel.dob}
                          onChange={this.handleDateChange}
                        /> */}
                      </div>
                      <div className="mf-3">
                        <Label name="Subscriber ID"></Label>
                        <Input
                          type="text"
                          name="insuredID"
                          id="insuredID"
                          value={this.state.searchModel.insuredID}
                          onChange={(event) => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        {/* <Label name="Practice"></Label>
                        <Input
                          type="text"
                          name="practice"
                          id="practice"
                          value={this.state.searchModel.practice}
                          onChange={event => this.handleChange}
                        ></Input> */}

                        <Label name="Location"></Label>
                        <Input
                          type="text"
                          name="location"
                          id="location"
                          value={this.state.searchModel.location}
                          onChange={(event) => this.handleChange}
                        ></Input>
                      </div>
                    </div>
                    <div className="row-form">
                      <div className="mf-3">
                        <Label name="Provider"></Label>
                        <Input
                          type="text"
                          name="provider"
                          id="provider"
                          value={this.state.searchModel.provider}
                          onChange={(event) => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="Plan"></Label>
                        <Input
                          type="text"
                          name="plan"
                          id="plan"
                          value={this.state.searchModel.plan}
                          onChange={(event) => this.handleChange}
                        ></Input>
                      </div>
                      <div className="mf-3">
                        <Label name="Enter Date From "></Label>
                        <div className="textBoxValidate">
                          <input
                            style={{
                              width: "215px",
                              marginLeft: "0px",
                            }}
                            className="myInput"
                            type="date"
                            min="1900-01-01"
                            max="9999-12-31"
                            name="entryDateFrom"
                            id="entryDateFrom"
                            value={
                              this.state.searchModel.entryDateFrom == null
                                ? ""
                                : this.state.searchModel.entryDateFrom
                            }
                            onChange={this.handleChange}
                            // onKeyPress={this.handleSearch}
                          ></input>
                          {this.state.validationModel.enterDateFromValField}
                          {
                            this.state.validationModel
                              .selectEntryDateFromValField
                          }
                        </div>
                      </div>

                      <div className="mf-3">
                        <Label name="Enter Date To"></Label>

                        <div className="textBoxValidate">
                          <input
                            style={{
                              width: "215px",
                              marginLeft: "0px",
                            }}
                            className="myInput"
                            type="date"
                            min="1900-01-01"
                            max="9999-12-31"
                            name="entryDateTo"
                            id="entryDateTo"
                            value={
                              this.state.searchModel.entryDateTo == null
                                ? ""
                                : this.state.searchModel.entryDateTo
                            }
                            onChange={this.handleChange}
                            // onKeyPress={this.handleSearch}
                          ></input>
                          {this.state.validationModel.enterDateToValField}
                          {
                            this.state.validationModel
                              .entryDateToGreaterValField
                          }
                        </div>
                      </div>
                    </div>

                    <div className="row-form">
                      <div className="mf-3">
                        <label></label>
                        <div className="lblChkBox">
                          <input
                            type="checkBox"
                            id="inActive"
                            name="inActive"
                            checked={this.state.searchModel.inActive}
                            onClick={this.handleCheck}
                          />
                          <label htmlFor="inActive">
                            <span>In Active</span>
                          </label>
                        </div>
                      </div>

                      <div className="mf-3"></div>
                      <div className="mf-3"></div>
                      <div className="mf-3"></div>
                    </div>

                    <div className="row-form row-btn">
                      <div className="mf-12">
                        <Input
                          type="submit"
                          name="name"
                          id="name"
                          className="btn-blue"
                          value="Search"
                          disabled={this.isDisabled(this.props.rights.search)}
                        />

                        <Input
                          type="button"
                          name="clear"
                          id="clear"
                          value="Clear"
                          className="btn-grey"
                          onClick={(event) => this.clearFields(event)}
                        ></Input>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
              <div className="mf-12 table-grid mt-15">
                <GridHeading
                  Heading="PATIENT SEARCH RESULT"
                  disabled={this.isDisabled(this.props.rights.export)}
                  dataObj={this.state.searchModel}
                  url={this.url}
                  methodName="Export"
                  methodNamePdf="ExportPdf"
                  length={this.state.data.length}
                ></GridHeading>

                {popup}

                <div className="tableGridContainer text-nowrap">
                  <MDBDataTable
                    striped
                    bordered
                    searching={false}
                    data={tableData}
                    displayEntries={false}
                    sortable={true}
                    scrollX={false}
                    scrollY={false}
                    responsive={true}
                  />
                </div>
              </div>
              {this.props.SchedularAdvSearch ? (
                <div
                  style={{
                    textAlign: "center",
                    width: "100%",
                    margin: "10px",
                  }}
                >
                  <input
                    // className="SchedularAppointmentButtons text-white w-auto px-3 mr-2 Schedularsave"
                    type="button"
                    value="Select"
                    className="btn-blue"
                    onClick={() => this.sendRowData()}
                  ></input>
                  <input
                    // className="SchedularAppointmentButtons text-white w-auto px-3 mr-2 Schedularcancel mt-2 mt-lg-0"
                    type="button"
                    value="Cancel"
                    className="btn-grey"
                    onClick={this.props.closeAdvSrch}
                  ></input>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  try {
    return {
      patientInfo: state.selectPatient ? state.selectPatient : null,
      patientGridData: state.PatientGridDataReducer
        ? state.PatientGridDataReducer
        : [],
      selectedTab:
        state.selectedTab !== null ? state.selectedTab.selectedTab : "",
      selectedTabPage: state.selectedTabPage,
      selectedPopup: state.selectedPopup,
      id: state.selectedTab !== null ? state.selectedTab.id : 0,
      setupLeftMenu: state.leftNavigationMenus,
      loginObject: state.loginToken
        ? state.loginToken
        : { toekn: "", isLogin: false },
      userInfo: state.loginInfo
        ? state.loginInfo
        : { userPractices: [], name: "", practiceID: null },
      rights: state.loginInfo
        ? {
            search: state.loginInfo.rights.patientSearch,
            add: state.loginInfo.rights.patientCreate,
            update: state.loginInfo.rights.patientEdit,
            delete: state.loginInfo.rights.patientDelete,
            export: state.loginInfo.rights.patientExport,
            import: state.loginInfo.rights.patientImport,
          }
        : [],
    };
  } catch {}
}
function matchDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      selectTabPageAction: selectTabPageAction,
      loginAction: loginAction,
      selectTabAction: selectTabAction,
      selectPatient: selectPatient,
      setPatientGridData: setPatientGridData,
    },
    dispatch
  );
}

export default withRouter(
  connect(mapStateToProps, matchDispatchToProps)(Patient)
);
