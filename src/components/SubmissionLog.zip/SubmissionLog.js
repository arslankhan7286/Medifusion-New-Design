import React, { Component } from 'react'
import axios from 'axios';
import { MDBDataTable, MDBBtn, MDBInput } from 'mdbreact';
import GridHeading from './GridHeading';
import Label from './Label'
import Input from './Input'
import { saveAs } from 'file-saver';
import $ from 'jquery';
import Swal from 'sweetalert2'

export class SubmissionLog extends Component {
    constructor(props) {
        super(props)

        this.url = 'http://192.168.110.44/database/api/SubmissionLog'


        this.elecUrl = 'http://192.168.110.44/database/api/ElectronicSubmission'
        this.paperUrl = 'http://192.168.110.44/database/api/PaperSubmission'

        this.electModel = {

            "receiver": '',
            "submitDate": null,
            "submitType": '',
            "isaControllNumber": '',
            "submitBatchNumber": ''
        }

        this.state = {
            electModel: this.electModel,
            data: [],
            id: 0,
            revData: [],
        }
        this.searchSubmissionLog = this.searchSubmissionLog.bind(this);
        this.clearFields = this.clearFields.bind(this);
        this.downloadSubmissionLogs = this.downloadSubmissionLogs.bind(this);
    }


    handleChange = event => {
        event.preventDefault();
        this.setState({
            electModel: { ...this.state.electModel, [event.target.name]: event.target.value }
        });
    };

    clearFields = event => {
        this.setState({
            electModel: this.electModel
        });
    };

    componentWillMount() {
        axios.get(this.url + '/GetSubmissionLogs')
            .then(response => {

                console.log(response.data);
                this.setState({

                    revData: response.data.receivers,
                })
            }).catch(error => {
                console.log(error);
            });
    }

    downloadSubmissionLogs(id, submitType) {


        let myUrl = ''
        let contentType = ''
        let outputfile = ''

        if (submitType === 'EDI') {
            myUrl = this.elecUrl + '/DownloadEDIFile/'
            contentType = 'application/txt'
            outputfile = '837.txt'
        }
        else if (submitType === 'Paper') {
            myUrl = this.paperUrl + '/DownloadHCFAFile/'
            contentType = 'application/pdf'
            outputfile = 'hcfa.pdf'
        }


        axios.get(
            myUrl + id, {
            headers: {
                'Content-Type': 'application/json',
            },
            responseType: 'blob',
        })
            .then(function (res) {
                var blob = new Blob([res.data], {
                    type: contentType,
                });

                saveAs(blob, outputfile);
            }).catch(error => {
                if (error.response.status === 404) {
                    console.log(error.response.status)
                    Swal.fire(
                        {
                            type: 'info',
                            text: 'File Not Found on server',
                        })
                }
            });;

    }

    searchSubmissionLog = (e) => {

        console.log(this.state.electModel)
        axios.post(this.url + '/FindSubmissionLog', this.state.electModel)
            .then(response => {
                console.log(response.data)

                let newList = []
                response.data.map((row, i) => {
                    newList.push({

                        id: row.id,
                        submitBatchNumber: row.submitBatchNumber,
                        receiver: row.receiver,
                        formType: row.formType,
                        submitDate: row.submitDate,
                        status: row.status,
                        isaControllNumber: row.isaControllNumber,
                        submitType: row.submitType,
                        notes: row.notes,
                        download: < MDBBtn className='gridBlueBtn' onClick={() => this.downloadSubmissionLogs(row.submitBatchNumber, row.submitType)}> {"Download"}</MDBBtn >,
                    });
                });
                this.setState({
                    data: newList
                });
            }).catch(error => {
                console.log(error)
            });
        e.preventDefault();
    }

    render() {

        const subType = [

            { value: "", display: "All" },
            { value: "E", display: "EDI" },
            { value: "P", display: "Paper" }
        ]

        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc',
                    width: 0,
                },
                {
                    label: 'Submit Batch #',
                    field: 'submitBatchNumber',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Receiver',
                    field: 'receiver',
                    sort: 'asc',
                    width: 150
                },

                {
                    label: 'Form Type',
                    field: 'formType',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Submit date',
                    field: 'submitDate',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Status',
                    field: 'status',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Controll #',
                    field: 'isaControllNumber',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Submit Type',
                    field: 'submitType',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Notes',
                    field: 'notes',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Download',
                    field: 'download',
                    sort: 'asc',
                    width: 150
                }

            ],
            rows: this.state.data
        };

        return (
            < React.Fragment >
                <div className="mainHeading row">
                    <div className="col-md-6">
                        <h1>Submission Logs</h1>
                    </div>
                    <div className="col-md-6 headingRight">
                    </div>
                </div>

                <form onSubmit={event => this.searchSubmissionLog(event)}>
                    <div className="mainTable">

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Receiver'></Label>
                                <Input type='text' name='receiver' id='receiver' value={this.state.electModel.receiver} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <label>&nbsp;</label>
                            </div>
                        </div>

                        <div className="row-form">
                            <div className="mf-6">
                                <Label name='Submit Date'></Label>
                                <Input type='text' name='submitDate' id='submitDate' value={this.state.electModel.submitDate} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">


                                <Label name='Submit Type'></Label>
                                <select name="submitType" id="submitType" value={this.state.electModel.submitType} onChange={this.handleChange}>
                                    {subType.map(s => (
                                        <option key={s.value} value={s.value}>
                                            {s.display}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        <div className="row-form">

                            <div className="mf-6">
                                <Label name='Control Number'></Label>
                                <Input type='text' name='isaControllNumber' id='isaControllNumber' value={this.state.electModel.isaControllNumber} onChange={() => this.handleChange} />
                            </div>
                            <div className="mf-6">
                                <Label name='Submit Batch #'></Label>
                                <Input type='text' name='submitBatchNumber' id='submitBatchNumber'
                                    value={this.state.electModel.submitBatchNumber} onChange={() => this.handleChange} />
                            </div>


                        </div>

                        <div className="row-form row-btn">
                            <div className="mf-12">

                                <Input type='submit' name='name' id='name' className='btn-blue' value='Search' />
                                <Input type='button' name='name' id='name' className='btn-grey' value='Clear' onClick={() => this.clearFields()} />
                            </div>
                        </div>
                    </div>

                </form>


                <div className="mf-12 table-grid mt-15">

                    <GridHeading Heading='Submission Logs Results'></GridHeading>

                    <div className="tableGridContainer">
                        <MDBDataTable
                            striped
                            bordered
                            searching={false}
                            data={data}
                            displayEntries={false}
                            sortable={true}
                            scrollX={false}
                        />
                    </div>
                </div>

            </React.Fragment >
        )
    }
}

export default SubmissionLog
